"""Train/refresh the ML models and (optionally) evaluate them on synthetic ground truth.

Usage:
    python -m scripts.train_models [--evaluate] [--seed 42]
Writes artefacts to data/models/ and, with --evaluate, data/reports/ml_evaluation.json + .md.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.database.models import User  # noqa: E402
from app.database.session import init_engine, session_scope  # noqa: E402
from app.ml import model_registry  # noqa: E402
from app.services import analytics_service as an  # noqa: E402
from app.services import model_evaluation as ev  # noqa: E402
from app.utils.logging_config import configure_logging  # noqa: E402


def _md(report: dict) -> str:
    a, d, i, f = (
        report["anomaly"],
        report["duplicates"],
        report["item_matching"],
        report["forecast"],
    )
    pct = lambda x: f"{x:.1%}"  # noqa: E731
    lines = [
        "# ML evaluation (synthetic ground truth)",
        "",
        "> Numbers describe synthetic scenarios generated and detected by the same project. They show",
        "> the pipelines work as designed; they are NOT expected real-world performance.",
        "",
        f"Generated {report['generated_at']} | seed {report['seed']} | documents {report['documents']}",
        "",
        "## Forecasting (rolling-origin backtest, one month ahead)",
        "",
    ]
    if "metrics" in f:
        lines += [
            f"History: {f['history_months']} complete months; backtest months: {f['backtest_months']}; chosen: **{f['chosen']}**",
            "",
            "| model | MAE | RMSE | MAPE % |",
            "|---|---|---|---|",
        ]
        lines += [
            f"| {k} | {v['mae']:,.0f} | {v['rmse']:,.0f} | {v['mape_pct']:.1f} |"
            for k, v in f["metrics"].items()
        ]
    else:
        lines.append(f"Not evaluated: {f.get('warning')}")
    lines += [
        "",
        "## Unusual-transaction detection (fit on earliest 70 % of documents, test on the rest)",
        "",
        f"Test documents: {a['test_docs']} (injected unusual: {a['test_injected']})",
        "",
        "| method | precision | recall | F1 | flagged |",
        "|---|---|---|---|---|",
    ]
    lines += [
        f"| {k} | {pct(v['precision'])} | {pct(v['recall'])} | {pct(v['f1'])} | {v['flagged']} |"
        for k, v in a["methods"].items()
    ]
    lines += [
        "",
        "Recall by injected kind:",
        "",
        "| kind | n | rules | isolation forest | combined |",
        "|---|---|---|---|---|",
    ]
    lines += [
        f"| {k} | {v['n']} | {pct(v['rules_only'])} | {pct(v['isolation_forest_only'])} | {pct(v['rules_plus_isolation_forest'])} |"
        for k, v in a["recall_by_kind"].items()
    ]
    lines += [
        "",
        "## Duplicate detection",
        "",
        f"Labelled duplicate pairs: {d['labeled_duplicate_pairs']}; candidates found: {d['candidates_found']}",
        "",
        "| method | precision | recall | F1 |",
        "|---|---|---|---|",
        f"| evidence-scored detector | {pct(d['detector']['precision'])} | {pct(d['detector']['recall'])} | {pct(d['detector']['f1'])} |",
        f"| identical amount only (baseline) | {pct(d['amount_only_baseline']['precision'])} | {pct(d['amount_only_baseline']['recall'])} | {pct(d['amount_only_baseline']['f1'])} |",
        "",
        f"Legitimate repeats (partial payments) flagged: {d['legitimate_repeats_flagged']} of {d['legitimate_repeat_pairs']}; "
        f"same-amount-different-document flagged: {d['hard_negatives_flagged']} of {d['hard_negative_pairs']}. "
        "Precision counts every unlabelled candidate as a false positive.",
        "",
        "## Item matching (technical comparability)",
        "",
        f"Pairs: {i['positive_pairs']} equivalent, {i['negative_pairs']} not equivalent (mostly same product family).",
        "",
        "| method | precision | recall | F1 |",
        "|---|---|---|---|",
    ]
    for name, key in (
        ("attribute-first matcher", "attribute_first_matcher"),
        ("text similarity only (best threshold)", "text_similarity_only_best_threshold"),
        ("text similarity only (0.85)", "text_similarity_only_threshold_0.85"),
    ):
        m = i[key]
        lines.append(f"| {name} | {pct(m['precision'])} | {pct(m['recall'])} | {pct(m['f1'])} |")
    ch = report["challenge"]
    lines += [
        "",
        f"### Hand-written challenge set (phrasings the parser was not designed around): accuracy {pct(ch['accuracy'])}",
        "",
        "| A | B | truth | matcher level | correct |",
        "|---|---|---|---|---|",
    ]
    lines += [
        f"| {r['a']} | {r['b']} | {'equivalent' if r['truth'] else 'different'} | {r['level']} | {'yes' if r['correct'] else '**no**'} |"
        for r in ch["pairs"]
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evaluate", action="store_true")
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()
    settings = get_settings()
    configure_logging(settings.log_level)
    seed = settings.random_seed if args.seed is None else args.seed
    init_engine()
    t0 = time.perf_counter()
    with session_scope() as s:
        admin = (
            s.execute(select(User).where(User.role == "administrator", User.is_active.is_(True)))
            .scalars()
            .first()
        )
        model = an.train_anomaly_model(s, admin, seed)
        print(
            f"anomaly model {model.version}: {model.n_train_docs} documents, threshold {model.alert_threshold:.3f}"
        )
        fcast = an.spend_forecast(s, admin)
        if fcast.model is not None:
            model_registry.save_model(
                "forecast_global",
                f"ridge-{model.version[-14:]}",
                fcast.model,
                {
                    "history_months": len(fcast.history),
                    "chosen": fcast.chosen,
                    "metrics": fcast.metrics,
                    "seed": seed,
                },
            )
            print(f"forecast: chosen={fcast.chosen} over {len(fcast.history)} months")
        else:
            print("forecast: not enough history; skipped")
    print(f"training took {time.perf_counter() - t0:.1f}s")
    if args.evaluate:
        t1 = time.perf_counter()
        from datetime import UTC, datetime

        from sqlalchemy import func

        from app.database.models import PurchaseDocument

        with session_scope() as s:
            admin = s.execute(select(User).where(User.role == "administrator")).scalars().first()
            report = {
                "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
                "seed": seed,
                "documents": s.execute(select(func.count(PurchaseDocument.id))).scalar_one(),
                "forecast": ev.evaluate_forecast(s, admin),
                "anomaly": ev.evaluate_anomaly(s, seed=seed),
                "duplicates": ev.evaluate_duplicates(s),
                "item_matching": ev.evaluate_item_matching(s),
                "challenge": ev.evaluate_challenge_set(),
            }
        out = settings.model_dir.parent / "reports"
        out.mkdir(parents=True, exist_ok=True)
        (out / "ml_evaluation.json").write_text(json.dumps(report, indent=2, default=str))
        (out / "ml_evaluation.md").write_text(_md(report))
        print(f"evaluation took {time.perf_counter() - t1:.1f}s -> {out / 'ml_evaluation.md'}")
        print(_md(report))


if __name__ == "__main__":
    main()
