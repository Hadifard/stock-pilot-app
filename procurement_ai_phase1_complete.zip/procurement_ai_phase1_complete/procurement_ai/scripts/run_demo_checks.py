"""End-to-end check of the demo scenario on a throw-away database.

Usage: python -m scripts.run_demo_checks
Runs: create -> submit -> review -> correction request -> approve correction -> approve ->
export -> audit-chain verification. Prints one PASS/FAIL line per step.
"""

from __future__ import annotations

import os
import sys
import tempfile
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def main() -> int:
    tmp = tempfile.mkdtemp(prefix="procurement_demo_")
    os.environ["PROCUREMENT_DATABASE_URL"] = f"sqlite:///{tmp}/demo.db"
    os.environ["PROCUREMENT_ATTACHMENT_DIR"] = f"{tmp}/attachments"
    from sqlalchemy import select

    from app.database.models import Project, User
    from app.database.seed import generate_documents, seed_reference_data
    from app.database.session import create_all, init_engine, session_scope
    from app.security import audit_log
    from app.services import approval_service as appr
    from app.services import correction_service as corr
    from app.services import document_service as docs
    from app.services import reporting_service as rep
    from app.services.validation_service import DocumentInput, LineInput

    init_engine()
    create_all()
    failures = 0

    def check(name: str, ok: bool) -> None:
        nonlocal failures
        failures += not ok
        print(f"[{'PASS' if ok else 'FAIL'}] {name}")

    with session_scope() as s:
        seed_reference_data(s, "tiny", 42, "demo-check-only")
        generate_documents(s, 200, 42)
        u = {x.username: x for x in s.execute(select(User)).scalars()}
        emp, mgr, aud = u["employee.demo"], u["manager.demo"], u["auditor.demo"]
        project = s.execute(select(Project).where(Project.code == "PRJ-001")).scalar_one()
        from app.database.models import CostCenter, Supplier

        cc = (
            s.execute(select(CostCenter).where(CostCenter.org_unit_id == project.org_unit_id))
            .scalars()
            .first()
        )
        sup = s.execute(select(Supplier)).scalars().first()
        inp = DocumentInput(
            project_id=project.id,
            cost_center_id=cc.id,
            supplier_id=sup.id,
            doc_type="invoice",
            purchase_date=date.today() - timedelta(days=1),
            currency="EUR",
            lines=(
                LineInput(
                    "Ball valve DN50 PN16",
                    Decimal("4"),
                    Decimal("185.50"),
                    "pcs",
                    Decimal("0.05"),
                    Decimal("0.19"),
                ),
            ),
            supplier_ref="DEMO-INV-1",
            description="Demo purchase",
            shipping=Decimal("25"),
        )
        d = docs.create_draft(s, emp, inp)
        # 4 x 185.50 = 742.00; -5 % = 37.10; net 704.90; +19 % = 133.93; + 25.00 shipping = 863.83
        check("draft total matches hand calculation (863.83)", d.total == Decimal("863.83"))
        docs.submit(s, emp, d.id)
        check("submitted", d.status == "submitted")
        appr.start_review(s, mgr, d.id)
        req = corr.create_request(s, emp, d.id, {"shipping": "40.00"}, None, "Shipping was 40")
        check(
            "correction filed, original untouched",
            d.shipping == Decimal("25") and d.status == "correction_requested",
        )
        corr.decide_request(s, mgr, req.id, True, "ok")
        check(
            "correction applied and resubmitted",
            d.shipping == Decimal("40") and d.status == "resubmitted",
        )
        appr.start_review(s, mgr, d.id)
        appr.approve(s, mgr, d.id, "approved")
        check("approved", d.status == "approved")
        check("CSV export is scoped", len(rep.export_csv(s, mgr)) > 100)
        res = audit_log.verify_chain(s)
        check(f"audit chain valid ({res.checked} events)", res.ok)
        check("auditor can read all documents", rep.documents_frame(s, aud).shape[0] >= 200)
        from app.utils.exceptions import PermissionDenied

        try:
            rep.export_csv(s, emp)
            denied = False
        except PermissionDenied:
            denied = True
        check("employee export is denied by the service layer", denied)
    # ---- analytics / ML / extraction on the same throw-away database ----
    os.environ["PROCUREMENT_MODEL_DIR"] = f"{tmp}/models"
    from app.config import reset_settings_cache

    reset_settings_cache()
    from app.services import analytics_service as an
    from app.services import extraction_service as xs
    from app.services import price_service as ps

    with session_scope() as s:
        u = {x.username: x for x in s.execute(select(User)).scalars()}
        admin, fin, emp = u["admin.demo"], u["finance.demo"], u["employee.demo"]
        generate_documents(s, 600, 43)
        model = an.train_anomaly_model(s, admin)
        scan = an.run_anomaly_scan(s, fin)
        check(
            f"anomaly model trained ({model.version}); scan flagged {scan.flagged} of {scan.scanned}",
            scan.flagged > 0,
        )
        found, _ = an.run_duplicate_scan(s, fin)
        check(f"duplicate scan found {found} candidate pair(s)", found > 0)
        fc = an.spend_forecast(s, fin)
        check(
            f"forecast produced with '{fc.chosen}' over {len(fc.history)} months",
            not fc.forecast.empty,
        )
        b = ps.benchmark(s, fin, "Ball valve DN50 PN16 stainless 316", "pcs")
        check("price benchmark has statistics from comparable history", b.stats is not None)
        check(
            "unknown item gets 'No verified benchmark available'",
            ps.NO_BENCHMARK in ps.benchmark(s, fin, "Quantum flux capacitor", "pcs").message,
        )
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from tests.unit.test_extraction import INVOICE, make_pdf

        name = (
            s.execute(
                select(__import__("app.database.models", fromlist=["Supplier"]).Supplier.name)
            )
            .scalars()
            .first()
        )
        out = xs.run_extraction(s, emp, "invoice.pdf", make_pdf([name, *INVOICE[1:]]))
        check(
            f"PDF extraction ({out.method}) read the invoice number",
            out.fields["supplier_ref"].value == "INV-2026-0042",
        )
        check("audit chain still valid after analytics + extraction", audit_log.verify_chain(s).ok)
    print("ALL CHECKS PASSED" if not failures else f"{failures} CHECK(S) FAILED")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
