"""Create the database schema. Usage: python -m scripts.initialize_database [--reset]"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy.engine import make_url  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.database.session import create_all, init_engine  # noqa: E402
from app.utils.logging_config import configure_logging  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reset", action="store_true", help="delete the existing SQLite file first"
    )
    args = parser.parse_args()
    settings = get_settings()
    configure_logging(settings.log_level)
    url = make_url(settings.database_url)
    if args.reset and url.drivername.startswith("sqlite") and url.database:
        for suffix in ("", "-wal", "-shm"):
            Path(url.database + suffix).unlink(missing_ok=True)
    if url.database:
        Path(url.database).parent.mkdir(parents=True, exist_ok=True)
    init_engine()
    create_all()
    print(f"Database ready: {settings.database_url}")


if __name__ == "__main__":
    main()
