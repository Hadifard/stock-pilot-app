"""Measure database size and the time of key operations on the configured database.

Usage: python -m scripts.measure_performance   (writes data/reports/performance.md)
Numbers depend on the machine; they are reported as measured, with the hardware noted.
"""

from __future__ import annotations

import os
import platform
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def main() -> None:
    t_import = time.perf_counter()
    from sqlalchemy import func, select
    from sqlalchemy.engine import make_url

    from app.config import get_settings
    from app.database.models import LineItem, PurchaseDocument, User
    from app.database.session import init_engine, session_scope
    from app.services import analytics_service as an
    from app.services import reporting_service as rep
    from app.services.document_service import DocumentFilter, list_documents

    settings = get_settings()
    init_engine()
    startup = time.perf_counter() - t_import
    results: list[tuple[str, float, str]] = []

    def timed(label: str, fn, note: str = ""):
        t = time.perf_counter()
        out = fn()
        results.append((label, time.perf_counter() - t, note))
        return out

    with session_scope() as s:
        docs = s.execute(select(func.count(PurchaseDocument.id))).scalar_one()
        lines = s.execute(select(func.count(LineItem.id))).scalar_one()
        fin = s.execute(select(User).where(User.username == "finance.demo")).scalar_one()
        mgr = s.execute(select(User).where(User.username == "manager.demo")).scalar_one()
        admin = s.execute(select(User).where(User.username == "admin.demo")).scalar_one()
        timed("Overview KPIs (finance, all documents)", lambda: rep.compute_kpis(s, fin))
        timed("Spend by month", lambda: rep.spend_by_month(s, fin))
        timed("Top suppliers", lambda: rep.spend_by(s, fin, "supplier"))
        timed(
            "Document list page (25 rows, search)",
            lambda: list_documents(s, fin, DocumentFilter(search="SYN-42-0001"), 1, 25),
        )
        timed(
            "Document list page (25 rows, status filter)",
            lambda: list_documents(s, mgr, DocumentFilter(statuses=("approved",)), 3, 25),
        )
        timed(
            "Spend analysis, 12-month filter",
            lambda: rep.spend_lines(
                s,
                fin,
                rep.SpendFilter(
                    date_from=datetime.now(UTC).date().replace(year=datetime.now(UTC).year - 1)
                ),
            ),
            "pulls line rows into pandas",
        )
        timed("Budget utilisation", lambda: rep.budget_utilization(s, fin))
        timed("Inconsistent-total check", lambda: rep.inconsistent_totals(s, fin))
        timed("CSV export (all documents)", lambda: rep.export_csv(s, fin))
        timed("Excel export (all documents)", lambda: rep.export_excel(s, fin))
        timed("PDF export (first 1,000 rows)", lambda: rep.export_pdf(s, fin))
        timed("Forecast (all scope)", lambda: an.spend_forecast(s, fin))
        timed(
            "Train anomaly model", lambda: an.train_anomaly_model(s, admin), "fit on all documents"
        )
        timed("Anomaly scan (finance, all documents)", lambda: an.run_anomaly_scan(s, fin))
        timed("Duplicate scan (all documents)", lambda: an.run_duplicate_scan(s, fin))
        s.rollback()  # measurement must not alter the data
    url = make_url(settings.database_url)
    size_mb = Path(url.database).stat().st_size / 1e6
    out = [
        "# Performance measurements",
        "",
        f"Measured {datetime.now(UTC):%Y-%m-%d %H:%M} UTC on {platform.platform()} / Python {platform.python_version()} / {os.cpu_count()} CPU(s).",
        f"Database: {docs:,} documents, {lines:,} line items, {size_mb:.1f} MB (SQLite).",
        f"Import + engine start: {startup:.2f} s.",
        "",
        "| operation | seconds | note |",
        "|---|---|---|",
    ]
    out += [f"| {a} | {b:.2f} | {c} |" for a, b, c in results]
    text = "\n".join(out) + "\n"
    report = settings.model_dir.parent / "reports"
    report.mkdir(parents=True, exist_ok=True)
    (report / "performance.md").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
