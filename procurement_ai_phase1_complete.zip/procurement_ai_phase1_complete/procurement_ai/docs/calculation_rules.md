# Calculation rules

All arithmetic uses `decimal.Decimal`; floats are refused. Rounding = ROUND_HALF_UP to the currency
minor unit (2 decimals by default; JPY 0; KWD/BHD 3), applied per line.

```
gross    = round(quantity * unit_price)
discount = round(gross * discount_rate)
net      = gross - discount
tax      = round(net * tax_rate)
line     = net + tax
subtotal = sum(net)            discount_total = sum(discount)
tax_total = sum(tax) + round(shipping * shipping_tax_rate)
total    = subtotal + sum(tax) + shipping + shipping_tax + other_charges
```
* Quantities, prices, discounts, tax rates, shipping and charges accept at most **4 decimals**
  (storage precision), so stored values always reproduce the stored totals.
* Totals read from an uploaded file may only be *compared* with this calculation, never trusted.
* Reporting conversion: `total_reporting = round(total * fx_rate, 2)` using the latest rate whose
  `effective_date <= purchase_date`; the rate used is stored on the document. If no rate exists,
  `total_reporting` is NULL and the document is excluded from spend and counted as "missing FX".
  Different currencies are never added without conversion.
* Limitations: rates have 4 decimals, so very low-value currencies (JPY, TRY, CZK) are not
  supported for conversion yet. Synthetic rates are random walks, not market data.
* Corrections: an approved correction rewrites the document and recalculates; the old and new values
  are preserved in the correction request and the audit event. Reports always show current values.
