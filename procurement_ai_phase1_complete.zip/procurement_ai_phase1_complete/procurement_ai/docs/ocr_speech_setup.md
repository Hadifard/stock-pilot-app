# OCR and speech setup (optional components)

The application runs without them; PDF text extraction needs only `pypdf` (a pip dependency).

## Tesseract OCR (scans and photos)
| OS | Install |
|---|---|
| Windows | Install the UB Mannheim build of Tesseract, tick the English language data, and add `C:\Program Files\Tesseract-OCR` to `PATH` (open a new PowerShell and run `tesseract --version`). |
| Ubuntu/Debian | `sudo apt install tesseract-ocr tesseract-ocr-eng` (add `tesseract-ocr-deu` for German) |
| macOS | `brew install tesseract` |

Scanned PDFs are rendered with `pdftoppm` (poppler) when it is installed (Windows: poppler for Windows on `PATH`; Ubuntu: `sudo apt install poppler-utils`; macOS: `brew install poppler`). Without poppler the embedded page images of the PDF are OCR-ed instead, which works for typical scanner output.

Verified in this repository: digital PDF text, PNG OCR and a scanned (image-only) PDF are covered by automated tests that ran against Tesseract 5.3. If Tesseract is missing those tests are skipped and the UI says OCR is unavailable.

Limits: Tesseract reads printed text reasonably well on clean scans, poorly on skewed, blurry or low-contrast photos, and unreliably on handwriting. A handwritten document will often produce low confidence or wrong values; the review step and manual entry are the fallback. Extraction rules are deterministic (labels such as Invoice No, Date, Total; known suppliers; simple table rows) and understand English-style invoices best.

## Speech-to-text
Speech uses `faster-whisper` through a provider interface:
```powershell
pip install faster-whisper==1.2.1
$env:PROCUREMENT_WHISPER_MODEL = "small"     # or a path to a downloaded model folder
```
The first use of a model *name* downloads it from the internet (a few hundred MB); use a local path for offline machines. Add the variable to `.env` to make it permanent. **This path was not executed in the development environment** (no model download was possible there); it is covered by tests with a stub provider only, so treat it as untested on your hardware until you try it. Audio upload (WAV/MP3/M4A) always works; browser microphone recording (`st.audio_input`) depends on browser permissions and HTTPS/localhost. Transcription is not speaker identification and never authorises anything.
