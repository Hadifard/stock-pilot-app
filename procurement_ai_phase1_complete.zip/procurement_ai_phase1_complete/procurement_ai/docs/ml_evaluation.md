# ML evaluation (synthetic ground truth)

> Numbers describe synthetic scenarios generated and detected by the same project. They show
> the pipelines work as designed; they are NOT expected real-world performance.

Generated 2026-10-15T00:15:20+00:00 | seed 42 | documents 51250

## Forecasting (rolling-origin backtest, one month ahead)

History: 33 complete months; backtest months: 6; chosen: **naive_last**

| model | MAE | RMSE | MAPE % |
|---|---|---|---|
| naive_last | 12,162,930 | 15,683,182 | 21.3 |
| seasonal_naive | 12,000,307 | 17,251,367 | 18.9 |
| trailing_mean_3 | 16,787,682 | 18,602,912 | 32.6 |
| seasonal_ridge | 11,233,287 | 15,800,472 | 19.0 |

## Unusual-transaction detection (fit on earliest 70 % of documents, test on the rest)

Test documents: 14121 (injected unusual: 307)

| method | precision | recall | F1 | flagged |
|---|---|---|---|---|
| rules_only | 59.5% | 84.4% | 69.8% | 435 |
| isolation_forest_only | 50.2% | 33.2% | 40.0% | 203 |
| rules_plus_isolation_forest | 57.7% | 84.4% | 68.5% | 449 |

Recall by injected kind:

| kind | n | rules | isolation forest | combined |
|---|---|---|---|---|
| price_spike | 114 | 100.0% | 5.3% | 100.0% |
| quantity_spike | 100 | 52.0% | 3.0% | 52.0% |
| near_threshold | 93 | 100.0% | 100.0% | 100.0% |

## Duplicate detection

Labelled duplicate pairs: 500; candidates found: 468

| method | precision | recall | F1 |
|---|---|---|---|
| evidence-scored detector | 100.0% | 93.6% | 96.7% |
| identical amount only (baseline) | 49.4% | 93.6% | 64.7% |

Legitimate repeats (partial payments) flagged: 0 of 250; same-amount-different-document flagged: 0 of 250. Precision counts every unlabelled candidate as a false positive.

## Item matching (technical comparability)

Pairs: 226 equivalent, 226 not equivalent (mostly same product family).

| method | precision | recall | F1 |
|---|---|---|---|
| attribute-first matcher | 100.0% | 100.0% | 100.0% |
| text similarity only (best threshold) | 53.2% | 77.9% | 63.2% |
| text similarity only (0.85) | 34.7% | 15.0% | 21.0% |

### Hand-written challenge set (phrasings the parser was not designed around): accuracy 64.3%

| A | B | truth | matcher level | correct |
|---|---|---|---|---|
| Ball valve DN50 PN16 stainless 316 | Kugelhahn DN50 PN16 Edelstahl 316 | equivalent | not_comparable | **no** |
| Hex bolt M10 x 50 A2 | Hex bolt M10 x 50 A2 DIN 933 | equivalent | technically_comparable | yes |
| Ball valve DN50 PN16 stainless 316 | Ball valve 2 inch PN16 stainless 316 | equivalent | needs_review | **no** |
| Steel plate 10 mm S355J2 | S355J2 sheet 10 mm | equivalent | not_comparable | **no** |
| Control cable 5x1.5 mm2 | Control cable 5G1.5 | equivalent | needs_review | **no** |
| Hydraulic oil ISO VG 46 | Hydraulic oil HLP 46 | equivalent | needs_review | **no** |
| Ball valve DN50 PN16 stainless 316 | Ball valve DN50 PN40 stainless 316 | different | similar_description_only | yes |
| Hex bolt M10 x 50 A2 | Hex bolt M10 x 60 A2 | different | similar_description_only | yes |
| Steel plate 10 mm S355J2 | Steel plate 12 mm S355J2 | different | similar_description_only | yes |
| Torque wrench 100 Nm | Torque wrench 200 Nm | different | similar_description_only | yes |
| Safety gloves EN388 size 9 | Safety gloves EN388 size 10 | different | similar_description_only | yes |
| Ball bearing 6204-2RS | Ball bearing 6205-2RS | different | similar_description_only | yes |
| Hex bolt M10 x 50 A2 | Hex nut M10 A2 | different | not_comparable | yes |
| Hydraulic oil ISO VG 46 | Hydraulic oil ISO VG 68 | different | similar_description_only | yes |
