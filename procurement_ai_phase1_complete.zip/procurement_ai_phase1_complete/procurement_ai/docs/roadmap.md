# Roadmap

Phase 1 (Python + Streamlit) is complete as described in the README status table. Known gaps to close
before or during later phases: credit-note document type and sign-aware reporting, handwriting-capable
OCR, a verified speech model setup, real exchange-rate provider, approved external price catalogues,
authentication hardening (lockout, MFA/SSO), retention policy, load testing beyond one user, and
screenshots for the portfolio.

Phase 2 (FastAPI): `/api/v1`, Pydantic schemas, Alembic migrations, JWT/OIDC with the existing RBAC,
PostgreSQL (replace the SQLite triggers with an insert-only role; replace `strftime` in monthly
aggregations), background jobs for OCR/ML scans, upload endpoints, API integration tests. The services
in `app/services` and `app/ml` are reused unchanged; `session_scope` becomes a request dependency.

Phase 3: Flutter employee app (camera, upload, voice, statuses, corrections) and a web management
portal on the same API. Mobile permissions (camera, microphone, location) must be requested with
informed consent; location is never proof of purchase.
