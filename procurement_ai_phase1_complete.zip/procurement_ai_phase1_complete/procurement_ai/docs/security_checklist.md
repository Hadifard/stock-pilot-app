# Security and production-readiness checklist

| Item | Phase 1 status |
|---|---|
| Role-based authorisation in the service layer | Done, tested |
| Password hashing (scrypt) | Done; synthetic users have login disabled |
| Login lockout / MFA / SSO | Not done - needed for production |
| Session handling | Streamlit session state only (demo) |
| Input validation (UI + service) | Done |
| Upload whitelist, magic bytes, size limit, UUID file names, path containment | Done, tested |
| Malware scanning of uploads | Not done |
| Audit log append-only (triggers) + hash chain | Done, tested |
| External anchoring of audit hashes | Not done |
| Errors shown to users without stack traces | Done (logged server-side) |
| Secrets in `.env`, never in code | Done (`.env` is git-ignored) |
| Backups | Manual: stop the app, copy `data/procurement.db` and `data/attachments/`; restore by copying back |
| Retention / deletion policy | Not implemented; define before real data |
| HTTPS, reverse proxy, hardened deployment | Not done - required before any real use |
| Voice/location data | Not collected in this milestone |

## Threat model of the hash chain
Detects: edits or deletions of past events by someone who does not recompute the chain.
Does not prevent: an administrator who edits the database file, drops the triggers and rewrites
every later hash. Mitigation for production: export the newest hash regularly to write-once storage
or a separate system. This is not a blockchain.

This application is a local demonstration and must not be exposed to the internet.
