# Demo recording checklist
1. `python -m scripts.generate_synthetic_data --mode small --reset` then `python -m scripts.train_models`.
2. Show the synthetic-data banner on the finance overview; open Spend analysis and change filters.
3. Follow the 9-step scenario in the README; say that totals are computed by the server.
4. Show a refused permission (the employee has no "Review queue" or "Reports").
5. Upload `tests`-style PDF invoice in *Autofill*, show the conflict choice, then submit.
6. Alerts: run both scans, open an alert, read the factors, record a review. Price benchmark: search a valve, show a "similar description only" candidate and a confirmation.
7. Audit log: verify the hash chain.
8. State clearly what is limited: handwriting, speech untested without a model, ML numbers are synthetic.

## Screenshots (not captured in the build environment)
Run the app, open the page, and capture at 1440x900 with the browser's tools (Chrome: DevTools > Ctrl+Shift+P > "Capture screenshot"). Save to `docs/screenshots/<page>.png`. Suggested set: Overview, Spend analysis, Forecast, Alerts, Price benchmark, Create document with autofill, Review queue, Audit log.
