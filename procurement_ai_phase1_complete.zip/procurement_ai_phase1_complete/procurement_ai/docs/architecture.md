# Architecture (Phase 1)

```mermaid
flowchart LR
  UI[Streamlit UI<br/>app/ui] --> SVC[Services<br/>app/services]
  SVC --> SEC[Security: RBAC + audit chain<br/>app/security]
  SVC --> DB[(SQLite via SQLAlchemy<br/>app/database)]
  SVC --> ML[ML + extraction<br/>app/ml, ocr/speech services]
  ML --> REG[(Model registry<br/>data/models)]
  SCRIPTS[scripts/] --> DB
```
Rules: the UI never contains business rules; services take `(session, actor, ...)`, check
permissions themselves, run inside one transaction (`session_scope` commits or rolls back) and write
audit events in that same transaction.

```mermaid
erDiagram
  ORG_UNITS ||--o{ USERS : employs
  ORG_UNITS ||--o{ PROJECTS : owns
  ORG_UNITS ||--o{ COST_CENTERS : has
  USERS ||--o{ PURCHASE_DOCUMENTS : creates
  PROJECTS ||--o{ PURCHASE_DOCUMENTS : charged_to
  COST_CENTERS ||--o{ PURCHASE_DOCUMENTS : charged_to
  SUPPLIERS ||--o{ PURCHASE_DOCUMENTS : supplies
  PURCHASE_DOCUMENTS ||--|{ LINE_ITEMS : contains
  PURCHASE_DOCUMENTS ||--o{ ATTACHMENTS : has
  PURCHASE_DOCUMENTS ||--o{ CORRECTION_REQUESTS : receives
  USERS ||--o{ NOTIFICATIONS : receives
  EXCHANGE_RATES }o--|| PURCHASE_DOCUMENTS : "converts (by date)"
  AUDIT_EVENTS }o--o| USERS : "actor"
  PURCHASE_DOCUMENTS ||--o{ ANOMALY_ALERTS : flagged_by
  PURCHASE_DOCUMENTS ||--o{ DUPLICATE_CANDIDATES : paired_in
  PURCHASE_DOCUMENTS ||--o{ EXTRACTION_RECORDS : prefilled_from
  USERS ||--o{ ITEM_MATCH_DECISIONS : confirms
  PURCHASE_DOCUMENTS ||--o{ SYNTHETIC_LABELS : "ground truth (demo only)"
```
Money and quantities are stored as integers scaled by 10^4 (exact, SUM-able in SQL).
Timestamps are stored as UTC and shown in `PROCUREMENT_TIMEZONE`.

## State machine
draft -> submitted -> under_review -> approved | rejected;
submitted/under_review/resubmitted -> correction_requested -> resubmitted (approved) or back to the
previous state (rejected); draft/submitted -> cancelled (owner; submitted only inside the window).
Transitions are a table in `approval_service.TRANSITIONS`; `apply_transition` is the only code that
changes `status`. Transitions marked `system` are reachable only from `correction_service`.

## Correction policy
Window = `PROCUREMENT_CORRECTION_WINDOW_HOURS` (default 4) after `submitted_at`, compared with
timezone-aware UTC values. Inside the window only the owner can file; a manager/admin (never the
requester) decides. After the window, or for an approved document, only roles with
`correction.override_deadline` can file, with a mandatory justification; this is stored on the
request and written as `correction.deadline_exception`. Approval re-checks that the document did
not change since the request, re-validates, recalculates and applies the change atomically, then
moves the document to `resubmitted` so it must be approved again.

## Reuse in Phase 2 / 3
Reusable as-is: `app/services`, `app/security`, `app/database/models.py`, `app/utils`, tests.
To rewrite: `app/ui` (Streamlit), `session_scope` usage per request (becomes a FastAPI dependency),
demo authentication (becomes JWT/OIDC), SQLite triggers (become PostgreSQL rules or an
insert-only role), file storage (object storage). Add Alembic migrations in Phase 2.
