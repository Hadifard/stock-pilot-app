# Performance measurements

Measured 2026-10-14 19:14 UTC on Linux-6.18.44-fc-v114-x86_64-with-glibc2.39 / Python 3.12.3 / 1 CPU(s).
Database: 51,250 documents, 166,228 line items, 53.3 MB (SQLite).
Import + engine start: 2.39 s.

| operation | seconds | note |
|---|---|---|
| Overview KPIs (finance, all documents) | 0.44 |  |
| Spend by month | 0.07 |  |
| Top suppliers | 0.11 |  |
| Document list page (25 rows, search) | 0.07 |  |
| Document list page (25 rows, status filter) | 0.06 |  |
| Spend analysis, 12-month filter | 1.34 | pulls line rows into pandas |
| Budget utilisation | 0.06 |  |
| Inconsistent-total check | 0.34 |  |
| CSV export (all documents) | 0.84 |  |
| Excel export (all documents) | 13.59 |  |
| PDF export (first 1,000 rows) | 1.08 |  |
| Forecast (all scope) | 0.12 |  |
| Train anomaly model | 6.42 | fit on all documents |
| Anomaly scan (finance, all documents) | 14.48 |  |
| Duplicate scan (all documents) | 6.05 |  |
