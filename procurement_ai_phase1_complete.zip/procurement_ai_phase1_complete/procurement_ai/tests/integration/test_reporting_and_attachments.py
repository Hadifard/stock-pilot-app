import io

import pandas as pd
import pytest

from app.database.seed import generate_documents
from app.services import approval_service as appr
from app.services import attachment_service as att
from app.services import document_service as docs
from app.services import reporting_service as rep
from app.utils.exceptions import PermissionDenied, UploadRejected
from tests.conftest import get_user, make_input

PDF = b"%PDF-1.4\n%fake but valid magic bytes\n"


def test_kpis_exclude_drafts_and_respect_scope(session):
    emp, mgr = get_user(session, "employee.demo"), get_user(session, "manager.demo")
    other_mgr = get_user(session, "finance.demo")
    d1 = docs.create_draft(session, emp, make_input(session))
    d2 = docs.create_draft(session, emp, make_input(session))
    docs.submit(session, emp, d2.id)
    k = rep.compute_kpis(session, mgr)
    assert k.documents_counted == 1 and k.pending_approvals == 1
    assert k.submitted_total_reporting == d2.total_reporting
    assert rep.compute_kpis(session, other_mgr).documents_counted == 1
    with pytest.raises(PermissionDenied):
        rep.compute_kpis(session, emp)  # employees have no analytics permission
    assert d1.status == "draft"


def test_kpis_avg_approval_time(session):
    emp, mgr = get_user(session, "employee.demo"), get_user(session, "manager.demo")
    d = docs.create_draft(session, emp, make_input(session))
    docs.submit(session, emp, d.id)
    appr.start_review(session, mgr, d.id)
    appr.approve(session, mgr, d.id)
    assert rep.compute_kpis(session, mgr).avg_approval_hours is not None


def test_export_csv_excel_scope_and_metadata(session):
    created = generate_documents(session, 60, seed=3)
    mgr, fin = get_user(session, "manager.demo"), get_user(session, "finance.demo")
    mgr_df = pd.read_csv(io.BytesIO(rep.export_csv(session, mgr)), comment="#")
    fin_df = pd.read_csv(io.BytesIO(rep.export_csv(session, fin)), comment="#")
    assert 0 < len(mgr_df) < len(fin_df) == created
    raw = rep.export_csv(session, mgr).decode()
    assert "Reporting currency" in raw and "synthetic" in raw.lower()
    xl = pd.read_excel(io.BytesIO(rep.export_excel(session, mgr)), sheet_name=None)
    assert set(xl) == {"Report info", "Documents"} and len(xl["Documents"]) == len(mgr_df)
    with pytest.raises(PermissionDenied):
        rep.export_csv(session, get_user(session, "employee.demo"))


def test_no_cross_currency_sum_uses_stored_conversion(session):
    generate_documents(session, 80, seed=5)
    fin = get_user(session, "finance.demo")
    assert rep.compute_kpis(session, fin).missing_fx_count == 0
    assert not rep.spend_by_month(session, fin).empty


def test_attachment_store_read_and_access_control(session):
    emp, other = get_user(session, "employee.demo"), get_user(session, "employee2.demo")
    d = docs.create_draft(session, emp, make_input(session))
    a = att.store_attachment(session, emp, d.id, "../../evil name.pdf", PDF)
    assert a.original_name == "evil name.pdf" and a.stored_name != a.original_name
    meta, data = att.read_attachment(session, emp, a.id)
    assert data == PDF and meta.sha256 == a.sha256
    with pytest.raises(PermissionDenied):
        att.read_attachment(session, other, a.id)
    with pytest.raises(UploadRejected):
        att.store_attachment(session, emp, d.id, "x.pdf", b"nope")


def test_attachment_not_allowed_after_submit(session):
    emp = get_user(session, "employee.demo")
    d = docs.create_draft(session, emp, make_input(session))
    docs.submit(session, emp, d.id)
    with pytest.raises(PermissionDenied):
        att.store_attachment(session, emp, d.id, "x.pdf", PDF)


def test_spend_filters_budget_pdf_and_consistency(session):
    from datetime import date

    from sqlalchemy import update

    from app.database.models import PurchaseDocument

    generate_documents(session, 150, seed=9)
    fin, mgr = get_user(session, "finance.demo"), get_user(session, "manager.demo")
    everything = rep.spend_lines(session, fin, rep.SpendFilter())
    assert not everything.empty and (everything["net_reporting"] > 0).all()
    cat = everything["category"].iloc[0]
    only_cat = rep.spend_lines(session, fin, rep.SpendFilter(category=cat))
    assert set(only_cat["category"]) == {cat} and len(only_cat) < len(everything)
    window = rep.spend_lines(
        session, fin, rep.SpendFilter(date_from=date(2025, 1, 1), date_to=date(2025, 6, 30))
    )
    assert window["purchase_date"].between(date(2025, 1, 1), date(2025, 6, 30)).all()
    assert len(rep.spend_lines(session, mgr, rep.SpendFilter())) < len(
        everything
    )  # scope respected
    assert not rep.budget_utilization(session, fin).empty
    pdf = rep.export_pdf(session, mgr)
    assert pdf.startswith(b"%PDF") and len(pdf) > 1500
    assert rep.inconsistent_totals(session, fin).empty
    session.execute(
        update(PurchaseDocument)
        .where(PurchaseDocument.id == 1)
        .values(total=PurchaseDocument.total + 5)
    )
    session.flush()
    assert list(rep.inconsistent_totals(session, fin)["document"]) == [
        session.get(PurchaseDocument, 1).doc_number
    ]
    with pytest.raises(PermissionDenied):
        rep.export_pdf(session, get_user(session, "employee.demo"))
