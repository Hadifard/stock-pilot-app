from datetime import timedelta

import pytest

from app.services import approval_service as appr
from app.services import document_service as docs
from app.services.document_service import DocumentFilter
from app.utils.exceptions import InvalidTransition, PermissionDenied, ValidationError
from tests.conftest import get_user, make_input


def _submitted(s):
    emp = get_user(s, "employee.demo")
    d = docs.create_draft(s, emp, make_input(s))
    docs.submit(s, emp, d.id)
    return d.id


def test_create_calculates_totals_server_side(session):
    emp = get_user(session, "employee.demo")
    d = docs.create_draft(session, emp, make_input(session))
    assert d.status == "draft" and d.doc_number.startswith("PD-")
    # 2 x 100 = 200, -10 % = 180, +19 % = 34.20, + shipping 10 = 224.20
    assert str(d.total) == "224.2000" or d.total == d.subtotal + d.tax_total + d.shipping
    assert d.total_reporting == d.total  # EUR -> EUR rate 1
    assert len(d.lines) == 1


def test_full_happy_path(session):
    mgr, emp = get_user(session, "manager.demo"), get_user(session, "employee.demo")
    doc_id = _submitted(session)
    appr.start_review(session, mgr, doc_id)
    appr.approve(session, mgr, doc_id, "ok")
    d = docs.get_document(session, emp, doc_id)
    assert d.status == "approved" and d.decided_by == mgr.id


def test_cannot_skip_review_or_bypass_state_machine(session):
    mgr = get_user(session, "manager.demo")
    doc_id = _submitted(session)
    with pytest.raises(InvalidTransition):
        appr.approve(session, mgr, doc_id)  # must be under_review first
    with pytest.raises(InvalidTransition):
        appr.apply_transition(
            session, mgr, docs.get_document(session, mgr, doc_id), "approved", "reviewer"
        )


def test_employee_cannot_approve_or_review(session):
    emp = get_user(session, "employee.demo")
    doc_id = _submitted(session)
    with pytest.raises(PermissionDenied):
        appr.start_review(session, emp, doc_id)


def test_manager_of_other_unit_has_no_access(session):
    other = get_user(session, "employee2.demo")
    doc_id = _submitted(session)
    with pytest.raises(PermissionDenied):
        docs.get_document(session, other, doc_id)


def test_reject_requires_reason_and_state(session):
    mgr = get_user(session, "manager.demo")
    doc_id = _submitted(session)
    appr.start_review(session, mgr, doc_id)
    with pytest.raises(ValidationError):
        appr.reject(session, mgr, doc_id, "  ")
    assert appr.reject(session, mgr, doc_id, "Wrong cost center").status == "rejected"
    with pytest.raises(InvalidTransition):
        appr.approve(session, mgr, doc_id)


def test_project_manager_scope_and_admin(session):
    pm, admin = get_user(session, "pm.demo"), get_user(session, "admin.demo")
    doc_id = _submitted(session)  # project PRJ-001 is managed by pm.demo
    assert appr.start_review(session, pm, doc_id).status == "under_review"
    assert appr.approve(session, admin, doc_id).status == "approved"


def test_nobody_decides_their_own_document(session):
    admin = get_user(session, "admin.demo")
    d = docs.create_draft(session, admin, make_input(session))
    docs.submit(session, admin, d.id)
    with pytest.raises(PermissionDenied):
        appr.start_review(session, admin, d.id)


def test_submit_only_owner_and_cancel_rules(session):
    emp, other = get_user(session, "employee.demo"), get_user(session, "employee2.demo")
    d = docs.create_draft(session, emp, make_input(session))
    with pytest.raises(PermissionDenied):
        docs.submit(session, other, d.id)
    appr.cancel(session, emp, d.id)
    assert d.status == "cancelled"


def test_cancel_after_window_is_refused(session):
    emp = get_user(session, "employee.demo")
    doc_id = _submitted(session)
    d = docs.get_document(session, emp, doc_id)
    d.submitted_at = d.submitted_at - timedelta(hours=5)
    session.flush()
    with pytest.raises(InvalidTransition):
        appr.cancel(session, emp, doc_id)


def test_update_draft_only_while_draft(session):
    emp = get_user(session, "employee.demo")
    doc_id = _submitted(session)
    with pytest.raises(PermissionDenied):
        docs.update_draft(session, emp, doc_id, make_input(session, description="changed"))


def test_listing_is_scoped_and_paginated(session):
    emp, other, auditor = (
        get_user(session, n) for n in ("employee.demo", "employee2.demo", "auditor.demo")
    )
    for _ in range(3):
        docs.create_draft(session, emp, make_input(session))
    rows, total = docs.list_documents(session, emp, DocumentFilter(only_own=True), 1, 2)
    assert total == 3 and len(rows) == 2
    assert docs.list_documents(session, other)[1] == 0
    assert docs.list_documents(session, auditor)[1] == 3


def test_invalid_input_rejected_and_nothing_saved(session):
    from decimal import Decimal

    from app.services.validation_service import LineInput

    emp = get_user(session, "employee.demo")
    bad = make_input(session, lines=(LineInput("x", Decimal("-1"), Decimal("1")),))
    with pytest.raises(ValidationError):
        docs.create_draft(session, emp, bad)
    assert docs.list_documents(session, emp)[1] == 0


def test_exact_duplicate_hint_recorded(session):
    emp = get_user(session, "employee.demo")
    a = docs.create_draft(session, emp, make_input(session))
    docs.submit(session, emp, a.id)
    b = docs.create_draft(session, emp, make_input(session))
    assert docs.find_exact_duplicates(session, b) == [a.id]


def test_stored_values_roundtrip_through_new_session(db):
    """Totals recalculated from stored values equal the stored totals (no hidden rounding)."""
    from app.database.session import session_scope
    from app.services.validation_service import calculate

    with session_scope() as s:
        emp = get_user(s, "employee.demo")
        doc_id = docs.create_draft(s, emp, make_input(s)).id
    with session_scope() as s:
        emp = get_user(s, "employee.demo")
        d = docs.get_document(s, emp, doc_id)
        assert calculate(docs.document_to_input(d)).total == d.total
        docs.submit(s, emp, doc_id)
