import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from app.database.models import AuditEvent, PurchaseDocument
from app.database.session import session_scope
from app.security import audit_log
from app.security.authentication import authenticate
from app.services import document_service as docs
from app.utils.exceptions import AuthenticationError
from tests.conftest import PASSWORD, get_user, make_input


def test_chain_valid_and_events_created(session):
    emp = get_user(session, "employee.demo")
    d = docs.create_draft(session, emp, make_input(session))
    docs.submit(session, emp, d.id)
    result = audit_log.verify_chain(session)
    assert result.ok and result.checked >= 3


def test_update_and_delete_are_blocked_by_triggers(db):
    with session_scope() as s:
        audit_log.record(s, actor_id=None, action="t", entity_type="x", entity_id=1)
    with pytest.raises(DBAPIError), session_scope() as s:
        s.execute(text("UPDATE audit_events SET action='tampered'"))
    with pytest.raises(DBAPIError), session_scope() as s:
        s.execute(text("DELETE FROM audit_events"))


def test_tampering_is_detected_when_triggers_are_bypassed(db):
    with session_scope() as s:
        for i in range(4):
            audit_log.record(s, actor_id=1, action=f"a{i}", entity_type="x", entity_id=i)
    with session_scope() as s:  # a privileged attacker drops the trigger and edits a row
        s.execute(text("DROP TRIGGER audit_no_update"))
        s.execute(text("UPDATE audit_events SET payload_json='tampered' WHERE action='a2'"))
    with session_scope() as s:
        res = audit_log.verify_chain(s)
        assert not res.ok and s.get(AuditEvent, res.first_bad_id).action == "a2"


def test_deleted_middle_event_breaks_chain(db):
    with session_scope() as s:
        for i in range(4):
            audit_log.record(s, actor_id=1, action=f"a{i}", entity_type="x", entity_id=i)
    with session_scope() as s:
        s.execute(text("DROP TRIGGER audit_no_delete"))
        s.execute(text("DELETE FROM audit_events WHERE action='a1'"))
    with session_scope() as s:
        assert not audit_log.verify_chain(s).ok


def test_transaction_rollback_discards_document_and_audit_event(db):
    with session_scope() as s:
        before = s.query(AuditEvent).count()
    with pytest.raises(RuntimeError), session_scope() as s:
        emp = get_user(s, "employee.demo")
        docs.create_draft(s, emp, make_input(s))
        raise RuntimeError("boom after creating the document")
    with session_scope() as s:
        assert s.query(PurchaseDocument).count() == 0
        assert s.query(AuditEvent).count() == before


def test_authentication(db):
    with session_scope() as s:
        assert authenticate(s, "Employee.Demo", PASSWORD).username == "employee.demo"
    with pytest.raises(AuthenticationError), session_scope() as s:
        authenticate(s, "employee.demo", "wrong")
    with pytest.raises(AuthenticationError), session_scope() as s:
        authenticate(s, "synthetic.employee000", PASSWORD)  # login disabled for synthetic users
    with session_scope() as s:  # failed attempts were audited and chain is still valid
        assert audit_log.verify_chain(s).ok
        assert s.query(AuditEvent).filter(AuditEvent.action == "auth.login_failed").count() == 2
