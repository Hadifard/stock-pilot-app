from datetime import timedelta
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.database.models import AuditEvent
from app.services import approval_service as appr
from app.services import correction_service as corr
from app.services import document_service as docs
from app.utils.exceptions import CorrectionWindowExpired, PermissionDenied, ValidationError
from tests.conftest import get_user, make_input


def _submitted(s):
    emp = get_user(s, "employee.demo")
    d = docs.create_draft(s, emp, make_input(s))
    docs.submit(s, emp, d.id)
    return emp, d


def test_request_inside_window_does_not_overwrite_original(session):
    emp, d = _submitted(session)
    old_total = d.total
    req = corr.create_request(session, emp, d.id, {"shipping": "50.00"}, None, "Wrong shipping")
    assert d.status == "correction_requested" and d.total == old_total
    assert req.status == "pending" and "50.00" in req.proposed_json


def test_approval_applies_change_and_recalculates(session):
    emp, d = _submitted(session)
    mgr = get_user(session, "manager.demo")
    req = corr.create_request(session, emp, d.id, {"shipping": "50.00"}, None, "Wrong shipping")
    corr.decide_request(session, mgr, req.id, True, "ok")
    assert d.status == "resubmitted" and d.shipping == Decimal("50")
    assert d.total == d.subtotal + d.tax_total + d.shipping
    ev = session.execute(
        select(AuditEvent).where(AuditEvent.action == "correction.approved")
    ).scalar_one()
    assert "old" in ev.payload_json and "new" in ev.payload_json and ev.actor_id == mgr.id


def test_rejection_restores_previous_status(session):
    emp, d = _submitted(session)
    mgr = get_user(session, "manager.demo")
    appr.start_review(session, mgr, d.id)
    req = corr.create_request(session, emp, d.id, {"description": "New text"}, None, "typo")
    with pytest.raises(ValidationError):
        corr.decide_request(session, mgr, req.id, False, " ")
    corr.decide_request(session, mgr, req.id, False, "Not needed")
    assert d.status == "under_review" and d.description != "New text"


def test_line_replacement(session):
    emp, d = _submitted(session)
    mgr = get_user(session, "manager.demo")
    lines = [
        {
            "description": "Ball valve DN50",
            "quantity": "3",
            "unit_price": "100.00",
            "unit": "pcs",
            "discount_rate": "0.10",
            "tax_rate": "0.19",
        }
    ]
    req = corr.create_request(session, emp, d.id, {}, lines, "Quantity was 3")
    corr.decide_request(session, mgr, req.id, True)
    assert d.lines[0].quantity == Decimal("3") and d.subtotal == Decimal("270.00")


def test_expired_window_blocks_employee(session):
    emp, d = _submitted(session)
    d.submitted_at -= timedelta(hours=4, minutes=1)
    session.flush()
    with pytest.raises(CorrectionWindowExpired):
        corr.create_request(session, emp, d.id, {"shipping": "1"}, None, "late")


def test_window_boundary_just_inside(session):
    emp, d = _submitted(session)
    d.submitted_at -= timedelta(hours=3, minutes=59)
    session.flush()
    assert (
        corr.create_request(session, emp, d.id, {"shipping": "1"}, None, "ok").status == "pending"
    )


def test_manager_exception_after_deadline_is_audited_and_needs_reason(session):
    emp, d = _submitted(session)
    mgr = get_user(session, "manager.demo")
    d.submitted_at -= timedelta(hours=10)
    session.flush()
    with pytest.raises(ValidationError):
        corr.create_request(session, mgr, d.id, {"shipping": "1"}, None, "late fix")
    req = corr.create_request(
        session,
        mgr,
        d.id,
        {"shipping": "1"},
        None,
        "late fix",
        override_reason="Supplier credit note received",
    )
    assert req.deadline_exception
    assert session.execute(
        select(AuditEvent).where(AuditEvent.action == "correction.deadline_exception")
    ).scalar_one()
    # requester cannot decide their own request
    with pytest.raises(PermissionDenied):
        corr.decide_request(session, mgr, req.id, True)
    corr.decide_request(session, get_user(session, "admin.demo"), req.id, True)
    assert d.status == "resubmitted"


def test_only_one_pending_and_no_noop_and_owner_only(session):
    emp, d = _submitted(session)
    other = get_user(session, "employee2.demo")
    with pytest.raises(PermissionDenied):
        corr.create_request(session, other, d.id, {"shipping": "1"}, None, "x")
    with pytest.raises(ValidationError):
        corr.create_request(session, emp, d.id, {"shipping": "10.00"}, None, "same value")
    corr.create_request(session, emp, d.id, {"shipping": "20"}, None, "first")
    with pytest.raises(ValidationError):
        corr.create_request(session, emp, d.id, {"shipping": "30"}, None, "second")


def test_invalid_or_forbidden_proposals_rejected(session):
    emp, d = _submitted(session)
    with pytest.raises(ValidationError):
        corr.create_request(session, emp, d.id, {"shipping": "-5"}, None, "bad")
    with pytest.raises(ValidationError):
        corr.create_request(session, emp, d.id, {"status": "approved"}, None, "sneaky")
    with pytest.raises(ValidationError):
        corr.create_request(session, emp, d.id, {"shipping": "5"}, None, " ")


def test_employee_cannot_decide(session):
    emp, d = _submitted(session)
    req = corr.create_request(session, emp, d.id, {"shipping": "20"}, None, "fix")
    with pytest.raises(PermissionDenied):
        corr.decide_request(session, emp, req.id, True)
