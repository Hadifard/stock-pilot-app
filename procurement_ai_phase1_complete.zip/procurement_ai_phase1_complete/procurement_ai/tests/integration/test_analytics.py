import pytest
from sqlalchemy import select

from app.database.models import AnomalyAlert, AuditEvent
from app.database.seed import generate_documents
from app.database.session import session_scope
from app.ml import model_registry
from app.security import audit_log
from app.services import analytics_service as an
from app.services import model_evaluation as ev
from app.services import price_service as ps
from app.utils.exceptions import PermissionDenied, ValidationError
from tests.conftest import get_user


@pytest.fixture
def populated(db):
    with session_scope() as s:
        generate_documents(s, 700, seed=11)
    with session_scope() as s:
        yield s


def test_training_requires_admin_and_enough_data(db):
    with session_scope() as s:
        admin, mgr = get_user(s, "admin.demo"), get_user(s, "manager.demo")
        with pytest.raises(PermissionDenied):
            an.train_anomaly_model(s, mgr)
        with pytest.raises(ValidationError):
            an.train_anomaly_model(s, admin)  # no documents yet


def test_train_scan_review_flow(populated):
    s = populated
    admin, fin, mgr, emp = (
        get_user(s, n) for n in ("admin.demo", "finance.demo", "manager.demo", "employee.demo")
    )
    with pytest.raises(ValidationError):
        an.run_anomaly_scan(s, fin)  # model not trained yet
    model = an.train_anomaly_model(s, admin)
    assert model_registry.latest_version(an.ANOMALY_MODEL) == model.version
    res = an.run_anomaly_scan(s, fin)
    assert res.scanned > 600 and res.flagged > 0 and res.new_alerts == res.flagged
    assert an.run_anomaly_scan(s, fin).new_alerts == 0  # idempotent per model version
    alerts = an.list_alerts(s, fin)
    assert alerts and alerts[0][0].score >= alerts[-1][0].score
    with pytest.raises(PermissionDenied):
        an.list_alerts(s, emp)
    alert = alerts[0][0]
    with pytest.raises(ValidationError):
        an.review_alert(s, fin, alert.id, "needs_follow_up", " ")
    an.review_alert(s, fin, alert.id, "needs_follow_up", "Asked requester for the PO")
    assert alert.status == "reviewed" and alert.reviewed_by == fin.id
    assert (
        s.execute(select(AuditEvent).where(AuditEvent.action == "anomaly.reviewed"))
        .scalars()
        .first()
    )
    assert audit_log.verify_chain(s).ok
    # a manager only sees alerts for documents in their organisational unit
    unit_alerts = an.list_alerts(s, mgr, status=None)
    all_alerts = an.list_alerts(s, fin, status=None)
    assert len(unit_alerts) < len(all_alerts)
    assert s.query(AnomalyAlert).count() == len(all_alerts)


def test_duplicate_scan_and_review(populated):
    s = populated
    fin, auditor = get_user(s, "finance.demo"), get_user(s, "auditor.demo")
    found, new = an.run_duplicate_scan(s, fin)
    assert found > 0 and new == found
    cands = an.list_duplicates(s, fin)
    assert cands and all(c.score >= 0.6 for c in cands)
    with pytest.raises(PermissionDenied):
        an.run_duplicate_scan(s, auditor)  # auditors are read-only
    assert an.list_duplicates(s, auditor)  # but may read
    an.review_duplicate(s, fin, cands[0].id, "confirmed_duplicate", "Same PO number")
    assert cands[0].status == "reviewed"


def test_forecast_scopes_and_permissions(populated):
    s = populated
    fin, mgr, emp = (
        get_user(s, "finance.demo"),
        get_user(s, "manager.demo"),
        get_user(s, "employee.demo"),
    )
    res = an.spend_forecast(s, fin)
    assert res.chosen in ("seasonal_ridge", "naive_last", "seasonal_naive", "trailing_mean_3")
    assert len(res.forecast) == 6 and not res.forecast.empty
    unit = an.spend_forecast(s, mgr)
    assert unit.history.sum() < res.history.sum()
    with pytest.raises(PermissionDenied):
        an.spend_forecast(s, emp)


def test_price_benchmark_comparables_and_no_benchmark_message(populated):
    s = populated
    fin = get_user(s, "finance.demo")
    b = ps.benchmark(s, fin, "Ball valve DN50 PN16 stainless 316", "pcs")
    assert b.stats is not None and b.n_samples >= ps.MIN_SAMPLES
    assert b.stats["p25"] <= b.stats["median"] <= b.stats["p75"]
    assert "synthetic" in b.message.lower()
    # an unknown product never gets an invented price
    none = ps.benchmark(s, fin, "Quantum flux capacitor 9000", "pcs")
    assert none.stats is None and ps.NO_BENCHMARK in none.message
    # similar text but different DN is listed as a candidate, not used in the statistics
    levels = {c[0]: c[1].level for c in b.comparables}
    assert any(lv == "similar_description_only" for lv in levels.values())
    assert all(
        lv != "similar_description_only"
        for d, lv in levels.items()
        if d in set(b.purchases.get("description", []))
    )


def test_human_confirmation_changes_benchmark_inclusion(populated):
    s = populated
    fin = get_user(s, "finance.demo")
    base = ps.benchmark(s, fin, "Ball valve DN50 PN16 stainless 316", "pcs")
    other = next(c for c in base.comparables if c[1].level == "similar_description_only")[0]
    ps.confirm_match(s, fin, "Ball valve DN50 PN16 stainless 316", other, equivalent=True)
    after = ps.benchmark(s, fin, "Ball valve DN50 PN16 stainless 316", "pcs")
    assert after.n_samples > base.n_samples


def test_evaluation_functions_run_and_report_sane_numbers(populated):
    s = populated
    dup = ev.evaluate_duplicates(s)
    assert (
        dup["detector"]["recall"] >= 0.8
        and dup["legitimate_repeats_flagged"] == 0
        and dup["hard_negatives_flagged"] == 0
    )
    assert dup["detector"]["precision"] > dup["amount_only_baseline"]["precision"]
    im = ev.evaluate_item_matching(s)
    assert im["attribute_first_matcher"]["f1"] > im["text_similarity_only_best_threshold"]["f1"]
    assert 0 < ev.evaluate_challenge_set()["accuracy"] < 1  # honest: not perfect
    an_res = ev.evaluate_anomaly(s)
    assert an_res["test_injected"] >= 0 and "rules_only" in an_res["methods"]
