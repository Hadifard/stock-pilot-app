import io

import pytest
from sqlalchemy import select

from app.database.models import AuditEvent, ExtractionRecord, Supplier
from app.security import audit_log
from app.services import extraction_service as xs
from app.services import speech_service as sp
from app.utils.exceptions import PermissionDenied
from tests.conftest import get_user
from tests.unit.test_extraction import INVOICE, make_pdf


def _invoice_pdf(supplier_name: str) -> bytes:
    return make_pdf([supplier_name, *INVOICE[1:]])


def test_pdf_extraction_is_recorded_audited_and_mapped_to_form_values(session):
    emp = get_user(session, "employee.demo")
    name = session.execute(select(Supplier.name)).scalars().first()
    out = xs.run_extraction(session, emp, "inv.pdf", _invoice_pdf(name))
    assert out.status in ("ok", "partial") and out.fields["supplier_ref"].value == "INV-2026-0042"
    rec = session.get(ExtractionRecord, out.record_id)
    assert rec.method == "pdf_text" and "INV-2026-0042" in rec.raw_text and len(rec.sha256) == 64
    vals = xs.form_values(out)
    assert vals["supplier_ref"] == "INV-2026-0042" and len(vals["lines"]) == 2
    assert session.execute(
        select(AuditEvent).where(AuditEvent.action == "extraction.run")
    ).scalar_one()
    assert audit_log.verify_chain(session).ok


def test_unreadable_pdf_is_recorded_as_failed_not_raised(session):
    emp = get_user(session, "employee.demo")
    out = xs.run_extraction(session, emp, "bad.pdf", b"%PDF-1.4 this is not a real pdf")
    assert out.status == "failed" and out.warnings
    assert session.get(ExtractionRecord, out.record_id).status == "failed"


def test_audio_without_provider_fails_gracefully_and_with_provider_is_parsed(session):
    emp = get_user(session, "employee.demo")
    wav = b"RIFF" + b"\x00\x00\x00\x00" + b"WAVE" + b"\x00" * 32
    sp.set_speech_provider(None)
    out = xs.run_extraction(session, emp, "note.wav", wav)
    assert out.status == "failed" and "speech-to-text" in " ".join(out.warnings)

    class Stub(sp.SpeechProvider):
        name = "stub"

        def available(self):
            return True

        def transcribe(self, audio, filename):
            return sp.Transcript("Invoice number AB-7788 total 250 euros", "en", "stub")

    sp.set_speech_provider(Stub())
    try:
        ok = xs.run_extraction(session, emp, "note.wav", wav)
        assert ok.method == "stub" and ok.fields["supplier_ref"].value == "AB-7788"
        assert any("does not identify the speaker" in w for w in ok.warnings)
    finally:
        sp._provider = None


def test_resolutions_only_by_owner_and_problem_list_scope(session):
    emp, other, mgr = (
        get_user(session, "employee.demo"),
        get_user(session, "employee2.demo"),
        get_user(session, "manager.demo"),
    )
    out = xs.run_extraction(session, emp, "bad.pdf", b"%PDF-1.4 nope")
    with pytest.raises(PermissionDenied):
        xs.record_resolutions(
            session, other, out.record_id, {"supplier_ref": {"chosen_source": "manual"}}
        )
    xs.record_resolutions(
        session, emp, out.record_id, {"supplier_ref": {"chosen_source": "manual", "conflict": True}}
    )
    assert "manual" in session.get(ExtractionRecord, out.record_id).resolutions_json
    assert [r.id for r in xs.list_problem_extractions(session, emp)] == [out.record_id]
    assert xs.list_problem_extractions(session, other) == []
    assert [r.id for r in xs.list_problem_extractions(session, mgr)] == [out.record_id]  # same unit


def test_employee_role_required(session):
    with pytest.raises(PermissionDenied):
        xs.run_extraction(
            session, get_user(session, "auditor.demo"), "a.pdf", io.BytesIO(b"%PDF-1.4").getvalue()
        )
