"""UI smoke tests using Streamlit's AppTest (renders pages, checks role-based navigation)."""

from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from app.database.seed import generate_documents
from app.database.session import session_scope
from tests.conftest import PASSWORD

APP = str(Path(__file__).resolve().parents[2] / "app" / "main.py")


@pytest.fixture
def populated(db):
    with session_scope() as s:
        generate_documents(s, 60, seed=2)


def login(username: str, password: str = PASSWORD) -> AppTest:
    at = AppTest.from_file(APP, default_timeout=60).run()
    at.text_input[0].input(username)
    at.text_input[1].input(password)
    at.button[0].click().run()
    return at


def test_login_page_and_wrong_password(populated):
    at = AppTest.from_file(APP, default_timeout=60).run()
    assert not at.exception and at.title[0].value == "Sign in"
    at = login("manager.demo", "wrong")
    assert at.error and at.title[0].value == "Sign in"


@pytest.mark.parametrize(
    "user,expected,forbidden",
    [
        (
            "employee.demo",
            {"My documents", "Create document", "Corrections"},
            {"Review queue", "Reports", "Audit log"},
        ),
        (
            "manager.demo",
            {"Review queue", "Reports", "Corrections"},
            {"Create document", "Audit log"},
        ),
        (
            "finance.demo",
            {"Documents", "Reports"},
            {"Review queue", "Create document", "Audit log"},
        ),
        (
            "auditor.demo",
            {"Documents", "Audit log", "Reports"},
            {"Review queue", "Create document"},
        ),
        ("admin.demo", {"Review queue", "Audit log", "Reports", "Create document"}, set()),
    ],
)
def test_navigation_matches_role_and_all_pages_render(populated, user, expected, forbidden):
    at = login(user)
    assert not at.exception
    options = set(at.sidebar.radio[0].options)
    assert expected <= options and not (forbidden & options)
    for page in at.sidebar.radio[0].options:
        at.sidebar.radio[0].set_value(page).run()
        assert not at.exception, f"{user} / {page}: {at.exception}"
