"""Drive the real Streamlit create-document page end to end (service + UI together)."""

from decimal import Decimal
from pathlib import Path

import pandas as pd
from sqlalchemy import select
from streamlit.testing.v1 import AppTest

from app.database.models import PurchaseDocument
from app.database.session import session_scope
from tests.conftest import PASSWORD

APP = str(Path(__file__).resolve().parents[2] / "app" / "main.py")


def _login(user):
    at = AppTest.from_file(APP, default_timeout=60).run()
    at.text_input[0].input(user)
    at.text_input[1].input(PASSWORD)
    at.button[0].click().run()
    return at


def _fill(at):
    at.sidebar.radio[0].set_value("Create document").run()
    at.session_state["lines_init"] = pd.DataFrame(
        [
            {
                "description": "Ball valve DN50 PN16",
                "quantity": 2.0,
                "unit": "pcs",
                "unit_price": 100.0,
                "discount_pct": 10.0,
                "tax_pct": 19.0,
                "category": "valves",
            }
        ]
    )
    at.run()
    at.text_area(key="f_desc").input("Valves for pump station").run()
    return at


def test_employee_creates_and_submits_via_ui(db):
    at = _fill(_login("employee.demo"))
    assert not at.exception
    totals = [m.value for m in at.metric]
    assert any("214.20" in t for t in totals)  # 2 x 100.00, -10 %, +19 % tax
    next(b for b in at.button if b.label == "Save and submit").click().run()
    assert not at.exception and any("submitted" in s.value for s in at.success)
    with session_scope() as s:
        doc = s.execute(select(PurchaseDocument)).scalar_one()
        assert doc.status == "submitted" and doc.total == Decimal("214.20")


def test_validation_blocks_saving_and_draft_can_be_edited(db):
    at = _login("employee.demo")
    at.sidebar.radio[0].set_value("Create document").run()
    assert at.warning  # empty form shows validation messages
    assert next(b for b in at.button if b.label == "Save as draft").disabled
    at = _fill(at)
    next(b for b in at.button if b.label == "Save as draft").click().run()
    with session_scope() as s:
        doc = s.execute(select(PurchaseDocument)).scalar_one()
        assert doc.status == "draft"
        doc_id = doc.id
    at.sidebar.radio[0].set_value("My documents").run()
    next(b for b in at.button if b.label == "Edit draft").click().run()
    assert at.sidebar.radio[0].value == "Create document"
    assert at.text_area(key="f_desc").value == "Valves for pump station"
    at.text_area(key="f_desc").input("Valves, updated").run()
    next(b for b in at.button if b.label == "Save draft").click().run()
    with session_scope() as s:
        assert s.get(PurchaseDocument, doc_id).description == "Valves, updated"
