"""Extraction tests. OCR tests use real generated files and are skipped if Tesseract is absent."""

import io
import shutil
from datetime import date
from decimal import Decimal

import pytest

from app.services import field_extraction as fx
from app.services import ocr_service as ocr
from app.services import speech_service as sp
from app.utils.exceptions import UploadRejected

SUPPLIERS = [(1, "ACME Stahl GmbH (synthetic)"), (2, "Nordtech Supply (synthetic)")]
INVOICE = [
    "ACME Stahl GmbH",
    "Invoice No: INV-2026-0042",
    "Date: 03.03.2026",
    "Due date: 02.04.2026",
    "1 Ball valve DN50 PN16 stainless 316  4 pcs 185,50 742,00",
    "2 Hex bolt M10 x 50 A2  100 pcs 0,35 35,00",
    "Subtotal 777,00 EUR",
    "VAT 19% 147,63",
    "Total 924,63 EUR",
]
needs_tesseract = pytest.mark.skipif(
    shutil.which("tesseract") is None, reason="Tesseract not installed"
)


def make_pdf(lines) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    y = 800
    for ln in lines:
        c.drawString(50, y, ln)
        y -= 22
    c.save()
    return buf.getvalue()


def make_png(lines) -> bytes:
    from PIL import Image, ImageDraw, ImageFont

    font = ImageFont.load_default(size=30)
    img = Image.new("RGB", (1500, 80 + 52 * len(lines)), "white")
    d = ImageDraw.Draw(img)
    for i, ln in enumerate(lines):
        d.text((40, 40 + 52 * i), ln, fill="black", font=font)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


def image_only_pdf(png: bytes) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.drawImage(ImageReader(io.BytesIO(png)), 20, 450, width=555, height=330)
    c.save()
    return buf.getvalue()


# ----------------------------------------------------------------- parsing rules
def test_parse_fields_from_clean_text():
    r = fx.extract_fields("\n".join(INVOICE), SUPPLIERS)
    f = r.fields
    assert f["supplier"].value == 1 and f["supplier_ref"].value == "INV-2026-0042"
    assert f["purchase_date"].value == date(2026, 3, 3)  # the due date is ignored
    assert f["currency"].value == "EUR" and f["total"].value == Decimal("924.63")
    assert len(r.lines) == 2 and all(ln.consistent for ln in r.lines)
    assert r.missing == [] and r.issues == []


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("1.234,56", "1234.56"),
        ("1,234.56", "1234.56"),
        ("12,5", "12.5"),
        ("1.234.567", "1234567"),
        ("€ 99", "99"),
    ],
)
def test_amount_formats(raw, expected):
    assert fx.parse_amount(raw) == Decimal(expected)


def test_missing_and_contradictory_values_are_reported_not_resolved():
    text = "Invoice No: AB-1001\nInvoice No: AB-2002\nDate: 2026-03-01\nDate: 2026-03-09\nTotal 100,00 EUR\nTotal 120,00 EUR"
    r = fx.extract_fields(text, SUPPLIERS)
    joined = " ".join(r.issues)
    assert "document numbers" in joined and "dates" in joined and "totals" in joined
    assert "supplier" in r.missing and r.fields["total"].candidates == [
        Decimal("100.00"),
        Decimal("120.00"),
    ]


def test_total_vs_lines_mismatch_flagged_and_inconsistent_line_flagged():
    text = "\n".join(INVOICE[:4] + ["1 Ball valve DN50  4 pcs 185,50 700,00", "Total 924,63 EUR"])
    r = fx.extract_fields(text, SUPPLIERS)
    assert any("differs from the amount" in i or "differs from amount" in i for i in r.issues)
    assert any("sum of lines" in i for i in r.issues)


def test_low_ocr_confidence_lowers_field_confidence():
    hi = fx.extract_fields("\n".join(INVOICE), SUPPLIERS, 0.95).fields["total"].confidence
    lo = fx.extract_fields("\n".join(INVOICE), SUPPLIERS, 0.30).fields["total"].confidence
    assert lo < hi


def test_conflict_detection_shows_sources_and_ignores_agreement():
    conflicts = fx.find_conflicts(
        {
            "manual": {"supplier_ref": "INV-1", "currency": "EUR", "total": Decimal("10.00")},
            "document": {"supplier_ref": "INV-2", "currency": "eur", "total": "10.0"},
            "speech": {"supplier_ref": None},
        }
    )
    assert [c.field for c in conflicts] == ["supplier_ref"]
    assert {s for s, _ in conflicts[0].options} == {"manual", "document"}


# ----------------------------------------------------------------- speech
def test_transcript_parsing_and_provider_absence():
    t = "Invoice number INV-2026-0042 from ACME Stahl, total 924.63 euros on 3 March 2026"
    f = sp.parse_transcript(t, SUPPLIERS)
    assert f["supplier_ref"].value == "INV-2026-0042" and f["total"].value == Decimal("924.63")
    assert f["currency"].value == "EUR" and f["purchase_date"].value == date(2026, 3, 3)
    assert f["supplier"].confidence <= 0.7 and f["description"].value == t
    assert sp.parse_transcript("", SUPPLIERS)["total"].value is None
    sp.set_speech_provider(None)
    assert sp.get_speech_provider() is None  # no model configured -> unavailable, never faked


# ----------------------------------------------------------------- PDF / OCR pipeline
def test_digital_pdf_uses_text_layer_not_ocr():
    res = ocr.extract_text("inv.pdf", make_pdf(INVOICE))
    assert res.method == "pdf_text" and res.confidence is None and "INV-2026-0042" in res.text


def test_corrupt_and_unsupported_files_are_rejected_cleanly():
    with pytest.raises(UploadRejected):
        ocr.extract_text("x.pdf", b"%PDF-1.4 garbage")
    with pytest.raises(UploadRejected):
        ocr.extract_text("x.docx", b"PK")


@needs_tesseract
def test_image_ocr_end_to_end():
    res = ocr.extract_text("inv.png", make_png(INVOICE))
    assert res.method == "ocr_tesseract" and res.confidence and res.confidence > 0.6
    parsed = fx.extract_fields(res.text, SUPPLIERS, res.confidence)
    assert parsed.fields["supplier_ref"].value == "INV-2026-0042"
    assert parsed.fields["total"].value == Decimal("924.63")
    assert any("reviewed" in w for w in res.warnings)


@needs_tesseract
def test_scanned_pdf_falls_back_to_ocr():
    res = ocr.extract_text("scan.pdf", image_only_pdf(make_png(INVOICE)))
    assert res.method == "ocr_tesseract" and "INV-2026-0042" in res.text
    assert any("Scanned PDF" in w for w in res.warnings)


@needs_tesseract
def test_blank_image_yields_no_values_and_warning():
    from PIL import Image

    buf = io.BytesIO()
    Image.new("RGB", (800, 600), "white").save(buf, "PNG")
    res = ocr.extract_text("blank.png", buf.getvalue())
    assert fx.extract_fields(res.text, SUPPLIERS).fields["total"].value is None


def test_missing_tesseract_degrades_gracefully():
    class Off(ocr.OcrProvider):
        name = "off"

        def available(self):
            return False

        def read_image(self, data):
            raise AssertionError

    ocr.set_ocr_provider(Off())
    try:
        res = ocr.extract_text("a.png", make_png(INVOICE))
        assert res.text == "" and "not installed" in res.warnings[0]
    finally:
        ocr.set_ocr_provider(None)
        ocr._provider = None
