from datetime import date
from decimal import Decimal

import numpy as np
import pandas as pd
import pytest

from app.ml import anomaly_detection as ad
from app.ml import duplicate_detection as dd
from app.ml import forecasting as fc
from app.ml import model_registry
from app.ml.evaluation import classification_metrics, regression_metrics
from app.ml.item_matching import match_items, normalize_item


# ---------------------------------------------------------------- item matching
def m(a, b, unit="pcs"):
    return match_items(normalize_item(a, unit), normalize_item(b, unit))


def test_same_item_different_phrasing_is_comparable():
    r = m("Ball valve DN50 PN16 stainless 316", "stainless 316 ball valve, DN 50, PN 16")
    assert r.level == "technically_comparable" and not r.conflicts and r.score > 0.9


@pytest.mark.parametrize(
    "a,b",
    [
        ("Ball valve DN50 PN16 stainless 316", "Ball valve DN80 PN16 stainless 316"),
        ("Hex bolt M10 x 50 A2", "Hex bolt M10 x 50 A4"),
        ("Control cable 5x1.5 mm2", "Control cable 5x2.5 mm2"),
        ("Ball bearing 6204-2RS", "Ball bearing 6204-ZZ"),
        ("Technical service inspection", "Technical service calibration"),
    ],
)
def test_similar_text_but_different_specification_is_not_equivalent(a, b):
    r = m(a, b)
    assert r.level == "similar_description_only" and r.conflicts and r.score < 0.6
    assert r.text_similarity > 0.7  # text alone would have called them alike


def test_missing_attributes_need_review_and_are_listed():
    r = m("Ball valve DN50", "Ball valve DN50 PN16")
    assert r.level == "needs_review" and any("pn" in x for x in r.missing)


def test_different_product_or_unit_not_comparable():
    assert m("Hex bolt M10 x 50 A2", "Hex nut M10 A2").level == "not_comparable"
    assert m("Hydraulic oil ISO VG 46", "Hydraulic oil ISO VG 46").level == "technically_comparable"
    a, b = (
        normalize_item("Steel plate 10 mm S355J2", "kg"),
        normalize_item("Steel plate 10 mm S355J2", "m2"),
    )
    assert match_items(a, b).level == "not_comparable"
    assert normalize_item("something unknown 123").product_type is None


# ---------------------------------------------------------------- duplicates
def rec(
    i,
    ref="INV-100200",
    total="500.00",
    d=date(2026, 3, 1),
    supplier=1,
    dtype="invoice",
    lines=(("valve", "5"),),
    files=(),
):
    return dd.DocRecord(
        i, supplier, dtype, ref, "EUR", Decimal(total), d, frozenset(lines), frozenset(files)
    )


def test_exact_and_near_duplicates_detected_with_reasons():
    exact = dd.score_pair(rec(1), rec(2, d=date(2026, 3, 3)))
    near = dd.score_pair(rec(1), rec(3, ref="INV-100201", d=date(2026, 3, 4)))
    assert exact and exact.score > 0.9 and "same supplier reference" in exact.reasons
    assert near and near.score >= dd.REVIEW_THRESHOLD


def test_same_amount_alone_is_not_enough():
    other = rec(2, ref="ZZ-998877", d=date(2026, 8, 1), lines=(("bearing", "9"),))
    assert dd.score_pair(rec(1), other) is None


def test_partial_payments_and_different_types_are_not_duplicates():
    assert (
        dd.score_pair(rec(1, ref="INV-7-P1", total="250"), rec(2, ref="INV-7-P2", total="250"))
        is None
    )
    assert dd.score_pair(rec(1), rec(2, dtype="quotation")) is None
    assert dd.score_pair(rec(1), rec(2, supplier=2)) is None


def test_identical_file_hash_is_decisive():
    r = dd.score_pair(
        rec(1, ref="A1", total="1", files=("abc",)), rec(2, ref="B2", total="2", files=("abc",))
    )
    assert r and r.score == 1.0


def test_find_candidates_blocking():
    recs = [rec(1), rec(2), rec(3, ref="OTHER-1", total="9.00", lines=(("x", "1"),))]
    found = dd.find_candidates(recs)
    assert [(f.doc_a, f.doc_b) for f in found] == [(1, 2)]


# ---------------------------------------------------------------- forecasting
def series(n=36, seed=0, noise=0.03):
    rng = np.random.default_rng(seed)
    idx = pd.period_range("2023-01", periods=n, freq="M")
    t = np.arange(n)
    vals = (
        1000
        * (1 + 0.01 * t)
        * (1 + 0.3 * np.sin(2 * np.pi * (idx.month - 1) / 12))
        * (1 + noise * rng.standard_normal(n))
    )
    return pd.Series(vals, index=idx)


def test_seasonal_model_beats_naive_baseline_on_seasonal_data():
    res = fc.forecast(series())
    assert res.metrics["seasonal_ridge"]["rmse"] < res.metrics["naive_last"]["rmse"]
    assert res.chosen in fc.MODELS and len(res.forecast) == 6
    assert (res.forecast["lower"] <= res.forecast["prediction"]).all()
    assert (res.forecast["prediction"] <= res.forecast["upper"]).all()


def test_insufficient_history_gives_warning_not_forecast():
    res = fc.forecast(series(n=12))
    assert res.chosen == "none" and res.forecast.empty and "complete months" in res.warnings[0]


def test_backtest_has_no_future_leakage():
    s = series()
    bt1 = fc.rolling_backtest(s, 6)
    s2 = s.copy()
    s2.iloc[-3:] *= 10  # change only the last three months
    bt2 = fc.rolling_backtest(s2, 6)
    first_three = bt1.index[:3]
    pd.testing.assert_frame_equal(
        bt1.loc[first_three].drop(columns="actual"), bt2.loc[first_three].drop(columns="actual")
    )


def test_current_incomplete_month_is_dropped():
    frame = pd.DataFrame({"month": ["2026-08", "2026-09", "2026-10"], "spend": [1.0, 2.0, 3.0]})
    assert str(fc.monthly_series(frame, today=date(2026, 10, 14)).index[-1]) == "2026-09"


def test_metrics_helpers():
    r = regression_metrics([10, 20], [12, 18])
    assert r["mae"] == 2 and r["rmse"] == 2
    c = classification_metrics(8, 2, 2)
    assert c["precision"] == 0.8 and c["recall"] == 0.8


# ---------------------------------------------------------------- anomaly detection
def anomaly_frames(n=400, seed=1):
    rng = np.random.default_rng(seed)
    lines, docs = [], []
    for i in range(1, n + 1):
        price = rng.uniform(90, 110) * (5 if i == n else 1)  # last document: 5x price spike
        lines.append((i, i, "Ball valve DN50 PN16 stainless 316", "pcs", 10.0, price))
        docs.append(
            (
                i,
                int(rng.integers(1, 5)),
                int(rng.integers(1, 5)),
                date(2025, 1, 1),
                "EUR",
                Decimal(str(round(price * 10, 2))),
                price * 10,
                "R",
                "invoice",
                "approved",
                1e9,
                "EUR",
                float("inf"),
                False,
            )
        )
    lcols = ["line_id", "document_id", "description", "unit", "quantity", "price_eur"]
    dcols = [
        "document_id",
        "supplier_id",
        "project_id",
        "purchase_date",
        "currency",
        "total",
        "total_eur",
        "supplier_ref",
        "doc_type",
        "status",
        "budget",
        "budget_currency",
        "budget_eur",
        "counts_toward_budget",
    ]
    return pd.DataFrame(lines, columns=lcols), pd.DataFrame(docs, columns=dcols)


def test_price_spike_is_flagged_with_explanation_and_normal_docs_mostly_not():
    lines, docs = anomaly_frames()
    model = ad.fit(lines, docs, seed=3)
    sc = ad.score(model, lines, docs, context=docs)
    spike = sc.loc[400]
    assert spike["flagged"] and "price_high" in spike["rules"]
    assert any(f["feature"] == "price_hi" for f in spike["factors"])
    assert sc["flagged"].mean() < 0.05


def test_scoring_is_reproducible_and_handles_unknown_items():
    lines, docs = anomaly_frames()
    a = ad.score(ad.fit(lines, docs, seed=3), lines, docs)["iforest_score"]
    b = ad.score(ad.fit(lines, docs, seed=3), lines, docs)["iforest_score"]
    pd.testing.assert_series_equal(a, b)
    model = ad.fit(lines, docs, seed=3)
    l2, d2 = lines.tail(2).copy(), docs.tail(2).copy()
    l2["description"] = "Completely unknown thing"
    out = ad.score(model, l2, d2)
    assert (
        len(out) == 2
        and out["factors"].map(lambda f: any(x["feature"] == "comparables" for x in f)).all()
    )


def test_near_threshold_rule():
    lines, docs = anomaly_frames()
    model = ad.fit(lines, docs, seed=3)
    d, ln = docs.tail(1).copy(), lines.tail(1).copy()
    d["total_eur"] = 9_800.0
    assert "near_approval_threshold" in ad.score(model, ln, d).iloc[0]["rules"]


def test_model_registry_roundtrip(db):
    assert model_registry.load_latest("demo") is None
    model_registry.save_model("demo", "v1", {"a": 1}, {"note": "x"})
    obj, meta = model_registry.load_latest("demo")
    assert obj == {"a": 1} and meta["version"] == "v1" and meta["note"] == "x"
