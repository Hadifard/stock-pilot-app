from datetime import date, timedelta
from decimal import Decimal

import pytest

from app.services.validation_service import (
    DocumentInput,
    LineInput,
    calculate,
    validate_or_raise,
    validation_errors,
)
from app.utils.currency import currency_exponent, quantize_money, to_decimal
from app.utils.exceptions import ValidationError


def doc(lines, **kw):
    base = dict(
        project_id=1,
        cost_center_id=1,
        supplier_id=1,
        doc_type="invoice",
        purchase_date=date.today(),
        currency="EUR",
        lines=tuple(lines),
        description="x",
    )
    base.update(kw)
    return DocumentInput(**base)


def test_basic_line_discount_tax_and_shipping():
    # gross 200.00, discount 20.00 -> net 180.00, tax 19 % = 34.20, shipping 10 -> 224.20
    d = doc(
        [LineInput("a", Decimal("2"), Decimal("100"), "pcs", Decimal("0.10"), Decimal("0.19"))],
        shipping=Decimal("10"),
    )
    c = calculate(d)
    assert c.subtotal == Decimal("180.00")
    assert c.discount_total == Decimal("20.00")
    assert c.tax_total == Decimal("34.20")
    assert c.total == Decimal("224.20")


def test_rounding_half_up_per_line():
    # 3 x 0.335 = 1.005 -> 1.01 (half up), not banker's rounding 1.00
    c = calculate(doc([LineInput("a", Decimal("3"), Decimal("0.335"))]))
    assert c.lines[0].net_amount == Decimal("1.01")


def test_sum_of_rounded_lines_is_document_total():
    lines = [LineInput("a", Decimal("1"), Decimal("0.333"), tax_rate=Decimal("0.19"))] * 3
    c = calculate(doc(lines))
    assert c.total == sum(x.line_total for x in c.lines)


def test_shipping_tax_included_in_tax_total():
    c = calculate(
        doc(
            [LineInput("a", Decimal("1"), Decimal("100"))],
            shipping=Decimal("20"),
            shipping_tax_rate=Decimal("0.19"),
        )
    )
    assert c.tax_total == Decimal("3.80")
    assert c.total == Decimal("123.80")


def test_currency_exponents():
    assert currency_exponent("JPY") == 0
    assert quantize_money(Decimal("10.5"), "JPY") == Decimal("11")
    assert currency_exponent("EUR") == 2


def test_float_is_refused():
    with pytest.raises(TypeError):
        to_decimal(0.1)
    assert to_decimal("1,5") == Decimal("1.5")


@pytest.mark.parametrize(
    "kw,fragment",
    [
        (dict(quantity=Decimal("0")), "quantity"),
        (dict(unit_price=Decimal("-1")), "unit price"),
        (dict(discount_rate=Decimal("1.5")), "discount"),
        (dict(tax_rate=Decimal("0.9")), "tax"),
        (dict(unit="parsec"), "unit"),
    ],
)
def test_line_validation(kw, fragment):
    line = LineInput("a", **{"quantity": Decimal("1"), "unit_price": Decimal("1"), **kw})
    errs = validation_errors(doc([line]))
    assert any(fragment in e for e in errs)


def test_document_level_validation():
    errs = validation_errors(
        doc([], currency="XXX", purchase_date=date.today() + timedelta(days=30), description=" ")
    )
    joined = " ".join(errs)
    assert "Currency" in joined and "future" in joined and "description" in joined
    assert "At least one line" in joined
    with pytest.raises(ValidationError):
        validate_or_raise(doc([]))


def test_more_than_four_decimals_rejected_so_storage_never_changes_totals():
    errs = validation_errors(doc([LineInput("a", Decimal("1.00005"), Decimal("1"))]))
    assert any("4 decimal places" in e for e in errs)
    assert validation_errors(doc([LineInput("a", Decimal("1.0005"), Decimal("1.2345"))])) == []
