import pytest

from app.security.hashing import hash_password, verify_password
from app.services.attachment_service import safe_display_name, validate_upload
from app.utils.exceptions import UploadRejected


def test_password_hash_roundtrip_and_disabled():
    h = hash_password("secret")
    assert verify_password("secret", h)
    assert not verify_password("wrong", h)
    assert not verify_password("secret", "!")
    assert not verify_password("secret", "garbage")
    assert h != hash_password("secret")  # random salt


def test_upload_validation(db):
    assert validate_upload("a.pdf", b"%PDF-1.4 data")[1] == "application/pdf"
    with pytest.raises(UploadRejected):
        validate_upload("a.exe", b"MZ....")
    with pytest.raises(UploadRejected):
        validate_upload("a.pdf", b"not a pdf")
    with pytest.raises(UploadRejected):
        validate_upload("a.pdf", b"")
    with pytest.raises(UploadRejected):
        validate_upload("a.png", b"\x89PNG\r\n\x1a\n" + b"0" * (11 * 1024 * 1024))


def test_safe_display_name_blocks_traversal():
    assert safe_display_name("../../etc/passwd") == "passwd"
    assert safe_display_name("..\\..\\win.ini") == "win.ini"
    assert "/" not in safe_display_name("a/b<c>.pdf")
