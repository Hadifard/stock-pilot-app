"""Application configuration loaded from environment variables (and an optional .env file)."""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    """Immutable runtime settings. Never put real secrets in source code."""

    database_url: str
    reporting_currency: str
    timezone: str
    correction_window_hours: int
    max_upload_mb: int
    attachment_dir: Path
    model_dir: Path
    log_level: str
    demo_password: str
    random_seed: int

    @property
    def max_upload_bytes(self) -> int:
        return self.max_upload_mb * 1024 * 1024


def _resolve_sqlite_url(url: str) -> str:
    """Make relative sqlite paths relative to the project root, not the current directory."""
    prefix = "sqlite:///"
    if url.startswith(prefix) and not url.startswith("sqlite:////") and url != "sqlite://":
        rel = url[len(prefix) :]
        if rel and rel != ":memory:" and not Path(rel).is_absolute():
            return prefix + str((PROJECT_ROOT / rel).resolve())
    return url


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    load_dotenv(PROJECT_ROOT / ".env")
    env = os.environ.get
    attachment_dir = Path(env("PROCUREMENT_ATTACHMENT_DIR", "data/attachments"))
    if not attachment_dir.is_absolute():
        attachment_dir = PROJECT_ROOT / attachment_dir
    model_dir = Path(env("PROCUREMENT_MODEL_DIR", "data/models"))
    if not model_dir.is_absolute():
        model_dir = PROJECT_ROOT / model_dir
    return Settings(
        database_url=_resolve_sqlite_url(
            env("PROCUREMENT_DATABASE_URL", "sqlite:///data/procurement.db")
        ),
        reporting_currency=env("PROCUREMENT_REPORTING_CURRENCY", "EUR").upper(),
        timezone=env("PROCUREMENT_TIMEZONE", "Europe/Berlin"),
        correction_window_hours=int(env("PROCUREMENT_CORRECTION_WINDOW_HOURS", "4")),
        max_upload_mb=int(env("PROCUREMENT_MAX_UPLOAD_MB", "10")),
        attachment_dir=attachment_dir,
        model_dir=model_dir,
        log_level=env("PROCUREMENT_LOG_LEVEL", "INFO").upper(),
        demo_password=env("PROCUREMENT_DEMO_PASSWORD", "demo-only-change-me"),
        random_seed=int(env("PROCUREMENT_RANDOM_SEED", "42")),
    )


def reset_settings_cache() -> None:
    """Used by tests after changing environment variables."""
    get_settings.cache_clear()
