"""Session-state helpers for the create/edit document form (prefill, drafts, touched fields)."""

from __future__ import annotations

from datetime import date

import pandas as pd
import streamlit as st

from app.database.session import session_scope
from app.services import document_service

LINE_COLUMNS = [
    "description",
    "quantity",
    "unit",
    "unit_price",
    "discount_pct",
    "tax_pct",
    "category",
]
EMPTY_LINES = pd.DataFrame(
    [
        {
            "description": "",
            "quantity": 1.0,
            "unit": "pcs",
            "unit_price": 0.0,
            "discount_pct": 0.0,
            "tax_pct": 19.0,
            "category": "general",
        }
    ]
)
DEFAULTS = {
    "f_type": "invoice",
    "f_ref": "",
    "f_date": None,
    "f_ccy": "EUR",
    "f_pay": "bank_transfer",
    "f_desc": "",
    "f_purpose": "",
    "f_ship": 0.0,
    "f_other": 0.0,
    "f_shiptax": 0.0,
}


def init_form_state() -> None:
    for k, v in DEFAULTS.items():
        st.session_state.setdefault(k, v if v is not None else date.today())
    st.session_state.setdefault("lines_init", EMPTY_LINES.copy())
    st.session_state.setdefault("ed_v", 0)
    st.session_state.setdefault("touched", set())


def touch(name: str) -> None:
    st.session_state["touched"].add(name)


def reset_form() -> None:
    for k in list(DEFAULTS) + [
        "f_project",
        "f_cc",
        "f_supplier",
        "extract",
        "extract_file",
        "extract_record_id",
        "editing_draft_id",
    ]:
        st.session_state.pop(k, None)
    st.session_state["lines_init"] = EMPTY_LINES.copy()
    st.session_state["ed_v"] = st.session_state.get("ed_v", 0) + 1
    st.session_state["touched"] = set()


def start_editing_draft(doc_id: int) -> None:
    """Button callback: load a draft into the form and switch to the form page."""
    from app.database.models import User

    with session_scope() as s:
        actor = s.get(User, st.session_state["user_id"])
        doc = document_service.get_document(s, actor, doc_id)
        reset_form()
        st.session_state.update(
            editing_draft_id=doc.id,
            f_project=doc.project_id,
            f_cc=doc.cost_center_id,
            f_supplier=doc.supplier_id,
            f_type=doc.doc_type,
            f_ref=doc.supplier_ref or "",
            f_date=doc.purchase_date,
            f_ccy=doc.currency,
            f_pay=doc.payment_method,
            f_desc=doc.description,
            f_purpose=doc.business_purpose,
            f_ship=float(doc.shipping),
            f_other=float(doc.other_charges),
            f_shiptax=float(doc.shipping_tax_rate * 100),
        )
        st.session_state["lines_init"] = pd.DataFrame(
            [
                {
                    "description": ln.description,
                    "quantity": float(ln.quantity),
                    "unit": ln.unit,
                    "unit_price": float(ln.unit_price),
                    "discount_pct": float(ln.discount_rate * 100),
                    "tax_pct": float(ln.tax_rate * 100),
                    "category": ln.category,
                }
                for ln in doc.lines
            ]
        )
    st.session_state["nav"] = "Create document"
