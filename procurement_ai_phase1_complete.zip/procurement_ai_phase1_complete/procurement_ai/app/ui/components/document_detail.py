"""Shared document detail view with role-aware actions. Services re-check every permission."""

from __future__ import annotations

import pandas as pd
import streamlit as st
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import AuditEvent, User
from app.security.authorization import can_decide_document
from app.services import approval_service as appr
from app.services import attachment_service, document_service
from app.ui.components.form_state import start_editing_draft
from app.ui.components.formatting import money
from app.ui.styles.theme import badge_html
from app.utils.dates import format_local


def render_document_detail(session: Session, actor: User, doc_id: int, key: str = "d") -> None:
    doc = document_service.get_document(session, actor, doc_id)
    st.markdown(f"### {doc.doc_number}  {badge_html(doc.status)}", unsafe_allow_html=True)
    if doc.is_synthetic:
        st.caption("Synthetic demo document")
    c1, c2, c3 = st.columns(3)
    c1.metric("Total", money(doc.total, doc.currency))
    c2.metric(
        "In reporting currency",
        money(doc.total_reporting, doc.reporting_currency)
        if doc.total_reporting is not None
        else "no FX rate",
    )
    c3.metric("Purchase date", doc.purchase_date.isoformat())
    st.write(
        f"**Supplier:** {doc.supplier.name}  \n**Project:** {doc.project.code}  \n"
        f"**Cost center:** {doc.cost_center.code}  \n**Type:** {doc.doc_type}  \n"
        f"**Supplier reference:** {doc.supplier_ref or '-'}  \n"
        f"**Employee:** {doc.employee.full_name}  \n**Submitted:** {format_local(doc.submitted_at)}"
    )
    st.write(f"**Description:** {doc.description}")
    if doc.business_purpose:
        st.write(f"**Business purpose:** {doc.business_purpose}")
    deadline = document_service.correction_deadline(doc)
    if deadline and doc.status in ("submitted", "under_review", "resubmitted"):
        inside = document_service.within_correction_window(doc)
        st.info(
            f"Correction deadline: {format_local(deadline)} "
            f"({'open' if inside else 'expired - manager exception required'})"
        )
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "#": ln.line_no,
                    "Description": ln.description,
                    "Qty": float(ln.quantity),
                    "Unit": ln.unit,
                    "Unit price": float(ln.unit_price),
                    "Discount %": float(ln.discount_rate * 100),
                    "Tax %": float(ln.tax_rate * 100),
                    "Net": float(ln.net_amount),
                    "Tax": float(ln.tax_amount),
                    "Line total": float(ln.line_total),
                }
                for ln in doc.lines
            ]
        ),
        hide_index=True,
        width="stretch",
    )
    st.caption(
        f"Subtotal {money(doc.subtotal, doc.currency)} - Discounts included {money(doc.discount_total, doc.currency)} - "
        f"Tax {money(doc.tax_total, doc.currency)} - Shipping {money(doc.shipping, doc.currency)} - "
        f"Other {money(doc.other_charges, doc.currency)}. Totals are calculated on the server."
    )

    for att in doc.attachments:
        a, data = attachment_service.read_attachment(session, actor, att.id)
        st.download_button(
            f"Download {a.original_name} ({a.size_bytes // 1024 + 1} KB)",
            data,
            file_name=a.original_name,
            mime=a.mime_type,
            key=f"{key}-att-{a.id}",
        )

    _render_actions(session, actor, doc, key)
    with st.expander("History"):
        events = session.execute(
            select(AuditEvent, User.full_name)
            .outerjoin(User, AuditEvent.actor_id == User.id)
            .where(AuditEvent.entity_type == "document", AuditEvent.entity_id == doc.id)
            .order_by(AuditEvent.id)
        ).all()
        if not events:
            st.caption("No recorded events (synthetic documents have no per-event history).")
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "When": format_local(e.timestamp),
                        "Who": who or "system",
                        "Event": e.action,
                    }
                    for e, who in events
                ]
            ),
            hide_index=True,
            width="stretch",
        )


def _render_actions(session: Session, actor: User, doc, key: str) -> None:
    if doc.employee_id == actor.id and doc.status == "draft":
        c0, c1, c2 = st.columns(3)
        c0.button("Edit draft", key=f"{key}-edit", on_click=start_editing_draft, args=(doc.id,))
        if c1.button("Submit for approval", key=f"{key}-submit", type="primary"):
            document_service.submit(session, actor, doc.id)
            session.commit()
            st.rerun()
        if c2.button("Cancel draft", key=f"{key}-cancel"):
            appr.cancel(session, actor, doc.id, "Cancelled by owner")
            session.commit()
            st.rerun()
    if not can_decide_document(actor, doc):
        return
    st.markdown("**Review actions**")
    if doc.status in ("submitted", "resubmitted"):
        if st.button("Start review", key=f"{key}-start", type="primary"):
            appr.start_review(session, actor, doc.id)
            session.commit()
            st.rerun()
    elif doc.status == "under_review":
        note = st.text_input("Decision note (required to reject)", key=f"{key}-note")
        confirm = st.checkbox("I confirm this decision", key=f"{key}-confirm")
        c1, c2 = st.columns(2)
        if c1.button("Approve", key=f"{key}-approve", type="primary", disabled=not confirm):
            appr.approve(session, actor, doc.id, note)
            session.commit()
            st.rerun()
        if c2.button("Reject", key=f"{key}-reject", disabled=not confirm):
            appr.reject(session, actor, doc.id, note)
            session.commit()
            st.rerun()
