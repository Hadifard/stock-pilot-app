from __future__ import annotations

from decimal import Decimal

from app.utils.currency import currency_exponent


def money(amount: Decimal | None, currency: str) -> str:
    if amount is None:
        return "n/a"
    exp = currency_exponent(currency)
    return f"{amount:,.{exp}f} {currency}"
