from __future__ import annotations

import pandas as pd
import streamlit as st
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database.models import PurchaseDocument, User
from app.services import notification_service
from app.ui.styles.theme import status_label


def render(session: Session, actor: User) -> None:
    st.title("Home")
    st.write(f"Welcome, **{actor.full_name}**.")
    rows = session.execute(
        select(PurchaseDocument.status, func.count())
        .where(PurchaseDocument.employee_id == actor.id)
        .group_by(PurchaseDocument.status)
    ).all()
    if not rows:
        st.info("You have not created any documents yet. Open **Create document** to start.")
    else:
        cols = st.columns(min(len(rows), 4))
        for i, (status, n) in enumerate(sorted(rows)):
            cols[i % len(cols)].metric(status_label(status), n)
    unread = notification_service.unread_count(session, actor)
    if unread:
        st.warning(f"You have {unread} unread notification(s).")
    recent = (
        session.execute(
            select(PurchaseDocument)
            .where(PurchaseDocument.employee_id == actor.id)
            .order_by(PurchaseDocument.created_at.desc())
            .limit(5)
        )
        .scalars()
        .all()
    )
    if recent:
        st.subheader("Recent documents")
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "Document": d.doc_number,
                        "Status": status_label(d.status),
                        "Total": f"{d.total:,.2f} {d.currency}",
                        "Date": d.purchase_date,
                    }
                    for d in recent
                ]
            ),
            hide_index=True,
            width="stretch",
        )
