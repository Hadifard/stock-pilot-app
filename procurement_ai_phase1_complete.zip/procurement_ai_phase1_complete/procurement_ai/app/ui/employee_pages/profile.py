from __future__ import annotations

import streamlit as st
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import User
from app.security.authorization import ROLE_LABELS, ROLE_PERMISSIONS, Role


def render(session: Session, actor: User) -> None:
    st.title("Profile and settings")
    s = get_settings()
    st.write(
        f"**Name:** {actor.full_name}  \n**Username:** {actor.username}  \n"
        f"**Role:** {ROLE_LABELS[actor.role]}  \n**Organisational unit:** {actor.org_unit.name}"
    )
    st.write(
        f"**Timezone:** {s.timezone}  \n**Reporting currency:** {s.reporting_currency}  \n"
        f"**Correction window:** {s.correction_window_hours} hours after submission"
    )
    st.subheader("Your permissions")
    st.write(", ".join(sorted(p.value for p in ROLE_PERMISSIONS[Role(actor.role)])))
    st.caption("Local demo authentication only. Not a production identity or security system.")
