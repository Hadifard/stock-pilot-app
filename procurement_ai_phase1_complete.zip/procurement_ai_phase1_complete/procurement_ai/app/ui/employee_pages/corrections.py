"""Correction requests: employees file them; managers decide them."""

from __future__ import annotations

from datetime import date

import pandas as pd
import streamlit as st
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import PurchaseDocument, User
from app.security.authorization import Perm, has_permission
from app.services import correction_service as corr
from app.services import document_service
from app.services.validation_service import input_to_dict
from app.ui.components.formatting import money
from app.utils.dates import format_local


def _header_diff(original: dict, new: dict) -> dict:
    from decimal import Decimal

    out = {}
    for k, v in new.items():
        if k == "lines":
            continue
        old = original.get(k)
        same = str(old) == str(v)
        if not same:
            try:
                same = Decimal(str(old)) == Decimal(str(v))
            except Exception:
                same = False
        if not same:
            out[k] = v
    return out


def render(session: Session, actor: User) -> None:
    st.title("Correction requests")
    st.caption(
        "Submitted documents are never overwritten directly. A correction is proposed, "
        "reviewed by an authorised manager, and applied in an audited transaction."
    )
    if has_permission(actor, Perm.CORRECTION_REQUEST):
        _employee_form(session, actor)
    if has_permission(actor, Perm.CORRECTION_DECIDE) or has_permission(
        actor, Perm.CORRECTION_OVERRIDE
    ):
        _manager_section(session, actor)
    st.subheader("Requests")
    reqs = corr.list_requests(session, actor)
    if not reqs:
        st.info("No correction requests yet.")
        return
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "Request": r.id,
                    "Document": session.get(PurchaseDocument, r.document_id).doc_number,
                    "Filed": format_local(r.requested_at),
                    "Status": r.status,
                    "Reason": r.reason,
                    "Deadline exception": "yes" if r.deadline_exception else "no",
                }
                for r in reqs
            ]
        ),
        hide_index=True,
        width="stretch",
    )


def _employee_form(session: Session, actor: User) -> None:
    docs = (
        session.execute(
            select(PurchaseDocument)
            .where(
                PurchaseDocument.employee_id == actor.id,
                PurchaseDocument.status.in_(("submitted", "under_review", "resubmitted")),
            )
            .order_by(PurchaseDocument.submitted_at.desc())
        )
        .scalars()
        .all()
    )
    st.subheader("Request a correction")
    if not docs:
        st.info("You have no submitted documents that can be corrected.")
        return
    doc = st.selectbox(
        "Document", docs, format_func=lambda d: f"{d.doc_number} - {money(d.total, d.currency)}"
    )
    inside = document_service.within_correction_window(doc)
    deadline = document_service.correction_deadline(doc)
    if inside:
        st.success(f"Correction window open until {format_local(deadline)}.")
    else:
        st.error(
            f"The correction window closed at {format_local(deadline)}. "
            "Ask your manager to file an exception."
        )
        return
    _correction_inputs(session, actor, doc)


def _correction_inputs(
    session: Session, actor: User, doc: PurchaseDocument, override: bool = False
) -> None:
    key = f"corr-{doc.id}-{'o' if override else 'e'}"
    base = input_to_dict(document_service.document_to_input(doc))
    c1, c2 = st.columns(2)
    description = c1.text_area("Description", base["description"], key=f"{key}-d")
    supplier_ref = c2.text_input("Supplier reference", base["supplier_ref"] or "", key=f"{key}-r")
    purchase_date = c1.date_input(
        "Purchase date", date.fromisoformat(base["purchase_date"]), key=f"{key}-pd"
    )
    shipping = c2.text_input("Shipping", base["shipping"], key=f"{key}-s")
    other = c1.text_input("Other charges", base["other_charges"], key=f"{key}-o")
    lines = st.data_editor(
        pd.DataFrame(base["lines"]), num_rows="dynamic", width="stretch", key=f"{key}-lines"
    )
    reason = st.text_area("Reason for the correction (required)", key=f"{key}-reason")
    justification = None
    if override:
        justification = st.text_area(
            "Justification for the deadline exception (required)", key=f"{key}-just"
        )
    if st.button("Submit correction request", key=f"{key}-go", type="primary"):
        new = dict(base)
        new.update(
            description=description,
            supplier_ref=supplier_ref or None,
            purchase_date=purchase_date.isoformat(),
            shipping=shipping,
            other_charges=other,
        )
        header = _header_diff(base, new)
        line_rows = [
            {k: str(v) for k, v in r.items() if v is not None} for r in lines.to_dict("records")
        ]
        line_changes = None if _lines_equal(base["lines"], line_rows) else line_rows
        corr.create_request(session, actor, doc.id, header, line_changes, reason, justification)
        session.commit()
        st.success("Correction request filed. A reviewer will decide on it.")
        st.rerun()


def _lines_equal(a: list[dict], b: list[dict]) -> bool:
    from decimal import Decimal

    if len(a) != len(b):
        return False
    for x, y in zip(a, b, strict=True):
        for k in ("description", "unit", "category"):
            if str(x.get(k)) != str(y.get(k)):
                return False
        for k in ("quantity", "unit_price", "discount_rate", "tax_rate"):
            if Decimal(str(x[k])) != Decimal(str(y[k])):
                return False
    return True


def _manager_section(session: Session, actor: User) -> None:
    pending = corr.list_requests(session, actor, pending_only=True)
    st.subheader("Pending decisions")
    if not pending:
        st.info("No pending correction requests in your scope.")
    for r in pending:
        doc = session.get(PurchaseDocument, r.document_id)
        import json

        old, new = json.loads(r.original_json), json.loads(r.proposed_json)
        with st.expander(
            f"Request #{r.id} - {doc.doc_number} {'(deadline exception)' if r.deadline_exception else ''}"
        ):
            st.write(f"**Reason:** {r.reason}")
            if r.exception_reason:
                st.write(f"**Exception justification:** {r.exception_reason}")
            st.write(
                f"Calculated total: {old['calculated_total']} -> **{new['calculated_total']}** {doc.currency}"
            )
            diffs = _header_diff(old["input"], new["input"])
            if diffs:
                st.dataframe(
                    pd.DataFrame(
                        [
                            {"Field": k, "Current": old["input"].get(k), "Proposed": v}
                            for k, v in diffs.items()
                        ]
                    ),
                    hide_index=True,
                )
            if old["input"]["lines"] != new["input"]["lines"]:
                st.write("Line items change:")
                st.dataframe(pd.DataFrame(new["input"]["lines"]), hide_index=True)
            note = st.text_input("Decision note (required to reject)", key=f"cn-{r.id}")
            ok = st.checkbox("I confirm this decision", key=f"cc-{r.id}")
            a, b = st.columns(2)
            if a.button("Approve and apply", key=f"ca-{r.id}", type="primary", disabled=not ok):
                corr.decide_request(session, actor, r.id, True, note)
                session.commit()
                st.rerun()
            if b.button("Reject", key=f"cr-{r.id}", disabled=not ok):
                corr.decide_request(session, actor, r.id, False, note)
                session.commit()
                st.rerun()
    if has_permission(actor, Perm.CORRECTION_OVERRIDE):
        with st.expander("File a correction with a deadline exception"):
            from app.services.document_service import scoped_query

            docs = (
                session.execute(
                    scoped_query(session, actor)
                    .where(
                        PurchaseDocument.status.in_(
                            ("submitted", "under_review", "resubmitted", "approved")
                        ),
                        PurchaseDocument.is_synthetic.is_(False),
                    )
                    .order_by(PurchaseDocument.id.desc())
                    .limit(50)
                )
                .scalars()
                .all()
            )
            if not docs:
                st.info("No eligible documents.")
            else:
                d = st.selectbox(
                    "Document",
                    docs,
                    format_func=lambda x: f"{x.doc_number} ({x.status})",
                    key="ov-doc",
                )
                _correction_inputs(session, actor, d, override=True)
