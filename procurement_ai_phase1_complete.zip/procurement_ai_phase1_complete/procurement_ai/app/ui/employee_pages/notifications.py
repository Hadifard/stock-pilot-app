from __future__ import annotations

import streamlit as st
from sqlalchemy.orm import Session

from app.database.models import User
from app.services import notification_service as ns
from app.utils.dates import format_local


def render(session: Session, actor: User) -> None:
    st.title("Messages and notifications")
    items = ns.list_notifications(session, actor)
    if not items:
        st.info("No notifications yet.")
        return
    for n in items:
        st.markdown(
            f"{'**' if not n.is_read else ''}{n.message}{'**' if not n.is_read else ''}  \n"
            f"<small>{format_local(n.created_at)}</small>",
            unsafe_allow_html=True,
        )
    if st.button("Mark all as read"):
        ns.mark_all_read(session, actor)
        session.commit()
        st.rerun()
