"""Create/edit a purchase document: manual entry plus optional OCR / PDF / voice autofill."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pandas as pd
import streamlit as st
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import CostCenter, Project, Supplier, User
from app.services import (
    attachment_service,
    document_service,
    extraction_service,
    field_extraction,
    ocr_service,
    speech_service,
)
from app.services.validation_service import (
    DOC_TYPES,
    PAYMENT_METHODS,
    UNITS,
    DocumentInput,
    LineInput,
    calculate,
    validation_errors,
)
from app.ui.components.form_state import init_form_state, reset_form, touch
from app.ui.components.formatting import money
from app.utils.currency import SUPPORTED_CURRENCIES, quantize_rate, to_decimal
from app.utils.exceptions import UploadRejected


def _lines_from_frame(df: pd.DataFrame) -> tuple[LineInput, ...]:
    out = []
    for r in df.to_dict("records"):
        if not str(r.get("description") or "").strip() and not r.get("unit_price"):
            continue  # ignore completely empty rows
        out.append(
            LineInput(
                description=str(r.get("description") or ""),
                quantity=to_decimal(str(r.get("quantity") or 0)),
                unit_price=to_decimal(str(r.get("unit_price") or 0)),
                unit=str(r.get("unit") or "pcs"),
                discount_rate=quantize_rate(to_decimal(str(r.get("discount_pct") or 0)) / 100),
                tax_rate=quantize_rate(to_decimal(str(r.get("tax_pct") or 0)) / 100),
                category=str(r.get("category") or "general"),
            )
        )
    return tuple(out)


SOURCE_LABEL = {"pdf": "document", "image": "document", "audio": "speech"}
FIELD_LABEL = {
    "supplier_id": "Supplier",
    "supplier_ref": "Supplier reference",
    "purchase_date": "Purchase date",
    "currency": "Currency",
    "description": "Description",
}


def _autofill_section(session: Session, actor: User, supplier_names: dict[int, str]) -> None:
    with st.expander("Autofill from a file or voice (optional)", expanded=False):
        ocr_ok = ocr_service.get_ocr_provider() is not None
        sp_ok = speech_service.get_speech_provider() is not None
        st.caption(
            f"PDF text: available. OCR for scans and photos: {'available (Tesseract)' if ocr_ok else 'NOT installed'}. "
            f"Speech-to-text: {'available' if sp_ok else 'NOT configured (type the description instead)'}. "
            "Extraction uses fixed rules, not an AI model; handwriting is not reliably read. You always review the values."
        )
        up = st.file_uploader(
            "Invoice / quotation (PDF, PNG, JPG) or audio (WAV, MP3, M4A)",
            type=["pdf", "png", "jpg", "jpeg", "wav", "mp3", "m4a"],
            key="af_file",
        )
        mic = (
            st.audio_input("...or record a description (browser microphone)", key="af_mic")
            if hasattr(st, "audio_input")
            else None
        )
        source = up or mic
        if source is not None and st.button("Read file", key="af_go"):
            name = getattr(source, "name", "recording.wav") or "recording.wav"
            data = source.getvalue()
            try:
                out = extraction_service.run_extraction(session, actor, name, data)
                session.commit()
                st.session_state["extract"] = out
                st.session_state["extract_file"] = (name, data)
            except Exception as exc:  # DomainError subclasses carry user-facing text
                session.rollback()
                st.error(str(exc))
        out = st.session_state.get("extract")
        if out is None:
            return
        _review_extraction(session, actor, out, supplier_names)


def _review_extraction(session: Session, actor: User, out, supplier_names: dict[int, str]) -> None:
    for w in out.warnings:
        st.warning(w)
    if out.status == "failed":
        st.error("Nothing usable was extracted. Please enter the values manually.")
        return
    if out.ocr_confidence is not None:
        st.write(
            f"Mean OCR confidence: **{out.ocr_confidence:.0%}** (heuristic; low values mean the scan needs careful review)."
        )
    rows = []
    for key, f in out.fields.items():
        v = f.value
        if key == "supplier" and v is not None:
            v = supplier_names.get(int(v), v)
        rows.append(
            {
                "Field": key,
                "Extracted value": "" if v is None else str(v),
                "Rule confidence": f.confidence,
                "Evidence": f.evidence,
            }
        )
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    if out.lines:
        st.write("Line items read:")
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "Description": ln.description,
                        "Qty": float(ln.quantity),
                        "Unit": ln.unit,
                        "Unit price": float(ln.unit_price),
                        "Amount": float(ln.amount),
                        "Consistent": ln.consistent,
                    }
                    for ln in out.lines
                ]
            ),
            hide_index=True,
            width="stretch",
        )
    for msg in out.issues:
        st.warning(msg)
    if out.missing:
        st.info("Not found (enter manually): " + ", ".join(out.missing))
    with st.expander("Raw extracted text"):
        st.text(out.text[:5000])

    values = extraction_service.form_values(out)
    state_map = {
        "supplier_id": "f_supplier",
        "supplier_ref": "f_ref",
        "purchase_date": "f_date",
        "currency": "f_ccy",
        "description": "f_desc",
    }
    src = SOURCE_LABEL[out.source_type]
    manual = {
        k: st.session_state.get(state_map[k])
        for k in values
        if k in state_map and state_map[k] in st.session_state["touched"]
    }
    candidate = {k: v for k, v in values.items() if k in state_map}
    conflicts = field_extraction.find_conflicts({"manual": manual, src: candidate})
    choices: dict[str, str] = {}
    if conflicts:
        st.error(
            "Your entries and the extracted values disagree. Choose the correct value for each field; nothing is chosen for you."
        )
    for c in conflicts:
        shown = {
            s: (supplier_names.get(int(v), v) if c.field == "supplier_id" else v)
            for s, v in c.options
        }
        pick = st.radio(
            f"{FIELD_LABEL[c.field]}",
            [f"{s}: {v}" for s, v in shown.items()],
            index=None,
            key=f"af_c_{c.field}",
        )
        if pick:
            choices[c.field] = pick.split(":", 1)[0]
    apply_fields = [k for k in candidate if k not in {c.field for c in conflicts}]
    st.caption(
        "Fields without conflict will be filled with the extracted value; you can still edit them afterwards."
    )
    if st.button(
        "Apply reviewed values to the form",
        type="primary",
        key="af_apply",
        disabled=len(choices) < len(conflicts),
    ):
        resolutions: dict[str, dict] = {}
        for k in apply_fields:
            st.session_state[state_map[k]] = candidate[k]
            resolutions[k] = {"chosen_source": src, "value": str(candidate[k]), "conflict": False}
        for c in conflicts:
            chosen = choices[c.field]
            val = dict(c.options)[chosen]
            if chosen != "manual":
                st.session_state[state_map[c.field]] = val
            resolutions[c.field] = {
                "chosen_source": chosen,
                "options": {s: str(v) for s, v in c.options},
                "conflict": True,
            }
        if "lines" in values:
            st.session_state["lines_init"] = pd.DataFrame(values["lines"])
            st.session_state["ed_v"] += 1
            resolutions["lines"] = {"chosen_source": src, "count": len(values["lines"])}
        extraction_service.record_resolutions(session, actor, out.record_id, resolutions)
        session.commit()
        st.session_state["extract_record_id"] = out.record_id
        st.session_state.pop("extract", None)
        st.rerun()


def render(session: Session, actor: User) -> None:
    if st.session_state.pop("reset_pending", False):
        reset_form()  # done at the top of the run, before any widget exists (Streamlit rule)
    editing = st.session_state.get("editing_draft_id")
    st.title("Edit draft" if editing else "Create purchase document")
    init_form_state()
    flash = st.session_state.pop("flash", None)
    if flash:
        st.success(flash[0])
        if flash[1]:
            st.info(flash[1])
    projects = session.execute(select(Project).order_by(Project.code)).scalars().all()
    ccs = (
        session.execute(
            select(CostCenter)
            .where(CostCenter.org_unit_id == actor.org_unit_id)
            .order_by(CostCenter.code)
        )
        .scalars()
        .all()
    )
    suppliers = session.execute(select(Supplier).order_by(Supplier.name)).scalars().all()
    supplier_names = {s.id: s.name for s in suppliers}
    if editing:
        st.info(
            "You are editing a draft. Submitted documents can only be changed through correction requests."
        )
        st.button("Stop editing and start a new document", on_click=reset_form)
    _autofill_section(session, actor, supplier_names)

    c1, c2 = st.columns(2)
    project_id = c1.selectbox(
        "Project",
        [p.id for p in projects],
        format_func=lambda i: next(f"{p.code} - {p.name}" for p in projects if p.id == i),
        key="f_project",
    )
    cc_id = c2.selectbox(
        "Cost center",
        [c.id for c in ccs],
        format_func=lambda i: next(f"{c.code} - {c.name}" for c in ccs if c.id == i),
        key="f_cc",
    )
    supplier_id = c1.selectbox(
        "Supplier",
        list(supplier_names),
        format_func=supplier_names.get,
        key="f_supplier",
        on_change=touch,
        args=("f_supplier",),
    )
    doc_type = c2.selectbox("Document type", DOC_TYPES, key="f_type")
    supplier_ref = c1.text_input(
        "Supplier invoice / quotation number",
        max_chars=60,
        key="f_ref",
        on_change=touch,
        args=("f_ref",),
    )
    purchase_date = c2.date_input(
        "Purchase date", max_value=date.today(), key="f_date", on_change=touch, args=("f_date",)
    )
    currency = c1.selectbox(
        "Currency", SUPPORTED_CURRENCIES, key="f_ccy", on_change=touch, args=("f_ccy",)
    )
    payment = c2.selectbox("Payment method", PAYMENT_METHODS, key="f_pay")
    description = st.text_area(
        "Description", max_chars=2000, key="f_desc", on_change=touch, args=("f_desc",)
    )
    purpose = st.text_area("Business purpose", max_chars=2000, key="f_purpose")

    st.markdown("**Line items** (use the + row to add; discount and tax are percentages)")
    lines_df = st.data_editor(
        st.session_state["lines_init"],
        num_rows="dynamic",
        width="stretch",
        key=f"line_editor_{st.session_state['ed_v']}",
        column_config={
            "description": st.column_config.TextColumn("Description", required=True, max_chars=300),
            "quantity": st.column_config.NumberColumn("Qty", min_value=0.0001, format="%.4f"),
            "unit": st.column_config.SelectboxColumn("Unit", options=list(UNITS)),
            "unit_price": st.column_config.NumberColumn("Unit price", min_value=0.0, format="%.4f"),
            "discount_pct": st.column_config.NumberColumn(
                "Discount %", min_value=0.0, max_value=100.0
            ),
            "tax_pct": st.column_config.NumberColumn("Tax %", min_value=0.0, max_value=50.0),
            "category": st.column_config.TextColumn("Category"),
        },
    )
    c3, c4, c5 = st.columns(3)
    shipping = c3.number_input("Shipping", 0.0, 10_000_000.0, format="%.2f", key="f_ship")
    other = c4.number_input("Other charges", 0.0, 10_000_000.0, format="%.2f", key="f_other")
    ship_tax = c5.number_input("Shipping tax %", 0.0, 50.0, key="f_shiptax")
    files = st.file_uploader(
        "Attachments (PDF, PNG, JPG, WAV, MP3, M4A; max 10 MB each)",
        accept_multiple_files=True,
        type=["pdf", "png", "jpg", "jpeg", "wav", "mp3", "m4a"],
        key="f_files",
    )
    src_file = st.session_state.get("extract_file")
    attach_src = (
        bool(src_file)
        and st.checkbox(f"Also attach the source file you read ({src_file[0]})", value=True)
        if src_file
        else False
    )

    try:
        inp = DocumentInput(
            project_id=project_id or 0,
            cost_center_id=cc_id or 0,
            supplier_id=supplier_id or 0,
            doc_type=doc_type,
            purchase_date=purchase_date,
            currency=currency,
            lines=_lines_from_frame(lines_df),
            supplier_ref=supplier_ref.strip() or None,
            description=description,
            business_purpose=purpose,
            payment_method=payment,
            shipping=to_decimal(str(shipping)),
            other_charges=to_decimal(str(other)),
            shipping_tax_rate=quantize_rate(to_decimal(str(ship_tax)) / 100),
        )
    except (ValueError, TypeError) as exc:
        st.error(f"Please check numeric inputs: {exc}")
        return
    errors = validation_errors(inp)
    st.subheader("Calculation preview")
    if errors:
        for e in errors:
            st.warning(e)
    else:
        calc = calculate(inp)
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Subtotal", money(calc.subtotal, currency))
        m2.metric("Tax", money(calc.tax_total, currency))
        m3.metric("Shipping + other", money(calc.shipping + calc.other_charges, currency))
        m4.metric("Total", money(calc.total, currency))
        st.caption(
            "Totals are always recalculated by the server when saving; totals printed on a document are never trusted."
        )
        ex = st.session_state.get("extract_record_id")
        if ex:
            st.caption(
                "Values were prefilled from an extraction and reviewed by you; the review is stored with the document."
            )

    b1, b2 = st.columns(2)
    save = b1.button("Save draft" if editing else "Save as draft", disabled=bool(errors))
    submit = b2.button("Save and submit", type="primary", disabled=bool(errors))
    if save or submit:
        doc = (
            document_service.update_draft(session, actor, editing, inp)
            if editing
            else document_service.create_draft(session, actor, inp)
        )
        to_store = [(f.name, f.getvalue()) for f in files or []]
        if attach_src:
            to_store.append(src_file)
        for name, data in to_store:
            try:
                attachment_service.store_attachment(session, actor, doc.id, name, data)
            except UploadRejected as exc:
                raise UploadRejected(f"{name}: {exc}") from exc
        ex = st.session_state.get("extract_record_id")
        if ex:
            from app.database.models import ExtractionRecord

            rec = session.get(ExtractionRecord, ex)
            if rec and rec.user_id == actor.id:
                rec.document_id = doc.id
        if submit:
            document_service.submit(session, actor, doc.id)
        session.commit()
        number = doc.doc_number
        st.session_state["flash"] = (
            f"{number} {'submitted' if submit else 'saved as draft'}.",
            "You can request a correction within the correction window under 'Corrections'."
            if submit
            else "",
        )
        st.session_state["reset_pending"] = True
        st.rerun()


_ = Decimal
