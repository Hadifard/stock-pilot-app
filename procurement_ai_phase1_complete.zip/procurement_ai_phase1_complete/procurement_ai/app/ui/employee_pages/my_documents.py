"""Document list + detail. Used for 'My documents' (own only) and 'Documents' (everything in scope)."""

from __future__ import annotations

import pandas as pd
import streamlit as st
from sqlalchemy.orm import Session

from app.database.models import User
from app.services.document_service import ALL_STATUSES, DocumentFilter, list_documents
from app.ui.components.document_detail import render_document_detail
from app.ui.components.formatting import money
from app.ui.styles.theme import status_label

PAGE_SIZE = 20


def render(
    session: Session, actor: User, only_own: bool = True, preselect_status: tuple = ()
) -> None:
    key = "own" if only_own else "all"
    st.title("My documents" if only_own else "Documents")
    c1, c2 = st.columns([3, 2])
    search = c1.text_input("Search number, reference or description", key=f"{key}-search")
    statuses = c2.multiselect(
        "Status",
        ALL_STATUSES,
        default=list(preselect_status),
        format_func=status_label,
        key=f"{key}-status",
    )
    page = int(st.session_state.get(f"{key}-page", 1))
    rows, total = list_documents(
        session, actor, DocumentFilter(tuple(statuses), search, only_own), page, PAGE_SIZE
    )
    if total == 0:
        st.info("No documents match. Adjust the filters or create a new document.")
        return
    pages = max(1, -(-total // PAGE_SIZE))
    page = st.number_input(
        f"Page (of {pages}, {total} documents)", 1, pages, min(page, pages), key=f"{key}-pageinput"
    )
    st.session_state[f"{key}-page"] = page
    rows, _ = list_documents(
        session, actor, DocumentFilter(tuple(statuses), search, only_own), int(page), PAGE_SIZE
    )
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "Document": d.doc_number,
                    "Status": status_label(d.status),
                    "Date": d.purchase_date,
                    "Supplier": d.supplier.name,
                    "Project": d.project.code,
                    "Total": money(d.total, d.currency),
                    "Employee": d.employee.full_name,
                }
                for d in rows
            ]
        ),
        hide_index=True,
        width="stretch",
    )
    chosen = st.selectbox(
        "Open document",
        [d.id for d in rows],
        format_func=lambda i: next(d.doc_number for d in rows if d.id == i),
        key=f"{key}-open",
    )
    st.divider()
    render_document_detail(session, actor, chosen, key=key)
