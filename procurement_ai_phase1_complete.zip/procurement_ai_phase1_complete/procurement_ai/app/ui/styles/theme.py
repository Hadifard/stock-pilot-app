"""Small, restrained design system: one accent colour, accessible status badges (text + colour)."""

from __future__ import annotations

import streamlit as st

BADGES = {
    "draft": ("Draft", "#4A5568", "#E8ECF1"),
    "submitted": ("Submitted", "#1F4E79", "#DCE9F7"),
    "under_review": ("Under review", "#7A4B00", "#FDEBC8"),
    "correction_requested": ("Correction requested", "#7A2E00", "#FFE0CC"),
    "resubmitted": ("Resubmitted", "#1F4E79", "#DCE9F7"),
    "approved": ("Approved", "#14532D", "#D8F2E0"),
    "rejected": ("Rejected", "#7F1D1D", "#FADADA"),
    "cancelled": ("Cancelled", "#4A5568", "#E8ECF1"),
}

CSS = """
<style>
.block-container {padding-top: 2rem; max-width: 1200px;}
.badge {display:inline-block; padding:2px 10px; border-radius:12px; font-size:0.8rem; font-weight:600;}
.app-title {font-size:1.05rem; font-weight:700; color:#1F4E79; letter-spacing:.2px;}
.synthetic-banner {background:#FFF8E1; border-left:4px solid #E0A800; padding:6px 12px;
  font-size:0.85rem; border-radius:4px; margin-bottom:0.75rem;}
</style>
"""


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def badge_html(status: str) -> str:
    label, fg, bg = BADGES.get(status, (status, "#1B2430", "#E8ECF1"))
    return f'<span class="badge" style="color:{fg};background:{bg}">{label}</span>'


def status_label(status: str) -> str:
    return BADGES.get(status, (status,))[0]


def synthetic_banner() -> None:
    st.markdown(
        '<div class="synthetic-banner">Demo data is <b>synthetic</b>. It does not represent real '
        "expenditure, supplier quotations or verified market prices.</div>",
        unsafe_allow_html=True,
    )
