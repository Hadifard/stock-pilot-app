from __future__ import annotations

import pandas as pd
import streamlit as st
from sqlalchemy.orm import Session, selectinload

from app.database.models import PurchaseDocument, User
from app.security.authorization import can_decide_document
from app.services.document_service import scoped_query
from app.ui.components.document_detail import render_document_detail
from app.ui.components.formatting import money
from app.ui.styles.theme import status_label


def render(session: Session, actor: User) -> None:
    st.title("Review queue")
    docs = (
        session.execute(
            scoped_query(session, actor)
            .where(PurchaseDocument.status.in_(("submitted", "resubmitted", "under_review")))
            .options(
                selectinload(PurchaseDocument.supplier),
                selectinload(PurchaseDocument.employee),
                selectinload(PurchaseDocument.project),
            )
            .order_by(PurchaseDocument.submitted_at)
            .limit(200)
        )
        .scalars()
        .all()
    )
    docs = [d for d in docs if can_decide_document(actor, d)]
    if not docs:
        st.success("Nothing is waiting for your review.")
        return
    st.caption(f"{len(docs)} document(s) in your scope, oldest first (max. 200 shown).")
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "Document": d.doc_number,
                    "Status": status_label(d.status),
                    "Employee": d.employee.full_name,
                    "Supplier": d.supplier.name,
                    "Total": money(d.total, d.currency),
                }
                for d in docs
            ]
        ),
        hide_index=True,
        width="stretch",
    )
    chosen = st.selectbox(
        "Open document",
        [d.id for d in docs],
        format_func=lambda i: next(d.doc_number for d in docs if d.id == i),
    )
    st.divider()
    render_document_detail(session, actor, chosen, key="rq")
