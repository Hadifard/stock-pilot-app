from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st
from sqlalchemy.orm import Session

from app.database.models import User
from app.security.authorization import Perm, has_permission
from app.services import price_service as ps
from app.services.validation_service import UNITS
from app.ui.styles.theme import synthetic_banner

LEVEL_TEXT = {
    "technically_comparable": "Technically comparable (all recognised attributes match)",
    "needs_review": "Needs review (attributes missing on one side)",
    "similar_description_only": "Similar description only - NOT equivalent",
    "not_comparable": "Not comparable",
}


def render(session: Session, actor: User) -> None:
    st.title("Price benchmark")
    synthetic_banner()
    st.caption(
        "Benchmarks come from internal purchase history, matched by technical attributes first. "
        "No online or market prices are used; without enough comparable purchases you will see "
        f"'{ps.NO_BENCHMARK}'."
    )
    c1, c2 = st.columns([4, 1])
    desc = c1.text_input("Item description", "Ball valve DN50 PN16 stainless 316")
    unit = c2.selectbox("Unit", UNITS)
    if not st.button("Find comparable purchases", type="primary"):
        return
    b = ps.benchmark(session, actor, desc, unit)
    if b.stats is None:
        st.warning(b.message)
    else:
        st.success(b.message)
        m = st.columns(5)
        m[0].metric("Median (EUR)", f"{b.stats['median']:,.2f}")
        m[1].metric("25-75 %", f"{b.stats['p25']:,.2f} - {b.stats['p75']:,.2f}")
        m[2].metric("Samples", b.n_samples)
        m[3].metric("Suppliers", b.stats["suppliers"])
        m[4].metric("Org. units", b.stats["org_units"])
        st.caption(
            "Net unit price after line discount, converted at the stored rate of each document. "
            "Excludes shipping, duties, lead time and warranty terms, which also affect real comparisons."
        )
        if not b.purchases.empty:
            fig = px.histogram(
                b.purchases, x="price_eur", nbins=20, labels={"price_eur": "Net unit price (EUR)"}
            )
            fig.update_layout(height=260, margin=dict(l=10, r=10, t=10, b=10))
            st.plotly_chart(fig, width="stretch")
            st.dataframe(b.purchases.round({"price_eur": 2}), hide_index=True, width="stretch")
    st.subheader("Candidate items and why they were or were not matched")
    if not b.comparables:
        st.info("No candidates found.")
    for text, res, n in b.comparables:
        with st.expander(f"{text} - {LEVEL_TEXT[res.level]} (score {res.score}, {n} purchases)"):
            st.write(res.explanation)
            st.caption(
                f"Matched: {', '.join(res.matched) or '-'} | Conflicts: {'; '.join(res.conflicts) or '-'} | Missing: {'; '.join(res.missing) or '-'} | text similarity {res.text_similarity}"
            )
            if res.level != "technically_comparable" and has_permission(actor, Perm.ANALYTICS_VIEW):
                k = abs(hash(text)) % 10**8
                ca, cb = st.columns(2)
                if ca.button("Confirm: technically equivalent", key=f"yes-{k}"):
                    ps.confirm_match(session, actor, desc, text, True)
                    session.commit()
                    st.success("Recorded. Search again to include it.")
                if cb.button("Confirm: not equivalent", key=f"no-{k}"):
                    ps.confirm_match(session, actor, desc, text, False)
                    session.commit()
                    st.success("Recorded.")
    _ = pd
