from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import OrgUnit, Project, User
from app.ml import model_registry
from app.security.authorization import Perm, has_permission
from app.services import analytics_service as an
from app.ui.styles.theme import synthetic_banner


def render(session: Session, actor: User) -> None:
    st.title("Spend forecast")
    synthetic_banner()
    cur = get_settings().reporting_currency
    c1, c2, c3 = st.columns(3)
    org_id = proj_id = None
    if has_permission(actor, Perm.DOC_VIEW_ALL):
        units = session.execute(select(OrgUnit).order_by(OrgUnit.code)).scalars().all()
        org = c1.selectbox(
            "Organisational unit",
            [None, *units],
            format_func=lambda u: "All" if u is None else u.code,
        )
        org_id = org.id if org else None
    projects = session.execute(select(Project).order_by(Project.code)).scalars().all()
    proj = c2.selectbox(
        "Project", [None, *projects], format_func=lambda p: "All" if p is None else p.code
    )
    proj_id = proj.id if proj else None
    horizon = c3.slider("Months ahead", 3, 12, 6)
    res = an.spend_forecast(session, actor, org_id, proj_id, horizon)
    if res.history.empty:
        st.info("No spend history in this scope.")
        return
    for w in res.warnings:
        (st.warning if "Only" in w or "did not beat" in w or "unreliable" in w else st.info)(w)
    if res.forecast.empty:
        return
    hist = res.history
    fig = go.Figure()
    fig.add_scatter(
        x=hist.index.astype(str), y=hist.values, name="Actual spend", mode="lines+markers"
    )
    fig.add_scatter(
        x=res.forecast.index.astype(str),
        y=res.forecast["prediction"],
        name=f"Forecast ({res.chosen})",
        mode="lines+markers",
        line=dict(dash="dash"),
    )
    xs = list(res.forecast.index.astype(str))
    fig.add_scatter(
        x=xs + xs[::-1],
        y=list(res.forecast["upper"]) + list(res.forecast["lower"])[::-1],
        fill="toself",
        line=dict(width=0),
        name="Approx. 95 % interval",
        opacity=0.2,
    )
    fig.update_layout(
        height=380,
        margin=dict(l=10, r=10, t=30, b=10),
        yaxis_title=f"Spend ({cur})",
        legend=dict(orientation="h"),
    )
    st.plotly_chart(fig, width="stretch")
    st.caption("An estimate from past spend, not a guarantee of future expenditure or savings.")
    st.subheader("Backtest: candidate vs baselines")
    st.caption(
        "Rolling one-month-ahead predictions for the most recent months; each model only saw earlier months."
    )
    st.dataframe(
        pd.DataFrame(res.metrics)
        .T.rename(columns={"mae": "MAE", "rmse": "RMSE", "mape_pct": "MAPE %"})
        .round(1),
        width="stretch",
    )
    st.dataframe(res.backtest.round(0), width="stretch")
    loaded = model_registry.load_latest("forecast_global")
    with st.expander("Method and limitations"):
        st.write(
            "Monthly spend in the reporting currency; incomplete current month excluded. Candidate: ridge regression on a linear "
            "trend plus month-of-year effects, compared against naive, seasonal-naive and trailing-mean baselines. The model with the "
            "lowest backtest RMSE is used. Intervals are approximate and based on a short backtest. At least 24 complete months are required."
        )
        if loaded:
            st.caption(
                f"Stored global model: {loaded[1].get('version')} (saved {loaded[1].get('saved_at', '')[:19]})"
            )
