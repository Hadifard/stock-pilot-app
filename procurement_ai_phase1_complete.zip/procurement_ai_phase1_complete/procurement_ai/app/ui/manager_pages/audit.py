from __future__ import annotations

import json

import pandas as pd
import streamlit as st
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import AuditEvent, User
from app.security import audit_log
from app.security.authorization import Perm, require
from app.utils.dates import format_local


def render(session: Session, actor: User) -> None:
    require(actor, Perm.AUDIT_VIEW)
    st.title("Audit log")
    st.caption(
        "Append-only and hash-chained. This detects casual modification; it does not stop "
        "an attacker who controls the whole database. It is not a blockchain."
    )
    if st.button("Verify hash chain"):
        res = audit_log.verify_chain(session)
        (st.success if res.ok else st.error)(res.message)
    action = st.text_input("Filter by action (e.g. document.submitted)")
    q = (
        select(AuditEvent, User.username)
        .outerjoin(User, AuditEvent.actor_id == User.id)
        .order_by(AuditEvent.id.desc())
        .limit(200)
    )
    if action.strip():
        q = q.where(AuditEvent.action.like(f"%{action.strip()}%"))
    rows = session.execute(q).all()
    if not rows:
        st.info("No audit events match.")
        return
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "#": e.id,
                    "When": format_local(e.timestamp),
                    "Actor": u or "system",
                    "Action": e.action,
                    "Entity": f"{e.entity_type}:{e.entity_id}",
                    "Details": json.dumps(json.loads(e.payload_json))[:160],
                }
                for e, u in rows
            ]
        ),
        hide_index=True,
        width="stretch",
    )
