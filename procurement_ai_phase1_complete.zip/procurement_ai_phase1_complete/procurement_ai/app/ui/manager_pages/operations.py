from __future__ import annotations

import pandas as pd
import streamlit as st
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database.models import AnomalyAlert, DuplicateCandidate, PurchaseDocument, User
from app.services import analytics_service as an
from app.services import extraction_service
from app.services import reporting_service as rep
from app.services.document_service import scoped_query
from app.ui.components.formatting import money
from app.ui.styles.theme import status_label
from app.utils.dates import format_local


def render(session: Session, actor: User) -> None:
    st.title("Operations")
    sub = scoped_query(session, actor).subquery()
    counts = dict(session.execute(select(sub.c.status, func.count()).group_by(sub.c.status)).all())
    pending = (
        counts.get("submitted", 0) + counts.get("resubmitted", 0) + counts.get("under_review", 0)
    )
    ids = scoped_query(session, actor).with_only_columns(PurchaseDocument.id)
    new_alerts = session.execute(
        select(func.count())
        .select_from(AnomalyAlert)
        .where(AnomalyAlert.status == "new", AnomalyAlert.document_id.in_(ids))
    ).scalar_one()
    price_alerts = session.execute(
        select(func.count())
        .select_from(AnomalyAlert)
        .where(
            AnomalyAlert.status == "new",
            AnomalyAlert.document_id.in_(ids),
            AnomalyAlert.rules_json.like("%price_%"),
        )
    ).scalar_one()
    dups = session.execute(
        select(func.count())
        .select_from(DuplicateCandidate)
        .where(DuplicateCandidate.status == "new", DuplicateCandidate.doc_a_id.in_(ids))
    ).scalar_one()
    bad = rep.inconsistent_totals(session, actor)
    bu = rep.budget_utilization(session, actor)
    over = bu[bu["utilization"] >= 1.0] if not bu.empty else bu
    m = st.columns(6)
    m[0].metric("Pending approvals", pending)
    m[1].metric("Correction requests", counts.get("correction_requested", 0))
    m[2].metric(
        "Unusual transactions", new_alerts, help="Open alerts; run a scan on the Alerts page."
    )
    m[3].metric("Possible duplicates", dups)
    m[4].metric(
        "Inconsistent totals",
        len(bad),
        help="Stored total differs from lines + shipping + charges.",
    )
    m[5].metric(
        "Over budget", len(over), help="Projects whose visible spend is at or above their budget."
    )
    st.caption(
        f"Unusual price changes flagged: {price_alerts}. Counts are scoped to the documents you may see."
    )

    st.subheader("Recent submissions")
    recent = (
        session.execute(
            scoped_query(session, actor)
            .where(PurchaseDocument.submitted_at.is_not(None))
            .order_by(PurchaseDocument.submitted_at.desc())
            .limit(15)
        )
        .scalars()
        .all()
    )
    if recent:
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "Document": d.doc_number,
                        "Submitted": format_local(d.submitted_at),
                        "Status": status_label(d.status),
                        "Total": money(d.total, d.currency),
                    }
                    for d in recent
                ]
            ),
            hide_index=True,
            width="stretch",
        )
    else:
        st.info("No submissions yet.")
    st.subheader("Failed or incomplete extractions")
    ex = extraction_service.list_problem_extractions(session, actor, 20)
    if ex:
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "When": format_local(e.created_at),
                        "File": e.filename,
                        "Source": e.source_type,
                        "Status": e.status,
                        "Note": (e.error or "values missing or contradictory")[:90],
                    }
                    for e in ex
                ]
            ),
            hide_index=True,
            width="stretch",
        )
    else:
        st.success("No failed or incomplete extraction jobs.")
    st.subheader("Documents with inconsistent totals")
    if bad.empty:
        st.success("Every checked document's stored total matches its lines.")
    else:
        st.dataframe(bad.head(50), hide_index=True, width="stretch")
    st.subheader("Potential budget overruns")
    if over.empty:
        st.success("No project in your scope has reached its budget.")
    else:
        st.dataframe(over.head(30).round(2), hide_index=True, width="stretch")
    _ = an
