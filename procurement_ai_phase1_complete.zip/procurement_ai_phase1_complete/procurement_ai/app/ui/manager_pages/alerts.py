from __future__ import annotations

import json

import pandas as pd
import streamlit as st
from sqlalchemy.orm import Session

from app.database.models import PurchaseDocument, User
from app.security.authorization import Perm, has_permission
from app.services import analytics_service as an
from app.ui.components.document_detail import render_document_detail
from app.ui.components.formatting import money

RULE_TEXT = {
    "price_high": "unit price more than 2x the median of comparable purchases",
    "price_low": "unit price below 0.4x the median of comparable purchases",
    "quantity_high": "quantity more than 3x the 99th percentile of comparable purchases",
    "near_approval_threshold": "total 0.5-7 % below an approval threshold",
    "repeated_amount": "same supplier and amount at least 3 times within 90 days",
    "budget_crossing": "first document that takes the project over its budget",
}


def render(session: Session, actor: User) -> None:
    st.title("Review alerts")
    st.caption(
        "Unusual transactions and possible duplicates are prompts for human review. "
        "They are not findings of error, fraud or misconduct."
    )
    can_review = has_permission(actor, Perm.ALERT_REVIEW)
    tab1, tab2 = st.tabs(["Unusual transactions", "Possible duplicates"])
    with tab1:
        _anomalies(session, actor, can_review)
    with tab2:
        _duplicates(session, actor, can_review)


def _anomalies(session: Session, actor: User, can_review: bool) -> None:
    if can_review and st.button("Run anomaly scan on my scope"):
        res = an.run_anomaly_scan(session, actor)
        session.commit()
        st.success(
            f"Scanned {res.scanned} documents with model {res.model_version}: {res.flagged} flagged, {res.new_alerts} new."
        )
    status = st.radio("Show", ["new", "reviewed", "all"], horizontal=True, key="al-status")
    rows = an.list_alerts(session, actor, None if status == "all" else status)
    if not rows:
        st.info("No alerts. Run a scan (model must be trained: `python -m scripts.train_models`).")
        return
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "Alert": a.id,
                    "Document": d.doc_number,
                    "Total": money(d.total, d.currency),
                    "Model score": round(a.score, 2),
                    "Priority": a.severity,
                    "Why": ", ".join(json.loads(a.rules_json)) or "model score only",
                    "Status": a.status,
                }
                for a, d in rows
            ]
        ),
        hide_index=True,
        width="stretch",
    )
    ids = [a.id for a, _ in rows]
    chosen = st.selectbox("Open alert", ids, format_func=lambda i: f"#{i}", key="al-open")
    alert, doc = next((a, d) for a, d in rows if a.id == chosen)
    st.markdown("**Why this document is flagged**")
    for r in json.loads(alert.rules_json):
        st.write(f"- Rule: {RULE_TEXT.get(r, r)}")
    for f in json.loads(alert.factors_json):
        st.write(f"- Model factor: {f['meaning']} (robust z = {f['robust_z']})")
    st.caption(
        f"Model {alert.model_version}; score {alert.score:.2f} is a model estimate of how unusual the document is."
    )
    if alert.status == "reviewed":
        st.success(
            f"Reviewed: {an.ALERT_DISPOSITIONS.get(alert.disposition, alert.disposition)} - {alert.review_note}"
        )
    elif can_review:
        disp = st.selectbox(
            "Disposition",
            list(an.ALERT_DISPOSITIONS),
            format_func=an.ALERT_DISPOSITIONS.get,
            key="al-disp",
        )
        note = st.text_input("Review note (required)", key="al-note")
        if st.button("Record review", type="primary", key="al-go"):
            an.review_alert(session, actor, alert.id, disp, note)
            session.commit()
            st.rerun()
    with st.expander("Document"):
        render_document_detail(session, actor, doc.id, key=f"al-{doc.id}")


def _duplicates(session: Session, actor: User, can_review: bool) -> None:
    if can_review and st.button("Run duplicate scan on my scope"):
        found, new = an.run_duplicate_scan(session, actor)
        session.commit()
        st.success(f"{found} candidate pair(s) found, {new} new.")
    status = st.radio("Show", ["new", "reviewed", "all"], horizontal=True, key="du-status")
    cands = an.list_duplicates(session, actor, None if status == "all" else status)
    if not cands:
        st.info("No duplicate candidates.")
        return
    docs = {
        d.id: d
        for d in session.query(PurchaseDocument)
        .filter(PurchaseDocument.id.in_([x for c in cands for x in (c.doc_a_id, c.doc_b_id)]))
        .all()
    }
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "Pair": c.id,
                    "Document A": docs[c.doc_a_id].doc_number,
                    "Document B": docs[c.doc_b_id].doc_number,
                    "Score": c.score,
                    "Evidence": "; ".join(json.loads(c.reasons_json)),
                    "Status": c.status,
                }
                for c in cands
            ]
        ),
        hide_index=True,
        width="stretch",
    )
    chosen = st.selectbox("Open pair", [c.id for c in cands], key="du-open")
    cand = next(c for c in cands if c.id == chosen)
    a, b = docs[cand.doc_a_id], docs[cand.doc_b_id]
    st.table(
        pd.DataFrame(
            {
                "": ["Number", "Reference", "Date", "Total", "Status"],
                "A": [
                    a.doc_number,
                    a.supplier_ref,
                    a.purchase_date,
                    money(a.total, a.currency),
                    a.status,
                ],
                "B": [
                    b.doc_number,
                    b.supplier_ref,
                    b.purchase_date,
                    money(b.total, b.currency),
                    b.status,
                ],
            }
        ).set_index("")
    )
    st.caption(
        "Identical amounts alone are never enough. Partial payments and different document types are excluded; "
        "credit notes are not modelled yet, so a reversal may appear here and should be dismissed."
    )
    if cand.status == "reviewed":
        st.success(
            f"Reviewed: {an.DUPLICATE_DISPOSITIONS.get(cand.disposition, cand.disposition)} - {cand.review_note}"
        )
    elif can_review:
        disp = st.selectbox(
            "Disposition",
            list(an.DUPLICATE_DISPOSITIONS),
            format_func=an.DUPLICATE_DISPOSITIONS.get,
            key="du-disp",
        )
        note = st.text_input("Review note (required)", key="du-note")
        if st.button("Record review", type="primary", key="du-go"):
            an.review_duplicate(session, actor, cand.id, disp, note)
            session.commit()
            st.rerun()
