from __future__ import annotations

from datetime import date, timedelta

import plotly.express as px
import streamlit as st
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import LineItem, OrgUnit, Project, Supplier, User
from app.security.authorization import Perm, has_permission
from app.services import reporting_service as rep
from app.services.document_service import ALL_STATUSES
from app.ui.styles.theme import status_label, synthetic_banner
from app.utils.currency import SUPPORTED_CURRENCIES


def render(session: Session, actor: User) -> None:
    st.title("Spend analysis")
    synthetic_banner()
    cur = get_settings().reporting_currency
    with st.expander("Filters", expanded=True):
        c1, c2, c3 = st.columns(3)
        d_from = c1.date_input("From", date.today() - timedelta(days=365), key="sa_from")
        d_to = c2.date_input("To", date.today(), key="sa_to")
        statuses = c3.multiselect(
            "Status (default: all except draft/cancelled/rejected)",
            ALL_STATUSES,
            format_func=status_label,
            key="sa_status",
        )
        c4, c5, c6, c7 = st.columns(4)
        org = None
        if has_permission(actor, Perm.DOC_VIEW_ALL):
            units = session.execute(select(OrgUnit).order_by(OrgUnit.code)).scalars().all()
            org = c4.selectbox(
                "Subsidiary / office",
                [None, *units],
                format_func=lambda u: "All" if u is None else u.code,
                key="sa_org",
            )
        projects = session.execute(select(Project).order_by(Project.code)).scalars().all()
        proj = c5.selectbox(
            "Project",
            [None, *projects],
            format_func=lambda p: "All" if p is None else p.code,
            key="sa_proj",
        )
        suppliers = session.execute(select(Supplier).order_by(Supplier.name)).scalars().all()
        sup = c6.selectbox(
            "Supplier",
            [None, *suppliers],
            format_func=lambda s: "All" if s is None else s.name,
            key="sa_sup",
        )
        categories = [
            c
            for (c,) in session.execute(
                select(LineItem.category).distinct().order_by(LineItem.category)
            )
        ]
        cat = c7.selectbox(
            "Product category",
            [None, *categories],
            format_func=lambda c: "All" if c is None else c,
            key="sa_cat",
        )
        ccy = st.selectbox(
            "Original currency",
            [None, *SUPPORTED_CURRENCIES],
            format_func=lambda c: "All (converted)" if c is None else c,
            key="sa_ccy",
        )
    flt = rep.SpendFilter(
        d_from,
        d_to,
        org.id if org else None,
        proj.id if proj else None,
        sup.id if sup else None,
        cat,
        ccy,
        tuple(statuses),
    )
    df = rep.spend_lines(session, actor, flt)
    if df.empty:
        st.info("No spend matches these filters.")
        return
    if df.attrs.get("missing_fx"):
        st.warning(f"{df.attrs['missing_fx']} line(s) have no exchange rate and are excluded.")
    st.caption(
        f"Net spend (excluding tax and shipping) converted to {cur} with the stored effective-dated rate of each document. Lines: {len(df):,}."
    )
    m = st.columns(3)
    m[0].metric("Net spend", f"{df['net_reporting'].sum():,.0f} {cur}")
    m[1].metric("Documents", f"{df['doc_id'].nunique():,}")
    m[2].metric("Suppliers", f"{df['supplier'].nunique():,}")
    monthly = df.groupby("month", as_index=False)["net_reporting"].sum()
    st.plotly_chart(
        px.line(
            monthly,
            x="month",
            y="net_reporting",
            markers=True,
            title="Net spend by month",
            labels={"net_reporting": cur, "month": ""},
        ).update_layout(height=300, margin=dict(l=10, r=10, t=40, b=10)),
        width="stretch",
    )
    left, right = st.columns(2)
    by_cat = (
        df.groupby("category", as_index=False)["net_reporting"].sum().sort_values("net_reporting")
    )
    left.plotly_chart(
        px.bar(
            by_cat,
            x="net_reporting",
            y="category",
            orientation="h",
            title="By product category",
            labels={"net_reporting": cur, "category": ""},
        ).update_layout(height=340, margin=dict(l=10, r=10, t=40, b=10)),
        width="stretch",
    )
    by_proj = (
        df.groupby("project", as_index=False)["net_reporting"]
        .sum()
        .nlargest(12, "net_reporting")
        .sort_values("net_reporting")
    )
    right.plotly_chart(
        px.bar(
            by_proj,
            x="net_reporting",
            y="project",
            orientation="h",
            title="Top projects",
            labels={"net_reporting": cur, "project": ""},
        ).update_layout(height=340, margin=dict(l=10, r=10, t=40, b=10)),
        width="stretch",
    )
    by_sup = (
        df.groupby("supplier", as_index=False)["net_reporting"]
        .sum()
        .sort_values("net_reporting", ascending=False)
    )
    top5 = by_sup.head(5)["net_reporting"].sum() / by_sup["net_reporting"].sum()
    st.write(
        f"**Supplier concentration:** the five largest suppliers account for **{top5:.0%}** of net spend in this selection."
    )
    st.dataframe(
        by_sup.head(15).rename(columns={"net_reporting": f"Net spend ({cur})"}).round(0),
        hide_index=True,
        width="stretch",
    )
    st.subheader("Budget utilisation")
    bu = rep.budget_utilization(session, actor)
    if bu.empty:
        st.info("No budget data in your scope.")
    else:
        st.caption(
            f"Spend = documents you can see (submitted/approved), in {cur}; only {cur} budgets are compared. Scoped users may see understated utilisation."
        )
        top = bu.head(15).copy()
        top["utilization_pct"] = (top["utilization"] * 100).round(1)
        fig = px.bar(
            top.sort_values("utilization_pct"),
            x="utilization_pct",
            y="project",
            orientation="h",
            labels={"utilization_pct": "% of budget used", "project": ""},
        )
        fig.add_vline(x=100, line_dash="dash")
        st.plotly_chart(
            fig.update_layout(height=380, margin=dict(l=10, r=10, t=10, b=10)), width="stretch"
        )
