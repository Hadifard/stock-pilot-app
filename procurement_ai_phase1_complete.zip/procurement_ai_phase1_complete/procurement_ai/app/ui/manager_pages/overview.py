"""Management overview. Every number comes from a database query scoped to the viewer."""

from __future__ import annotations

import plotly.express as px
import streamlit as st
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database.models import User
from app.services import reporting_service as rep
from app.services.document_service import scoped_query
from app.ui.components.formatting import money
from app.ui.styles.theme import status_label, synthetic_banner


def render(session: Session, actor: User) -> None:
    st.title("Overview")
    sub = scoped_query(session, actor).subquery()
    n_syn = session.execute(
        select(func.count()).select_from(sub).where(sub.c.is_synthetic.is_(True))
    ).scalar_one()
    if n_syn:
        synthetic_banner()
    k = rep.compute_kpis(session, actor)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric(
        "Submitted spend",
        money(k.submitted_total_reporting, k.reporting_currency),
        help="SUM(total_reporting) of documents that are not draft, cancelled or rejected. "
        "Converted with the stored effective-dated exchange rate.",
    )
    c2.metric("Documents counted", f"{k.documents_counted:,}")
    c3.metric(
        "Pending approvals",
        k.pending_approvals,
        help="Status submitted, resubmitted or under review.",
    )
    c4.metric(
        "Avg approval time",
        f"{k.avg_approval_hours:.1f} h" if k.avg_approval_hours is not None else "n/a",
        help="Mean of decided_at - submitted_at over approved documents.",
    )
    if k.missing_fx_count:
        st.warning(
            f"{k.missing_fx_count} document(s) have no exchange rate and are excluded from spend."
        )
    if k.pending_corrections:
        st.warning(f"{k.pending_corrections} correction request(s) await review.")

    month = rep.spend_by_month(session, actor)
    if month.empty:
        st.info("No spend data in your scope yet.")
        return
    month["spend"] = month["spend"].astype(float)
    fig = px.bar(
        month,
        x="month",
        y="spend",
        labels={"month": "Month", "spend": f"Spend ({k.reporting_currency})"},
        title="Spend by month",
    )
    fig.update_layout(margin=dict(l=10, r=10, t=40, b=10), height=320)
    st.plotly_chart(fig, width="stretch")
    left, right = st.columns(2)
    for col, dim, title in (
        (left, "supplier", "Top suppliers"),
        (right, "project", "Top projects"),
    ):
        df = rep.spend_by(session, actor, dim)
        df["spend"] = df["spend"].astype(float)
        f = px.bar(
            df.iloc[::-1],
            x="spend",
            y="name",
            orientation="h",
            title=title,
            labels={"spend": k.reporting_currency, "name": ""},
        )
        f.update_layout(margin=dict(l=10, r=10, t=40, b=10), height=420)
        col.plotly_chart(f, width="stretch")
    st.subheader("Documents by status")
    rows = session.execute(select(sub.c.status, func.count()).group_by(sub.c.status)).all()
    st.dataframe([{"Status": status_label(s), "Documents": n} for s, n in rows], hide_index=True)
    st.caption(
        "Model-based forecasts, anomaly alerts and savings estimates are not part of this "
        "milestone; no figure on this page is a model estimate."
    )
