from __future__ import annotations

import streamlit as st
from sqlalchemy.orm import Session

from app.database.models import User
from app.services import reporting_service as rep
from app.services.document_service import ALL_STATUSES
from app.ui.styles.theme import status_label


def render(session: Session, actor: User) -> None:
    st.title("Reports")
    st.caption(
        "Exports contain only documents you are allowed to see and include generation "
        "time, reporting currency, filters and a synthetic-data note."
    )
    statuses = tuple(st.multiselect("Status filter", ALL_STATUSES, format_func=status_label))
    df = rep.documents_frame(session, actor, statuses)
    st.write(f"{len(df):,} document(s) match.")
    st.dataframe(df.head(50), hide_index=True, width="stretch")
    c1, c2, c3 = st.columns(3)
    if c3.button("Prepare PDF"):
        st.session_state["pdf_bytes"] = rep.export_pdf(session, actor, statuses)
    if "pdf_bytes" in st.session_state:
        c3.download_button(
            "Download PDF", st.session_state["pdf_bytes"], "documents.pdf", "application/pdf"
        )
    if c1.button("Prepare CSV"):
        st.session_state["csv_bytes"] = rep.export_csv(session, actor, statuses)
    if c2.button("Prepare Excel"):
        st.session_state["xlsx_bytes"] = rep.export_excel(session, actor, statuses)
    if "csv_bytes" in st.session_state:
        c1.download_button(
            "Download CSV", st.session_state["csv_bytes"], "documents.csv", "text/csv"
        )
    if "xlsx_bytes" in st.session_state:
        c2.download_button(
            "Download Excel",
            st.session_state["xlsx_bytes"],
            "documents.xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    st.caption("The PDF lists at most 1,000 rows; use CSV or Excel for complete exports.")
