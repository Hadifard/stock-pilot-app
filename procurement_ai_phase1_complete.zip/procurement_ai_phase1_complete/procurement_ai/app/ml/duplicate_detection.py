"""Exact and near-duplicate document detection (rule-scored, explainable).

Evidence is combined, never a single signal. Equal amounts alone score far below the review
threshold. Handling of legitimate repeats:
  * partial payments / instalments: references such as 'INV-1-P1', 'INV-1-P2' or 'part 2' are
    recognised and the pair is not scored as a duplicate unless the file hash is identical;
  * different document types (invoice vs quotation vs receipt) are never paired;
  * line items are compared: same amount but different goods lowers the score;
  * credit notes are NOT modelled as a document type yet (documented limitation), so a reversal
    posted as a separate document would surface as a candidate for a human to dismiss.
Candidates are suggestions for review ('possible duplicate'), not accusations.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from difflib import SequenceMatcher
from itertools import combinations

import pandas as pd

REVIEW_THRESHOLD = 0.60
_PART_RE = re.compile(r"(?:[-_ ]?(?:p|part|teil|rate|inst)[-_ ]?\d+)$", re.IGNORECASE)


@dataclass(frozen=True)
class DocRecord:
    id: int
    supplier_id: int
    doc_type: str
    supplier_ref: str | None
    currency: str
    total: Decimal
    purchase_date: date
    lines_signature: frozenset[tuple[str, str]]  # (normalised description, quantity)
    file_hashes: frozenset[str] = frozenset()


@dataclass(frozen=True)
class DuplicateMatch:
    doc_a: int
    doc_b: int
    score: float
    reasons: list[str] = field(default_factory=list)


def normalize_ref(ref: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (ref or "").lower())


def is_partial_reference(ref: str | None) -> bool:
    return bool(ref and _PART_RE.search(ref.strip()))


def score_pair(a: DocRecord, b: DocRecord) -> DuplicateMatch | None:
    if a.supplier_id != b.supplier_id or a.doc_type != b.doc_type:
        return None
    reasons: list[str] = []
    score = 0.0
    shared_files = a.file_hashes & b.file_hashes
    if shared_files:
        return DuplicateMatch(
            min(a.id, b.id), max(a.id, b.id), 1.0, ["identical attachment file (SHA-256)"]
        )
    ra, rb = normalize_ref(a.supplier_ref), normalize_ref(b.supplier_ref)
    partial = is_partial_reference(a.supplier_ref) or is_partial_reference(b.supplier_ref)
    if partial and ra != rb:
        return None  # instalments / partial payments of one invoice are legitimate repeats
    if ra and ra == rb:
        score += 0.35
        reasons.append("same supplier reference")
    elif ra and rb and SequenceMatcher(None, ra, rb).ratio() >= 0.85:
        score += 0.20
        reasons.append(f"similar supplier reference ({a.supplier_ref} / {b.supplier_ref})")
    if a.currency == b.currency and a.total == b.total:
        score += 0.25
        reasons.append("identical amount and currency")
    day_gap = abs((a.purchase_date - b.purchase_date).days)
    if day_gap <= 7:
        score += 0.10
        reasons.append(f"purchase dates {day_gap} day(s) apart")
    if a.lines_signature and a.lines_signature == b.lines_signature:
        score += 0.30
        reasons.append("identical line items and quantities")
    elif a.lines_signature and b.lines_signature:
        overlap = len(a.lines_signature & b.lines_signature) / len(
            a.lines_signature | b.lines_signature
        )
        if overlap >= 0.5:
            score += 0.15 * overlap
            reasons.append(f"{overlap:.0%} of line items overlap")
        else:
            score -= 0.10
            reasons.append("line items differ (lowers the score)")
    score = max(0.0, min(score, 0.99))
    if score < REVIEW_THRESHOLD:
        return None
    return DuplicateMatch(min(a.id, b.id), max(a.id, b.id), round(score, 3), reasons)


def find_candidates(records: list[DocRecord]) -> list[DuplicateMatch]:
    """Blocking keeps this near-linear: only documents sharing supplier AND (amount OR reference
    prefix OR a file hash) are compared pairwise."""
    blocks: dict[tuple, list[int]] = {}
    by_id = {r.id: r for r in records}
    for r in records:
        sup = r.supplier_id
        blocks.setdefault(("amt", sup, r.doc_type, r.currency, r.total), []).append(r.id)
        ref = normalize_ref(r.supplier_ref)
        if len(ref) >= 6:
            blocks.setdefault(("ref", sup, r.doc_type, ref[:4]), []).append(r.id)
        for h in r.file_hashes:
            blocks.setdefault(("file", h), []).append(r.id)
    seen: set[tuple[int, int]] = set()
    out: list[DuplicateMatch] = []
    for ids in blocks.values():
        if len(ids) < 2 or len(ids) > 200:
            continue
        for x, y in combinations(sorted(set(ids)), 2):
            if (x, y) in seen:
                continue
            seen.add((x, y))
            m = score_pair(by_id[x], by_id[y])
            if m:
                out.append(m)
    return sorted(out, key=lambda m: -m.score)


def records_from_frames(
    docs: pd.DataFrame, lines: pd.DataFrame, files: pd.DataFrame | None = None
) -> list[DocRecord]:
    sig: dict[int, set[tuple[str, str]]] = {}
    for did, desc, qty in lines[["document_id", "description", "quantity"]].itertuples(index=False):
        sig.setdefault(did, set()).add((re.sub(r"\s+", " ", desc.lower().strip()), str(qty)))
    hashes: dict[int, set[str]] = {}
    if files is not None and not files.empty:
        for did, h in files[["document_id", "sha256"]].itertuples(index=False):
            hashes.setdefault(did, set()).add(h)
    return [
        DocRecord(
            id=int(r.id),
            supplier_id=int(r.supplier_id),
            doc_type=r.doc_type,
            supplier_ref=r.supplier_ref,
            currency=r.currency,
            total=Decimal(r.total),
            purchase_date=r.purchase_date,
            lines_signature=frozenset(sig.get(int(r.id), set())),
            file_hashes=frozenset(hashes.get(int(r.id), set())),
        )
        for r in docs.itertuples(index=False)
    ]
