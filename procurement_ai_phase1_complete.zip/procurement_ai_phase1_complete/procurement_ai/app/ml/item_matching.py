"""Attribute-first item normalisation and matching (Model C).

Design: structured attributes (type, dimensions, class, material, standard, unit) are compared
BEFORE any text similarity. Text similarity alone never makes two items "technically comparable":
'Ball valve DN50' and 'Ball valve DN80' are textually near-identical but different products.
The parser is rule-based (regular expressions + synonym tables). It is deterministic and
explainable, it is not a trained language model, and it only knows the attribute families below.
Match levels:
  technically_comparable   all shared attributes equal and none missing (still needs standards,
                           tolerances, brand etc. to be confirmed by a human for real purchases)
  needs_review             no conflicts, but attributes present on one side only
  similar_description_only same product type but at least one attribute conflicts
  not_comparable           different product type or unit
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher

PRODUCT_TYPES = [
    "hex bolt",
    "ball valve",
    "steel plate",
    "ball bearing",
    "control cable",
    "safety gloves",
    "hydraulic oil",
    "torque wrench",
    "technical service",
    "engineering software license",
]
PRODUCT_SYNONYMS = {
    "hexagon bolt": "hex bolt",
    "hexagonal bolt": "hex bolt",
    "hex head bolt": "hex bolt",
    "plate": "steel plate",
    "protective gloves": "safety gloves",
    "hydraulic fluid": "hydraulic oil",
    "software license": "engineering software license",
}
MATERIAL_PATTERNS = [
    ("stainless 316", r"\b(?:stainless(?: steel)?\s*316|ss\s?316|inox\s*316|1\.4401)\b"),
    ("carbon steel", r"\bcarbon steel\b"),
    ("s235jr", r"\bs235jr\b"),
    ("s355j2", r"\bs355j2\b"),
    ("1.4301", r"\b1\.4301\b"),
    ("a4", r"\ba4\b"),
    ("a2", r"\ba2\b"),
    ("8.8", r"\b8\.8\b"),
]
# (attribute, regex, formatter) - applied in order; matched spans are removed from the text
_NUM = r"(\d+(?:\.\d+)?)"
ATTRIBUTE_PATTERNS: list[tuple[str, str]] = [
    ("dn", r"\bdn\s?(\d+)\b"),
    ("pn", r"\bpn\s?(\d+)\b"),
    ("cable", rf"\b(\d+)\s?x\s?{_NUM}\s?mm2\b"),
    ("thread", r"\bm(\d+)\s?(?:x\s?(\d+))?\b"),
    ("bearing", r"\b(\d{4})-?\s?(2rs|zz)\b"),
    ("thickness_mm", rf"\b{_NUM}\s?mm\b"),
    ("standard", r"\ben\s?(\d+)\b"),
    ("size", r"\bsize\s+(\w+)\b"),
    ("vg", r"\b(?:iso\s)?vg\s?(\d+)\b"),
    ("torque_nm", r"\b(\d+)\s?nm\b"),
]


@dataclass(frozen=True)
class NormalizedItem:
    raw: str
    product_type: str | None
    unit: str
    attributes: dict[str, str] = field(default_factory=dict)

    @property
    def key(self) -> str:
        attrs = ",".join(f"{k}={v}" for k, v in sorted(self.attributes.items()))
        return f"{self.product_type}|{self.unit}|{attrs}"


@dataclass(frozen=True)
class MatchResult:
    score: float
    level: str
    matched: list[str]
    conflicts: list[str]
    missing: list[str]
    text_similarity: float
    explanation: str


def _clean(text: str) -> str:
    t = text.lower()
    t = re.sub(r"[,;/()]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def normalize_item(description: str, unit: str = "pcs") -> NormalizedItem:
    text = _clean(description)
    for syn, canon in sorted(PRODUCT_SYNONYMS.items(), key=lambda kv: -len(kv[0])):
        text = re.sub(rf"\b{re.escape(syn)}\b", canon, text)
    product = next((p for p in PRODUCT_TYPES if p in text), None)
    if product:
        text = text.replace(product, " ", 1)
    attrs: dict[str, str] = {}
    for name, pat in ATTRIBUTE_PATTERNS:
        m = re.search(pat, text)
        if not m:
            continue
        g = [x for x in m.groups() if x]
        if name == "thread":
            attrs["thread"] = f"M{g[0]}"
            if len(g) > 1:
                attrs["length_mm"] = g[1]
        elif name == "cable":
            attrs["cores"], attrs["section_mm2"] = g[0], g[1]
        elif name == "bearing":
            attrs["designation"], attrs["seal"] = g[0], g[1].upper()
        elif name == "standard":
            attrs["standard"] = f"EN{g[0]}"
        else:
            attrs[name] = g[0]
        text = text[: m.start()] + " " + text[m.end() :]
    for canon, pat in MATERIAL_PATTERNS:
        m = re.search(pat, text)
        if m:
            attrs["material"] = canon
            text = text[: m.start()] + " " + text[m.end() :]
            break
    text = re.sub(r"\b(grade|thick|iso|size|stainless|steel)\b", " ", text)
    variant = re.sub(r"[^a-z0-9. ]", " ", text).split()
    variant = [w for w in variant if w not in {"x", "mm", "and", "the"}]
    if variant and product in {"technical service", "engineering software license"}:
        attrs["variant"] = " ".join(variant)
    return NormalizedItem(description, product, unit, attrs)


def text_similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, _clean(a), _clean(b)).ratio()


def match_items(a: NormalizedItem, b: NormalizedItem) -> MatchResult:
    sim = text_similarity(a.raw, b.raw)
    if a.product_type is None or b.product_type is None or a.product_type != b.product_type:
        return MatchResult(
            0.0,
            "not_comparable",
            [],
            [],
            [],
            sim,
            f"Product types differ or are unknown ({a.product_type} vs {b.product_type}).",
        )
    if a.unit != b.unit:
        return MatchResult(
            0.0,
            "not_comparable",
            [],
            [f"unit: {a.unit} vs {b.unit}"],
            [],
            sim,
            "Units of measure differ; prices are not comparable without conversion.",
        )
    matched, conflicts, missing = [], [], []
    for k in sorted(set(a.attributes) | set(b.attributes)):
        va, vb = a.attributes.get(k), b.attributes.get(k)
        if va is not None and vb is not None:
            (matched if va == vb else conflicts).append(k if va == vb else f"{k}: {va} vs {vb}")
        else:
            missing.append(f"{k} (only on {'A' if va is not None else 'B'})")
    total = len(matched) + len(conflicts) + len(missing)
    attr_score = 1.0 if total == 0 else (len(matched) + 0.5 * len(missing)) / total
    if conflicts:
        level, score = "similar_description_only", min(0.5, 0.25 + 0.25 * sim)
        why = "Same product type but attributes conflict: " + "; ".join(conflicts) + "."
    elif missing:
        level, score = "needs_review", 0.6 + 0.3 * attr_score * 0.9
        why = "No conflicts, but attributes are missing on one side: " + "; ".join(missing) + "."
    else:
        level, score = "technically_comparable", 0.9 + 0.1 * sim
        why = (
            f"Product type, unit and all {len(matched)} recognised attributes match. "
            "Standards, tolerances, brand and delivery terms still need confirmation."
        )
    return MatchResult(round(score, 3), level, matched, conflicts, missing, round(sim, 3), why)
