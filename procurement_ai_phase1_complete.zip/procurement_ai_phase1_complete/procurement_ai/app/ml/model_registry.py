"""Minimal file-based model registry: versioned joblib artefacts + JSON metadata."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import joblib

from app.config import get_settings


def _dir(name: str) -> Path:
    d = get_settings().model_dir / name
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_model(name: str, version: str, model: Any, metadata: dict[str, Any]) -> Path:
    d = _dir(name)
    path = d / f"{version}.joblib"
    joblib.dump(model, path)
    meta = {**metadata, "name": name, "version": version, "saved_at": datetime.now(UTC).isoformat()}
    (d / f"{version}.json").write_text(json.dumps(meta, indent=2, default=str))
    (d / "latest.json").write_text(json.dumps({"version": version}))
    return path


def latest_version(name: str) -> str | None:
    f = _dir(name) / "latest.json"
    return json.loads(f.read_text())["version"] if f.exists() else None


def load_latest(name: str) -> tuple[Any, dict[str, Any]] | None:
    """Return (model, metadata) or None if nothing has been trained yet.

    Only load artefacts produced by this application: joblib uses pickle, which must never be
    fed untrusted files.
    """
    version = latest_version(name)
    if version is None:
        return None
    d = _dir(name)
    path = d / f"{version}.joblib"
    if not path.exists():
        return None
    meta_path = d / f"{version}.json"
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    return joblib.load(path), meta
