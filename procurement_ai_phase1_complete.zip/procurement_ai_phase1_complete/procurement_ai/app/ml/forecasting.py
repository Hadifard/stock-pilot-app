"""Spend forecasting (Model A): seasonal ridge regression vs. simple baselines.

Aggregation: monthly spend in the reporting currency (a defensible level for ~3 years of history;
daily data is too noisy). The last, incomplete calendar month is dropped.
Evaluation: rolling-origin backtest on the last `test_months` months. Each prediction is made by
a model fitted ONLY on months strictly before the predicted month (no future leakage).
Models:
  naive_last        - last observed month
  seasonal_naive    - same month last year
  trailing_mean_3   - mean of the last three months
  seasonal_ridge    - Ridge on a linear trend + month-of-year indicators (candidate)
The recommended model is the one with the lowest backtest RMSE; the candidate is only used if
it beats every baseline. Prediction intervals are approximate: +/- 1.96 x backtest RMSE x sqrt(h).
A forecast is an estimate from history, not a guarantee of future spend or savings.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

from app.ml.evaluation import regression_metrics

MIN_MONTHS = 24


def monthly_series(frame: pd.DataFrame, today: date | None = None) -> pd.Series:
    """frame: columns month ('YYYY-MM') and spend. Returns a gap-filled monthly Series."""
    today = today or date.today()
    if frame.empty:
        return pd.Series(dtype=float)
    s = frame.set_index(pd.PeriodIndex(frame["month"], freq="M"))["spend"].astype(float)
    full = pd.period_range(s.index.min(), s.index.max(), freq="M")
    s = s.reindex(full, fill_value=0.0)
    current = pd.Period(today, freq="M")
    return s[s.index < current]


def sufficiency_warning(series: pd.Series) -> str | None:
    if len(series) < MIN_MONTHS:
        return (
            f"Only {len(series)} complete months of history; at least {MIN_MONTHS} are needed for "
            "a seasonal model. Showing no ML forecast."
        )
    if (series > 0).mean() < 0.8:
        return "More than 20 % of months have no spend; the forecast would be unreliable."
    return None


def _design(index: pd.PeriodIndex, origin: pd.Period) -> np.ndarray:
    t = np.array([(p - origin).n for p in index], dtype=float) / 12.0
    months = np.array([p.month for p in index])
    dummies = np.stack([(months == m).astype(float) for m in range(2, 13)], axis=1)
    return np.column_stack([t, dummies])


@dataclass
class SeasonalRidge:
    alpha: float = 1.0
    origin: pd.Period | None = None
    model: Ridge | None = None
    scale: float = 1.0

    def fit(self, series: pd.Series) -> SeasonalRidge:
        self.origin = series.index[0]
        self.scale = float(series.mean()) or 1.0
        self.model = Ridge(alpha=self.alpha).fit(
            _design(series.index, self.origin), series.to_numpy() / self.scale
        )
        return self

    def predict(self, index: pd.PeriodIndex) -> np.ndarray:
        assert self.model is not None and self.origin is not None
        return np.maximum(self.model.predict(_design(index, self.origin)) * self.scale, 0.0)


def _predict_baseline(name: str, history: pd.Series, target: pd.Period) -> float:
    if name == "naive_last":
        return float(history.iloc[-1])
    if name == "seasonal_naive":
        ly = target - 12
        return float(history.loc[ly]) if ly in history.index else float(history.iloc[-1])
    if name == "trailing_mean_3":
        return float(history.iloc[-3:].mean())
    raise ValueError(name)


@dataclass
class ForecastResult:
    history: pd.Series
    backtest: pd.DataFrame  # index month; columns actual + one per model
    metrics: dict[str, dict[str, float]]
    chosen: str
    forecast: pd.DataFrame  # columns: prediction, lower, upper
    warnings: list[str] = field(default_factory=list)
    model: SeasonalRidge | None = None


MODELS = ["naive_last", "seasonal_naive", "trailing_mean_3", "seasonal_ridge"]


def rolling_backtest(series: pd.Series, test_months: int = 6) -> pd.DataFrame:
    rows = {}
    for target in series.index[-test_months:]:
        hist = series[series.index < target]
        row = {"actual": float(series.loc[target])}
        for name in MODELS[:3]:
            row[name] = _predict_baseline(name, hist, target)
        ridge = SeasonalRidge().fit(hist)
        row["seasonal_ridge"] = float(ridge.predict(pd.PeriodIndex([target]))[0])
        rows[target] = row
    return pd.DataFrame.from_dict(rows, orient="index")


def forecast(series: pd.Series, horizon: int = 6, test_months: int = 6) -> ForecastResult:
    warn = sufficiency_warning(series)
    if warn:
        return ForecastResult(series, pd.DataFrame(), {}, "none", pd.DataFrame(), [warn])
    bt = rolling_backtest(series, test_months)
    metrics = {m: regression_metrics(bt["actual"], bt[m]) for m in MODELS}
    best = min(MODELS, key=lambda m: metrics[m]["rmse"])
    warnings = []
    if best != "seasonal_ridge":
        warnings.append(
            f"The seasonal ML model did not beat the baseline '{best}' on the backtest "
            f"(RMSE {metrics['seasonal_ridge']['rmse']:,.0f} vs {metrics[best]['rmse']:,.0f}); "
            "the baseline is used. Seasonality in this history may be weak."
        )
    future = pd.period_range(series.index[-1] + 1, periods=horizon, freq="M")
    ridge = SeasonalRidge().fit(series)
    if best == "seasonal_ridge":
        pred = ridge.predict(future)
    else:
        hist = series.copy()
        vals = []
        for p in future:
            v = _predict_baseline(best, hist, p)
            vals.append(v)
            hist = pd.concat([hist, pd.Series([v], index=pd.PeriodIndex([p]))])
        pred = np.array(vals)
    sigma = metrics[best]["rmse"]
    half = np.array([1.96 * sigma * math.sqrt(h + 1) for h in range(horizon)])
    fc = pd.DataFrame(
        {"prediction": pred, "lower": np.maximum(pred - half, 0), "upper": pred + half},
        index=future,
    )
    warnings.append(
        "Intervals are approximate (backtest RMSE scaled by sqrt(horizon)); "
        f"the backtest covers only {test_months} months."
    )
    return ForecastResult(series, bt, metrics, best, fc, warnings, ridge)
