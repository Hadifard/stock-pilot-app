"""Metric helpers shared by training scripts, tests and the UI."""

from __future__ import annotations

import math
from collections.abc import Iterable


def regression_metrics(y_true: Iterable[float], y_pred: Iterable[float]) -> dict[str, float]:
    yt, yp = list(y_true), list(y_pred)
    if not yt or len(yt) != len(yp):
        raise ValueError("y_true and y_pred must be non-empty and of equal length")
    errs = [a - b for a, b in zip(yt, yp, strict=True)]
    mae = sum(abs(e) for e in errs) / len(errs)
    rmse = math.sqrt(sum(e * e for e in errs) / len(errs))
    nz = [(a, b) for a, b in zip(yt, yp, strict=True) if a != 0]
    mape = sum(abs((a - b) / a) for a, b in nz) / len(nz) * 100 if nz else float("nan")
    return {"mae": mae, "rmse": rmse, "mape_pct": mape}


def classification_metrics(tp: int, fp: int, fn: int) -> dict[str, float]:
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"precision": precision, "recall": recall, "f1": f1, "tp": tp, "fp": fp, "fn": fn}


def confusion_counts(y_true: Iterable[bool], y_pred: Iterable[bool]) -> tuple[int, int, int]:
    tp = fp = fn = 0
    for t, p in zip(y_true, y_pred, strict=True):
        tp += t and p
        fp += (not t) and p
        fn += t and (not p)
    return tp, fp, fn
