"""Unusual-transaction detection (Model B): interpretable rules + Isolation Forest.

An alert means "this document looks unusual compared with comparable history and deserves a
human look". It is NOT evidence of fraud or misconduct. Training (`fit`) and inference (`score`)
are separate; the fitted artefact stores reference statistics, feature scales and parameters so
inference never re-estimates anything from the data being scored.

Document features (all computed from line items and the document header):
  price_hi / price_lo : max / min of ln(net unit price in EUR / median of comparable items)
  qty_hi              : max of ln(quantity / 99th-percentile quantity of comparable items), floored at 0
  log_total           : ln(1 + total in EUR)
  near_threshold      : closeness (0..1) to an approval threshold from below, within 10 %
  pair_rarity         : 1 / (1 + number of historical documents of this supplier-project pair)
  n_lines             : number of line items
Comparable items = same normalised key (product type, unit, attributes); if fewer than
MIN_GROUP such lines exist, the product type + unit group is used; otherwise the feature is 0
and the document carries the factor "insufficient comparables".
Rules (each reported by name): price_high (>2x median), price_low (<0.4x), quantity_high (>3x the 99th percentile),
near_approval_threshold (0.5-7 % below a threshold), repeated_amount (>=3 same supplier+amount
in 90 days), budget_crossing (cumulative project spend first exceeds its budget).
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from datetime import UTC, datetime

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

from app.ml.item_matching import normalize_item

MIN_GROUP = 8
THRESHOLDS_EUR = (10_000.0, 50_000.0)
FEATURES = [
    "price_hi",
    "price_lo",
    "qty_hi",
    "log_total",
    "near_threshold",
    "pair_rarity",
    "n_lines",
]
FEATURE_TEXT = {
    "price_hi": "unit price far above comparable purchases",
    "price_lo": "unit price far below comparable purchases",
    "qty_hi": "quantity far above comparable purchases",
    "log_total": "document total unusually large",
    "near_threshold": "total just below an approval threshold",
    "pair_rarity": "rare supplier/project combination",
    "n_lines": "unusual number of line items",
}
MODEL_PARAMS = dict(n_estimators=200, max_samples="auto", contamination="auto", random_state=42)
ALERT_QUANTILE = 0.985


@dataclass
class AnomalyModel:
    version: str
    trained_at: str
    n_train_docs: int
    iforest: IsolationForest
    ref_price: dict[str, tuple[float, int]]
    ref_qty: dict[str, tuple[float, int]]
    pair_counts: dict[tuple[int, int], int]
    feat_median: dict[str, float]
    feat_mad: dict[str, float]
    score_min: float
    score_max: float
    alert_threshold: float
    params: dict = field(default_factory=dict)


def _keys(df: pd.DataFrame) -> pd.DataFrame:
    """Add 'key' and 'group' columns by normalising each distinct description once."""
    cache: dict[tuple[str, str], tuple[str, str]] = {}
    keys, groups = [], []
    for desc, unit in zip(df["description"], df["unit"], strict=True):
        k = (desc, unit)
        if k not in cache:
            n = normalize_item(desc, unit)
            cache[k] = (n.key, f"{n.product_type}|{unit}")
        keys.append(cache[k][0])
        groups.append(cache[k][1])
    out = df.copy()
    out["key"], out["group"] = keys, groups
    return out


def _reference(
    lines: pd.DataFrame, col: str, quantile: float = 0.5
) -> dict[str, tuple[float, int]]:
    """Per comparable group: (reference value = quantile of `col`, sample count)."""
    ref: dict[str, tuple[float, int]] = {}
    for column in ("key", "group"):
        g = lines.groupby(column)[col]
        q, n = g.quantile(quantile), g.count()
        for k in q.index:
            ref[str(k)] = (float(q[k]), int(n[k]))
    return ref


def _ratio(row_key: str, row_group: str, value: float, ref: dict[str, tuple[float, int]]):
    for k in (row_key, row_group):
        if k in ref and ref[k][1] >= MIN_GROUP and ref[k][0] > 0:
            return math.log(value / ref[k][0]), True
    return 0.0, False


def build_features(lines: pd.DataFrame, docs: pd.DataFrame, model_ref: dict) -> pd.DataFrame:
    """Compute document features using reference statistics from `model_ref`."""
    ln = _keys(lines)
    pr, qr = [], []
    for k, g, p, q in zip(ln["key"], ln["group"], ln["price_eur"], ln["quantity"], strict=True):
        pr.append(_ratio(k, g, float(p), model_ref["ref_price"]))
        qr.append(_ratio(k, g, float(q), model_ref["ref_qty"]))
    ln["lp"] = [x[0] for x in pr]
    ln["lq"] = [x[0] for x in qr]
    ln["has_ref"] = [x[1] for x in pr]
    agg = ln.groupby("document_id").agg(
        price_hi=("lp", "max"),
        price_lo=("lp", "min"),
        qty_hi=("lq", "max"),
        n_lines=("lp", "size"),
        has_ref=("has_ref", "all"),
    )
    d = docs.set_index("document_id").join(agg, how="inner")
    d["price_hi"] = d["price_hi"].clip(lower=0)
    d["price_lo"] = d["price_lo"].clip(upper=0)
    d["qty_hi"] = d["qty_hi"].clip(lower=0)
    d["log_total"] = np.log1p(d["total_eur"].astype(float))
    tot = d["total_eur"].to_numpy(dtype=float)
    thr = np.array(THRESHOLDS_EUR)[:, None]
    gaps = (thr - tot[None, :]) / thr  # relative distance below each threshold (>0 = below)
    closeness = np.where((gaps > 0) & (gaps <= 0.10), 1 - gaps / 0.10, 0.0)
    d["near_threshold"] = closeness.max(axis=0)
    pc = model_ref["pair_counts"]
    d["pair_rarity"] = [
        1.0 / (1 + pc.get((int(s), int(p)), 0))
        for s, p in zip(d["supplier_id"], d["project_id"], strict=True)
    ]
    d["gap_pct"] = np.where(gaps > 0, gaps, np.inf).min(axis=0)
    return d


def fit(
    lines: pd.DataFrame, docs: pd.DataFrame, seed: int = 42, version: str | None = None
) -> AnomalyModel:
    """Fit reference statistics and the Isolation Forest on (historical) documents."""
    ln = _keys(lines)
    ref = {
        "ref_price": _reference(ln, "price_eur"),
        "ref_qty": _reference(ln, "quantity", 0.99),
        "pair_counts": {
            (int(s), int(p)): int(n)
            for (s, p), n in docs.groupby(["supplier_id", "project_id"]).size().items()
        },
    }
    feats = build_features(lines, docs, ref)
    X = feats[FEATURES].to_numpy(dtype=float)
    params = {**MODEL_PARAMS, "random_state": seed}
    forest = IsolationForest(**params).fit(X)
    raw = -forest.score_samples(X)
    smin, smax = float(raw.min()), float(raw.max())
    norm = (raw - smin) / (smax - smin + 1e-12)
    med = {f: float(np.median(feats[f])) for f in FEATURES}
    mad = {f: float(np.median(np.abs(feats[f] - med[f]))) * 1.4826 for f in FEATURES}
    stamp = datetime.now(UTC)
    return AnomalyModel(
        version=version or f"iforest-{stamp:%Y%m%d%H%M%S}",
        trained_at=stamp.isoformat(),
        n_train_docs=len(feats),
        iforest=forest,
        ref_price=ref["ref_price"],
        ref_qty=ref["ref_qty"],
        pair_counts=ref["pair_counts"],
        feat_median=med,
        feat_mad=mad,
        score_min=smin,
        score_max=smax,
        alert_threshold=float(np.quantile(norm, ALERT_QUANTILE)),
        params={k: str(v) for k, v in params.items()},
    )


def _rules(row: pd.Series) -> list[str]:
    out = []
    if row["price_hi"] > math.log(2.0):
        out.append("price_high")
    if row["price_lo"] < math.log(0.4):
        out.append("price_low")
    if row["qty_hi"] > math.log(3.0):
        out.append("quantity_high")
    if 0.005 <= row["gap_pct"] <= 0.07:
        out.append("near_approval_threshold")
    return out


def _context_rules(d: pd.DataFrame, extra: pd.DataFrame | None) -> dict[int, list[str]]:
    """Rules needing cross-document context: repeated amounts and budget crossings."""
    out: dict[int, list[str]] = {}
    if extra is None or extra.empty:
        return out
    ex = extra.sort_values("purchase_date")
    for (_, _, _), g in ex.groupby(["supplier_id", "currency", "total"]):
        if len(g) < 3:
            continue
        dates = pd.to_datetime(g["purchase_date"]).reset_index(drop=True)
        ids = g["document_id"].reset_index(drop=True)
        for i in range(len(g)):
            window = ((dates - dates[i]).abs().dt.days <= 90).sum()
            if window >= 3:
                out.setdefault(int(ids[i]), []).append("repeated_amount")
    spend = ex[ex["counts_toward_budget"]].copy()
    spend["cum"] = spend.groupby("project_id")["total_eur"].cumsum()
    crossing = spend[
        (spend["cum"] > spend["budget_eur"])
        & (spend["cum"] - spend["total_eur"] <= spend["budget_eur"])
    ]
    for did in crossing["document_id"]:
        out.setdefault(int(did), []).append("budget_crossing")
    return out


def score(
    model: AnomalyModel,
    lines: pd.DataFrame,
    docs: pd.DataFrame,
    context: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Return one row per document: iforest_score (0-1), rules, factors, flagged, severity."""
    ref = {"ref_price": model.ref_price, "ref_qty": model.ref_qty, "pair_counts": model.pair_counts}
    feats = build_features(lines, docs, ref)
    raw = -model.iforest.score_samples(feats[FEATURES].to_numpy(dtype=float))
    feats["iforest_score"] = np.clip(
        (raw - model.score_min) / (model.score_max - model.score_min + 1e-12), 0, 1
    )
    ctx = _context_rules(feats, context)
    rules, factors = [], []
    for did, row in feats.iterrows():
        r = _rules(row) + ctx.get(int(did), [])
        rules.append(r)
        f = []
        for name in FEATURES:
            scale = max(model.feat_mad[name], 0.05)
            z = (row[name] - model.feat_median[name]) / scale
            if abs(z) >= 3 and name not in ("n_lines", "pair_rarity"):
                f.append(
                    {"feature": name, "meaning": FEATURE_TEXT[name], "robust_z": round(float(z), 1)}
                )
        f.sort(key=lambda x: -abs(x["robust_z"]))
        if not row.get("has_ref", True):
            f.append(
                {
                    "feature": "comparables",
                    "meaning": "insufficient comparable history for some lines",
                    "robust_z": 0.0,
                }
            )
        factors.append(f[:4])
    feats["rules"], feats["factors"] = rules, factors
    feats["model_flag"] = feats["iforest_score"] >= model.alert_threshold
    feats["flagged"] = feats["model_flag"] | feats["rules"].map(bool)
    feats["severity"] = np.where(
        (feats["rules"].map(len) >= 2) | (feats["iforest_score"] >= 0.9), "high", "review"
    )
    return feats


def dumps_list(x) -> str:
    return json.dumps(x, ensure_ascii=True)
