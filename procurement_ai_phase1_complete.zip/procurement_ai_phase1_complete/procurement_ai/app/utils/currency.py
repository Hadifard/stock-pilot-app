"""Decimal-safe money helpers.

Rounding policy (documented in docs/calculation_rules.md):
* All arithmetic uses decimal.Decimal, never float.
* Amounts are rounded with ROUND_HALF_UP to the currency's minor-unit exponent.
* Rounding happens at line level (net, tax) and the document totals are sums of rounded lines.
"""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

# Minor-unit exponents that differ from the default of 2.
CURRENCY_EXPONENTS: dict[str, int] = {"JPY": 0, "KRW": 0, "KWD": 3, "BHD": 3}
SUPPORTED_CURRENCIES: tuple[str, ...] = (
    "EUR",
    "USD",
    "GBP",
    "CHF",
    "PLN",
    "AED",
    "CNY",
)


def to_decimal(value: object) -> Decimal:
    """Convert str/int/Decimal to Decimal. Floats are refused to avoid binary rounding errors."""
    if isinstance(value, Decimal):
        return value
    if isinstance(value, float):
        raise TypeError("Floats are not accepted for monetary values; use str or Decimal.")
    try:
        return Decimal(str(value).strip().replace(",", "."))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"Not a valid number: {value!r}") from exc


def currency_exponent(currency: str) -> int:
    return CURRENCY_EXPONENTS.get(currency.upper(), 2)


def quantize_money(amount: Decimal, currency: str) -> Decimal:
    exp = Decimal(1).scaleb(-currency_exponent(currency))
    return amount.quantize(exp, rounding=ROUND_HALF_UP)


def quantize_rate(rate: Decimal) -> Decimal:
    """Rates (tax, discount fractions) keep 4 decimal places."""
    return rate.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)


def convert(amount: Decimal, rate_to_reporting: Decimal, reporting_currency: str) -> Decimal:
    """Convert an amount into the reporting currency with an explicit rate."""
    return quantize_money(amount * rate_to_reporting, reporting_currency)
