"""Timezone-aware time helpers. All stored timestamps are UTC; display uses the configured zone."""

from __future__ import annotations

from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from app.config import get_settings


def utcnow() -> datetime:
    return datetime.now(UTC)


def ensure_utc(value: datetime) -> datetime:
    """Return an aware UTC datetime. Naive values are rejected to avoid silent deadline bugs."""
    if value.tzinfo is None:
        raise ValueError("Naive datetime is not allowed; supply a timezone-aware value.")
    return value.astimezone(UTC)


def to_local(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return ensure_utc(value).astimezone(ZoneInfo(get_settings().timezone))


def format_local(value: datetime | None) -> str:
    local = to_local(value)
    return local.strftime("%Y-%m-%d %H:%M %Z") if local else "-"
