"""Engine and session management."""

from __future__ import annotations

import logging
from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import DDL, Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from app.config import get_settings
from app.database.base import Base
from app.database.models import AuditEvent

log = logging.getLogger(__name__)

_engine: Engine | None = None
_factory: sessionmaker[Session] | None = None

_NO_UPDATE = DDL(
    "CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_events "
    "BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END"
)
_NO_DELETE = DDL(
    "CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_events "
    "BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END"
)


def make_engine(url: str) -> Engine:
    engine = create_engine(url, future=True)
    if url.startswith("sqlite"):

        @event.listens_for(engine, "connect")
        def _pragmas(dbapi_conn, _record):  # pragma: no cover - trivial
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.close()

        event.listen(AuditEvent.__table__, "after_create", _NO_UPDATE.execute_if(dialect="sqlite"))
        event.listen(AuditEvent.__table__, "after_create", _NO_DELETE.execute_if(dialect="sqlite"))
    return engine


def init_engine(url: str | None = None) -> Engine:
    """(Re)bind the global engine. Tests call this with a temporary database URL."""
    global _engine, _factory
    _engine = make_engine(url or get_settings().database_url)
    _factory = sessionmaker(_engine, expire_on_commit=False, future=True)
    return _engine


def get_engine() -> Engine:
    return _engine if _engine is not None else init_engine()


def create_all() -> None:
    Base.metadata.create_all(get_engine())


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope: commit on success, roll back on any exception."""
    get_engine()
    assert _factory is not None
    session = _factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
