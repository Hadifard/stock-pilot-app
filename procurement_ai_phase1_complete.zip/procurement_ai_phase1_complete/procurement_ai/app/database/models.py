"""SQLAlchemy models for Phase 1 (SQLite). Designed to port to PostgreSQL in Phase 2."""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    Date,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, ScaledDecimal, UTCDateTime, utcnow


class OrgUnit(Base):
    __tablename__ = "org_units"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    kind: Mapped[str] = mapped_column(String(20))  # "domestic" | "international"
    country: Mapped[str] = mapped_column(String(2))


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(60), unique=True)
    full_name: Mapped[str] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(30))
    org_unit_id: Mapped[int] = mapped_column(ForeignKey("org_units.id"))
    password_hash: Mapped[str] = mapped_column(String(300), default="!")  # "!" = login disabled
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    org_unit: Mapped[OrgUnit] = relationship()


class CostCenter(Base):
    __tablename__ = "cost_centers"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    org_unit_id: Mapped[int] = mapped_column(ForeignKey("org_units.id"))


class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(160))
    org_unit_id: Mapped[int] = mapped_column(ForeignKey("org_units.id"))
    manager_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    budget: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    budget_currency: Mapped[str] = mapped_column(String(3), default="EUR")


class Supplier(Base):
    __tablename__ = "suppliers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), unique=True)
    country: Mapped[str] = mapped_column(String(2))
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=True)


class ExchangeRate(Base):
    """Rate = units of reporting currency per 1 unit of `currency`, valid from effective_date."""

    __tablename__ = "exchange_rates"
    __table_args__ = (UniqueConstraint("currency", "effective_date"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    currency: Mapped[str] = mapped_column(String(3), index=True)
    reporting_currency: Mapped[str] = mapped_column(String(3))
    rate: Mapped[Decimal] = mapped_column(ScaledDecimal)
    effective_date: Mapped[date] = mapped_column(Date)
    source: Mapped[str] = mapped_column(String(60), default="synthetic")
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=True)


class PurchaseDocument(Base):
    __tablename__ = "purchase_documents"
    __table_args__ = (
        Index("ix_docs_status", "status"),
        Index("ix_docs_employee", "employee_id"),
        Index("ix_docs_project", "project_id"),
        Index("ix_docs_supplier", "supplier_id"),
        Index("ix_docs_purchase_date", "purchase_date"),
        Index("ix_docs_supplier_ref", "supplier_id", "supplier_ref"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    doc_number: Mapped[str] = mapped_column(String(30), unique=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    org_unit_id: Mapped[int] = mapped_column(ForeignKey("org_units.id"))
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"))
    cost_center_id: Mapped[int] = mapped_column(ForeignKey("cost_centers.id"))
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"))
    doc_type: Mapped[str] = mapped_column(String(30))  # invoice|quotation|purchase_request|receipt
    supplier_ref: Mapped[str | None] = mapped_column(String(60))
    purchase_date: Mapped[date] = mapped_column(Date)
    currency: Mapped[str] = mapped_column(String(3))
    description: Mapped[str] = mapped_column(Text, default="")
    business_purpose: Mapped[str] = mapped_column(Text, default="")
    payment_method: Mapped[str] = mapped_column(String(30), default="bank_transfer")
    shipping: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    other_charges: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    shipping_tax_rate: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    subtotal: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    discount_total: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    tax_total: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    total: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    fx_rate: Mapped[Decimal | None] = mapped_column(ScaledDecimal)
    reporting_currency: Mapped[str] = mapped_column(String(3), default="EUR")
    total_reporting: Mapped[Decimal | None] = mapped_column(ScaledDecimal)
    status: Mapped[str] = mapped_column(String(30), default="draft")
    status_before_correction: Mapped[str | None] = mapped_column(String(30))
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    submitted_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    decided_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    decided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decision_note: Mapped[str | None] = mapped_column(Text)

    lines: Mapped[list[LineItem]] = relationship(
        back_populates="document", cascade="all, delete-orphan", order_by="LineItem.line_no"
    )
    attachments: Mapped[list[Attachment]] = relationship(back_populates="document")
    employee: Mapped[User] = relationship(foreign_keys=[employee_id])
    project: Mapped[Project] = relationship()
    supplier: Mapped[Supplier] = relationship()
    cost_center: Mapped[CostCenter] = relationship()
    org_unit: Mapped[OrgUnit] = relationship()


class LineItem(Base):
    __tablename__ = "line_items"
    __table_args__ = (Index("ix_lines_document", "document_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("purchase_documents.id"))
    line_no: Mapped[int] = mapped_column(Integer)
    description: Mapped[str] = mapped_column(String(300))
    category: Mapped[str] = mapped_column(String(60), default="general")
    quantity: Mapped[Decimal] = mapped_column(ScaledDecimal)
    unit: Mapped[str] = mapped_column(String(20), default="pcs")
    unit_price: Mapped[Decimal] = mapped_column(ScaledDecimal)
    discount_rate: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    tax_rate: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    discount_amount: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    net_amount: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    tax_amount: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    line_total: Mapped[Decimal] = mapped_column(ScaledDecimal, default=Decimal("0"))
    document: Mapped[PurchaseDocument] = relationship(back_populates="lines")


class Attachment(Base):
    __tablename__ = "attachments"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("purchase_documents.id"), index=True)
    stored_name: Mapped[str] = mapped_column(String(80))
    original_name: Mapped[str] = mapped_column(String(200))
    mime_type: Mapped[str] = mapped_column(String(80))
    size_bytes: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    uploaded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    document: Mapped[PurchaseDocument] = relationship(back_populates="attachments")


class CorrectionRequest(Base):
    __tablename__ = "correction_requests"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("purchase_documents.id"), index=True)
    requested_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    requested_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    reason: Mapped[str] = mapped_column(Text)
    original_json: Mapped[str] = mapped_column(Text)
    proposed_json: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|approved|rejected
    deadline_exception: Mapped[bool] = mapped_column(Boolean, default=False)
    exception_reason: Mapped[str | None] = mapped_column(Text)
    decided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    decision_note: Mapped[str | None] = mapped_column(Text)


class AuditEvent(Base):
    """Append-only, hash-chained audit record (see app/security/audit_log.py)."""

    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(UTCDateTime)
    actor_id: Mapped[int | None] = mapped_column(Integer)
    action: Mapped[str] = mapped_column(String(60), index=True)
    entity_type: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[int | None] = mapped_column(Integer)
    payload_json: Mapped[str] = mapped_column(Text, default="{}")
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64))
    __table_args__ = (Index("ix_audit_entity", "entity_type", "entity_id"),)


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    message: Mapped[str] = mapped_column(String(400))
    document_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_documents.id"))
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class AnomalyAlert(Base):
    """An 'unusual transaction' flagged for human review. Not evidence of fraud or misconduct."""

    __tablename__ = "anomaly_alerts"
    __table_args__ = (
        UniqueConstraint("document_id", "model_version"),
        Index("ix_alert_status", "status"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("purchase_documents.id"), index=True)
    model_version: Mapped[str] = mapped_column(String(60))
    score: Mapped[float] = mapped_column(Float)  # 0..1, higher = more unusual (model estimate)
    severity: Mapped[str] = mapped_column(String(10))  # review | high
    rules_json: Mapped[str] = mapped_column(Text, default="[]")
    factors_json: Mapped[str] = mapped_column(Text, default="[]")
    status: Mapped[str] = mapped_column(String(12), default="new")  # new | reviewed
    disposition: Mapped[str | None] = mapped_column(String(30))
    review_note: Mapped[str | None] = mapped_column(Text)
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class DuplicateCandidate(Base):
    __tablename__ = "duplicate_candidates"
    __table_args__ = (UniqueConstraint("doc_a_id", "doc_b_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    doc_a_id: Mapped[int] = mapped_column(ForeignKey("purchase_documents.id"), index=True)
    doc_b_id: Mapped[int] = mapped_column(ForeignKey("purchase_documents.id"), index=True)
    score: Mapped[float] = mapped_column(Float)
    reasons_json: Mapped[str] = mapped_column(Text, default="[]")
    status: Mapped[str] = mapped_column(String(12), default="new")
    disposition: Mapped[str | None] = mapped_column(String(30))
    review_note: Mapped[str | None] = mapped_column(Text)
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class ItemMatchDecision(Base):
    """Human confirmation of whether two item descriptions are technically equivalent."""

    __tablename__ = "item_match_decisions"
    __table_args__ = (UniqueConstraint("text_a", "text_b"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    text_a: Mapped[str] = mapped_column(String(300))
    text_b: Mapped[str] = mapped_column(String(300))
    decision: Mapped[str] = mapped_column(String(20))  # equivalent | not_equivalent
    decided_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class ExtractionRecord(Base):
    """History of document/audio extraction runs and of the values the employee chose."""

    __tablename__ = "extraction_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    document_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_documents.id"))
    source_type: Mapped[str] = mapped_column(String(20))  # pdf | image | audio | text
    filename: Mapped[str] = mapped_column(String(200))
    sha256: Mapped[str] = mapped_column(String(64))
    method: Mapped[str] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(12))  # ok | partial | failed
    raw_text: Mapped[str] = mapped_column(Text, default="")
    result_json: Mapped[str] = mapped_column(Text, default="{}")
    resolutions_json: Mapped[str | None] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class SyntheticLabel(Base):
    """Ground truth injected by the synthetic generator. Never used as a model feature."""

    __tablename__ = "synthetic_labels"
    __table_args__ = (Index("ix_label_kind", "entity_type", "kind"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(10))  # document | line
    entity_id: Mapped[int] = mapped_column(Integer)
    kind: Mapped[str] = mapped_column(String(30))
    value: Mapped[str] = mapped_column(String(300), default="")
