"""Declarative base and custom column types."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy import BigInteger, DateTime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.types import TypeDecorator

SCALE = 10_000  # four decimal places


class Base(DeclarativeBase):
    pass


class ScaledDecimal(TypeDecorator):
    """Store a Decimal as an integer scaled by 10^4.

    SQLite has no exact decimal type; REAL would introduce binary rounding. Integers keep
    values exact and still allow SUM() in SQL.
    """

    impl = BigInteger
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        return int((Decimal(value) * SCALE).to_integral_value())

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return Decimal(value) / SCALE


class UTCDateTime(TypeDecorator):
    """Store timezone-aware datetimes as naive UTC and return aware UTC datetimes."""

    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("Naive datetime refused; use timezone-aware values.")
        return value.astimezone(UTC).replace(tzinfo=None)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return value.replace(tzinfo=UTC)


def utcnow() -> datetime:
    return datetime.now(UTC)
