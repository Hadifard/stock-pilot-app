"""Reproducible SYNTHETIC data. Nothing here represents real spend, suppliers or market prices.

Synthetic documents are written directly (not via the workflow services) for speed; they carry
is_synthetic=True and do not have per-event audit histories. The seed run itself is audited.
"""

from __future__ import annotations

import random
import zlib
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import (
    CostCenter,
    ExchangeRate,
    LineItem,
    OrgUnit,
    Project,
    PurchaseDocument,
    Supplier,
    SyntheticLabel,
    User,
)
from app.security import audit_log
from app.security.authorization import Role
from app.security.hashing import hash_password
from app.services.validation_service import DocumentInput, LineInput, calculate
from app.utils.currency import quantize_money

DEMO_ACCOUNTS = [
    # username, full name, role, org unit index
    ("employee.demo", "Erika Demo (Purchasing)", Role.EMPLOYEE, 0),
    ("employee2.demo", "Jonas Demo (Purchasing, other unit)", Role.EMPLOYEE, 1),
    ("manager.demo", "Marta Demo (Purchasing Manager)", Role.MANAGER, 0),
    ("finance.demo", "Felix Demo (Finance)", Role.FINANCE, 0),
    ("pm.demo", "Paula Demo (Project Manager)", Role.PROJECT_MANAGER, 0),
    ("auditor.demo", "Aiden Demo (Auditor)", Role.AUDITOR, 0),
    ("admin.demo", "Ada Demo (Administrator)", Role.ADMIN, 0),
]


@dataclass(frozen=True)
class Mode:
    employees: int
    projects: int
    suppliers: int
    documents: int


MODES = {
    "tiny": Mode(20, 12, 40, 300),
    "small": Mode(60, 30, 150, 4000),
    "full": Mode(140, 80, 500, 50000),
}

SUBSIDIARY_CITIES = [
    "Nuremberg",
    "Munich",
    "Hamburg",
    "Berlin",
    "Stuttgart",
    "Dresden",
    "Leipzig",
    "Bremen",
    "Essen",
    "Dortmund",
    "Hannover",
    "Mannheim",
    "Augsburg",
    "Kassel",
    "Rostock",
    "Erfurt",
    "Kiel",
]
INTERNATIONAL = [
    ("INT-US", "Office USA (synthetic)", "US"),
    ("INT-AE", "Office UAE (synthetic)", "AE"),
    ("INT-PL", "Office Poland (synthetic)", "PL"),
]

# EUR base price, unit, category, description template
# category, unit, EUR base price, [text templates; first = canonical], attribute choices.
# Alternative templates simulate how different suppliers phrase the same item.
CATALOG = [
    (
        "Fasteners",
        "pcs",
        0.35,
        ["Hex bolt M{a} x {b} {m}", "Hexagon bolt M{a}x{b} grade {m}", "M{a}x{b} hex bolt {m}"],
        {"a": [8, 10, 12, 16, 20], "b": [30, 50, 80], "m": ["A2", "A4", "8.8"]},
    ),
    (
        "Valves",
        "pcs",
        180.0,
        [
            "Ball valve DN{a} PN{b} {m}",
            "{m} ball valve, DN {a}, PN {b}",
            "Ball valve PN{b} DN{a} ({m})",
        ],
        {"a": [25, 50, 80, 100], "b": [16, 40], "m": ["stainless 316", "carbon steel"]},
    ),
    (
        "Steel",
        "kg",
        1.4,
        ["Steel plate {a} mm {m}", "{m} steel plate, {a}mm thick"],
        {"a": [5, 10, 20, 30], "m": ["S235JR", "S355J2", "1.4301"]},
    ),
    (
        "Bearings",
        "pcs",
        24.0,
        ["Ball bearing {m}-{a}", "Ball bearing {m} {a}"],
        {"a": ["2RS", "ZZ"], "m": ["6204", "6206", "6305", "6310"]},
    ),
    (
        "Electrical",
        "m",
        2.6,
        ["Control cable {a}x{b} mm2", "Control cable {a} x {b} mm2"],
        {"a": [3, 5, 7, 12], "b": [0.75, 1.5, 2.5]},
    ),
    (
        "Safety",
        "pcs",
        12.0,
        ["Safety gloves EN388 size {a}", "Protective gloves EN 388 size {a}"],
        {"a": [8, 9, 10, 11]},
    ),
    (
        "Consumables",
        "l",
        6.5,
        ["Hydraulic oil ISO VG {a}", "Hydraulic fluid VG{a}"],
        {"a": [32, 46, 68]},
    ),
    (
        "Tools",
        "pcs",
        95.0,
        ["Torque wrench {a} Nm", "Torque wrench {a}Nm"],
        {"a": [40, 100, 200, 350]},
    ),
    (
        "Services",
        "h",
        78.0,
        ["Technical service {a}"],
        {"a": ["inspection", "calibration", "commissioning"]},
    ),
    ("Software", "lot", 450.0, ["Engineering software license {a}"], {"a": ["CAD", "FEM", "PLM"]}),
]
APPROVAL_THRESHOLDS_EUR = (10_000, 50_000)
CURRENCY_BASE = {
    "EUR": "1.0000",
    "USD": "0.9200",
    "GBP": "1.1700",
    "CHF": "1.0400",
    "PLN": "0.2300",
    "AED": "0.2500",
    "CNY": "0.1300",
}
TAX_BY_CCY = {
    "EUR": "0.19",
    "USD": "0.00",
    "GBP": "0.20",
    "CHF": "0.081",
    "PLN": "0.23",
    "AED": "0.05",
    "CNY": "0.13",
}
WORDS_A = [
    "Nord",
    "Alpen",
    "Rhein",
    "Stahl",
    "Metall",
    "Tech",
    "Prima",
    "Global",
    "Euro",
    "Inter",
    "Delta",
    "Omega",
    "Vector",
    "Ferro",
    "Hydro",
    "Electro",
    "Mecha",
    "Pro",
    "Uni",
    "Terra",
]
WORDS_B = [
    "Werke",
    "Industrie",
    "Systems",
    "Supply",
    "Trading",
    "Components",
    "Solutions",
    "Armaturen",
    "Antriebe",
    "Handel",
    "Logistik",
    "Engineering",
]
STATUS_WEIGHTS = [
    ("draft", 3),
    ("submitted", 7),
    ("under_review", 6),
    ("resubmitted", 2),
    ("approved", 72),
    ("rejected", 7),
    ("cancelled", 3),
]


def seed_reference_data(
    session: Session,
    mode_name: str = "small",
    seed: int = 42,
    demo_password: str = "demo-only-change-me",
) -> None:
    """Create org units, users, cost centers, projects, suppliers and exchange rates."""
    mode = MODES[mode_name]
    rng = random.Random(seed)
    units: list[OrgUnit] = []
    for i, city in enumerate(SUBSIDIARY_CITIES, start=1):
        units.append(
            OrgUnit(
                code=f"SUB-{i:02d}",
                name=f"Subsidiary {i:02d} {city} (synthetic)",
                kind="domestic",
                country="DE",
            )
        )
    for code, name, country in INTERNATIONAL:
        units.append(OrgUnit(code=code, name=name, kind="international", country=country))
    session.add_all(units)
    session.flush()

    pw_hash = hash_password(demo_password)  # one hash is enough for the demo accounts
    users: list[User] = []
    for username, name, role, unit_idx in DEMO_ACCOUNTS:
        u = User(
            username=username,
            full_name=name,
            role=role.value,
            org_unit_id=units[unit_idx].id,
            password_hash=pw_hash,
        )
        session.add(u)
        users.append(u)
    first = ["Anna", "Ben", "Clara", "David", "Elif", "Frank", "Gina", "Hugo", "Ines", "Jan"]
    last = [
        "Schmidt",
        "Weber",
        "Koch",
        "Bauer",
        "Wolf",
        "Neumann",
        "Kraus",
        "Vogel",
        "Hahn",
        "Roth",
    ]
    for i in range(mode.employees):
        unit = units[i % len(units)]
        users.append(
            User(
                username=f"synthetic.employee{i:03d}",
                full_name=f"{rng.choice(first)} {rng.choice(last)} (synthetic)",
                role=Role.EMPLOYEE.value,
                org_unit_id=unit.id,
                password_hash="!",
            )
        )
    session.add_all(users[len(DEMO_ACCOUNTS) :])
    session.flush()

    for unit in units:
        for n in range(1, 4):
            session.add(
                CostCenter(
                    code=f"{unit.code}-CC{n}",
                    name=f"Cost center {n} {unit.code}",
                    org_unit_id=unit.id,
                )
            )
    pm_demo = next(u for u in users if u.username == "pm.demo")
    for i in range(mode.projects):
        unit = units[i % len(units)]
        # first projects of the first unit are managed by pm.demo so the demo has a scoped PM view
        manager = pm_demo if i % len(units) == 0 else None
        session.add(
            Project(
                code=f"PRJ-{i + 1:03d}",
                name=f"Project {i + 1:03d} (synthetic)",
                org_unit_id=unit.id,
                manager_id=manager.id if manager else None,
                budget=Decimal(rng.randrange(80_000, 2_000_000, 5_000)),
                budget_currency="EUR",
            )
        )
    names: set[str] = set()
    countries = ["DE"] * 6 + ["PL", "US", "CN", "AE", "CH", "GB"]
    while len(names) < mode.suppliers:
        names.add(f"{rng.choice(WORDS_A)}{rng.choice(WORDS_B)} {rng.randrange(10, 99)} (synthetic)")
    for name in sorted(names):
        session.add(Supplier(name=name, country=rng.choice(countries)))

    # monthly exchange rates 2023-01 .. 2026-10 as a bounded random walk (synthetic)
    d = date(2023, 1, 1)
    levels = {c: Decimal(v) for c, v in CURRENCY_BASE.items()}
    while d <= date(2026, 10, 1):
        for ccy, base in CURRENCY_BASE.items():
            if ccy != "EUR":
                step = Decimal(str(rng.uniform(-0.012, 0.012)))
                levels[ccy] = max(
                    Decimal(base) * Decimal("0.85"),
                    min(Decimal(base) * Decimal("1.15"), levels[ccy] * (1 + step)),
                )
                session.add(
                    ExchangeRate(
                        currency=ccy,
                        reporting_currency="EUR",
                        rate=levels[ccy].quantize(Decimal("0.0001")),
                        effective_date=d,
                        source="synthetic random walk",
                        is_synthetic=True,
                    )
                )
        d = date(d.year + (d.month == 12), d.month % 12 + 1, 1)
    session.flush()
    audit_log.record(
        session,
        actor_id=None,
        action="seed.reference_data",
        entity_type="system",
        entity_id=None,
        payload={"mode": mode_name, "seed": seed},
    )


def _month_profile(start: date, today: date) -> tuple[list[date], list[float]]:
    """Monthly document-volume weights: linear growth x yearly seasonality (peaks Mar and Oct-Nov)."""
    import math

    months: list[date] = []
    d = start
    while d <= today - timedelta(days=12):
        months.append(d)
        d = date(d.year + (d.month == 12), d.month % 12 + 1, 1)
    weights = []
    for i, m in enumerate(months):
        seasonal = (
            1 + 0.30 * math.sin(2 * math.pi * (m.month - 1) / 12) + 0.15 * (m.month in (10, 11))
        )
        weights.append((1 + 0.015 * i) * seasonal)
    return months, weights


def _random_date(rng: random.Random, months: list[date], weights: list[float], today: date) -> date:
    m = rng.choices(months, weights)[0]
    last = min(
        date(m.year + (m.month == 12), m.month % 12 + 1, 1) - timedelta(days=1),
        today - timedelta(days=12),
    )
    return m + timedelta(days=rng.randrange((last - m).days + 1))


def _add_historical_correction(
    session, doc, outcome: str, original_ship: Decimal, proposed_ship: Decimal
):
    """Insert a decided correction request consistent with the document's stored state."""
    import json

    from app.database.models import CorrectionRequest

    base = (
        doc.total - doc.shipping
    )  # total without shipping (shipping tax rate is 0 for synthetic data)

    def snap(ship):
        return json.dumps(
            {"input": {"shipping": str(ship)}, "calculated_total": str(base + ship)}, sort_keys=True
        )

    requested = (doc.submitted_at or doc.created_at) + timedelta(hours=1)
    session.add(
        CorrectionRequest(
            document_id=doc.id,
            requested_by=doc.employee_id,
            requested_at=requested,
            reason="Shipping cost differs from the supplier document (synthetic history)",
            original_json=snap(original_ship),
            proposed_json=snap(proposed_ship),
            status=outcome,
            decided_by=doc.decided_by,
            decided_at=requested + timedelta(hours=3),
            decision_note="synthetic history",
        )
    )


def _pick_item(rng: random.Random):
    """Return (category, unit, base_price, description, canonical_key)."""
    cat, unit, base, templates, attrs = rng.choice(CATALOG)
    chosen = {k: rng.choice(v) for k, v in attrs.items()}
    tpl = templates[0] if rng.random() < 0.5 else rng.choice(templates)
    key = f"{cat}|{templates[0]}|" + ",".join(f"{k}={chosen[k]}" for k in sorted(chosen))
    return cat, unit, base, tpl.format(**chosen), key


def generate_documents(
    session: Session, count: int, seed: int = 42, today: date | None = None
) -> int:
    """Insert `count` consistent synthetic documents plus labelled injected cases.

    Injected (ground-truth labels stored in synthetic_labels, never used as features):
    ~2 % anomalous documents (price spike / quantity spike / total just below an approval
    threshold), ~1 % duplicate invoices (exact and near), partial-payment pairs and hard
    negatives (same amount, different document) that must NOT be flagged as duplicates.
    Returns the number of documents created including injected ones.
    """
    from app.services import fx_service

    rng = random.Random(seed + 1)
    today = today or date.today()
    employees = list(
        session.execute(select(User).where(User.role == Role.EMPLOYEE.value)).scalars()
    )
    projects_by_unit: dict[int, list[Project]] = {}
    for p in session.execute(select(Project)).scalars():
        projects_by_unit.setdefault(p.org_unit_id, []).append(p)
    ccs_by_unit: dict[int, list[CostCenter]] = {}
    for c in session.execute(select(CostCenter)).scalars():
        ccs_by_unit.setdefault(c.org_unit_id, []).append(c)
    suppliers = list(session.execute(select(Supplier)).scalars())
    managers = {
        u.org_unit_id: u
        for u in session.execute(select(User).where(User.role == Role.MANAGER.value)).scalars()
    }
    all_projects = [p for lst in projects_by_unit.values() for p in lst]
    statuses, weights = zip(*STATUS_WEIGHTS, strict=True)
    start = date(2024, 1, 1)
    month_choices, month_weights = _month_profile(start, today)
    rate_cache: dict[tuple[str, date], Decimal | None] = {}
    pending_labels: list[tuple[str, object, str, str]] = []  # (entity_type, obj, kind, value)
    pending_corrections: list[tuple[PurchaseDocument, str, Decimal, Decimal]] = []
    created = 0
    counter = 0

    def next_number() -> str:
        nonlocal counter
        counter += 1
        return f"SYN-{seed}-{counter:06d}"

    def fx(ccy: str, d: date) -> Decimal:
        key = (ccy, date(d.year, d.month, 1))
        if key not in rate_cache:
            rate_cache[key] = fx_service.get_rate(session, ccy, key[1], "EUR")
        return rate_cache[key] or Decimal("1")

    def build_document(inp, calc, emp, project, sup, status, rate, number, ref_keys):
        pdate = inp.purchase_date
        submitted = decided = None
        base_ts = datetime(pdate.year, pdate.month, pdate.day, 8, tzinfo=UTC)
        if status != "draft":
            submitted = base_ts + timedelta(hours=rng.uniform(0, 36))
        if status in ("approved", "rejected"):
            decided = min(
                submitted + timedelta(hours=rng.expovariate(1 / 20) + 0.5), datetime.now(UTC)
            )
        doc = PurchaseDocument(
            doc_number=number,
            employee_id=emp.id,
            org_unit_id=emp.org_unit_id,
            project_id=project.id,
            cost_center_id=inp.cost_center_id,
            supplier_id=sup.id,
            doc_type=inp.doc_type,
            supplier_ref=inp.supplier_ref,
            purchase_date=pdate,
            currency=inp.currency,
            description=inp.description,
            business_purpose=inp.business_purpose,
            payment_method="bank_transfer",
            shipping=inp.shipping,
            subtotal=calc.subtotal,
            discount_total=calc.discount_total,
            tax_total=calc.tax_total,
            total=calc.total,
            fx_rate=rate,
            reporting_currency="EUR",
            total_reporting=(calc.total * rate).quantize(Decimal("0.01")),
            status=status,
            is_synthetic=True,
            created_at=submitted or base_ts,
            submitted_at=submitted,
            decided_at=decided,
            decided_by=managers[emp.org_unit_id].id
            if decided and emp.org_unit_id in managers
            else None,
        )
        for i, (ln, cl) in enumerate(zip(inp.lines, calc.lines, strict=True), start=1):
            line = LineItem(
                line_no=i,
                description=ln.description,
                category=ln.category,
                quantity=ln.quantity,
                unit=ln.unit,
                unit_price=ln.unit_price,
                discount_rate=ln.discount_rate,
                tax_rate=ln.tax_rate,
                discount_amount=cl.discount_amount,
                net_amount=cl.net_amount,
                tax_amount=cl.tax_amount,
                line_total=cl.line_total,
            )
            doc.lines.append(line)
            if ref_keys and ref_keys[i - 1]:
                pending_labels.append(("line", line, "item_key", ref_keys[i - 1]))
        session.add(doc)
        return doc

    def flush_labels() -> None:
        session.flush()
        for etype, obj, kind, value in pending_labels:
            session.add(SyntheticLabel(entity_type=etype, entity_id=obj.id, kind=kind, value=value))
        pending_labels.clear()
        for d, outcome, old_ship, new_ship in pending_corrections:
            _add_historical_correction(session, d, outcome, old_ship, new_ship)
        pending_corrections.clear()

    made: list[PurchaseDocument] = []
    for _ in range(count):
        emp = rng.choice(employees)
        project = rng.choice(projects_by_unit.get(emp.org_unit_id) or all_projects)
        sup = rng.choice(suppliers)
        ccy = {
            "DE": "EUR",
            "PL": "PLN",
            "US": "USD",
            "CN": "CNY",
            "AE": "AED",
            "CH": "CHF",
            "GB": "GBP",
        }[sup.country]
        if rng.random() < 0.1:
            ccy = "EUR"
        pdate = _random_date(rng, month_choices, month_weights, today)
        months = (pdate.year - 2024) * 12 + pdate.month
        index = 1 + 0.004 * months + 0.05 * (1 if pdate.month in (3, 4, 9, 10) else 0)
        rate = fx(ccy, pdate)
        anomaly = rng.choices(
            [None, "price_spike", "quantity_spike", "near_threshold"], [97.9, 0.8, 0.6, 0.7]
        )[0]
        spike_line = None
        n_lines = rng.choice([1, 2, 2, 3, 3, 4, 5, 6])
        lines: list[LineInput] = []
        keys: list[str] = []
        for li in range(n_lines):
            cat, unit, base, desc, key = _pick_item(rng)
            qty = (
                Decimal(rng.choice([1, 2, 5, 10, 20, 50, 100, 500]))
                if unit != "h"
                else Decimal(rng.randrange(2, 40))
            )
            price_eur = (
                base
                * index
                * rng.uniform(0.85, 1.2)
                * (1.0 + 0.02 * (zlib.crc32(key.encode()) % 7))
            )
            if anomaly == "price_spike" and li == 0:
                price_eur *= rng.uniform(2.5, 5.0)
                spike_line = li
            if anomaly == "quantity_spike" and li == 0:
                qty = min(qty * rng.randint(20, 60), Decimal("900000"))
                spike_line = li
            price = max(quantize_money(Decimal(str(price_eur)) / rate, ccy), Decimal("0.01"))
            disc = Decimal(rng.choice(["0", "0", "0", "0.05", "0.10"]))
            lines.append(LineInput(desc, qty, price, unit, disc, Decimal(TAX_BY_CCY[ccy]), cat))
            keys.append(key)
        shipping = quantize_money(Decimal(str(rng.choice([0, 0, 15, 40, 120]))), ccy)
        ref = f"INV-{rng.randrange(100000, 999999)}"
        cc_id = rng.choice(ccs_by_unit[emp.org_unit_id]).id

        doc_type = rng.choice(["invoice", "invoice", "quotation", "receipt"])

        def make_input(
            lns,
            ref=ref,
            ship=shipping,
            pid=project.id,
            cc=cc_id,
            sid=sup.id,
            d=pdate,
            c=ccy,
            t=doc_type,
        ):
            return DocumentInput(
                project_id=pid,
                cost_center_id=cc,
                supplier_id=sid,
                doc_type=t,
                purchase_date=d,
                currency=c,
                lines=tuple(lns),
                supplier_ref=ref,
                description=f"{lns[0].description} and related items (synthetic)",
                business_purpose="Synthetic demo purchase",
                shipping=ship,
            )

        inp = make_input(lines)
        calc = calculate(inp)
        if anomaly == "near_threshold":
            thr = Decimal(rng.choice(APPROVAL_THRESHOLDS_EUR))
            target = thr * Decimal(str(rng.uniform(0.96, 0.995)))
            now_eur = calc.total * rate
            first_eur = calc.lines[0].line_total * rate
            scale = (first_eur + (target - now_eur)) / first_eur if first_eur > 0 else Decimal(0)
            if scale <= 0:
                scale = Decimal(1)
            first = lines[0]
            lines[0] = LineInput(
                first.description,
                first.quantity,
                max(quantize_money(first.unit_price * scale, ccy), Decimal("0.01")),
                first.unit,
                first.discount_rate,
                first.tax_rate,
                first.category,
            )
            inp = make_input(lines)
            calc = calculate(inp)
            eur_total = calc.total * rate
            if not (thr * Decimal("0.93") <= eur_total < thr):
                anomaly = None  # could not hit the window cleanly; keep as a normal document
        status = rng.choices(statuses, weights)[0]
        doc = build_document(inp, calc, emp, project, sup, status, rate, next_number(), keys)
        made.append(doc)
        created += 1
        if (
            status in ("submitted", "under_review", "resubmitted", "approved")
            and rng.random() < 0.04
        ):
            # Historical correction request about the shipping cost. The stored document already
            # reflects the outcome: approved -> corrected value is in the document, rejected -> original stays.
            old = quantize_money(shipping + Decimal(rng.choice([5, 10, 25, 60])), ccy)
            if rng.random() < 0.6:
                pending_corrections.append((doc, "approved", old, shipping))
            else:
                pending_corrections.append((doc, "rejected", shipping, old))
        if anomaly:
            pending_labels.append(
                ("document", doc, anomaly, "" if spike_line is None else str(spike_line))
            )
        if created % 500 == 0:
            flush_labels()
    flush_labels()

    # ---- injected duplicate / legitimate-repeat / hard-negative cases ------------------------
    originals = [d for d in made if d.status not in ("draft", "cancelled") and d.supplier_ref]
    rng.shuffle(originals)

    def clone(
        src: PurchaseDocument,
        ref: str,
        shift_days: int,
        scale: Decimal | None = None,
        new_desc: str | None = None,
        sdoc_type: str | None = None,
    ):
        new_date = min(src.purchase_date + timedelta(days=shift_days), today - timedelta(days=1))
        lns = []
        for ln in src.lines:
            qty = (
                ln.quantity
                if scale is None
                else max(Decimal("1"), (ln.quantity * scale).quantize(Decimal("1")))
            )
            lns.append(
                LineInput(
                    new_desc or ln.description,
                    qty,
                    ln.unit_price,
                    ln.unit,
                    ln.discount_rate,
                    ln.tax_rate,
                    ln.category,
                )
            )
        inp = DocumentInput(
            project_id=src.project_id,
            cost_center_id=src.cost_center_id,
            supplier_id=src.supplier_id,
            doc_type=sdoc_type or src.doc_type,
            purchase_date=new_date,
            currency=src.currency,
            lines=tuple(lns),
            supplier_ref=ref,
            description=src.description,
            business_purpose=src.business_purpose,
            shipping=src.shipping,
        )
        calc = calculate(inp)
        emp = src.employee
        return build_document(
            inp,
            calc,
            emp,
            src.project,
            src.supplier,
            src.status,
            src.fx_rate or Decimal("1"),
            next_number(),
            None,
        )

    n_dup = max(1, int(len(made) * 0.010))
    for i, src in enumerate(originals[:n_dup]):
        if i % 5 < 3:  # 60 % exact duplicates: same reference, amount, lines; 0-3 days later
            d = clone(src, src.supplier_ref, rng.randint(0, 3))
            pending_labels.append(("document", d, "duplicate_exact", str(src.id)))
        else:  # 40 % near duplicates: one character of the reference differs, 1-5 days later
            ref = list(src.supplier_ref)
            pos = rng.randrange(4, len(ref))
            ref[pos] = str((int(ref[pos]) + 1) % 10) if ref[pos].isdigit() else "0"
            d = clone(src, "".join(ref), rng.randint(1, 5))
            pending_labels.append(("document", d, "duplicate_near", str(src.id)))
        created += 1
    for src in originals[n_dup : n_dup + max(1, int(len(made) * 0.005))]:
        p1 = clone(src, f"{src.supplier_ref}-P1", 0, Decimal("0.5"))
        p2 = clone(src, f"{src.supplier_ref}-P2", 7, Decimal("0.5"))
        session.flush()
        pending_labels.append(("document", p1, "legit_repeat", str(p2.id)))
        pending_labels.append(("document", p2, "legit_repeat", str(p1.id)))
        created += 2
    for src in originals[n_dup + max(1, int(len(made) * 0.005)) :][
        : max(1, int(len(made) * 0.005))
    ]:
        h = clone(
            src,
            f"INV-{rng.randrange(100000, 999999)}",
            rng.randint(60, 200),
            new_desc=f"Different goods {rng.randrange(1000, 9999)} (synthetic)",
        )
        pending_labels.append(("document", h, "hard_negative", str(src.id)))
        created += 1
    flush_labels()
    audit_log.record(
        session,
        actor_id=None,
        action="seed.documents",
        entity_type="system",
        entity_id=None,
        payload={"count": created, "seed": seed},
    )
    return created
