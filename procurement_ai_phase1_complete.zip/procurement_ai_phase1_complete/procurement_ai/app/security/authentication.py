"""Demo authentication. LOCAL DEMONSTRATION ONLY - not a production identity system."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import User
from app.security import audit_log
from app.security.hashing import verify_password
from app.utils.exceptions import AuthenticationError


def authenticate(session: Session, username: str, password: str) -> User:
    """Return the user or raise AuthenticationError with a deliberately generic message."""
    user = session.execute(
        select(User).where(User.username == username.strip().lower())
    ).scalar_one_or_none()
    if user is None or not user.is_active or not verify_password(password, user.password_hash):
        audit_log.record(
            session,
            actor_id=None,
            action="auth.login_failed",
            entity_type="user",
            entity_id=user.id if user else None,
            payload={"username": username[:60]},
        )
        session.commit()  # keep the failed-login record although the caller raises
        raise AuthenticationError("Invalid username or password.")
    audit_log.record(
        session, actor_id=user.id, action="auth.login", entity_type="user", entity_id=user.id
    )
    return user
