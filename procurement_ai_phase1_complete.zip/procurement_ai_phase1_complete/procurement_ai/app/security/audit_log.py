"""Append-only audit trail with a SHA-256 hash chain.

Threat model (honest version):
* Detects accidental or casual edits/deletions of historical rows: every event stores the hash
  of the previous event, so changing or removing a row breaks verification from that point on.
* SQLite triggers additionally reject UPDATE/DELETE on audit_events.
* It does NOT stop a privileged attacker who can modify the database file, drop the triggers and
  recompute every later hash. Defending against that needs an external anchor (e.g. periodically
  exporting the latest hash to write-once storage). This is not a blockchain.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import AuditEvent
from app.security.hashing import sha256_hex
from app.utils.dates import utcnow

GENESIS_HASH = "0" * 64


def _canonical(
    ts: datetime,
    actor_id: int | None,
    action: str,
    entity_type: str,
    entity_id: int | None,
    payload_json: str,
    prev_hash: str,
) -> str:
    return json.dumps(
        [ts.isoformat(), actor_id, action, entity_type, entity_id, payload_json, prev_hash],
        separators=(",", ":"),
        ensure_ascii=True,
    )


def record(
    session: Session,
    *,
    actor_id: int | None,
    action: str,
    entity_type: str,
    entity_id: int | None,
    payload: dict[str, Any] | None = None,
) -> AuditEvent:
    """Add an audit event inside the caller's transaction (rolls back with it)."""
    session.flush()
    last = session.execute(
        select(AuditEvent).order_by(AuditEvent.id.desc()).limit(1)
    ).scalar_one_or_none()
    prev_hash = last.hash if last else GENESIS_HASH
    ts = utcnow()
    payload_json = json.dumps(payload or {}, sort_keys=True, default=str, ensure_ascii=True)
    digest = sha256_hex(
        _canonical(ts, actor_id, action, entity_type, entity_id, payload_json, prev_hash)
    )
    event = AuditEvent(
        timestamp=ts,
        actor_id=actor_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        payload_json=payload_json,
        prev_hash=prev_hash,
        hash=digest,
    )
    session.add(event)
    session.flush()
    return event


@dataclass(frozen=True)
class ChainVerification:
    ok: bool
    checked: int
    first_bad_id: int | None = None
    message: str = ""


def verify_chain(session: Session) -> ChainVerification:
    prev = GENESIS_HASH
    count = 0
    stream = session.execute(select(AuditEvent).order_by(AuditEvent.id)).scalars()
    for ev in stream:
        expected = sha256_hex(
            _canonical(
                ev.timestamp,
                ev.actor_id,
                ev.action,
                ev.entity_type,
                ev.entity_id,
                ev.payload_json,
                prev,
            )
        )
        if ev.prev_hash != prev or ev.hash != expected:
            return ChainVerification(
                False, count, ev.id, f"Chain broken at event #{ev.id} (content or order changed)."
            )
        prev = ev.hash
        count += 1
    return ChainVerification(True, count, None, f"{count} events verified.")
