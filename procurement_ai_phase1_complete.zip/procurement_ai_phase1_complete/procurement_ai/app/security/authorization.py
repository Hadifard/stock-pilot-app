"""Role-based access control. Enforced in services, never only in the UI."""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING

from app.utils.exceptions import PermissionDenied

if TYPE_CHECKING:
    from app.database.models import PurchaseDocument, User


class Role(StrEnum):
    EMPLOYEE = "purchasing_employee"
    MANAGER = "purchasing_manager"
    FINANCE = "finance_officer"
    PROJECT_MANAGER = "project_manager"
    AUDITOR = "auditor"
    ADMIN = "administrator"


class Perm(StrEnum):
    DOC_CREATE = "document.create"
    DOC_VIEW_OWN = "document.view_own"
    DOC_VIEW_ORG = "document.view_org"
    DOC_VIEW_PROJECT = "document.view_project"
    DOC_VIEW_ALL = "document.view_all"
    DOC_REVIEW = "document.review"
    DOC_DECIDE = "document.decide"
    CORRECTION_REQUEST = "correction.request"
    CORRECTION_DECIDE = "correction.decide"
    CORRECTION_OVERRIDE = "correction.override_deadline"
    AUDIT_VIEW = "audit.view"
    ANALYTICS_VIEW = "analytics.view"
    REPORT_EXPORT = "report.export"
    ALERT_REVIEW = "alert.review"
    ADMIN_MANAGE = "admin.manage"


ROLE_PERMISSIONS: dict[Role, frozenset[Perm]] = {
    Role.EMPLOYEE: frozenset({Perm.DOC_CREATE, Perm.DOC_VIEW_OWN, Perm.CORRECTION_REQUEST}),
    Role.MANAGER: frozenset(
        {
            Perm.DOC_VIEW_OWN,
            Perm.DOC_VIEW_ORG,
            Perm.DOC_REVIEW,
            Perm.DOC_DECIDE,
            Perm.CORRECTION_DECIDE,
            Perm.CORRECTION_OVERRIDE,
            Perm.ANALYTICS_VIEW,
            Perm.REPORT_EXPORT,
            Perm.ALERT_REVIEW,
        }
    ),
    Role.FINANCE: frozenset(
        {Perm.DOC_VIEW_ALL, Perm.ANALYTICS_VIEW, Perm.REPORT_EXPORT, Perm.ALERT_REVIEW}
    ),
    Role.PROJECT_MANAGER: frozenset(
        {
            Perm.DOC_VIEW_OWN,
            Perm.DOC_VIEW_PROJECT,
            Perm.DOC_REVIEW,
            Perm.DOC_DECIDE,
            Perm.ANALYTICS_VIEW,
        }
    ),
    Role.AUDITOR: frozenset(
        {Perm.DOC_VIEW_ALL, Perm.AUDIT_VIEW, Perm.ANALYTICS_VIEW, Perm.REPORT_EXPORT}
    ),
    Role.ADMIN: frozenset(Perm),
}

ROLE_LABELS: dict[str, str] = {
    Role.EMPLOYEE: "Purchasing employee",
    Role.MANAGER: "Purchasing manager",
    Role.FINANCE: "Finance officer",
    Role.PROJECT_MANAGER: "Project manager",
    Role.AUDITOR: "Auditor (read-only)",
    Role.ADMIN: "Administrator",
}


def has_permission(user: User, perm: Perm) -> bool:
    try:
        return user.is_active and perm in ROLE_PERMISSIONS[Role(user.role)]
    except ValueError:
        return False


def require(user: User, perm: Perm) -> None:
    if not has_permission(user, perm):
        raise PermissionDenied(f"Your role is not allowed to perform '{perm.value}'.")


def can_view_document(user: User, doc: PurchaseDocument) -> bool:
    if not user.is_active:
        return False
    if has_permission(user, Perm.DOC_VIEW_ALL):
        return True
    if doc.employee_id == user.id and has_permission(user, Perm.DOC_VIEW_OWN):
        return True
    if has_permission(user, Perm.DOC_VIEW_ORG) and doc.org_unit_id == user.org_unit_id:
        return True
    return bool(has_permission(user, Perm.DOC_VIEW_PROJECT) and doc.project.manager_id == user.id)


def require_view(user: User, doc: PurchaseDocument) -> None:
    if not can_view_document(user, doc):
        raise PermissionDenied("You are not allowed to access this document.")


def can_decide_document(user: User, doc: PurchaseDocument) -> bool:
    """Scope check for review/approve/reject. No one may decide their own document."""
    if not has_permission(user, Perm.DOC_DECIDE) or doc.employee_id == user.id:
        return False
    if user.role == Role.ADMIN:
        return True
    if user.role == Role.MANAGER:
        return doc.org_unit_id == user.org_unit_id
    if user.role == Role.PROJECT_MANAGER:
        return doc.project.manager_id == user.id
    return False


def require_decide(user: User, doc: PurchaseDocument) -> None:
    if not can_decide_document(user, doc):
        raise PermissionDenied(
            "You may not review this document (outside your scope, or it is your own)."
        )
