"""Price benchmarking against internal purchase history (attribute-first matching).

Only technically comparable items (or ones a human confirmed as equivalent) enter a benchmark.
Aggregated statistics use all stored history; individual documents are listed only if the viewer
may see them. In this demo the history is synthetic and labelled as such. No external prices are
used: `ExternalPriceProvider` is an interface only, so nothing here claims to know market prices.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import (
    ItemMatchDecision,
    LineItem,
    OrgUnit,
    PurchaseDocument,
    Supplier,
    User,
)
from app.ml.item_matching import MatchResult, match_items, normalize_item
from app.security import audit_log
from app.security.authorization import Perm, require
from app.services.document_service import CANCELLED, DRAFT, scoped_query
from app.utils.exceptions import ValidationError

MIN_SAMPLES = 3
NO_BENCHMARK = "No verified benchmark available"


class ExternalPriceProvider(ABC):
    """Integration point for approved supplier catalogues/APIs (not implemented in Phase 1).

    A provider must respect access restrictions, website terms and rate limits, and must return
    prices that are verifiable (source, date, currency, terms). None is configured, so the
    application never displays an 'online market price'.
    """

    @abstractmethod
    def lookup(self, description: str, unit: str) -> list[dict]: ...


@dataclass
class Benchmark:
    query: str
    unit: str
    n_samples: int
    stats: dict[str, float] | None
    message: str
    comparables: list[tuple[str, MatchResult, int]] = field(default_factory=list)
    purchases: pd.DataFrame = field(default_factory=pd.DataFrame)


def _decision_map(session: Session) -> dict[tuple[str, str], str]:
    rows = session.execute(select(ItemMatchDecision)).scalars()
    return {(r.text_a, r.text_b): r.decision for r in rows}


def _pair(a: str, b: str) -> tuple[str, str]:
    a, b = a.strip().lower(), b.strip().lower()
    return (a, b) if a <= b else (b, a)


def confirm_match(
    session: Session, actor: User, text_a: str, text_b: str, equivalent: bool
) -> None:
    require(actor, Perm.ANALYTICS_VIEW)
    a, b = _pair(text_a, text_b)
    if a == b:
        raise ValidationError("Choose two different descriptions.")
    decision = "equivalent" if equivalent else "not_equivalent"
    existing = session.execute(
        select(ItemMatchDecision).where(
            ItemMatchDecision.text_a == a, ItemMatchDecision.text_b == b
        )
    ).scalar_one_or_none()
    if existing:
        existing.decision, existing.decided_by = decision, actor.id
    else:
        session.add(ItemMatchDecision(text_a=a, text_b=b, decision=decision, decided_by=actor.id))
    audit_log.record(
        session,
        actor_id=actor.id,
        action="item_match.decided",
        entity_type="item_match",
        entity_id=None,
        payload={"a": a, "b": b, "decision": decision},
    )


def benchmark(
    session: Session, actor: User, description: str, unit: str, sample_cap: int = 5000
) -> Benchmark:
    require(actor, Perm.ANALYTICS_VIEW)
    if not description.strip():
        raise ValidationError("Enter an item description.")
    target = normalize_item(description, unit)
    if target.product_type is None:
        return Benchmark(
            description,
            unit,
            0,
            None,
            f"{NO_BENCHMARK}: the product type is not recognised, so no comparable items were searched.",
        )
    distinct = session.execute(
        select(LineItem.description, func_count())
        .join(PurchaseDocument, LineItem.document_id == PurchaseDocument.id)
        .where(LineItem.unit == unit, PurchaseDocument.status.not_in((DRAFT, CANCELLED)))
        .group_by(LineItem.description)
    ).all()
    decisions = _decision_map(session)
    included: list[str] = []
    comparables: list[tuple[str, MatchResult, int]] = []
    for desc, n in distinct:
        res = match_items(target, normalize_item(desc, unit))
        human = decisions.get(_pair(description, desc))
        if human == "equivalent" or (human is None and res.level == "technically_comparable"):
            included.append(desc)
        if (
            res.level in ("technically_comparable", "needs_review", "similar_description_only")
            and human != "not_equivalent"
        ):
            comparables.append((desc, res, int(n)))
    comparables.sort(key=lambda t: -t[1].score)
    if not included:
        return Benchmark(
            description,
            unit,
            0,
            None,
            f"{NO_BENCHMARK} (no technically comparable purchases).",
            comparables[:15],
        )
    rows = session.execute(
        select(
            LineItem.id,
            LineItem.description,
            LineItem.quantity,
            LineItem.unit_price,
            LineItem.discount_rate,
            PurchaseDocument.fx_rate,
            PurchaseDocument.currency,
            PurchaseDocument.purchase_date,
            PurchaseDocument.doc_number,
            PurchaseDocument.supplier_id,
            PurchaseDocument.org_unit_id,
            PurchaseDocument.id.label("doc_id"),
        )
        .join(PurchaseDocument, LineItem.document_id == PurchaseDocument.id)
        .where(
            LineItem.description.in_(included),
            LineItem.unit == unit,
            PurchaseDocument.status.not_in((DRAFT, CANCELLED)),
            PurchaseDocument.fx_rate.is_not(None),
        )
        .limit(sample_cap)
    ).all()
    df = pd.DataFrame(
        [tuple(r) for r in rows],
        columns=[
            "line_id",
            "description",
            "quantity",
            "unit_price",
            "discount_rate",
            "fx_rate",
            "currency",
            "purchase_date",
            "doc_number",
            "supplier_id",
            "org_unit_id",
            "doc_id",
        ],
    )
    if len(df) < MIN_SAMPLES:
        return Benchmark(
            description,
            unit,
            len(df),
            None,
            f"{NO_BENCHMARK} (only {len(df)} comparable purchase(s); at least {MIN_SAMPLES} needed).",
            comparables[:15],
        )
    df["price_eur"] = [
        float(u * (1 - d) * f)
        for u, d, f in zip(df["unit_price"], df["discount_rate"], df["fx_rate"], strict=True)
    ]
    p = df["price_eur"].to_numpy()
    stats = {
        "median": float(np.median(p)),
        "p25": float(np.percentile(p, 25)),
        "p75": float(np.percentile(p, 75)),
        "min": float(p.min()),
        "max": float(p.max()),
        "suppliers": int(df["supplier_id"].nunique()),
        "org_units": int(df["org_unit_id"].nunique()),
    }
    visible_ids = set(
        session.execute(
            scoped_query(session, actor).with_only_columns(PurchaseDocument.id)
        ).scalars()
    )
    mine = df[df["doc_id"].isin(visible_ids)].copy()
    sup = dict(session.execute(select(Supplier.id, Supplier.name)).all())
    org = dict(session.execute(select(OrgUnit.id, OrgUnit.code)).all())
    mine["supplier"] = mine["supplier_id"].map(sup)
    mine["unit_code"] = mine["org_unit_id"].map(org)
    purchases = (
        mine[
            [
                "doc_number",
                "purchase_date",
                "description",
                "supplier",
                "unit_code",
                "currency",
                "price_eur",
            ]
        ]
        .sort_values("purchase_date", ascending=False)
        .head(200)
    )
    return Benchmark(
        description,
        unit,
        len(df),
        stats,
        "Benchmark from internal purchase history (synthetic in this demo), net unit price in EUR.",
        comparables[:15],
        purchases,
    )


def func_count():
    from sqlalchemy import func

    return func.count(LineItem.id)
