"""Correction requests: the only way to change a submitted financial record.

Policy (configurable window, default 4 h after submission, UTC-aware comparison):
* Inside the window the document owner may file a correction request for a document that is
  submitted / under review / resubmitted. Nothing is overwritten yet.
* A reviewer (manager / admin within scope, never the requester) approves or rejects it.
  Approval re-validates, recalculates and applies the change in one transaction and moves the
  document to RESUBMITTED. Rejection restores the previous status.
* After the window, or for an already approved document, only users with the explicit
  'correction.override_deadline' permission may file a request, with a mandatory reason; the
  exception is flagged on the request and audited.
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import CorrectionRequest, PurchaseDocument, User
from app.security import audit_log
from app.security.authorization import Perm, has_permission, require, require_decide
from app.services import notification_service
from app.services.approval_service import apply_transition
from app.services.document_service import (
    APPROVED,
    CORRECTION_REQUESTED,
    RESUBMITTED,
    SUBMITTED,
    UNDER_REVIEW,
    correction_deadline,
    document_to_input,
    get_document,
    within_correction_window,
    write_calculation,
)
from app.services.validation_service import (
    apply_changes,
    calculate,
    input_to_dict,
    validate_or_raise,
)
from app.utils.dates import utcnow
from app.utils.exceptions import (
    CorrectionWindowExpired,
    NotFound,
    PermissionDenied,
    ValidationError,
)

CORRECTABLE = (SUBMITTED, UNDER_REVIEW, RESUBMITTED)


def _snapshot(inp) -> str:
    calc = calculate(inp)
    return json.dumps(
        {"input": input_to_dict(inp), "calculated_total": str(calc.total)}, sort_keys=True
    )


def create_request(
    session: Session,
    actor: User,
    doc_id: int,
    header_changes: dict[str, Any],
    line_changes: list[dict] | None,
    reason: str,
    override_reason: str | None = None,
) -> CorrectionRequest:
    doc = get_document(session, actor, doc_id)
    if not reason or not reason.strip():
        raise ValidationError("A reason for the correction is required.")
    if not header_changes and line_changes is None:
        raise ValidationError("No changes were proposed.")
    pending = session.execute(
        select(CorrectionRequest.id).where(
            CorrectionRequest.document_id == doc.id, CorrectionRequest.status == "pending"
        )
    ).first()
    if pending:
        raise ValidationError("This document already has a pending correction request.")

    in_window = doc.status in CORRECTABLE and _in_window(doc)
    is_exception = False
    if in_window:
        require(actor, Perm.CORRECTION_REQUEST)
        if doc.employee_id != actor.id:
            raise PermissionDenied("Only the document owner can request a correction.")
    else:
        if not has_permission(actor, Perm.CORRECTION_OVERRIDE):
            raise CorrectionWindowExpired(
                "The correction window has expired or the document is no longer correctable. "
                "Ask a manager to file an exception."
            )
        if not override_reason or not override_reason.strip():
            raise ValidationError("A deadline exception requires a written justification.")
        if doc.status not in CORRECTABLE + (APPROVED,):
            raise ValidationError(f"A document in status '{doc.status}' cannot be corrected.")
        is_exception = True

    original = document_to_input(doc)
    proposed = apply_changes(original, header_changes, line_changes)
    validate_or_raise(proposed)
    if proposed == original:
        raise ValidationError("The proposed values are identical to the current values.")

    req = CorrectionRequest(
        document_id=doc.id,
        requested_by=actor.id,
        requested_at=utcnow(),
        reason=reason.strip(),
        original_json=_snapshot(original),
        proposed_json=_snapshot(proposed),
        deadline_exception=is_exception,
        exception_reason=(override_reason or None),
    )
    session.add(req)
    doc.status_before_correction = doc.status
    apply_transition(session, actor, doc, CORRECTION_REQUESTED, "system", reason)
    session.flush()
    audit_log.record(
        session,
        actor_id=actor.id,
        action="correction.deadline_exception" if is_exception else "correction.requested",
        entity_type="document",
        entity_id=doc.id,
        payload={
            "request_id": req.id,
            "reason": reason.strip(),
            "exception_reason": override_reason or "",
            "original": json.loads(req.original_json),
            "proposed": json.loads(req.proposed_json),
        },
    )
    notification_service.notify_role_in_org(
        session,
        "purchasing_manager",
        doc.org_unit_id,
        f"Correction requested for {doc.doc_number}.",
        doc.id,
    )
    return req


def _in_window(doc: PurchaseDocument) -> bool:
    return within_correction_window(doc)


def decide_request(
    session: Session, actor: User, request_id: int, approve: bool, note: str = ""
) -> CorrectionRequest:
    req = session.get(CorrectionRequest, request_id)
    if req is None:
        raise NotFound(f"Correction request {request_id} was not found.")
    require(actor, Perm.CORRECTION_DECIDE)
    doc = get_document(session, actor, req.document_id)
    require_decide(actor, doc)
    if req.requested_by == actor.id:
        raise PermissionDenied("You cannot decide your own correction request.")
    if req.status != "pending":
        raise ValidationError("This correction request has already been decided.")
    if not approve and not (note and note.strip()):
        raise ValidationError("A reason is required to reject a correction request.")

    req.decided_by, req.decided_at, req.decision_note = actor.id, utcnow(), note or None
    prior = doc.status_before_correction or SUBMITTED
    if approve:
        current = _snapshot(document_to_input(doc))
        if current != req.original_json:
            raise ValidationError(
                "The document changed after this request was filed; ask for a new request."
            )
        proposed_input = json.loads(req.proposed_json)["input"]
        from app.services.validation_service import input_from_dict

        new_inp = input_from_dict(proposed_input)
        calc = validate_or_raise(new_inp)
        write_calculation(session, doc, new_inp, calc)
        req.status = "approved"
        apply_transition(session, actor, doc, RESUBMITTED, "system", note)
        action = "correction.approved"
    else:
        req.status = "rejected"
        apply_transition(session, actor, doc, prior, "system", note)
        action = "correction.rejected"
    doc.status_before_correction = None
    audit_log.record(
        session,
        actor_id=actor.id,
        action=action,
        entity_type="document",
        entity_id=doc.id,
        payload={
            "request_id": req.id,
            "note": note,
            "old": json.loads(req.original_json),
            "new": json.loads(req.proposed_json) if approve else None,
        },
    )
    notification_service.notify(
        session,
        req.requested_by,
        f"Your correction request for {doc.doc_number} was {req.status}.",
        doc.id,
    )
    return req


def list_requests(
    session: Session, actor: User, pending_only: bool = False
) -> list[CorrectionRequest]:
    """Requests the actor may see: own requests, plus those on documents they may decide."""
    from app.services.document_service import scoped_query

    visible_ids = scoped_query(session, actor).with_only_columns(PurchaseDocument.id)
    q = select(CorrectionRequest).where(CorrectionRequest.document_id.in_(visible_ids))
    if pending_only:
        q = q.where(CorrectionRequest.status == "pending")
    return list(session.execute(q.order_by(CorrectionRequest.requested_at.desc())).scalars())


__all__ = ["correction_deadline", "create_request", "decide_request", "list_requests"]
