"""Exchange-rate lookup. Rates are effective-dated; the latest rate on or before the date wins."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import ExchangeRate


def get_rate(
    session: Session, currency: str, on_date: date, reporting_currency: str
) -> Decimal | None:
    """Units of reporting currency per 1 unit of `currency`. None if no rate exists (never guess)."""
    if currency == reporting_currency:
        return Decimal("1")
    row = session.execute(
        select(ExchangeRate.rate)
        .where(
            ExchangeRate.currency == currency,
            ExchangeRate.reporting_currency == reporting_currency,
            ExchangeRate.effective_date <= on_date,
        )
        .order_by(ExchangeRate.effective_date.desc())
        .limit(1)
    ).scalar_one_or_none()
    return row
