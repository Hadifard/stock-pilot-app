"""Purchase document creation, editing of drafts, submission and scoped retrieval."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import Select, false, func, or_, select
from sqlalchemy.orm import Session, selectinload

from app.config import get_settings
from app.database.models import (
    CostCenter,
    LineItem,
    Project,
    PurchaseDocument,
    Supplier,
    User,
)
from app.security import audit_log
from app.security.authorization import Perm, has_permission, require, require_view
from app.services import fx_service, notification_service
from app.services.validation_service import (
    CalculatedDocument,
    DocumentInput,
    LineInput,
    calculate,
    validate_or_raise,
)
from app.utils.dates import utcnow
from app.utils.exceptions import InvalidTransition, NotFound, PermissionDenied, ValidationError

# Status constants (the state machine itself lives in approval_service)
DRAFT = "draft"
SUBMITTED = "submitted"
UNDER_REVIEW = "under_review"
CORRECTION_REQUESTED = "correction_requested"
RESUBMITTED = "resubmitted"
APPROVED = "approved"
REJECTED = "rejected"
CANCELLED = "cancelled"
ALL_STATUSES = (
    DRAFT,
    SUBMITTED,
    UNDER_REVIEW,
    CORRECTION_REQUESTED,
    RESUBMITTED,
    APPROVED,
    REJECTED,
    CANCELLED,
)


def scoped_query(session: Session, user: User) -> Select:
    """Base SELECT of documents this user may see. Every listing/report must start from here."""
    conds = []
    if has_permission(user, Perm.DOC_VIEW_ALL):
        return select(PurchaseDocument)
    if has_permission(user, Perm.DOC_VIEW_OWN):
        conds.append(PurchaseDocument.employee_id == user.id)
    if has_permission(user, Perm.DOC_VIEW_ORG):
        conds.append(PurchaseDocument.org_unit_id == user.org_unit_id)
    if has_permission(user, Perm.DOC_VIEW_PROJECT):
        conds.append(
            PurchaseDocument.project_id.in_(select(Project.id).where(Project.manager_id == user.id))
        )
    return select(PurchaseDocument).where(or_(*conds) if conds else false())


def _check_references(session: Session, inp: DocumentInput) -> None:
    errs = []
    if session.get(Project, inp.project_id) is None:
        errs.append("Selected project does not exist.")
    if session.get(CostCenter, inp.cost_center_id) is None:
        errs.append("Selected cost center does not exist.")
    if session.get(Supplier, inp.supplier_id) is None:
        errs.append("Selected supplier does not exist.")
    if errs:
        raise ValidationError(errs)


def write_calculation(
    session: Session, doc: PurchaseDocument, inp: DocumentInput, calc: CalculatedDocument
) -> None:
    """Copy the validated input and server-side calculation onto the document (replaces lines)."""
    settings = get_settings()
    doc.project_id, doc.cost_center_id, doc.supplier_id = (
        inp.project_id,
        inp.cost_center_id,
        inp.supplier_id,
    )
    doc.doc_type, doc.supplier_ref, doc.purchase_date = (
        inp.doc_type,
        inp.supplier_ref,
        inp.purchase_date,
    )
    doc.currency, doc.description, doc.business_purpose = (
        inp.currency,
        inp.description,
        inp.business_purpose,
    )
    doc.payment_method, doc.shipping, doc.other_charges = (
        inp.payment_method,
        inp.shipping,
        inp.other_charges,
    )
    doc.shipping_tax_rate = inp.shipping_tax_rate
    doc.subtotal, doc.discount_total, doc.tax_total, doc.total = (
        calc.subtotal,
        calc.discount_total,
        calc.tax_total,
        calc.total,
    )
    rate = fx_service.get_rate(
        session, inp.currency, inp.purchase_date, settings.reporting_currency
    )
    doc.reporting_currency = settings.reporting_currency
    doc.fx_rate = rate
    doc.total_reporting = None if rate is None else (calc.total * rate).quantize(Decimal("0.01"))
    doc.lines.clear()
    session.flush()
    for i, (ln, cl) in enumerate(zip(inp.lines, calc.lines, strict=True), start=1):
        doc.lines.append(
            LineItem(
                line_no=i,
                description=ln.description.strip(),
                category=ln.category,
                quantity=ln.quantity,
                unit=ln.unit,
                unit_price=ln.unit_price,
                discount_rate=ln.discount_rate,
                tax_rate=ln.tax_rate,
                discount_amount=cl.discount_amount,
                net_amount=cl.net_amount,
                tax_amount=cl.tax_amount,
                line_total=cl.line_total,
            )
        )


def document_to_input(doc: PurchaseDocument) -> DocumentInput:
    """Rebuild the editable input from a stored document (used for recalculation/corrections)."""
    return DocumentInput(
        project_id=doc.project_id,
        cost_center_id=doc.cost_center_id,
        supplier_id=doc.supplier_id,
        doc_type=doc.doc_type,
        purchase_date=doc.purchase_date,
        currency=doc.currency,
        supplier_ref=doc.supplier_ref,
        description=doc.description,
        business_purpose=doc.business_purpose,
        payment_method=doc.payment_method,
        shipping=doc.shipping,
        other_charges=doc.other_charges,
        shipping_tax_rate=doc.shipping_tax_rate,
        lines=tuple(
            LineInput(
                description=ln.description,
                quantity=ln.quantity,
                unit_price=ln.unit_price,
                unit=ln.unit,
                discount_rate=ln.discount_rate,
                tax_rate=ln.tax_rate,
                category=ln.category,
            )
            for ln in doc.lines
        ),
    )


def create_draft(session: Session, actor: User, inp: DocumentInput) -> PurchaseDocument:
    require(actor, Perm.DOC_CREATE)
    calc = validate_or_raise(inp)
    _check_references(session, inp)
    doc = PurchaseDocument(
        doc_number="TMP-" + uuid.uuid4().hex,
        employee_id=actor.id,
        org_unit_id=actor.org_unit_id,
        project_id=inp.project_id,
        cost_center_id=inp.cost_center_id,
        supplier_id=inp.supplier_id,
        doc_type=inp.doc_type,
        purchase_date=inp.purchase_date,
        currency=inp.currency,
        status=DRAFT,
        created_at=utcnow(),
    )
    session.add(doc)
    session.flush()
    doc.doc_number = f"PD-{inp.purchase_date.year}-{doc.id:06d}"
    write_calculation(session, doc, inp, calc)
    audit_log.record(
        session,
        actor_id=actor.id,
        action="document.created",
        entity_type="document",
        entity_id=doc.id,
        payload={"doc_number": doc.doc_number, "total": str(doc.total), "currency": doc.currency},
    )
    return doc


def update_draft(
    session: Session, actor: User, doc_id: int, inp: DocumentInput
) -> PurchaseDocument:
    """Drafts are not yet financial records, so the owner may edit them freely."""
    doc = get_document(session, actor, doc_id)
    if doc.employee_id != actor.id or doc.status != DRAFT:
        raise PermissionDenied("Only the owner can edit a document, and only while it is a draft.")
    calc = validate_or_raise(inp)
    _check_references(session, inp)
    write_calculation(session, doc, inp, calc)
    audit_log.record(
        session,
        actor_id=actor.id,
        action="document.draft_updated",
        entity_type="document",
        entity_id=doc.id,
        payload={"total": str(doc.total)},
    )
    return doc


def find_exact_duplicates(session: Session, doc: PurchaseDocument) -> list[int]:
    """Exact-match hint only (same supplier + reference + currency + total). Not proof of duplication."""
    if not doc.supplier_ref:
        return []
    rows = session.execute(
        select(PurchaseDocument.id).where(
            PurchaseDocument.id != doc.id,
            PurchaseDocument.supplier_id == doc.supplier_id,
            PurchaseDocument.supplier_ref == doc.supplier_ref,
            PurchaseDocument.currency == doc.currency,
            PurchaseDocument.total == doc.total,
            PurchaseDocument.status != CANCELLED,
        )
    ).scalars()
    return list(rows)


def submit(session: Session, actor: User, doc_id: int) -> PurchaseDocument:
    from app.services.approval_service import apply_transition

    doc = get_document(session, actor, doc_id)
    if doc.employee_id != actor.id:
        raise PermissionDenied("Only the owner can submit a document.")
    if not doc.lines:
        raise ValidationError("A document without line items cannot be submitted.")
    # Re-run validation + calculation at submit time: never trust stored totals blindly.
    calc = calculate(document_to_input(doc))
    if calc.total != doc.total:
        raise ValidationError("Stored total does not match recalculation; re-save the draft.")
    apply_transition(session, actor, doc, SUBMITTED, "owner")
    doc.submitted_at = utcnow()
    dups = find_exact_duplicates(session, doc)
    audit_log.record(
        session,
        actor_id=actor.id,
        action="document.submitted",
        entity_type="document",
        entity_id=doc.id,
        payload={"total": str(doc.total), "possible_exact_duplicates": dups},
    )
    notification_service.notify_role_in_org(
        session,
        "purchasing_manager",
        doc.org_unit_id,
        f"{doc.doc_number} submitted by {actor.full_name} awaits review.",
        doc.id,
    )
    return doc


def get_document(session: Session, actor: User, doc_id: int) -> PurchaseDocument:
    doc = session.execute(
        select(PurchaseDocument)
        .where(PurchaseDocument.id == doc_id)
        .options(
            selectinload(PurchaseDocument.lines),
            selectinload(PurchaseDocument.attachments),
        )
    ).scalar_one_or_none()
    if doc is None:
        raise NotFound(f"Document {doc_id} was not found.")
    require_view(actor, doc)
    return doc


@dataclass(frozen=True)
class DocumentFilter:
    statuses: tuple[str, ...] = ()
    search: str = ""
    only_own: bool = False


def list_documents(
    session: Session,
    actor: User,
    flt: DocumentFilter | None = None,
    page: int = 1,
    page_size: int = 25,
) -> tuple[list[PurchaseDocument], int]:
    flt = flt or DocumentFilter()
    base = scoped_query(session, actor)
    if flt.only_own:
        base = base.where(PurchaseDocument.employee_id == actor.id)
    if flt.statuses:
        base = base.where(PurchaseDocument.status.in_(flt.statuses))
    if flt.search.strip():
        like = f"%{flt.search.strip()}%"
        base = base.where(
            or_(
                PurchaseDocument.doc_number.like(like),
                PurchaseDocument.supplier_ref.like(like),
                PurchaseDocument.description.like(like),
            )
        )
    total = session.execute(select(func.count()).select_from(base.subquery())).scalar_one()
    rows = session.execute(
        base.options(
            selectinload(PurchaseDocument.supplier),
            selectinload(PurchaseDocument.employee),
            selectinload(PurchaseDocument.project),
        )
        .order_by(PurchaseDocument.created_at.desc(), PurchaseDocument.id.desc())
        .limit(page_size)
        .offset((max(page, 1) - 1) * page_size)
    ).scalars()
    return list(rows), total


def correction_deadline(doc: PurchaseDocument):
    if doc.submitted_at is None:
        return None
    return doc.submitted_at + timedelta(hours=get_settings().correction_window_hours)


def within_correction_window(doc: PurchaseDocument, now=None) -> bool:
    deadline = correction_deadline(doc)
    return deadline is not None and (now or utcnow()) <= deadline


__all__ = [
    "ALL_STATUSES",
    "APPROVED",
    "CANCELLED",
    "CORRECTION_REQUESTED",
    "DRAFT",
    "REJECTED",
    "RESUBMITTED",
    "SUBMITTED",
    "UNDER_REVIEW",
    "InvalidTransition",
    "create_draft",
    "get_document",
    "list_documents",
    "submit",
    "update_draft",
]
