"""Deterministic, rule-based field extraction from OCR/PDF text and speech transcripts.

This is NOT a trained language model and it is not a general invoice parser. It recognises
label-anchored fields (invoice number, dates, totals, currency), matches suppliers against the
known supplier list and parses simple 'description qty unit-price amount' table rows.
Confidences are heuristic scores of the rule that fired (adjusted by OCR confidence); they are
not probabilities. Missing or contradictory values are reported, never silently resolved.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher

from app.utils.currency import SUPPORTED_CURRENCIES

MONTHS = {
    m: i
    for i, m in enumerate(
        [
            "january",
            "february",
            "march",
            "april",
            "may",
            "june",
            "july",
            "august",
            "september",
            "october",
            "november",
            "december",
        ],
        1,
    )
}
MONTHS.update({k[:3]: v for k, v in list(MONTHS.items())})
SYMBOLS = {"€": "EUR", "£": "GBP"}
LEGAL = re.compile(r"\b(gmbh|ag|kg|ltd|llc|inc|sp\.? z o\.?o\.?|co\.?|synthetic)\b|[()]", re.I)


@dataclass
class ExtractedField:
    name: str
    value: object | None
    confidence: float
    evidence: str = ""
    candidates: list[object] = field(default_factory=list)


@dataclass
class ExtractedLine:
    description: str
    quantity: Decimal
    unit: str
    unit_price: Decimal
    amount: Decimal
    consistent: bool
    raw: str


@dataclass
class ExtractionResult:
    fields: dict[str, ExtractedField]
    lines: list[ExtractedLine]
    issues: list[str]
    missing: list[str]


def parse_amount(text: str) -> Decimal | None:
    s = re.sub(r"[^\d.,]", "", text.strip())
    if not s or not re.search(r"\d", s):
        return None
    if "," in s and "." in s:
        dec = "," if s.rfind(",") > s.rfind(".") else "."
        thou = "." if dec == "," else ","
        s = s.replace(thou, "").replace(dec, ".")
    elif "," in s:
        s = (
            s.replace(",", ".")
            if re.search(r",\d{1,2}$", s) and s.count(",") == 1
            else s.replace(",", "")
        )
    elif s.count(".") > 1:
        s = s.replace(".", "")
    try:
        return Decimal(s)
    except InvalidOperation:
        return None


def _norm(name: str) -> str:
    return re.sub(r"\s+", " ", LEGAL.sub(" ", name.lower())).strip()


def parse_dates(text: str) -> list[tuple[date, bool, str]]:
    """Return (date, labelled, line) candidates. Due dates are ignored."""
    out: list[tuple[date, bool, str]] = []
    for line in text.splitlines():
        low = line.lower()
        if re.search(r"\b(due|fällig|payable|zahlbar|valid until)\b", low):
            continue
        labelled = bool(re.search(r"\b(date|datum|dated)\b", low))
        for m in re.finditer(r"\b(\d{4})-(\d{2})-(\d{2})\b", line):
            _add(out, m.group(1), m.group(2), m.group(3), labelled, line)
        for m in re.finditer(r"\b(\d{1,2})[./](\d{1,2})[./](\d{4})\b", line):
            _add(out, m.group(3), m.group(2), m.group(1), labelled, line)  # day first (European)
        for m in re.finditer(
            r"\b(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]{3,9})\.?,?\s+(\d{4})\b", line
        ):
            mo = MONTHS.get(m.group(2).lower())
            if mo:
                _add(out, m.group(3), str(mo), m.group(1), labelled, line)
        for m in re.finditer(
            r"\b([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b", line
        ):
            mo = MONTHS.get(m.group(1).lower())
            if mo:
                _add(out, m.group(3), str(mo), m.group(2), labelled, line)
    return out


def _add(out, y, m, d, labelled, line):
    try:
        out.append((date(int(y), int(m), int(d)), labelled, line.strip()))
    except ValueError:
        pass


def parse_currency(text: str) -> tuple[str | None, list[str]]:
    counts: dict[str, int] = {}
    for m in re.finditer(r"\b(" + "|".join(SUPPORTED_CURRENCIES) + r")\b", text):
        counts[m.group(1)] = counts.get(m.group(1), 0) + 1
    for sym, code in SYMBOLS.items():
        n = text.count(sym)
        if n:
            counts[code] = counts.get(code, 0) + n
    if "$" in text and not counts:
        counts["USD"] = text.count("$")
    if not counts:
        return None, []
    ranked = sorted(counts, key=lambda c: -counts[c])
    return ranked[0], ranked


_LINE_RE = re.compile(
    r"^\s*(?:\d{1,2}[.)]?\s+)?(?P<desc>[A-Za-z].*?)\s+(?P<qty>\d+(?:[.,]\d+)?)\s*(?P<unit>pcs|pc|stk|kg|m|l|h|set|lot)?\s+"
    r"(?P<price>[\d.,]*\d)\s*(?:[A-Z]{3}|€|£|\$)?\s+(?P<amount>[\d.,]*\d)\s*(?:[A-Z]{3}|€|£|\$)?\s*$",
    re.I,
)
_UNIT_MAP = {"pc": "pcs", "stk": "pcs"}


def parse_lines(text: str) -> list[ExtractedLine]:
    out = []
    for raw in text.splitlines():
        if re.search(r"\b(total|subtotal|vat|tax|gesamt|summe|mwst|shipping)\b", raw, re.I):
            continue
        m = _LINE_RE.match(raw)
        if not m:
            continue
        qty, price, amount = (
            parse_amount(m["qty"]),
            parse_amount(m["price"]),
            parse_amount(m["amount"]),
        )
        if qty is None or price is None or amount is None or qty <= 0:
            continue
        unit = (m["unit"] or "pcs").lower()
        consistent = abs(qty * price - amount) <= max(Decimal("0.02"), amount * Decimal("0.005"))
        out.append(
            ExtractedLine(
                m["desc"].strip(" -:|"),
                qty,
                _UNIT_MAP.get(unit, unit),
                price,
                amount,
                consistent,
                raw.strip(),
            )
        )
    return out


def match_supplier(text: str, suppliers: list[tuple[int, str]]) -> ExtractedField:
    nt = _norm(text)
    best: tuple[float, int, str] | None = None
    for sid, name in suppliers:
        nn = _norm(name)
        if nn and nn in nt:
            if best is None or len(nn) > len(_norm(best[2])):
                best = (0.9, sid, name)
    if best:
        return ExtractedField(
            "supplier", best[1], best[0], f"supplier name '{best[2]}' found in text"
        )
    head = [ln for ln in text.splitlines() if ln.strip()][:6]
    scored = []
    for ln in head:
        for sid, name in suppliers:
            r = SequenceMatcher(None, _norm(ln), _norm(name)).ratio()
            if r >= 0.85:
                scored.append((r, sid, name, ln))
    if scored:
        r, sid, name, ln = max(scored)
        return ExtractedField(
            "supplier", sid, round(0.5 + 0.3 * r, 2), f"line '{ln.strip()}' resembles '{name}'"
        )
    return ExtractedField(
        "supplier",
        None,
        0.0,
        f"no known supplier recognised (first line: '{head[0].strip()}')" if head else "no text",
    )


def extract_fields(
    text: str, suppliers: list[tuple[int, str]], ocr_confidence: float | None = None
) -> ExtractionResult:
    issues: list[str] = []
    fields: dict[str, ExtractedField] = {}
    scale = 1.0 if ocr_confidence is None else max(0.2, min(1.0, ocr_confidence + 0.15))

    fields["supplier"] = match_supplier(text, suppliers)
    fields["supplier"].confidence = round(fields["supplier"].confidence * scale, 2)

    refs = []
    for m in re.finditer(
        r"(?im)\b(?:invoice|inv\.?|rechnung(?:s)?|quotation|quote|angebot|receipt|beleg)\s*(?:no\.?|number|nr\.?|num\.?|#)?\s*[:#]?\s*([A-Z0-9][A-Z0-9\-/]{3,})",
        text,
    ):
        cand = m.group(1).strip("-/")
        if re.search(r"\d", cand) and cand not in refs:
            refs.append(cand)
    fields["supplier_ref"] = ExtractedField(
        "supplier_ref",
        refs[0] if refs else None,
        round(0.8 * scale, 2) if refs else 0.0,
        "label-anchored match" if refs else "no invoice/quotation number found",
        refs,
    )
    if len(refs) > 1:
        issues.append(f"Several different document numbers were found: {', '.join(refs)}.")

    dates = parse_dates(text)
    labelled = [d for d in dates if d[1]]
    pick = labelled or dates
    distinct = sorted({d[0] for d in pick})
    fields["purchase_date"] = ExtractedField(
        "purchase_date",
        pick[0][0] if pick else None,
        round((0.8 if labelled else 0.4) * scale, 2) if pick else 0.0,
        pick[0][2] if pick else "no date found",
        distinct,
    )
    if len(distinct) > 1:
        issues.append(
            "Several different dates were found: "
            + ", ".join(d.isoformat() for d in distinct)
            + "."
        )

    cur, ranked = parse_currency(text)
    fields["currency"] = ExtractedField(
        "currency",
        cur,
        round((0.8 if cur else 0.0) * scale, 2),
        "currency code/symbol found in text" if cur else "no currency found",
        ranked,
    )
    if len(ranked) > 1:
        issues.append("Several currencies appear in the text: " + ", ".join(ranked) + ".")
    if "$" in text and cur == "USD":
        issues.append("'$' was read as USD; it can also mean other dollar currencies.")

    totals: dict[str, list[Decimal]] = {"total": [], "subtotal": [], "tax_total": []}
    for ln in text.splitlines():
        nums = re.findall(r"[\d][\d.,]*\d|\d", ln)
        if not nums:
            continue
        amount = parse_amount(nums[-1])
        if amount is None:
            continue
        if re.search(r"sub\s?-?total|zwischensumme|net amount|netto", ln, re.I):
            totals["subtotal"].append(amount)
        elif re.search(r"\b(vat|tax|mwst|ust|steuer)\b", ln, re.I):
            totals["tax_total"].append(amount)
        elif re.search(
            r"grand total|total due|amount due|total amount|\btotal\b|gesamt|endbetrag|summe",
            ln,
            re.I,
        ):
            totals["total"].append(amount)
    for name, vals in totals.items():
        distinct_vals = sorted(set(vals))
        fields[name] = ExtractedField(
            name,
            vals[-1] if vals else None,
            round(0.75 * scale, 2) if vals else 0.0,
            "label-anchored amount" if vals else f"no {name} found",
            distinct_vals,
        )
        if name == "total" and len(distinct_vals) > 1:
            issues.append(
                "Several different totals were found: "
                + ", ".join(str(v) for v in distinct_vals)
                + "."
            )

    lines = parse_lines(text)
    for ln in lines:
        if not ln.consistent:
            issues.append(
                f"Line '{ln.description}': quantity x price ({ln.quantity * ln.unit_price}) differs from amount ({ln.amount})."
            )
    total = fields["total"].value
    if lines and total is not None:
        calc = sum((ln.amount for ln in lines), Decimal("0")) + (
            fields["tax_total"].value or Decimal("0")
        )
        if abs(calc - total) > Decimal("0.02"):
            issues.append(
                f"Extracted total {total} differs from the sum of lines plus tax ({calc}); "
                "shipping, discounts or OCR errors may explain this."
            )
    if not lines:
        issues.append("No line items could be read from the text; enter them manually.")
    missing = [
        n
        for n in ("supplier", "supplier_ref", "purchase_date", "currency", "total")
        if fields[n].value is None
    ]
    return ExtractionResult(fields, lines, issues, missing)


@dataclass(frozen=True)
class FieldConflict:
    field: str
    options: list[tuple[str, object]]  # (source, value)


def _same(a: object, b: object) -> bool:
    """Equal if numerically equal (when both parse as numbers) or equal ignoring case/space."""
    try:
        return Decimal(str(a).strip()) == Decimal(str(b).strip())
    except InvalidOperation:
        return str(a).strip().lower() == str(b).strip().lower()


def find_conflicts(sources: dict[str, dict[str, object]]) -> list[FieldConflict]:
    """sources: {'manual': {...}, 'document': {...}, 'speech': {...}} -> conflicting fields.

    Empty values are ignored. Any field with two or more different non-empty values from
    different sources is a conflict the employee must resolve; nothing is chosen automatically.
    """
    names = sorted({f for vals in sources.values() for f in vals})
    out = []
    for name in names:
        opts = [
            (src, vals[name])
            for src, vals in sources.items()
            if vals.get(name) not in (None, "", 0)
        ]
        distinct: list[object] = []
        for _, v in opts:
            if not any(_same(v, d) for d in distinct):
                distinct.append(v)
        if len(distinct) > 1:
            out.append(FieldConflict(name, opts))
    return out
