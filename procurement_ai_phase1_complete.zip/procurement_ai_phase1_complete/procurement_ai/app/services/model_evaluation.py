"""Evaluation of the ML components against ground truth injected by the synthetic generator.

All numbers produced here describe SYNTHETIC scenarios built by the same author as the
detectors; they show the pipeline works as designed, not how it would perform on real data.
"""

from __future__ import annotations

import itertools
import random
from collections import defaultdict

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import LineItem, PurchaseDocument, SyntheticLabel
from app.ml import anomaly_detection as ad
from app.ml import duplicate_detection as dd
from app.ml.evaluation import classification_metrics, confusion_counts
from app.ml.item_matching import match_items, normalize_item, text_similarity
from app.services import analytics_service as an
from app.services.document_service import CANCELLED, DRAFT

ANOMALY_KINDS = ("price_spike", "quantity_spike", "near_threshold")
NON_ANOMALY_CLONES = ("duplicate_exact", "duplicate_near", "legit_repeat", "hard_negative")


def _labels(
    session: Session, kinds: tuple[str, ...], entity_type: str = "document"
) -> list[SyntheticLabel]:
    return list(
        session.execute(
            select(SyntheticLabel).where(
                SyntheticLabel.entity_type == entity_type, SyntheticLabel.kind.in_(kinds)
            )
        ).scalars()
    )


def evaluate_anomaly(session: Session, train_fraction: float = 0.7, seed: int = 42) -> dict:
    """Chronological split: fit on the earliest documents, evaluate on the later ones."""
    lines, docs = an.load_frames(session, select(PurchaseDocument))
    inj = {lab.entity_id: lab.kind for lab in _labels(session, ANOMALY_KINDS)}
    clones = {lab.entity_id for lab in _labels(session, NON_ANOMALY_CLONES)}
    docs = docs[~docs["document_id"].isin(clones)].copy()
    lines = lines[lines["document_id"].isin(docs["document_id"])]
    cutoff = docs["purchase_date"].sort_values().iloc[int(len(docs) * train_fraction)]
    train_d = docs[docs["purchase_date"] < cutoff]
    test_d = docs[docs["purchase_date"] >= cutoff]
    model = ad.fit(lines[lines["document_id"].isin(train_d["document_id"])], train_d, seed)
    scores = ad.score(
        model, lines[lines["document_id"].isin(test_d["document_id"])], test_d, context=docs
    )
    truth = [int(i) in inj for i in scores.index]
    out = {
        "train_docs": len(train_d),
        "test_docs": len(test_d),
        "test_injected": int(sum(truth)),
        "cutoff": str(cutoff),
        "methods": {},
        "recall_by_kind": {},
    }
    methods = {
        "rules_only": scores["rules"].map(bool),
        "isolation_forest_only": scores["model_flag"],
        "rules_plus_isolation_forest": scores["flagged"],
    }
    for name, pred in methods.items():
        out["methods"][name] = classification_metrics(*confusion_counts(truth, list(pred))) | {
            "flagged": int(pred.sum())
        }
    for kind in ANOMALY_KINDS:
        idx = [i for i in scores.index if inj.get(int(i)) == kind]
        if idx:
            out["recall_by_kind"][kind] = {
                "n": len(idx),
                "rules_plus_isolation_forest": float(scores.loc[idx, "flagged"].mean()),
                "isolation_forest_only": float(scores.loc[idx, "model_flag"].mean()),
                "rules_only": float(scores.loc[idx, "rules"].map(bool).mean()),
            }
    return out


def evaluate_duplicates(session: Session) -> dict:
    from app.database.models import PurchaseDocument as D

    recs = an.duplicate_records(session, select(D))
    found = dd.find_candidates(recs)
    pairs = {(m.doc_a, m.doc_b) for m in found}
    pos = {
        tuple(sorted((lab.entity_id, int(lab.value))))
        for lab in _labels(session, ("duplicate_exact", "duplicate_near"))
    }
    neg_legit = {
        tuple(sorted((lab.entity_id, int(lab.value))))
        for lab in _labels(session, ("legit_repeat",))
    }
    neg_hard = {
        tuple(sorted((lab.entity_id, int(lab.value))))
        for lab in _labels(session, ("hard_negative",))
    }
    tp = len(pos & pairs)
    # Precision treats every unlabeled candidate as a false positive (conservative).
    fp = len(pairs - pos)
    fn = len(pos - pairs)
    # Baseline: same supplier + same currency + same total (what "identical amount" alone gives).
    by_amt = defaultdict(list)
    for r in recs:
        by_amt[(r.supplier_id, r.doc_type, r.currency, r.total)].append(r.id)
    base_pairs = {
        tuple(sorted(p))
        for ids in by_amt.values()
        if len(ids) > 1
        for p in itertools.combinations(ids, 2)
    }
    btp, bfp, bfn = len(pos & base_pairs), len(base_pairs - pos), len(pos - base_pairs)
    return {
        "labeled_duplicate_pairs": len(pos),
        "candidates_found": len(pairs),
        "detector": classification_metrics(tp, fp, fn),
        "amount_only_baseline": classification_metrics(btp, bfp, bfn),
        "legitimate_repeat_pairs": len(neg_legit),
        "legitimate_repeats_flagged": len(neg_legit & pairs),
        "hard_negative_pairs": len(neg_hard),
        "hard_negatives_flagged": len(neg_hard & pairs),
    }


def evaluate_item_matching(session: Session, max_pairs: int = 3000, seed: int = 7) -> dict:
    rows = session.execute(select(LineItem.id, LineItem.description, LineItem.unit)).all()
    keys = {lab.entity_id: lab.value for lab in _labels(session, ("item_key",), "line")}
    desc_key: dict[tuple[str, str], str] = {}
    for lid, desc, unit in rows:
        if lid in keys:
            desc_key[(desc, unit)] = keys[lid]
    items = list(desc_key.items())
    by_key = defaultdict(list)
    by_type = defaultdict(set)
    for (d, u), k in items:
        by_key[k].append((d, u))
        by_type[k.split("|")[1]].add(k)
    rng = random.Random(seed)
    positives = [(a, b) for lst in by_key.values() for a, b in itertools.combinations(lst, 2)]
    rng.shuffle(positives)
    positives = positives[:max_pairs]
    negatives = []
    all_keys = list(by_key)
    while len(negatives) < len(positives):
        k1 = rng.choice(all_keys)
        same_family = [k for k in all_keys if k != k1 and k.split("|")[1] == k1.split("|")[1]]
        if same_family and rng.random() < 0.8:
            k2 = rng.choice(same_family)
        else:
            k2 = rng.choice([k for k in all_keys if k != k1])
        negatives.append((rng.choice(by_key[k1]), rng.choice(by_key[k2])))
    pairs = [(p, True) for p in positives] + [(n, False) for n in negatives]
    truth = [t for _, t in pairs]
    pred_attr, sims = [], []
    for (a, b), _ in pairs:
        res = match_items(normalize_item(*a), normalize_item(*b))
        pred_attr.append(res.level == "technically_comparable")
        sims.append(text_similarity(a[0], b[0]))
    out = {
        "positive_pairs": len(positives),
        "negative_pairs": len(negatives),
        "attribute_first_matcher": classification_metrics(*confusion_counts(truth, pred_attr)),
    }
    best = None
    for thr in [x / 100 for x in range(50, 100, 2)]:
        m = classification_metrics(*confusion_counts(truth, [s >= thr for s in sims]))
        m["threshold"] = thr
        if best is None or m["f1"] > best["f1"]:
            best = m
    out["text_similarity_only_best_threshold"] = best
    out["text_similarity_only_threshold_0.85"] = classification_metrics(
        *confusion_counts(truth, [s >= 0.85 for s in sims])
    )
    return out


CHALLENGE_PAIRS = [
    # (A, B, truly_equivalent) hand-written phrasings NOT used when designing the parser rules
    ("Ball valve DN50 PN16 stainless 316", "Kugelhahn DN50 PN16 Edelstahl 316", True),
    ("Hex bolt M10 x 50 A2", "Hex bolt M10 x 50 A2 DIN 933", True),
    ("Ball valve DN50 PN16 stainless 316", "Ball valve 2 inch PN16 stainless 316", True),
    ("Steel plate 10 mm S355J2", "S355J2 sheet 10 mm", True),
    ("Control cable 5x1.5 mm2", "Control cable 5G1.5", True),
    ("Hydraulic oil ISO VG 46", "Hydraulic oil HLP 46", True),
    ("Ball valve DN50 PN16 stainless 316", "Ball valve DN50 PN40 stainless 316", False),
    ("Hex bolt M10 x 50 A2", "Hex bolt M10 x 60 A2", False),
    ("Steel plate 10 mm S355J2", "Steel plate 12 mm S355J2", False),
    ("Torque wrench 100 Nm", "Torque wrench 200 Nm", False),
    ("Safety gloves EN388 size 9", "Safety gloves EN388 size 10", False),
    ("Ball bearing 6204-2RS", "Ball bearing 6205-2RS", False),
    ("Hex bolt M10 x 50 A2", "Hex nut M10 A2", False),
    ("Hydraulic oil ISO VG 46", "Hydraulic oil ISO VG 68", False),
]


def evaluate_challenge_set() -> dict:
    """Hand-written phrasings outside the generator's templates: an honest limit check."""
    rows = []
    for a, b, truth in CHALLENGE_PAIRS:
        res = match_items(normalize_item(a, "pcs"), normalize_item(b, "pcs"))
        pred = res.level == "technically_comparable"
        rows.append({"a": a, "b": b, "truth": truth, "level": res.level, "correct": pred == truth})
    acc = sum(r["correct"] for r in rows) / len(rows)
    return {"pairs": rows, "accuracy": acc}


def evaluate_forecast(session: Session, actor) -> dict:
    res = an.spend_forecast(session, actor)
    if not res.metrics:
        return {"warning": res.warnings}
    return {
        "history_months": len(res.history),
        "chosen": res.chosen,
        "metrics": res.metrics,
        "backtest_months": len(res.backtest),
    }


def labeled_doc_count(session: Session) -> int:
    return len(_labels(session, ANOMALY_KINDS))


__all__ = ["CANCELLED", "DRAFT", "pd"]
