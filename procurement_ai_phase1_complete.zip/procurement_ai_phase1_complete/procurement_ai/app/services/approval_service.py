"""Explicit document state machine. Status can only change through apply_transition()."""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.database.models import PurchaseDocument, User
from app.security import audit_log
from app.security.authorization import Perm, require, require_decide
from app.services import notification_service
from app.services.document_service import (
    APPROVED,
    CANCELLED,
    CORRECTION_REQUESTED,
    DRAFT,
    REJECTED,
    RESUBMITTED,
    SUBMITTED,
    UNDER_REVIEW,
    get_document,
    within_correction_window,
)
from app.utils.dates import utcnow
from app.utils.exceptions import InvalidTransition, PermissionDenied, ValidationError

# (from, to) -> kind of actor allowed to trigger it.
#   owner    : the employee who created the document
#   reviewer : manager / project manager / admin within scope (checked via require_decide)
#   system   : only internal callers in correction_service (never exposed to the UI directly)
TRANSITIONS: dict[tuple[str, str], str] = {
    (DRAFT, SUBMITTED): "owner",
    (DRAFT, CANCELLED): "owner",
    (SUBMITTED, CANCELLED): "owner",
    (SUBMITTED, UNDER_REVIEW): "reviewer",
    (RESUBMITTED, UNDER_REVIEW): "reviewer",
    (UNDER_REVIEW, APPROVED): "reviewer",
    (UNDER_REVIEW, REJECTED): "reviewer",
    (SUBMITTED, CORRECTION_REQUESTED): "system",
    (UNDER_REVIEW, CORRECTION_REQUESTED): "system",
    (RESUBMITTED, CORRECTION_REQUESTED): "system",
    (APPROVED, CORRECTION_REQUESTED): "system",  # only via audited deadline exception
    (CORRECTION_REQUESTED, RESUBMITTED): "system",
    (CORRECTION_REQUESTED, SUBMITTED): "system",  # correction rejected: restore prior state
    (CORRECTION_REQUESTED, UNDER_REVIEW): "system",
    (CORRECTION_REQUESTED, APPROVED): "system",
}


def allowed_next_states(doc: PurchaseDocument, kind: str) -> list[str]:
    return [to for (frm, to), k in TRANSITIONS.items() if frm == doc.status and k == kind]


def apply_transition(
    session: Session,
    actor: User,
    doc: PurchaseDocument,
    to_status: str,
    kind: str,
    note: str | None = None,
) -> None:
    key = (doc.status, to_status)
    if TRANSITIONS.get(key) != kind:
        raise InvalidTransition(f"Transition {doc.status} -> {to_status} is not allowed here.")
    if kind == "owner" and doc.employee_id != actor.id:
        raise PermissionDenied("Only the document owner can do this.")
    if kind == "reviewer":
        require(actor, Perm.DOC_DECIDE)
        require_decide(actor, doc)
    old = doc.status
    doc.status = to_status
    audit_log.record(
        session,
        actor_id=actor.id,
        action="document.status_changed",
        entity_type="document",
        entity_id=doc.id,
        payload={"from": old, "to": to_status, "note": note or ""},
    )


def start_review(session: Session, actor: User, doc_id: int) -> PurchaseDocument:
    doc = get_document(session, actor, doc_id)
    apply_transition(session, actor, doc, UNDER_REVIEW, "reviewer")
    return doc


def approve(session: Session, actor: User, doc_id: int, note: str = "") -> PurchaseDocument:
    doc = get_document(session, actor, doc_id)
    apply_transition(session, actor, doc, APPROVED, "reviewer", note)
    doc.decided_at, doc.decided_by, doc.decision_note = utcnow(), actor.id, note or None
    notification_service.notify(session, doc.employee_id, f"{doc.doc_number} was approved.", doc.id)
    return doc


def reject(session: Session, actor: User, doc_id: int, reason: str) -> PurchaseDocument:
    if not reason or not reason.strip():
        raise ValidationError("A reason is required to reject a document.")
    doc = get_document(session, actor, doc_id)
    apply_transition(session, actor, doc, REJECTED, "reviewer", reason.strip())
    doc.decided_at, doc.decided_by, doc.decision_note = utcnow(), actor.id, reason.strip()
    notification_service.notify(
        session, doc.employee_id, f"{doc.doc_number} was rejected: {reason.strip()[:200]}", doc.id
    )
    return doc


def cancel(session: Session, actor: User, doc_id: int, reason: str = "") -> PurchaseDocument:
    doc = get_document(session, actor, doc_id)
    if doc.status == SUBMITTED and not within_correction_window(doc):
        raise InvalidTransition(
            "The cancellation window has expired; submit a correction request instead."
        )
    apply_transition(session, actor, doc, CANCELLED, "owner", reason)
    return doc
