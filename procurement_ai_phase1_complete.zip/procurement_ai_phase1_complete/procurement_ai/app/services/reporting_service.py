"""KPIs and exports. Every query starts from document_service.scoped_query (permission-aware)."""

from __future__ import annotations

import io
from dataclasses import dataclass
from decimal import Decimal

import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import Project, PurchaseDocument, Supplier, User
from app.security.authorization import Perm, require
from app.services.document_service import CANCELLED, DRAFT, REJECTED, scoped_query
from app.utils.dates import format_local, utcnow

SYNTHETIC_NOTE = (
    "Demo data is synthetic and does not represent real expenditure, quotations "
    "or verified market prices."
)
_EXCLUDED = (DRAFT, CANCELLED, REJECTED)


@dataclass(frozen=True)
class Kpis:
    submitted_total_reporting: Decimal
    documents_counted: int
    pending_approvals: int
    pending_corrections: int
    avg_approval_hours: float | None
    missing_fx_count: int
    reporting_currency: str


def compute_kpis(session: Session, actor: User) -> Kpis:
    """Definitions: spend = SUM(total_reporting) of documents not draft/cancelled/rejected;
    pending approvals = status in (submitted, resubmitted, under_review);
    avg approval hours = mean(decided_at - submitted_at) over approved documents."""
    require(actor, Perm.ANALYTICS_VIEW)
    sub = scoped_query(session, actor).subquery()
    spend, count = session.execute(
        select(func.coalesce(func.sum(sub.c.total_reporting), 0), func.count()).where(
            sub.c.status.not_in(_EXCLUDED)
        )
    ).one()
    pending = session.execute(
        select(func.count())
        .select_from(sub)
        .where(sub.c.status.in_(("submitted", "resubmitted", "under_review")))
    ).scalar_one()
    corr = session.execute(
        select(func.count()).select_from(sub).where(sub.c.status == "correction_requested")
    ).scalar_one()
    missing = session.execute(
        select(func.count())
        .select_from(sub)
        .where(sub.c.status.not_in(_EXCLUDED), sub.c.total_reporting.is_(None))
    ).scalar_one()
    approved = session.execute(
        select(sub.c.submitted_at, sub.c.decided_at).where(
            sub.c.status == "approved",
            sub.c.decided_at.is_not(None),
            sub.c.submitted_at.is_not(None),
        )
    ).all()
    avg_h = None
    if approved:
        hours = [(d - s).total_seconds() / 3600 for s, d in approved]
        avg_h = sum(hours) / len(hours)
    return Kpis(
        Decimal(spend), count, pending, corr, avg_h, missing, get_settings().reporting_currency
    )


def spend_by_month(session: Session, actor: User) -> pd.DataFrame:
    require(actor, Perm.ANALYTICS_VIEW)
    sub = scoped_query(session, actor).subquery()
    month = func.strftime("%Y-%m", sub.c.purchase_date).label("month")
    rows = session.execute(
        select(month, func.sum(sub.c.total_reporting).label("spend"), func.count().label("n"))
        .where(sub.c.status.not_in(_EXCLUDED), sub.c.total_reporting.is_not(None))
        .group_by(month)
        .order_by(month)
    ).all()
    return pd.DataFrame(
        [(m, Decimal(s or 0), n) for m, s, n in rows], columns=["month", "spend", "documents"]
    )


def spend_by(session: Session, actor: User, dimension: str) -> pd.DataFrame:
    require(actor, Perm.ANALYTICS_VIEW)
    sub = scoped_query(session, actor).subquery()
    if dimension == "supplier":
        label = Supplier.name
        join_col = sub.c.supplier_id == Supplier.id
    elif dimension == "project":
        label = Project.code
        join_col = sub.c.project_id == Project.id
    else:
        raise ValueError("dimension must be 'supplier' or 'project'")
    rows = session.execute(
        select(label.label("name"), func.sum(sub.c.total_reporting).label("spend"))
        .select_from(sub)
        .join(Supplier if dimension == "supplier" else Project, join_col)
        .where(sub.c.status.not_in(_EXCLUDED), sub.c.total_reporting.is_not(None))
        .group_by(label)
        .order_by(func.sum(sub.c.total_reporting).desc())
        .limit(15)
    ).all()
    return pd.DataFrame([(n, Decimal(s or 0)) for n, s in rows], columns=["name", "spend"])


def documents_frame(session: Session, actor: User, statuses: tuple[str, ...] = ()) -> pd.DataFrame:
    """Permission-scoped document table for export."""
    require(actor, Perm.REPORT_EXPORT)
    q = (
        scoped_query(session, actor)
        .join(Supplier, PurchaseDocument.supplier_id == Supplier.id)
        .join(Project, PurchaseDocument.project_id == Project.id)
        .with_only_columns(
            PurchaseDocument.doc_number,
            PurchaseDocument.status,
            PurchaseDocument.purchase_date,
            Supplier.name.label("supplier"),
            Project.code.label("project"),
            PurchaseDocument.currency,
            PurchaseDocument.total,
            PurchaseDocument.reporting_currency,
            PurchaseDocument.total_reporting,
            PurchaseDocument.fx_rate,
            PurchaseDocument.is_synthetic,
        )
        .order_by(PurchaseDocument.id)
    )
    if statuses:
        q = q.where(PurchaseDocument.status.in_(statuses))
    rows = session.execute(q).all()
    return pd.DataFrame(
        [tuple(r) for r in rows],
        columns=[
            "doc_number",
            "status",
            "purchase_date",
            "supplier",
            "project",
            "currency",
            "total",
            "reporting_currency",
            "total_reporting",
            "fx_rate",
            "is_synthetic",
        ],
    )


def _meta(actor: User, statuses: tuple[str, ...]) -> list[tuple[str, str]]:
    return [
        ("Generated at", format_local(utcnow())),
        ("Generated by", actor.username),
        ("Reporting currency", get_settings().reporting_currency),
        ("Filters", f"status in {list(statuses)}" if statuses else "none"),
        ("Note", SYNTHETIC_NOTE),
    ]


def export_csv(session: Session, actor: User, statuses: tuple[str, ...] = ()) -> bytes:
    """CSV with '#'-prefixed metadata lines first (use comment='#' when reading with pandas)."""
    df = documents_frame(session, actor, statuses)
    buf = io.StringIO()
    for k, v in _meta(actor, statuses):
        buf.write(f"# {k}: {v}\n")
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


def export_excel(session: Session, actor: User, statuses: tuple[str, ...] = ()) -> bytes:
    df = documents_frame(session, actor, statuses)
    out = io.BytesIO()
    with pd.ExcelWriter(out, engine="openpyxl") as xw:
        pd.DataFrame(_meta(actor, statuses), columns=["Item", "Value"]).to_excel(
            xw, sheet_name="Report info", index=False
        )
        df.astype({"total": float, "total_reporting": float, "fx_rate": float}).to_excel(
            xw, sheet_name="Documents", index=False
        )
    return out.getvalue()


# ---------------------------------------------------------------------- spend analysis (filters)
@dataclass(frozen=True)
class SpendFilter:
    date_from: object | None = None
    date_to: object | None = None
    org_unit_id: int | None = None
    project_id: int | None = None
    supplier_id: int | None = None
    category: str | None = None
    currency: str | None = None
    statuses: tuple[str, ...] = ()


def spend_lines(session: Session, actor: User, flt: SpendFilter) -> pd.DataFrame:
    """Line-level NET spend (excluding tax and shipping) converted to the reporting currency.

    Documents without an exchange rate are excluded and counted in `attrs['missing_fx']`.
    """
    from app.database.models import LineItem, OrgUnit

    require(actor, Perm.ANALYTICS_VIEW)
    q = (
        scoped_query(session, actor)
        .join(LineItem, LineItem.document_id == PurchaseDocument.id)
        .join(Supplier, Supplier.id == PurchaseDocument.supplier_id)
        .join(Project, Project.id == PurchaseDocument.project_id)
        .join(OrgUnit, OrgUnit.id == PurchaseDocument.org_unit_id)
        .with_only_columns(
            PurchaseDocument.id,
            PurchaseDocument.purchase_date,
            OrgUnit.code,
            Project.code,
            Supplier.name,
            LineItem.category,
            PurchaseDocument.currency,
            PurchaseDocument.status,
            LineItem.net_amount,
            PurchaseDocument.fx_rate,
        )
    )
    q = q.where(
        PurchaseDocument.status.in_(flt.statuses)
        if flt.statuses
        else PurchaseDocument.status.not_in(_EXCLUDED)
    )
    if flt.date_from:
        q = q.where(PurchaseDocument.purchase_date >= flt.date_from)
    if flt.date_to:
        q = q.where(PurchaseDocument.purchase_date <= flt.date_to)
    for col, val in (
        (PurchaseDocument.org_unit_id, flt.org_unit_id),
        (PurchaseDocument.project_id, flt.project_id),
        (PurchaseDocument.supplier_id, flt.supplier_id),
        (LineItem.category, flt.category),
        (PurchaseDocument.currency, flt.currency),
    ):
        if val:
            q = q.where(col == val)
    rows = session.execute(q).all()
    df = pd.DataFrame(
        [tuple(r) for r in rows],
        columns=[
            "doc_id",
            "purchase_date",
            "org_unit",
            "project",
            "supplier",
            "category",
            "currency",
            "status",
            "net",
            "fx",
        ],
    )
    missing = int(df["fx"].isna().sum()) if not df.empty else 0
    df = df[df["fx"].notna()].copy() if not df.empty else df
    if not df.empty:
        df["net_reporting"] = [float(n * f) for n, f in zip(df["net"], df["fx"], strict=True)]
        df["month"] = pd.to_datetime(df["purchase_date"]).dt.strftime("%Y-%m")
    df.attrs["missing_fx"] = missing
    return df


def budget_utilization(session: Session, actor: User) -> pd.DataFrame:
    """Per project: budget (EUR budgets only) vs spend on documents the viewer can see."""
    require(actor, Perm.ANALYTICS_VIEW)
    sub = scoped_query(session, actor).subquery()
    spent = (
        select(sub.c.project_id, func.sum(sub.c.total_reporting).label("spent"))
        .where(
            sub.c.status.in_(
                ("submitted", "under_review", "approved", "resubmitted", "correction_requested")
            ),
            sub.c.total_reporting.is_not(None),
        )
        .group_by(sub.c.project_id)
        .subquery()
    )
    rows = session.execute(
        select(Project.code, Project.budget, Project.budget_currency, spent.c.spent).join(
            spent, spent.c.project_id == Project.id
        )
    ).all()
    df = pd.DataFrame(
        [(c, float(b), float(s or 0), cur) for c, b, cur, s in rows],
        columns=["project", "budget", "spent", "budget_currency"],
    )
    if df.empty:
        return df.assign(utilization=[])
    df = df[df["budget_currency"] == get_settings().reporting_currency].copy()
    df["utilization"] = df["spent"] / df["budget"].where(df["budget"] > 0)
    return df.sort_values("utilization", ascending=False).reset_index(drop=True)


def inconsistent_totals(session: Session, actor: User, limit: int = 20000) -> pd.DataFrame:
    """Documents whose stored total differs from lines + shipping + shipping tax + other charges."""
    require(actor, Perm.ANALYTICS_VIEW)
    from app.database.models import LineItem
    from app.utils.currency import quantize_money

    sub = scoped_query(session, actor).subquery()
    lt = (
        select(LineItem.document_id, func.sum(LineItem.line_total).label("lines"))
        .group_by(LineItem.document_id)
        .subquery()
    )
    rows = session.execute(
        select(
            sub.c.doc_number,
            sub.c.currency,
            sub.c.total,
            sub.c.shipping,
            sub.c.other_charges,
            sub.c.shipping_tax_rate,
            lt.c.lines,
            sub.c.status,
        )
        .join(lt, lt.c.document_id == sub.c.id)
        .order_by(sub.c.id.desc())
        .limit(limit)
    ).all()
    bad = []
    for num, cur, total, ship, other, srate, lines_total, status in rows:
        expected = lines_total + ship + other + quantize_money(ship * srate, cur)
        if abs(expected - total) > Decimal("0.01"):
            bad.append((num, status, cur, total, expected))
    return pd.DataFrame(
        bad, columns=["document", "status", "currency", "stored_total", "recalculated"]
    )


def export_pdf(
    session: Session, actor: User, statuses: tuple[str, ...] = (), max_rows: int = 1000
) -> bytes:
    """Simple tabular PDF (first `max_rows` rows). Use CSV/Excel for complete exports."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    df = documents_frame(session, actor, statuses)
    styles = getSampleStyleSheet()
    out = io.BytesIO()
    doc = SimpleDocTemplate(
        out,
        pagesize=landscape(A4),
        leftMargin=24,
        rightMargin=24,
        topMargin=24,
        bottomMargin=24,
        title="Document report",
    )
    story = [Paragraph("Purchase document report", styles["Title"])]
    for k, v in _meta(actor, statuses):
        story.append(Paragraph(f"<b>{k}:</b> {v}", styles["Normal"]))
    shown = df.head(max_rows)
    story.append(
        Paragraph(
            f"Rows shown: {len(shown)} of {len(df)}"
            + (" (truncated; use CSV/Excel for all rows)" if len(df) > max_rows else ""),
            styles["Normal"],
        )
    )
    story.append(Spacer(1, 8))
    header = ["Document", "Status", "Date", "Supplier", "Project", "Cur", "Total", "Total (rep.)"]
    data = [header] + [
        [
            r.doc_number,
            r.status,
            str(r.purchase_date),
            str(r.supplier)[:34],
            r.project,
            r.currency,
            f"{r.total:,.2f}",
            "" if pd.isna(r.total_reporting) else f"{r.total_reporting:,.2f}",
        ]
        for r in shown.itertuples()
    ]
    table = Table(data, repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E79")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 7),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F6FA")]),
                ("ALIGN", (6, 1), (7, -1), "RIGHT"),
            ]
        )
    )
    story.append(table)
    doc.build(story)
    return out.getvalue()
