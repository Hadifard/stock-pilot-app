from __future__ import annotations

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.database.models import Notification, User


def notify(session: Session, user_id: int, message: str, document_id: int | None = None) -> None:
    session.add(Notification(user_id=user_id, message=message[:400], document_id=document_id))


def notify_role_in_org(
    session: Session, role: str, org_unit_id: int, message: str, doc_id: int
) -> None:
    ids = session.execute(
        select(User.id).where(
            User.role == role, User.org_unit_id == org_unit_id, User.is_active.is_(True)
        )
    ).scalars()
    for uid in ids:
        notify(session, uid, message, doc_id)


def list_notifications(session: Session, user: User, limit: int = 50) -> list[Notification]:
    return list(
        session.execute(
            select(Notification)
            .where(Notification.user_id == user.id)
            .order_by(Notification.created_at.desc(), Notification.id.desc())
            .limit(limit)
        ).scalars()
    )


def unread_count(session: Session, user: User) -> int:
    return len(
        session.execute(
            select(Notification.id).where(
                Notification.user_id == user.id, Notification.is_read.is_(False)
            )
        ).all()
    )


def mark_all_read(session: Session, user: User) -> None:
    session.execute(
        update(Notification)
        .where(Notification.user_id == user.id, Notification.is_read.is_(False))
        .values(is_read=True)
    )
