"""Text extraction from PDFs and images with an honest, replaceable provider interface.

Pipeline:
  digital PDF  -> text layer via pypdf (no OCR needed)
  scanned PDF  -> pages rendered with `pdftoppm` (poppler) if installed, else embedded page
                  images; then OCR
  image        -> light preprocessing (grayscale, auto-contrast, upscale small images, mild
                  denoise) then Tesseract OCR with per-word confidences
OCR quality depends on scan quality. Handwriting is NOT reliably recognised by Tesseract; the
result carries a confidence value and warnings so the UI can force a human review.
Optional dependencies: Tesseract binary (+ language data) and pytesseract; poppler for scanned PDFs.
"""

from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

from app.utils.exceptions import UploadRejected

MAX_PAGES = 5
MIN_TEXT_CHARS_PER_PAGE = 25


@dataclass
class ExtractedText:
    text: str
    method: str  # pdf_text | ocr_tesseract | pdf_text+ocr
    confidence: float | None  # mean OCR word confidence 0..1; None for digital text
    pages: int
    warnings: list[str] = field(default_factory=list)


class OcrProvider(ABC):
    name: str

    @abstractmethod
    def available(self) -> bool: ...

    @abstractmethod
    def read_image(self, data: bytes) -> tuple[str, float | None]:
        """Return (text, mean confidence 0..1)."""


def preprocess_image(data: bytes):
    from PIL import Image, ImageFilter, ImageOps

    img = Image.open(io.BytesIO(data))
    img.load()
    img = ImageOps.exif_transpose(img).convert("L")
    if min(img.size) < 1000:  # small scans OCR poorly; upscale towards ~200 dpi equivalents
        factor = 1000 / min(img.size)
        img = img.resize((int(img.width * factor), int(img.height * factor)), Image.LANCZOS)
    img = ImageOps.autocontrast(img)
    return img.filter(ImageFilter.MedianFilter(3))


class TesseractProvider(OcrProvider):
    name = "tesseract"

    def __init__(self, lang: str = "eng") -> None:
        self.lang = lang

    def available(self) -> bool:
        if shutil.which("tesseract") is None:
            return False
        try:
            import pytesseract  # noqa: F401
        except ImportError:
            return False
        return True

    def read_image(self, data: bytes) -> tuple[str, float | None]:
        import pytesseract

        img = preprocess_image(data)
        info = pytesseract.image_to_data(
            img, lang=self.lang, output_type=pytesseract.Output.DICT, config="--psm 6"
        )
        words, confs = [], []
        lines: dict[tuple[int, int, int], list[str]] = {}
        for i, w in enumerate(info["text"]):
            if not w.strip():
                continue
            c = float(info["conf"][i])
            if c >= 0:
                confs.append(c)
            key = (info["block_num"][i], info["par_num"][i], info["line_num"][i])
            lines.setdefault(key, []).append(w)
            words.append(w)
        text = "\n".join(" ".join(ws) for _, ws in sorted(lines.items()))
        return text, (sum(confs) / len(confs) / 100 if confs else None)


_provider: OcrProvider | None = None


def get_ocr_provider() -> OcrProvider | None:
    """Return the configured provider if usable, else None (the UI then offers manual entry)."""
    global _provider
    if _provider is None:
        _provider = TesseractProvider()
    return _provider if _provider.available() else None


def set_ocr_provider(provider: OcrProvider | None) -> None:
    """Swap the provider (tests, or a cloud OCR integration implementing OcrProvider)."""
    global _provider
    _provider = provider


def _pdf_pages_as_images(data: bytes) -> list[bytes]:
    """Render PDF pages to PNG bytes. Prefers poppler; falls back to embedded page images."""
    if shutil.which("pdftoppm"):
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "in.pdf"
            src.write_bytes(data)
            try:
                subprocess.run(
                    [
                        "pdftoppm",
                        "-r",
                        "200",
                        "-l",
                        str(MAX_PAGES),
                        "-png",
                        str(src),
                        str(Path(tmp) / "p"),
                    ],
                    check=True,
                    capture_output=True,
                    timeout=90,
                )
                pages = sorted(Path(tmp).glob("p*.png"))
                if pages:
                    return [p.read_bytes() for p in pages]
            except (subprocess.SubprocessError, OSError):
                pass
    from pypdf import PdfReader

    out: list[bytes] = []
    reader = PdfReader(io.BytesIO(data))
    for page in list(reader.pages)[:MAX_PAGES]:
        for img in page.images:
            out.append(img.data)
    return out


def extract_text(filename: str, data: bytes) -> ExtractedText:
    """Extract text from a PDF or image. Raises UploadRejected for unsupported/unreadable files."""
    ext = Path(filename).suffix.lower()
    provider = get_ocr_provider()
    if ext == ".pdf":
        from pypdf import PdfReader
        from pypdf.errors import PyPdfError

        try:
            reader = PdfReader(io.BytesIO(data))
            if reader.is_encrypted:
                raise UploadRejected("Encrypted PDFs are not supported.")
            pages = list(reader.pages)[:MAX_PAGES]
            texts = [(p.extract_text() or "").strip() for p in pages]
        except PyPdfError as exc:
            raise UploadRejected("The PDF could not be read.") from exc
        warnings: list[str] = []
        if len(reader.pages) > MAX_PAGES:
            warnings.append(f"Only the first {MAX_PAGES} pages were read.")
        digital = "\n".join(t for t in texts if len(t) >= MIN_TEXT_CHARS_PER_PAGE)
        if digital:
            return ExtractedText(digital, "pdf_text", None, len(pages), warnings)
        if provider is None:
            warnings.append("This PDF has no text layer and OCR (Tesseract) is not installed.")
            return ExtractedText("", "none", None, len(pages), warnings)
        ocr_texts, confs = [], []
        for img in _pdf_pages_as_images(data):
            t, c = provider.read_image(img)
            ocr_texts.append(t)
            if c is not None:
                confs.append(c)
        warnings.append("Scanned PDF: text comes from OCR and must be reviewed.")
        return ExtractedText(
            "\n".join(ocr_texts),
            "ocr_tesseract",
            sum(confs) / len(confs) if confs else None,
            len(pages),
            warnings,
        )
    if ext in (".png", ".jpg", ".jpeg"):
        if provider is None:
            return ExtractedText(
                "",
                "none",
                None,
                1,
                ["OCR (Tesseract) is not installed; enter the values manually."],
            )
        try:
            text, conf = provider.read_image(data)
        except Exception as exc:  # corrupt image, decompression bomb, tesseract failure
            raise UploadRejected("The image could not be processed.") from exc
        warns = ["OCR text must be reviewed; handwriting is not reliably recognised."]
        if conf is not None and conf < 0.6:
            warns.append(
                f"Low OCR confidence ({conf:.0%}); the image may be blurry, skewed or handwritten."
            )
        return ExtractedText(text, "ocr_tesseract", conf, 1, warns)
    raise UploadRejected(f"Unsupported file type '{ext}' for text extraction.")
