"""Speech-to-text interface and transcript parsing.

Transcription is NOT speaker identification or authentication: nothing here verifies who spoke,
and a voice must never be used as the sole authorisation for a financial action.
Providers are optional: `FasterWhisperProvider` needs `pip install faster-whisper` and a speech
model available on the machine (set PROCUREMENT_WHISPER_MODEL to a model name or local path;
the first use of a model name downloads it from the internet). If no provider is available the UI
offers typing the description instead. Browser microphone capture can be unreliable; uploading an
audio file always works. Audio is processed in memory and is not stored unless the user attaches it.
"""

from __future__ import annotations

import io
import os
import re
import tempfile
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from app.services.field_extraction import (
    SYMBOLS,
    ExtractedField,
    match_supplier,
    parse_amount,
    parse_dates,
)
from app.utils.currency import SUPPORTED_CURRENCIES


@dataclass
class Transcript:
    text: str
    language: str | None
    method: str


class SpeechProvider(ABC):
    name: str

    @abstractmethod
    def available(self) -> bool: ...

    @abstractmethod
    def transcribe(self, audio: bytes, filename: str) -> Transcript: ...


class FasterWhisperProvider(SpeechProvider):
    name = "faster-whisper"

    def __init__(self) -> None:
        self.model_name = os.environ.get("PROCUREMENT_WHISPER_MODEL", "")
        self._model = None

    def available(self) -> bool:
        if not self.model_name:
            return False
        try:
            import faster_whisper  # noqa: F401
        except ImportError:
            return False
        return True

    def transcribe(self, audio: bytes, filename: str) -> Transcript:
        from faster_whisper import WhisperModel

        if self._model is None:
            self._model = WhisperModel(self.model_name, device="cpu", compute_type="int8")
        suffix = os.path.splitext(filename)[1] or ".wav"
        with tempfile.NamedTemporaryFile(suffix=suffix) as tmp:
            tmp.write(audio)
            tmp.flush()
            segments, info = self._model.transcribe(tmp.name, beam_size=1)
            text = " ".join(s.text.strip() for s in segments)
        return Transcript(text.strip(), info.language, f"faster-whisper:{self.model_name}")


_provider: SpeechProvider | None = None


def get_speech_provider() -> SpeechProvider | None:
    global _provider
    if _provider is None:
        _provider = FasterWhisperProvider()
    return _provider if _provider.available() else None


def set_speech_provider(provider: SpeechProvider | None) -> None:
    global _provider
    _provider = provider


_NUMBER_WORDS = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
    "twenty": 20,
    "fifty": 50,
    "hundred": 100,
}
_CCY_WORDS = {
    "euro": "EUR",
    "euros": "EUR",
    "dollar": "USD",
    "dollars": "USD",
    "pound": "GBP",
    "pounds": "GBP",
    "franc": "CHF",
    "francs": "CHF",
    "zloty": "PLN",
}


def parse_transcript(text: str, suppliers: list[tuple[int, str]]) -> dict[str, ExtractedField]:
    """Pull a few structured values out of a spoken description (English, rule-based)."""
    out: dict[str, ExtractedField] = {
        "description": ExtractedField(
            "description", text.strip() or None, 0.9 if text.strip() else 0.0, "full transcript"
        )
    }
    sup = match_supplier(text, suppliers)
    sup.confidence = round(min(sup.confidence, 0.7), 2)
    out["supplier"] = sup
    # Spoken numbers: letters/digits separated by spaces or hyphens; stop before a following
    # keyword such as "total" or "from". At least one digit is required.
    m = re.search(
        r"(?i)(?:invoice|quotation|receipt|reference)\s*(?:number|no\.?|#)?\s*(?:is\s*)?"
        r"((?=[A-Z0-9\- ]*\d)[A-Z0-9]+(?:[- ][A-Z0-9]+){0,3}?)"
        r"(?=\s+(?:total|from|for|on|dated|amount|costs?)\b|[,.;]|$)",
        text,
    )
    ref = re.sub(r"\s+", "-", m.group(1).strip()).upper() if m else None
    out["supplier_ref"] = ExtractedField(
        "supplier_ref",
        ref,
        0.5 if ref else 0.0,
        "spoken number; verify digit by digit" if ref else "no number heard",
    )
    dates = parse_dates(text)
    out["purchase_date"] = ExtractedField(
        "purchase_date",
        dates[0][0] if dates else None,
        0.5 if dates else 0.0,
        dates[0][2] if dates else "no date heard",
    )
    amount, currency = None, None
    m = re.search(
        r"(?i)\b(?:total|amount|costs?|for)\b[^\d]{0,20}([\d][\d.,]*)\s*(euros?|dollars?|pounds?|francs?|zloty|[A-Z]{3}|€|£)?",
        text,
    )
    if m:
        amount = parse_amount(m.group(1))
        cur = (m.group(2) or "").strip()
        currency = (
            _CCY_WORDS.get(cur.lower())
            or SYMBOLS.get(cur)
            or (cur.upper() if cur.upper() in SUPPORTED_CURRENCIES else None)
        )
    out["total"] = ExtractedField(
        "total",
        amount,
        0.5 if amount is not None else 0.0,
        "spoken amount; verify" if amount is not None else "no amount heard",
    )
    out["currency"] = ExtractedField(
        "currency",
        currency,
        0.5 if currency else 0.0,
        "spoken currency" if currency else "no currency heard",
    )
    return out


__all__ = ["Decimal", "date", "io"]
