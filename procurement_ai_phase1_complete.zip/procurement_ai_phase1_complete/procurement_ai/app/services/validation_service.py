"""Document input model, validation rules and the server-side monetary calculation.

Calculation rules (see docs/calculation_rules.md):
  gross_line    = quantity * unit_price
  discount_line = round(gross_line * discount_rate)
  net_line      = round(gross_line) - discount_line
  tax_line      = round(net_line * tax_rate)
  line_total    = net_line + tax_line
  subtotal      = sum(net_line);  tax_total = sum(tax_line)
  shipping_tax  = round(shipping * shipping_tax_rate)
  total         = subtotal + tax_total + shipping + shipping_tax + other_charges
Rounding: ROUND_HALF_UP to the currency's minor unit, at line level. Totals extracted from an
uploaded document are never trusted; they may only be compared with this calculation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

from app.utils.currency import (
    SUPPORTED_CURRENCIES,
    quantize_money,
    quantize_rate,
    to_decimal,
)
from app.utils.exceptions import ValidationError

DOC_TYPES = ("invoice", "quotation", "purchase_request", "receipt")
PAYMENT_METHODS = ("bank_transfer", "credit_card", "cash", "purchase_order")
UNITS = ("pcs", "kg", "m", "m2", "m3", "l", "set", "h", "lot")

MAX_LINES = 200
MAX_QUANTITY = Decimal("1000000")
MAX_UNIT_PRICE = Decimal("100000000")
MAX_CHARGE = Decimal("10000000")
MAX_TAX_RATE = Decimal("0.5")


@dataclass(frozen=True)
class LineInput:
    description: str
    quantity: Decimal
    unit_price: Decimal
    unit: str = "pcs"
    discount_rate: Decimal = Decimal("0")  # fraction, 0.10 = 10 %
    tax_rate: Decimal = Decimal("0")  # fraction, 0.19 = 19 %
    category: str = "general"


@dataclass(frozen=True)
class DocumentInput:
    project_id: int
    cost_center_id: int
    supplier_id: int
    doc_type: str
    purchase_date: date
    currency: str
    lines: tuple[LineInput, ...]
    supplier_ref: str | None = None
    description: str = ""
    business_purpose: str = ""
    payment_method: str = "bank_transfer"
    shipping: Decimal = Decimal("0")
    other_charges: Decimal = Decimal("0")
    shipping_tax_rate: Decimal = Decimal("0")


@dataclass(frozen=True)
class CalculatedLine:
    discount_amount: Decimal
    net_amount: Decimal
    tax_amount: Decimal
    line_total: Decimal


@dataclass(frozen=True)
class CalculatedDocument:
    lines: tuple[CalculatedLine, ...]
    subtotal: Decimal
    discount_total: Decimal
    tax_total: Decimal
    shipping: Decimal
    other_charges: Decimal
    shipping_tax: Decimal
    total: Decimal
    warnings: list[str] = field(default_factory=list)


def calculate(inp: DocumentInput) -> CalculatedDocument:
    cur = inp.currency
    calc_lines: list[CalculatedLine] = []
    for ln in inp.lines:
        gross = quantize_money(ln.quantity * ln.unit_price, cur)
        discount = quantize_money(gross * ln.discount_rate, cur)
        net = gross - discount
        tax = quantize_money(net * ln.tax_rate, cur)
        calc_lines.append(CalculatedLine(discount, net, tax, net + tax))
    subtotal = sum((c.net_amount for c in calc_lines), Decimal("0"))
    discount_total = sum((c.discount_amount for c in calc_lines), Decimal("0"))
    tax_total = sum((c.tax_amount for c in calc_lines), Decimal("0"))
    shipping = quantize_money(inp.shipping, cur)
    other = quantize_money(inp.other_charges, cur)
    shipping_tax = quantize_money(shipping * inp.shipping_tax_rate, cur)
    total = subtotal + tax_total + shipping + shipping_tax + other
    return CalculatedDocument(
        tuple(calc_lines),
        subtotal,
        discount_total,
        tax_total + shipping_tax,
        shipping,
        other,
        shipping_tax,
        total,
    )


def validation_errors(inp: DocumentInput, today: date | None = None) -> list[str]:
    today = today or date.today()
    errs: list[str] = []
    if inp.currency not in SUPPORTED_CURRENCIES:
        errs.append(f"Currency '{inp.currency}' is not supported.")
    if inp.doc_type not in DOC_TYPES:
        errs.append(f"Unknown document type '{inp.doc_type}'.")
    if inp.payment_method not in PAYMENT_METHODS:
        errs.append(f"Unknown payment method '{inp.payment_method}'.")
    if inp.purchase_date > today + timedelta(days=1):
        errs.append("Purchase date cannot be in the future.")
    if inp.purchase_date < today - timedelta(days=365 * 6):
        errs.append("Purchase date is more than six years in the past.")
    if not inp.description.strip():
        errs.append("A description is required.")
    if len(inp.description) > 2000 or len(inp.business_purpose) > 2000:
        errs.append("Description and business purpose are limited to 2000 characters.")
    if inp.supplier_ref is not None and len(inp.supplier_ref) > 60:
        errs.append("Supplier reference is limited to 60 characters.")
    if not inp.lines:
        errs.append("At least one line item is required.")
    if len(inp.lines) > MAX_LINES:
        errs.append(f"A document may contain at most {MAX_LINES} line items.")
    for charge, label in ((inp.shipping, "Shipping"), (inp.other_charges, "Other charges")):
        if charge < 0 or charge > MAX_CHARGE:
            errs.append(f"{label} must be between 0 and {MAX_CHARGE}.")
    if not (Decimal("0") <= inp.shipping_tax_rate <= MAX_TAX_RATE):
        errs.append("Shipping tax rate must be between 0 % and 50 %.")
    for value, label in (
        (inp.shipping, "Shipping"),
        (inp.other_charges, "Other charges"),
        (inp.shipping_tax_rate, "Shipping tax rate"),
    ):
        if _too_precise(value):
            errs.append(f"{label} may have at most 4 decimal places.")
    for i, ln in enumerate(inp.lines, start=1):
        p = f"Line {i}: "
        for value, label in (
            (ln.quantity, "quantity"),
            (ln.unit_price, "unit price"),
            (ln.discount_rate, "discount"),
            (ln.tax_rate, "tax rate"),
        ):
            if _too_precise(value):
                errs.append(p + f"{label} may have at most 4 decimal places.")
        if not ln.description.strip():
            errs.append(p + "description is required.")
        if len(ln.description) > 300:
            errs.append(p + "description is limited to 300 characters.")
        if not (Decimal("0") < ln.quantity <= MAX_QUANTITY):
            errs.append(p + f"quantity must be greater than 0 and at most {MAX_QUANTITY}.")
        if not (Decimal("0") < ln.unit_price <= MAX_UNIT_PRICE):
            errs.append(p + "unit price must be greater than 0 and at most 100,000,000.")
        if not (Decimal("0") <= ln.discount_rate <= Decimal("1")):
            errs.append(p + "discount must be between 0 % and 100 %.")
        if not (Decimal("0") <= ln.tax_rate <= MAX_TAX_RATE):
            errs.append(p + "tax rate must be between 0 % and 50 %.")
        if ln.unit not in UNITS:
            errs.append(p + f"unknown unit '{ln.unit}'.")
    return errs


def validate_or_raise(inp: DocumentInput, today: date | None = None) -> CalculatedDocument:
    errs = validation_errors(inp, today)
    if errs:
        raise ValidationError(errs)
    return calculate(inp)


def _d(value: Decimal) -> str:
    """Canonical 4-decimal string so snapshots compare equal regardless of Decimal exponent."""
    return str(value.quantize(Decimal("0.0001")))


def _too_precise(value: Decimal) -> bool:
    exp = value.as_tuple().exponent
    return isinstance(exp, int) and exp < -4


# ---- (de)serialisation used by correction requests and extraction results -------------------
def input_to_dict(inp: DocumentInput) -> dict[str, Any]:
    return {
        "project_id": inp.project_id,
        "cost_center_id": inp.cost_center_id,
        "supplier_id": inp.supplier_id,
        "doc_type": inp.doc_type,
        "purchase_date": inp.purchase_date.isoformat(),
        "currency": inp.currency,
        "supplier_ref": inp.supplier_ref,
        "description": inp.description,
        "business_purpose": inp.business_purpose,
        "payment_method": inp.payment_method,
        "shipping": _d(inp.shipping),
        "other_charges": _d(inp.other_charges),
        "shipping_tax_rate": _d(inp.shipping_tax_rate),
        "lines": [
            {
                "description": ln.description,
                "quantity": _d(ln.quantity),
                "unit_price": _d(ln.unit_price),
                "unit": ln.unit,
                "discount_rate": _d(ln.discount_rate),
                "tax_rate": _d(ln.tax_rate),
                "category": ln.category,
            }
            for ln in inp.lines
        ],
    }


def line_from_dict(d: dict[str, Any]) -> LineInput:
    try:
        return LineInput(
            description=str(d["description"]),
            quantity=to_decimal(d["quantity"]),
            unit_price=to_decimal(d["unit_price"]),
            unit=str(d.get("unit", "pcs")),
            discount_rate=quantize_rate(to_decimal(d.get("discount_rate", "0"))),
            tax_rate=quantize_rate(to_decimal(d.get("tax_rate", "0"))),
            category=str(d.get("category", "general")),
        )
    except (KeyError, ValueError, TypeError) as exc:
        raise ValidationError(f"Invalid line item data: {exc}") from exc


def input_from_dict(d: dict[str, Any]) -> DocumentInput:
    try:
        return DocumentInput(
            project_id=int(d["project_id"]),
            cost_center_id=int(d["cost_center_id"]),
            supplier_id=int(d["supplier_id"]),
            doc_type=str(d["doc_type"]),
            purchase_date=date.fromisoformat(str(d["purchase_date"])),
            currency=str(d["currency"]).upper(),
            lines=tuple(line_from_dict(x) for x in d.get("lines", [])),
            supplier_ref=(d.get("supplier_ref") or None),
            description=str(d.get("description", "")),
            business_purpose=str(d.get("business_purpose", "")),
            payment_method=str(d.get("payment_method", "bank_transfer")),
            shipping=to_decimal(d.get("shipping", "0")),
            other_charges=to_decimal(d.get("other_charges", "0")),
            shipping_tax_rate=quantize_rate(to_decimal(d.get("shipping_tax_rate", "0"))),
        )
    except (KeyError, ValueError, TypeError) as exc:
        raise ValidationError(f"Invalid document data: {exc}") from exc


def apply_changes(
    base: DocumentInput, header: dict[str, Any], lines: list[dict] | None
) -> DocumentInput:
    """Return a new input with proposed header changes (and optional full line replacement)."""
    merged = input_to_dict(base)
    allowed = set(merged) - {"lines"}
    unknown = set(header) - allowed
    if unknown:
        raise ValidationError(f"Fields cannot be corrected: {', '.join(sorted(unknown))}")
    merged.update(header)
    if lines is not None:
        merged["lines"] = lines
    return input_from_dict(merged)
