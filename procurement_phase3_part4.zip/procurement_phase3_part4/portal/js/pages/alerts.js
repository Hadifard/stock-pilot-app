import { html, raw } from "../util.js";
import { errorBox } from "./common.js";
import { openDetail } from "./detail.js";

const ALERT_DISP = { expected_business_reason: "مورد انتظار - دلیل کسب‌وکاری دارد", data_entry_error: "خطای ورود داده - اصلاح شود", needs_follow_up: "نیاز به پیگیری", not_unusual: "پس از بررسی غیرعادی نیست" };
const DUP_DISP = { confirmed_duplicate: "تکراری تایید شد", not_duplicate: "تکراری نیست", legitimate_repeat: "تکرار مجاز (قسط/سفارش مجدد)" };
const SEV = { high: "#D64545", medium: "#C98A12", low: "#4A6FA5" };

/** ML alerts (unusual transactions) and duplicate candidates. An alert prompts a human review; it is not a finding. */
export async function alerts(ctx, root) {
  let tab = "alerts", status = "new";
  const canReview = ctx.can("alert.review");

  const reviewForm = (id, kind, disp) => canReview ? html`<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
      <select data-d="${id}">${Object.entries(disp).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select>
      <input data-n="${id}" placeholder="یادداشت بررسی (الزامی)" style="flex:1;min-width:180px">
      <button class="btn" data-r="${id}" data-k="${kind}">ثبت بررسی</button></div>` : html``;

  async function load() {
    const body = root.querySelector("#body");
    try {
      if (tab === "alerts") {
        const r = await ctx.api.alerts({ status, page_size: 30 });
        body.innerHTML = (r.items.length ? html`${r.items.map((a) => html`<div class="card" style="margin-bottom:16px">
          <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><h2 style="margin:0"><a href="#" data-doc="${a.document_id}">${a.doc_number}</a></h2>
            <span><span class="chip" style="background:${SEV[a.severity] || "#8A93A0"}22;color:${SEV[a.severity] || "#8A93A0"}">${a.severity}</span> امتیاز ${Number(a.score).toFixed(2)}</span></div>
          <p>${a.rules.map((x) => html`<span class="chip" style="background:#E9ECF0;margin-inline-end:6px">${x}</span>`)}</p>
          ${a.factors.length ? html`<ul style="margin:8px 0;padding-inline-start:20px">${a.factors.slice(0, 4).map((f) => html`<li>${f.text || f.feature || JSON.stringify(f)}</li>`)}</ul>` : ""}
          ${a.status === "reviewed" ? html`<div class="chip" style="background:#2E9E6B22;color:#2E9E6B">${ALERT_DISP[a.disposition] || a.disposition}: ${a.review_note}</div>` : reviewForm(a.id, "alert", ALERT_DISP)}</div>`)}`
          : html`<div class="card"><div class="empty">هشداری نیست</div></div>`).toString();
      } else {
        const r = await ctx.api.duplicates({ status, page_size: 30 });
        body.innerHTML = (r.items.length ? html`${r.items.map((c) => html`<div class="card" style="margin-bottom:16px">
          <h2><a href="#" data-doc="${c.doc_a_id}">سند #${c.doc_a_id}</a> ⇄ <a href="#" data-doc="${c.doc_b_id}">سند #${c.doc_b_id}</a> · شباهت ${Number(c.score).toFixed(2)}</h2>
          <p>${c.reasons.map((x) => html`<span class="chip" style="background:#E9ECF0;margin-inline-end:6px">${x}</span>`)}</p>
          ${c.status === "reviewed" ? html`<div class="chip" style="background:#2E9E6B22;color:#2E9E6B">${DUP_DISP[c.disposition] || c.disposition}: ${c.review_note}</div>` : reviewForm(c.id, "dup", DUP_DISP)}</div>`)}`
          : html`<div class="card"><div class="empty">مورد تکراری مشکوکی نیست</div></div>`).toString();
      }
    } catch (e) { body.innerHTML = errorBox(e).toString(); return; }
    body.querySelectorAll("[data-doc]").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); openDetail(ctx, Number(a.dataset.doc), load); }));
    body.querySelectorAll("[data-r]").forEach((b) => b.addEventListener("click", async () => {
      const id = Number(b.dataset.r), note = body.querySelector(`[data-n="${id}"]`).value.trim(), disp = body.querySelector(`[data-d="${id}"]`).value;
      if (!note) { ctx.toast("یادداشت بررسی الزامی است."); return; }
      try { await (b.dataset.k === "alert" ? ctx.api.reviewAlert(id, disp, note) : ctx.api.reviewDuplicate(id, disp, note)); ctx.toast("بررسی ثبت شد."); }
      catch (e) { ctx.toast(e.message); }
      load();
    }));
  }

  root.innerHTML = `<div class="filters"><div class="tabs"><button class="tab active" data-t="alerts">تراکنش‌های غیرعادی</button><button class="tab" data-t="dups">اسناد تکراری مشکوک</button></div>
    <label>وضعیت<select id="st"><option value="new">جدید</option><option value="all">همه</option></select></label></div>
    <p style="color:var(--text-secondary)">هشدار یعنی «لازم است انسان نگاه کند»، نه اثبات خطا یا تخلف.</p><div id="body"></div>`;
  root.querySelectorAll(".tab").forEach((b) => b.addEventListener("click", () => { tab = b.dataset.t; root.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === b)); load(); }));
  root.querySelector("#st").addEventListener("change", (e) => { status = e.target.value; load(); });
  await load();
  ctx.setTimer(load, 30000);
}
export { raw };
