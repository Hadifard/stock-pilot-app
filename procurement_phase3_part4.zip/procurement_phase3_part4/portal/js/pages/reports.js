import { html, STATUS_FA } from "../util.js";
import { genericTable, errorBox } from "./common.js";

function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/** Exports (CSV / Excel / PDF of the documents the role may see) + data-quality check. */
export async function reports(ctx, root) {
  root.innerHTML = html`
    <div class="card"><h2>خروجی اسناد</h2>
      <p style="color:var(--text-secondary)">فقط اسنادی که نقش شما اجازه‌ی دیدنشان را دارد. فایل شامل زمان تولید، ارز گزارش و یادداشت داده‌ی مصنوعی است.</p>
      <div class="filters" id="st">${Object.entries(STATUS_FA).map(([k, v]) => html`<label style="flex-direction:row;align-items:center;gap:6px"><input type="checkbox" value="${k}">${v}</label>`)}</div>
      <div class="row-actions">
        <button class="btn" data-f="xlsx">Excel</button><button class="btn" data-f="csv">CSV</button><button class="btn" data-f="pdf">PDF</button>
      </div><div id="msg" style="margin-top:12px"></div></div>
    <div class="card"><h2>کنترل کیفیت داده: اسناد با مجموع ناسازگار</h2><div id="inc"><div class="empty">در حال بارگذاری…</div></div></div>`.toString();

  root.querySelectorAll("[data-f]").forEach((b) => b.addEventListener("click", async () => {
    const statuses = [...root.querySelectorAll("#st input:checked")].map((i) => i.value);
    const msg = root.querySelector("#msg");
    root.querySelectorAll("[data-f]").forEach((x) => (x.disabled = true));
    msg.textContent = "در حال ساخت فایل…";
    try {
      const { blob, filename } = await ctx.api.exportDocuments(b.dataset.f, statuses);
      saveBlob(blob, filename);
      msg.textContent = `فایل ${filename} دانلود شد (${Math.round(blob.size / 1024)} KB).`;
    } catch (e) { msg.innerHTML = errorBox(e).toString(); }
    root.querySelectorAll("[data-f]").forEach((x) => (x.disabled = false));
  }));

  try { root.querySelector("#inc").innerHTML = genericTable(await ctx.api.inconsistentTotals()).toString(); }
  catch (e) { root.querySelector("#inc").innerHTML = (e.status === 403 ? html`<div class="empty">دسترسی ندارید</div>` : errorBox(e)).toString(); }
}
