import { html, raw, esc, fmtMoney } from "../util.js";
import { donut, barChart, hbars, forecastChart } from "../charts.js";
import { genericTable, errorBox } from "./common.js";

const GROUPS = { month: "ماه", category: "دسته", project: "پروژه", supplier: "تامین‌کننده", org_unit: "واحد سازمانی", currency: "ارز", status: "وضعیت" };

/** Spend analysis, budget use, forecast and internal price benchmark. */
export async function analysis(ctx, root) {
  root.innerHTML = html`
    <div class="card"><h2>تحلیل هزینه</h2>
      <div class="filters">
        <label>گروه‌بندی<select id="g">${Object.entries(GROUPS).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select></label>
        <label>از تاریخ<input type="date" id="df"></label><label>تا تاریخ<input type="date" id="dt"></label>
        <button class="btn" id="go">نمایش</button></div><div id="spend"></div></div>
    <div class="grid two"><div class="card"><h2>مصرف بودجه‌ی پروژه‌ها</h2><div id="budget"></div></div>
      <div class="card"><h2>پیش‌بینی هزینه‌ی ماهانه</h2>
        <div class="filters"><label>افق (ماه)<select id="hz"><option>3</option><option selected>6</option><option>9</option><option>12</option></select></label></div><div id="fc"></div></div></div>
    <div class="card"><h2>معیار قیمت (سابقه‌ی داخلی)</h2>
      <div class="filters"><label>شرح کالا<input id="pb" placeholder="مثلاً Paper A4 80g" style="min-width:260px"></label><label>واحد<input id="pu" value="pcs" style="width:90px"></label><button class="btn" id="pgo">جست‌وجو</button></div><div id="pbres"></div></div>`.toString();
  const $ = (s) => root.querySelector(s);

  async function spend() {
    const g = $("#g").value, box = $("#spend");
    box.innerHTML = `<div class="empty">در حال بارگذاری…</div>`;
    try {
      const r = await ctx.api.spend(g, { date_from: $("#df").value, date_to: $("#dt").value });
      const rows = r.rows.map((x) => ({ label: String(x.key), value: x.net_spend }));
      const chart = g === "month" ? barChart(rows.slice(-18)) : rows.length <= 8 ? donut(rows) : hbars(rows.slice(0, 10));
      box.innerHTML = html`<div class="grid two"><div>${raw(chart)}</div><div>${genericTable(r.rows.map((x) => ({ [GROUPS[g]]: x.key, "هزینه خالص": fmtMoney(x.net_spend, 0), "اسناد": x.documents })), { limit: 30 })}</div></div>
        <small style="color:var(--text-secondary)">${r.basis}${r.missing_fx_lines ? ` · ${r.missing_fx_lines} ردیف بدون نرخ ارز` : ""}</small>`.toString();
    } catch (e) { box.innerHTML = (e.status === 403 ? html`<div class="empty">دسترسی ندارید</div>` : errorBox(e)).toString(); }
  }

  async function budget() {
    try {
      const rows = await ctx.api.budget();
      $("#budget").innerHTML = (rows.length ? html`<ul class="hbars">${rows.slice(0, 10).map((b) => { const u = Number(b.utilization) || 0; const over = u >= 1;
        return html`<li><div class="hb-top"><span>${b.project}</span><b dir="ltr">${(u * 100).toFixed(0)}% · ${fmtMoney(b.spent, 0)} / ${fmtMoney(b.budget, 0)} ${b.budget_currency}</b></div>
          <div class="hb-track"><div class="hb-fill" style="width:${Math.min(u, 1) * 100}%;background:${over ? "var(--danger)" : u > 0.8 ? "var(--warning)" : "var(--surface-dark)"}"></div></div></li>`; })}</ul>` : html`<div class="empty">بودجه‌ای ثبت نشده</div>`).toString();
    } catch (e) { $("#budget").innerHTML = (e.status === 403 ? html`<div class="empty">دسترسی ندارید</div>` : errorBox(e)).toString(); }
  }

  async function forecast() {
    const box = $("#fc");
    box.innerHTML = `<div class="empty">در حال محاسبه…</div>`;
    try {
      const f = await ctx.api.forecast(Number($("#hz").value));
      box.innerHTML = html`${raw(forecastChart(f.history.map((h) => ({ label: h.month, value: h.spend })), f.forecast.map((p) => ({ label: p.month, value: p.prediction, lower: p.lower, upper: p.upper }))))}
        <p>مدل انتخاب‌شده: <b>${f.chosen_model}</b></p>${f.warnings.length ? html`<div class="error">${f.warnings.join("\n")}</div>` : ""}
        ${genericTable(Object.entries(f.metrics).map(([m, v]) => ({ model: m, ...Object.fromEntries(Object.entries(v).map(([k, x]) => [k, Number(x).toFixed(2)])) })))}
        <small style="color:var(--text-secondary)">${f.disclaimer}</small>`.toString();
    } catch (e) { box.innerHTML = (e.status === 403 ? html`<div class="empty">دسترسی ندارید</div>` : errorBox(e)).toString(); }
  }

  async function bench() {
    const q = $("#pb").value.trim(), box = $("#pbres");
    if (!q) { ctx.toast("شرح کالا را وارد کنید."); return; }
    try {
      const b = await ctx.api.priceBenchmark(q, $("#pu").value.trim() || "pcs");
      box.innerHTML = html`<p><b>${b.message}</b> (${b.samples} نمونه)</p>
        ${b.stats_eur ? genericTable([Object.fromEntries(Object.entries(b.stats_eur).map(([k, v]) => [k, typeof v === "number" ? fmtMoney(v, 2) : v]))]) : ""}
        ${b.comparables.length ? genericTable(b.comparables.map((c) => ({ "شرح مشابه": c.description, سطح: c.level, "شباهت متن": Number(c.text_similarity).toFixed(2), خرید: c.purchases, توضیح: c.explanation }))) : ""}
        <small style="color:var(--text-secondary)">${b.note}</small>`.toString();
    } catch (e) { box.innerHTML = errorBox(e).toString(); }
  }

  $("#go").addEventListener("click", spend);
  $("#hz").addEventListener("change", forecast);
  $("#pgo").addEventListener("click", bench);
  $("#pb").addEventListener("keydown", (e) => { if (e.key === "Enter") bench(); });
  await Promise.all([spend(), budget(), forecast()]);
}
export { esc };
