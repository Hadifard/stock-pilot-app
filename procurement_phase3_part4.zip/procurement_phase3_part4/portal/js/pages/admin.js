import { html, ROLE_FA, fmtDateTime } from "../util.js";
import { errorBox, askText, genericTable } from "./common.js";

/** Administration: users (activate / unlock / temporary password) and audit log + hash-chain verification. */
export async function admin(ctx, root) {
  const tabs = [];
  if (ctx.can("admin.manage")) tabs.push(["users", "کاربران"]);
  if (ctx.can("audit.view")) tabs.push(["audit", "ممیزی (Audit)"]);
  let tab = tabs[0][0];
  const st = { q: "", upage: 1, apage: 1, action: "" };

  async function users() {
    const body = root.querySelector("#body");
    const r = await ctx.api.adminUsers({ q: st.q, page: st.upage, page_size: 15 });
    body.innerHTML = html`<div class="card"><div class="filters"><label>جست‌وجو<input id="q" value="${st.q}" placeholder="نام کاربری یا نام"></label><button class="btn" id="go">جست‌وجو</button></div>
      <div class="table-wrap"><table><thead><tr><th>#</th><th>نام کاربری</th><th>نام</th><th>نقش</th><th>وضعیت</th><th>قفل تا</th><th>عملیات</th></tr></thead><tbody>
      ${r.items.map((u) => html`<tr><td>${u.id}</td><td class="ltr">${u.username}</td><td>${u.full_name}</td><td>${ROLE_FA[u.role] || u.role}</td>
        <td><span class="chip" style="background:${u.is_active ? "#2E9E6B22" : "#D6454522"};color:${u.is_active ? "#2E9E6B" : "#D64545"}">${u.is_active ? "فعال" : "غیرفعال"}</span></td>
        <td class="ltr">${u.locked_until ? fmtDateTime(u.locked_until) : "-"}</td>
        <td><div class="row-actions"><button class="btn ghost" data-act="toggle" data-id="${u.id}" data-active="${u.is_active}">${u.is_active ? "غیرفعال" : "فعال‌سازی"}</button>
          ${u.locked_until || u.failed_login_count ? html`<button class="btn ghost" data-act="unlock" data-id="${u.id}">رفع قفل</button>` : ""}
          <button class="btn ghost" data-act="pw" data-id="${u.id}">گذرواژه‌ی موقت</button></div></td></tr>`)}</tbody></table></div>
      <div class="pager"><button class="btn ghost" id="pv" ${r.page <= 1 ? "disabled" : ""}>قبلی</button><span>صفحه ${r.page} از ${r.pages} · ${r.total} کاربر</span><button class="btn ghost" id="nx" ${r.page >= r.pages ? "disabled" : ""}>بعدی</button></div></div>`.toString();
    const q = body.querySelector("#q");
    body.querySelector("#go").onclick = () => { st.q = q.value.trim(); st.upage = 1; load(); };
    q.addEventListener("keydown", (e) => { if (e.key === "Enter") body.querySelector("#go").click(); });
    body.querySelector("#pv").onclick = () => { st.upage--; load(); };
    body.querySelector("#nx").onclick = () => { st.upage++; load(); };
    body.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", async () => {
      const id = Number(b.dataset.id);
      try {
        if (b.dataset.act === "toggle") await ctx.api.updateUser(id, { is_active: b.dataset.active !== "true" });
        else if (b.dataset.act === "unlock") await ctx.api.updateUser(id, { unlock: true });
        else {
          const pw = await askText("گذرواژه‌ی موقت (کاربر باید در ورود بعدی تغییرش دهد)", { password: true });
          if (!pw) return;
          await ctx.api.resetPassword(id, pw);
        }
        ctx.toast("انجام شد.");
      } catch (e) { ctx.toast(e.message); }
      load();
    }));
  }

  async function audit() {
    const body = root.querySelector("#body");
    const r = await ctx.api.auditEvents({ action: st.action, page: st.apage, page_size: 20 });
    body.innerHTML = html`<div class="card"><div class="filters"><label>پیشوند رویداد<input id="ac" value="${st.action}" placeholder="مثلاً document. یا auth."></label><button class="btn" id="go">فیلتر</button><button class="btn ghost" id="vf">بررسی زنجیره‌ی هش</button></div><div id="vres"></div>
      ${genericTable(r.items.map((e) => ({ "#": e.id, زمان: fmtDateTime(e.timestamp), کاربر: e.actor_id ?? "-", رویداد: e.action, موجودیت: `${e.entity_type}#${e.entity_id ?? "-"}`, hash: e.hash.slice(0, 12) + "…" })), { limit: 20 })}
      <div class="pager"><button class="btn ghost" id="pv" ${r.page <= 1 ? "disabled" : ""}>قبلی</button><span>صفحه ${r.page} از ${r.pages} · ${r.total} رویداد</span><button class="btn ghost" id="nx" ${r.page >= r.pages ? "disabled" : ""}>بعدی</button></div></div>`.toString();
    body.querySelector("#go").onclick = () => { st.action = body.querySelector("#ac").value.trim(); st.apage = 1; load(); };
    body.querySelector("#pv").onclick = () => { st.apage--; load(); };
    body.querySelector("#nx").onclick = () => { st.apage++; load(); };
    body.querySelector("#vf").onclick = async () => {
      const v = await ctx.api.auditVerify();
      body.querySelector("#vres").innerHTML = html`<p class="${v.ok ? "" : "error"}" style="color:${v.ok ? "var(--success)" : "var(--danger)"}"><b>${v.ok ? "سالم" : "ناسازگار"}</b> · ${v.checked} رویداد بررسی شد · ${v.message}</p>`.toString();
    };
  }

  async function load() {
    try { await (tab === "users" ? users() : audit()); }
    catch (e) { root.querySelector("#body").innerHTML = errorBox(e).toString(); }
  }

  root.innerHTML = `<div class="tabs">${tabs.map(([k, v], i) => `<button class="tab ${i ? "" : "active"}" data-t="${k}">${v}</button>`).join("")}</div><div id="body"></div>`;
  root.querySelectorAll(".tab").forEach((b) => b.addEventListener("click", () => { tab = b.dataset.t; root.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === b)); load(); }));
  await load();
}
