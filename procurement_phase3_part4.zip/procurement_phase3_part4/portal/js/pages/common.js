import { html, raw, fmtMoney, statusFa, statusColor, DOC_TYPE_FA } from "../util.js";

export const chip = (status) =>
  html`<span class="chip" style="background:${statusColor(status)}22;color:${statusColor(status)}">${statusFa(status)}</span>`;

/** Documents table; rows are clickable (data-id) - the page wires the click handler. */
export function docTable(rows, names) {
  if (!rows.length) return html`<div class="empty">سندی پیدا نشد</div>`;
  const body = rows.map((d) => html`<tr class="click" data-id="${d.id}">
    <td><b>${d.doc_number}</b></td>
    <td>${names.suppliers.get(d.supplier_id) || "#" + d.supplier_id}</td>
    <td>${names.projects.get(d.project_id) || "#" + d.project_id}</td>
    <td>${DOC_TYPE_FA[d.doc_type] || d.doc_type}</td>
    <td class="ltr">${d.purchase_date}</td>
    <td class="num">${fmtMoney(d.total)} ${d.currency}</td>
    <td>${chip(d.status)}</td></tr>`);
  return html`<div class="table-wrap"><table><thead><tr><th>شماره</th><th>تامین‌کننده</th><th>پروژه</th><th>نوع</th><th>تاریخ</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>${body}</tbody></table></div>`;
}

export function onRowClick(root, handler) {
  root.querySelectorAll("tr.click").forEach((tr) => tr.addEventListener("click", () => handler(Number(tr.dataset.id))));
}

export const errorBox = (e) => html`<div class="error">${e?.message || String(e)}</div>`;
export { raw };

/** Generic table for rows of unknown shape (keys become headers). Values are escaped. */
export function genericTable(rows, { limit = 100 } = {}) {
  if (!rows?.length) return html`<div class="empty">موردی نیست</div>`;
  const keys = Object.keys(rows[0]);
  return html`<div class="table-wrap"><table><thead><tr>${keys.map((k) => html`<th>${k}</th>`)}</tr></thead><tbody>${rows.slice(0, limit).map((r) => html`<tr>${keys.map((k) => html`<td class="${typeof r[k] === "number" ? "num" : ""}">${typeof r[k] === "object" && r[k] !== null ? JSON.stringify(r[k]) : r[k] ?? "-"}</td>`)}</tr>`)}</tbody></table></div>`;
}

/** Small modal asking for one line of text. Resolves to the text or null when cancelled. */
export function askText(title, { password = false, placeholder = "" } = {}) {
  return new Promise((resolve) => {
    const o = document.createElement("div");
    o.className = "overlay";
    o.innerHTML = html`<div class="modal" style="width:min(420px,100%)"><h2>${title}</h2>
      <input id="v" type="${password ? "password" : "text"}" placeholder="${placeholder}" class="ltr" autocomplete="off">
      <div class="row-actions"><button class="btn" id="ok">تایید</button><button class="btn ghost" id="no">انصراف</button></div></div>`.toString();
    document.body.appendChild(o);
    const done = (v) => { o.remove(); resolve(v); };
    o.querySelector("#ok").onclick = () => done(o.querySelector("#v").value);
    o.querySelector("#no").onclick = () => done(null);
  });
}
