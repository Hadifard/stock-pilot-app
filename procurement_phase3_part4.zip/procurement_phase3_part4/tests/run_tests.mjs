// Offline tests: node tests/run_tests.mjs   (Node 18+; no packages needed)
import assert from "node:assert/strict";
import { createMock } from "./mock_api.mjs";
import { Api, ApiError } from "../portal/js/api.js";
import { esc, html, fmtMoney, fmtCompact, fmtDateTime, correctionDiff } from "../portal/js/util.js";
import { donut, barChart, hbars } from "../portal/js/charts.js";
import { dashboard } from "../portal/js/pages/dashboard.js";
import { documents } from "../portal/js/pages/documents.js";
import { approvals } from "../portal/js/pages/approvals.js";
import { openDetail } from "../portal/js/pages/detail.js";
import { reports } from "../portal/js/pages/reports.js";
import { alerts } from "../portal/js/pages/alerts.js";
import { analysis } from "../portal/js/pages/analysis.js";
import { admin } from "../portal/js/pages/admin.js";
import { forecastChart } from "../portal/js/charts.js";
import { askText } from "../portal/js/pages/common.js";

let passed = 0;
const t = async (name, fn) => { try { await fn(); passed++; console.log("ok  -", name); } catch (e) { console.log("FAIL-", name, "\n", e); process.exitCode = 1; } };
const mem = () => { const m = new Map(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k) }; };

// ---------- pure helpers
await t("esc / html escape interpolations", () => {
  assert.equal(esc(`<a href="x">'&`), "&lt;a href=&quot;x&quot;&gt;&#39;&amp;");
  assert.equal(String(html`<p>${"<script>"}</p>`), "<p>&lt;script&gt;</p>");
  assert.equal(String(html`<b>${html`<i>${"<"}</i>`}</b>`), "<b><i>&lt;</i></b>");
});
await t("number/date formatting", () => {
  assert.equal(fmtMoney("1234567.891"), "1,234,567.89");
  assert.equal(fmtMoney("x"), "-");
  assert.equal(fmtCompact(1500), "1.5K");
  assert.equal(fmtCompact(2000000), "2M");
  assert.match(fmtDateTime("2026-10-17T09:30:00"), /^2026-10-17 \d\d:\d\d$/);
});
await t("correctionDiff reports only changes", () => {
  const rows = correctionDiff({ original: { input: { description: "a", lines: [{ description: "P", quantity: "1", unit_price: "100", tax_rate: "0.19" }] }, calculated_total: "119" }, proposed: { input: { description: "b", lines: [{ description: "P", quantity: "1", unit_price: "90", tax_rate: "0.19" }] }, calculated_total: "107.1" } });
  assert.deepEqual(rows.map((r) => r.field), ["description", "line 1 unit_price", "total"]);
});
await t("charts: donut shares sum, escapes labels, handles empty", () => {
  const d = donut([{ label: "<x>", value: 3 }, { label: "b", value: 1 }]);
  assert.ok(d.includes("&lt;x&gt;") && !d.includes("<x>") && d.includes("75%"));
  assert.ok(donut([]).includes("empty"));
  const b = barChart([{ label: "2026-09", value: 10 }, { label: "2026-10", value: 20 }]);
  assert.equal((b.match(/class="bar"/g) || []).length, 2);
  assert.ok(hbars([{ label: "<i>", value: 5 }]).includes("&lt;i&gt;"));
});

// ---------- API client against the mock
const mock = createMock({ expireFirstAccess: true });
const port = await mock.listen();
const base = `http://localhost:${port}/api/v1`;
const mk = (extra = {}) => new Api(base, { storage: mem(), ...extra });

await t("login failure surfaces server message", async () => {
  await assert.rejects(mk().login("u", "bad"), (e) => e instanceof ApiError && e.status === 401 && /Invalid/.test(e.message));
});
await t("network failure -> ApiError status 0", async () => {
  await assert.rejects(new Api("http://localhost:1/api/v1", { storage: mem() }).login("u", "p"), (e) => e.status === 0);
});
const api = mk();
await t("login stores tokens; expired access token triggers ONE refresh and retries", async () => {
  await api.login("manager.demo", "Mock-Pass-123");
  const me = await api.me(); // mock answers 401 once -> refresh -> retry
  assert.equal(me.username, "manager.demo");
  assert.equal(mock.state.refreshCalls, 1);
  assert.equal(api.refresh, "R2"); // rotated
});
await t("concurrent 401s share a single refresh (tokens are single-use)", async () => {
  mock.state.firstExpired = false; mock.state.accessSeq += 0;
  const before = mock.state.refreshCalls;
  await Promise.all([api.kpis(), api.operations(), api.spend("month")]);
  assert.equal(mock.state.refreshCalls - before, 1);
});
await t("refMap, documents query serialisation (repeated status)", async () => {
  const m = await api.refMap("/reference/suppliers", (s) => s.name);
  assert.equal(m.size, 2);
  await api.documents({ status: ["submitted", "under_review"], page_size: 50, q: "" });
  assert.ok(mock.state.log.some((l) => l.includes("status=submitted&status=under_review") && l.includes("page_size=50") && !l.includes("q=")));
});

// ---------- page rendering with real page code on mock data (fake root element)
const fakeEl = () => { const kids = new Map(); const el = { innerHTML: "", value: "", dataset: {}, textContent: "", classList: { toggle() {} }, addEventListener() {}, querySelectorAll: () => [], querySelector(sel) { if (!kids.has(sel)) kids.set(sel, fakeEl()); return kids.get(sel); } }; return el; };
const toasts = [];
const ctx = { api, me: { id: 5, permissions: ["analytics.view", "document.decide"] }, can(p) { return this.me.permissions.includes(p); }, toast: (m) => toasts.push(m), setTimer() {}, lookups: () => Promise.all([api.refMap("/reference/suppliers", (s) => s.name), api.refMap("/reference/projects", (p) => `${p.code} - ${p.name}`)]).then(([suppliers, projects]) => ({ suppliers, projects })) };

await t("dashboard renders KPIs, donuts, bars, table - and neutralises hostile supplier names", async () => {
  const root = fakeEl(); await dashboard(ctx, root);
  const h = root.innerHTML;
  assert.ok(h.includes("1,240") && h.includes("5.5"), "KPI values");
  assert.equal((h.match(/<circle/g) || []).length >= 4, true, "donut arcs");
  assert.ok(h.includes('class="bar"') && h.includes("hb-fill") && h.includes("DOC-000001"));
  assert.ok(!h.includes("<img src=x"), "raw hostile markup must not appear");
  assert.ok(h.includes("&lt;img src=x"), "hostile markup is escaped");
  assert.ok(h.includes("تایید شده") && h.includes("ارسال‌شده"), "status labels");
});
await t("documents page renders table + pager", async () => {
  const root = fakeEl(); await documents(ctx, root);
  assert.ok(root.innerHTML.includes('id="tbl"'));
  assert.ok(root.querySelector("#tbl").innerHTML.includes("DOC-000002") && root.querySelector("#tbl").innerHTML.includes("صفحه 1 از 1"));
});
await t("approvals: queue lists pending docs; corrections tab shows diff", async () => {
  const root = fakeEl(); await approvals(ctx, root);
  assert.ok(root.querySelector("#body").innerHTML.includes("DOC-000001"));
});
await t("approve/reject go without If-Match; reject needs a note (server rule mirrored)", async () => {
  await api.startReview(1);
  const d = await api.approve(1, "ok");
  assert.equal(d.status, "approved");
  await assert.rejects(api.reject(2, ""), (e) => e.status === 422);
});
await t("openDetail draws modal for a document without throwing", async () => {
  const added = [];
  globalThis.document = { createElement: () => { const o = fakeEl(); o.firstElementChild = fakeEl(); o.remove = () => {}; o.className = ""; return o; }, body: { appendChild: (x) => added.push(x) } };
  await openDetail(ctx, 2, () => {});
  const modal = added[0].firstElementChild;
  assert.ok(modal.innerHTML.includes("DOC-000002") && modal.innerHTML.includes("&lt;b&gt;paper&lt;/b&gt;"));
  delete globalThis.document;
});

// ---------- part 4
ctx.me.permissions = ["analytics.view", "document.decide", "report.export", "alert.review", "admin.manage", "audit.view"];
const click = (root, sel) => root.querySelector(sel); // fake DOM: children are stable per selector

await t("forecast chart: history + forecast + band, hostile labels escaped", () => {
  const svg = forecastChart([{ label: "2026-07", value: 800 }, { label: "2026-08", value: 900 }], [{ label: "<b>2026-09", value: 1000, lower: 700, upper: 1400 }]);
  assert.ok(svg.includes("ln-h") && svg.includes("ln-f") && svg.includes("band") && !svg.includes("<b>2026"));
  assert.ok(forecastChart([], []).includes("empty"));
});
await t("API: CSV export is downloaded as a blob with the bearer token and repeated status params", async () => {
  const r = await api.exportDocuments("csv", ["approved", "submitted"]);
  assert.equal(r.filename, "documents.csv");
  assert.match(await r.blob.text(), /DOC-000001/);
  assert.ok(mock.state.log.some((l) => l.includes("/reports/documents?format=csv&status=approved&status=submitted")));
});
await t("reports page renders export buttons and data-quality table", async () => {
  const root = fakeEl(); await reports(ctx, root);
  assert.ok(root.innerHTML.includes('data-f="xlsx"') && root.innerHTML.includes('data-f="pdf"'));
  assert.ok(root.querySelector("#inc").innerHTML.includes("DOC-000009"));
});
await t("alerts page: cards, severity, escaped rules, review form; duplicates tab data", async () => {
  const root = fakeEl(); await alerts(ctx, root);
  const h = root.querySelector("#body").innerHTML;
  assert.ok(h.includes("DOC-000001") && h.includes("0.93") && h.includes("ثبت بررسی"));
  assert.ok(h.includes("&lt;script&gt;x&lt;/script&gt;") && !h.includes("<script>x"));
  const d = await api.duplicates({ status: "new" });
  assert.equal(d.items[0].doc_b_id, 2);
});
await t("review calls carry disposition + note", async () => {
  await api.reviewAlert(11, "needs_follow_up", "check with supplier");
  await api.reviewDuplicate(21, "not_duplicate", "different invoice");
  assert.deepEqual(mock.state.reviews, [["alerts", "11", "needs_follow_up", "check with supplier"], ["duplicates", "21", "not_duplicate", "different invoice"]]);
});
await t("analysis page: spend chart+table, budget bars (over-budget flagged), forecast, escaped warnings", async () => {
  const root = fakeEl(); await analysis(ctx, root);
  assert.ok(root.querySelector("#spend").innerHTML.includes("bar") || root.querySelector("#spend").innerHTML.includes("circle"));
  const b = root.querySelector("#budget").innerHTML;
  assert.ok(b.includes("120%") && b.includes("var(--danger)") && b.includes("30%"));
  const f = root.querySelector("#fc").innerHTML;
  assert.ok(f.includes("seasonal_ridge") && f.includes("ln-f") && f.includes("&lt;b&gt;x&lt;/b&gt;") && f.includes("not a guarantee"));
  const pb = await api.priceBenchmark("Paper A4"); assert.equal(pb.benchmark_available, true);
});
await t("admin: users table escapes names, shows unlock for locked users; audit table + verify", async () => {
  const root = fakeEl(); await admin(ctx, root);
  const h = root.querySelector("#body").innerHTML;
  assert.ok(h.includes("employee.demo") && h.includes("Eva &lt;i&gt;Demo&lt;/i&gt;") && h.includes('data-act="unlock"') && h.includes('data-act="pw"'));
  await api.updateUser(9, { unlock: true }); assert.deepEqual(mock.state.patched, { unlock: true });
  await api.resetPassword(9, "Tmp#Pass12345"); assert.deepEqual(mock.state.pwReset, { temporary_password: "Tmp#Pass12345" });
  const ev = await api.auditEvents({ page: 1 }); assert.equal(ev.items[0].action, "document.created");
  assert.equal((await api.auditVerify()).ok, true);
});
await t("role gating: an auditor without admin.manage sees only the audit tab", async () => {
  const saved = ctx.me.permissions; ctx.me.permissions = ["audit.view"];
  const root = fakeEl(); await admin(ctx, root);
  assert.ok(root.innerHTML.includes("ممیزی") && !root.innerHTML.includes("کاربران"));
  ctx.me.permissions = saved;
});
await t("askText resolves with typed value / null on cancel", async () => {
  const els = [];
  globalThis.document = { createElement: () => { const o = fakeEl(); o.remove = () => {}; return o; }, body: { appendChild: (o) => els.push(o) } };
  const p1 = askText("x"); els[0].querySelector("#v").value = "secret"; els[0].querySelector("#ok").onclick();
  assert.equal(await p1, "secret");
  const p2 = askText("y"); els[1].querySelector("#no").onclick();
  assert.equal(await p2, null);
  delete globalThis.document;
});

await mock.close();
console.log(`\n${passed} checks passed${process.exitCode ? " (WITH FAILURES)" : ""}`);
