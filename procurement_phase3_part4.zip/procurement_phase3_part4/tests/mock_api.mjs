// Minimal mock of the Phase 2 API (only what the portal calls), shaped like the real schemas.
// Used for offline tests and for trying the portal without the real backend:
//   node tests/mock_api.mjs   -> http://localhost:8000/api/v1  (user: manager.demo / Mock-Pass-123)
import http from "node:http";

export function createMock({ expireFirstAccess = false } = {}) {
  const state = {
    accessSeq: 0, refreshCalls: 0, loginCalls: 0, log: [], firstExpired: false,
    docs: [
      { id: 1, doc_number: "DOC-000001", status: "submitted", doc_type: "invoice", purchase_date: "2026-10-01", currency: "EUR", total: "1190.0000", supplier_id: 1, project_id: 1, employee_id: 9, supplier_ref: "R-1", created_at: "2026-10-17T09:00:00", submitted_at: "2026-10-17T09:01:00", is_synthetic: true, row_version: 2 },
      { id: 2, doc_number: "DOC-000002", status: "under_review", doc_type: "receipt", purchase_date: "2026-10-02", currency: "EUR", total: "50.0000", supplier_id: 2, project_id: 1, employee_id: 9, supplier_ref: null, created_at: "2026-10-17T10:00:00", submitted_at: "2026-10-17T10:01:00", is_synthetic: true, row_version: 3 },
    ],
  };
  const me = { id: 5, username: "manager.demo", full_name: "Marta Demo", role: "purchasing_manager", org_unit_id: 1, is_active: true, must_change_password: false, permissions: ["analytics.view", "document.decide", "document.view_org", "correction.decide", "report.export", "alert.review", "admin.manage", "audit.view"] };
  const page = (items) => ({ items, total: items.length, page: 1, page_size: 100, pages: 1 });
  const detail = (d) => ({ ...d, org_unit_id: 1, cost_center_id: 1, description: "Office <b>paper</b>", business_purpose: "", payment_method: "bank_transfer", shipping: "0.0000", other_charges: "0.0000", shipping_tax_rate: "0.0000", subtotal: "1000.0000", discount_total: "0.0000", tax_total: "190.0000", decision_note: null, lines: [{ line_no: 1, description: "Paper A4", category: "general", quantity: "10.0000", unit: "pcs", unit_price: "100.0000", discount_rate: "0.0000", tax_rate: "0.1900", line_total: "1190.0000" }], attachments: [{ id: 1, original_name: "inv.pdf", mime_type: "application/pdf", size_bytes: 2048 }], correction_deadline: null, correction_window_open: false });
  const json = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Authorization, Content-Type" }); res.end(obj === null ? "" : JSON.stringify(obj)); };
  const err = (res, code, c, m) => json(res, code, { error: { code: c, message: m } });

  const server = http.createServer(async (req, res) => {
    if (req.method === "OPTIONS") return json(res, 204, null);
    const u = new URL(req.url, "http://x"); const p = u.pathname.replace("/api/v1", "");
    let body = ""; for await (const c of req) body += c;
    state.log.push(`${req.method} ${p}${u.search}`);
    if (p === "/auth/login") {
      state.loginCalls++;
      const f = new URLSearchParams(body);
      if (f.get("password") !== "Mock-Pass-123") return err(res, 401, "invalid_credentials", "Invalid username or password.");
      return json(res, 200, { access_token: "A" + ++state.accessSeq, refresh_token: "R1", token_type: "bearer", must_change_password: false });
    }
    if (p === "/auth/refresh") {
      state.refreshCalls++;
      const b = JSON.parse(body);
      if (b.refresh_token !== "R" + state.refreshCalls) return err(res, 401, "invalid_token", "Refresh token is invalid.");
      return json(res, 200, { access_token: "A" + ++state.accessSeq, refresh_token: "R" + (state.refreshCalls + 1), token_type: "bearer", must_change_password: false });
    }
    if (p === "/auth/logout") return json(res, 204, null);
    const auth = req.headers.authorization || "";
    if (!auth.startsWith("Bearer A")) return err(res, 401, "not_authenticated", "Not authenticated.");
    if (expireFirstAccess && !state.firstExpired) { state.firstExpired = true; return err(res, 401, "token_expired", "Token expired."); }
    if (p === "/auth/me") return json(res, 200, me);
    if (p === "/analytics/kpis") return json(res, 200, { submitted_spend: "1240.0000", reporting_currency: "EUR", documents_counted: 2, pending_approvals: 2, pending_corrections: 1, avg_approval_hours: 5.5, documents_without_fx_rate: 0, definitions: {}, synthetic_data_notice: "Synthetic demo data." });
    if (p === "/analytics/operations") return json(res, 200, { documents_by_status: { submitted: 1, under_review: 1, approved: 4 }, pending_approvals: 2, pending_corrections: 1, open_unusual_transactions: 3, open_duplicate_candidates: 1, inconsistent_totals: 0, projects_at_or_over_budget: 1 });
    if (p === "/analytics/spend") {
      const g = u.searchParams.get("group_by");
      const rows = g === "month" ? [{ key: "2026-08", net_spend: 900, documents: 3 }, { key: "2026-09", net_spend: 1500, documents: 5 }, { key: "2026-10", net_spend: 1000, documents: 2 }]
        : [{ key: g === "supplier" ? "Evil <img src=x onerror=alert(1)> GmbH" : "Office", net_spend: 1200, documents: 4 }, { key: g === "supplier" ? "Acme" : "IT", net_spend: 700, documents: 2 }];
      return json(res, 200, { group_by: g, rows, missing_fx_lines: 0, basis: "x" });
    }
    if (p === "/reference/suppliers") return json(res, 200, page([{ id: 1, name: "Evil <img src=x onerror=alert(1)> GmbH", country: "DE" }, { id: 2, name: "Acme", country: "DE" }]));
    if (p === "/reference/projects") return json(res, 200, page([{ id: 1, code: "PRJ-001", name: "Plant A" }]));
    if (p === "/documents") {
      const st = u.searchParams.getAll("status"); const q = (u.searchParams.get("q") || "").toLowerCase();
      let rows = state.docs.filter((d) => (!st.length || st.includes(d.status)) && (!q || d.doc_number.toLowerCase().includes(q)));
      return json(res, 200, page(rows));
    }
    let m;
    if ((m = p.match(/^\/documents\/(\d+)$/))) { const d = state.docs.find((x) => x.id == m[1]); return d ? json(res, 200, detail(d)) : err(res, 404, "not_found", "Not found"); }
    if ((m = p.match(/^\/documents\/(\d+)\/history$/))) return json(res, 200, [{ id: 1, timestamp: "2026-10-17T09:01:00", actor_id: 9, action: "document.status_changed", payload: { from: "draft", to: "submitted", note: "" } }]);
    if ((m = p.match(/^\/documents\/(\d+)\/review\/start$/))) { const d = state.docs.find((x) => x.id == m[1]); d.status = "under_review"; return json(res, 200, detail(d)); }
    if ((m = p.match(/^\/documents\/(\d+)\/(approve|reject)$/))) {
      const d = state.docs.find((x) => x.id == m[1]); const b = JSON.parse(body || "{}");
      if (req.headers["if-match"]) return err(res, 400, "unexpected", "portal must not send If-Match");
      if (m[2] === "reject" && !b.note) return err(res, 422, "validation_error", "A reason is required.");
      d.status = m[2] === "approve" ? "approved" : "rejected"; return json(res, 200, detail(d));
    }
    if (p === "/corrections") return json(res, 200, page([{ id: 4, document_id: 1, requested_by: 9, requested_at: "2026-10-17T09:30:00", reason: "Wrong price", status: "pending", deadline_exception: false, exception_reason: null, decided_by: null, decided_at: null, decision_note: null,
      original: { input: { description: "a", lines: [{ description: "Paper", quantity: "10.0000", unit_price: "100.0000", tax_rate: "0.1900" }] }, calculated_total: "1190.0000" },
      proposed: { input: { description: "a", lines: [{ description: "Paper", quantity: "10.0000", unit_price: "90.0000", tax_rate: "0.1900" }] }, calculated_total: "1071.0000" } }]));
    if (p === "/reports/documents") { const f = u.searchParams.get("format"); res.writeHead(200, { "Content-Type": f === "csv" ? "text/csv" : "application/octet-stream", "Access-Control-Allow-Origin": "*", "Content-Disposition": `attachment; filename="documents.${f}"` }); return res.end(f === "csv" ? "doc_number,total\nDOC-000001,1190\n" : Buffer.from([0x50, 0x4b, 3, 4])); }
    if (p === "/analytics/inconsistent-totals") return json(res, 200, [{ doc_number: "DOC-000009", stored_total: 10, computed_total: 12 }]);
    if (p === "/analytics/budget-utilization") return json(res, 200, [{ project: "PRJ-001 Plant A", budget: 1000, spent: 1200, budget_currency: "EUR", utilization: 1.2 }, { project: "PRJ-002 Plant B", budget: 1000, spent: 300, budget_currency: "EUR", utilization: 0.3 }]);
    if (p === "/analytics/forecast") return json(res, 200, { chosen_model: "seasonal_ridge", history: [{ month: "2026-07", spend: 800 }, { month: "2026-08", spend: 900 }, { month: "2026-09", spend: 1500 }], forecast: [{ month: "2026-10", prediction: 1100, lower: 700, upper: 1500 }, { month: "2026-11", prediction: 1200, lower: 800, upper: 1600 }], backtest: [], metrics: { naive_last: { mae: 100.5, mape: 0.2 }, seasonal_ridge: { mae: 80.1, mape: 0.15 } }, warnings: ["Short history <b>x</b>"], disclaimer: "An estimate, not a guarantee." });
    if (p === "/analytics/alerts") return json(res, 200, page([{ id: 11, document_id: 1, doc_number: "DOC-000001", score: 0.93, severity: "high", rules: ["round_amount", "<script>x</script>"], factors: [{ text: "Amount 5x the supplier median" }], status: "new", disposition: null, review_note: null, model_version: "v1" }]));
    if ((m = p.match(/^\/analytics\/(alerts|duplicates)\/(\d+)\/review$/))) { const b = JSON.parse(body); state.reviews = (state.reviews || []).concat([[m[1], m[2], b.disposition, b.note]]); return json(res, 200, { id: +m[2], status: "reviewed", disposition: b.disposition, review_note: b.note }); }
    if (p === "/analytics/duplicates") return json(res, 200, page([{ id: 21, doc_a_id: 1, doc_b_id: 2, score: 0.88, reasons: ["same_supplier", "same_amount"], status: "new", disposition: null, review_note: null }]));
    if (p === "/analytics/price-benchmark") return json(res, 200, { query: u.searchParams.get("description"), unit: "pcs", samples: 3, stats_eur: { median: 4.5, p25: 4, p75: 5 }, message: "Benchmark from 3 purchases", benchmark_available: true, comparables: [{ description: "Paper A4 80g", level: "exact", score: 1, text_similarity: 0.97, purchases: 3, explanation: "same attributes" }], purchases: [], note: "Internal history." });
    if (p === "/admin/users" && req.method === "GET") return json(res, 200, page([{ id: 9, username: "employee.demo", full_name: "Eva <i>Demo</i>", role: "purchasing_employee", org_unit_id: 1, is_active: true, is_synthetic: true, failed_login_count: 3, locked_until: "2026-10-17T10:00:00" }]));
    if ((m = p.match(/^\/admin\/users\/(\d+)$/)) && req.method === "PATCH") { state.patched = JSON.parse(body); return json(res, 200, { id: 9, username: "employee.demo", full_name: "E", role: "purchasing_employee", org_unit_id: 1, is_active: true, is_synthetic: true, failed_login_count: 0, locked_until: null }); }
    if ((m = p.match(/^\/admin\/users\/(\d+)\/reset-password$/))) { state.pwReset = JSON.parse(body); return json(res, 204, null); }
    if (p === "/audit/verify") return json(res, 200, { ok: true, checked: 120, first_bad_id: null, message: "Chain intact." });
    if (p === "/audit/events") return json(res, 200, { items: [{ id: 1, timestamp: "2026-10-17T09:00:00", actor_id: 9, action: "document.created", entity_type: "document", entity_id: 1, payload: {}, hash: "abcdef0123456789abcdef" }], total: 1, page: 1, page_size: 20, pages: 1 });
    return err(res, 404, "not_found", "Unknown route " + p);
  });
  return { server, state, listen: (port = 0) => new Promise((r) => server.listen(port, () => r(server.address().port))), close: () => new Promise((r) => server.close(r)) };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const m = createMock();
  const port = await m.listen(8000);
  console.log(`Mock API on http://localhost:${port}/api/v1  (manager.demo / Mock-Pass-123)`);
}
