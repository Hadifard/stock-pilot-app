# راهنمای نصب و اجرای کامل (ویندوز + گوشی اندروید) - برای کسی که از صفر شروع می‌کند

## 0) تصویر کلی (۲ دقیقه بخوانید)
چهار تکه داریم که همه با هم کار می‌کنند:

| تکه | چیست | کجا اجرا می‌شود |
|---|---|---|
| **بک‌اند (API)** | «مغز» سیستم: دیتابیس، ورود کاربران، قوانین. هیچ ظاهری ندارد. | روی لپ‌تاپ، پنجره‌ی PowerShell |
| **پورتال وب** | صفحه‌ی مدیریتی (داشبورد، نمودار، تایید اسناد) | مرورگر لپ‌تاپ |
| **اپ موبایل** | برنامه‌ی کارمند برای ثبت فاکتور | گوشی اندروید |
| **شبکه** | لپ‌تاپ و گوشی باید به **یک Wi‑Fi** وصل باشند | - |

اپ موبایل و پورتال هر دو فقط به بک‌اند وصل می‌شوند؛ پس بک‌اند باید **همیشه روشن** باشد (پنجره‌ی PowerShell آن را نبندید).
واژه‌ها: **API** = آدرسی که برنامه‌ها با آن با بک‌اند حرف می‌زنند. **آی‌پی** = آدرس لپ‌تاپ در شبکه (مثل 192.168.1.20). **حساب دمو** = کاربران آزمایشی که داده‌ی ساختگی دارند.

**ترتیب کار:** الف) بک‌اند ← ب) پورتال ← پ) اپ موبایل ← ت) تست هم‌زمان.
هر مرحله «چک‌پوینت» دارد؛ تا چک‌پوینت درست نشده به مرحله‌ی بعد نروید. اگر گیر کردید، **متن کامل خطا** را برای من بفرستید.

---
## الف) بک‌اند

### الف-۱) نصب Python
1. از python.org نسخه‌ی 3.12 را دانلود کنید. هنگام نصب **حتماً** تیک «Add python.exe to PATH» را بزنید.
2. PowerShell را باز کنید (Start ← تایپ PowerShell) و بزنید: `py -3.12 --version`
   ✅ چک‌پوینت: چیزی مثل `Python 3.12.x` نشان دهد.

### الف-۲) باز کردن پروژه
فایل zip پروژه‌ی فاز ۲ (`procurement_ai_phase2_complete.zip`) را در مسیر ساده‌ای مثل `C:\procurement` استخراج کنید تا پوشه‌ی `C:\procurement\procurement_ai` بسازد. (فاصله و حروف فارسی در مسیر نداشته باشد.)

### الف-۳) اعمال patch اعلان‌ها (زیربخش ۲)
از zip زیربخش ۲، پوشه‌ی `backend_patch`:
1. `app\api\routers\notifications.py` را کپی کنید داخل `C:\procurement\procurement_ai\app\api\routers\`
2. `tests\api\test_api_notifications.py` را کپی کنید داخل `...\procurement_ai\tests\api\`
3. فایل `app\api\main.py` را با Notepad باز کنید و دو تغییر بدهید:
   - خطی که با `from app.api.routers import` شروع می‌شود: کلمه‌ی `notifications` را به لیست اضافه کنید (مثلاً `... extraction, notifications, reference`).
   - خطی که `for r in (auth, reference, documents, extraction, analytics, admin):` است را بکنید `for r in (auth, reference, documents, extraction, analytics, admin, notifications):`

### الف-۴) ساخت محیط و نصب
در PowerShell:
```powershell
cd C:\procurement\procurement_ai
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
```
اگر خطای «running scripts is disabled» آمد: `Set-ExecutionPolicy -Scope Process Bypass` را بزنید و دوباره فعال‌سازی کنید.
✅ اول خط باید `(.venv)` ببینید. ادامه:
```powershell
pip install -r requirements-dev.txt
Copy-Item .env.example .env
notepad .env
```
(نصب چند دقیقه طول می‌کشد و اینترنت می‌خواهد.)

### الف-۵) تنظیم فایل `.env`
در Notepad این خط‌ها را تغییر دهید و ذخیره کنید:
- `PROCUREMENT_DEMO_PASSWORD=` یک گذرواژه‌ی قوی (حداقل ۱۲ کاراکتر، حروف بزرگ و کوچک، عدد، نماد؛ مثلاً `Demo#Procure2026x`). **این همان گذرواژه‌ی ورود همه‌ی حساب‌های دمو است.**
- `PROCUREMENT_JWT_SECRET=` خروجی این دستور را بگذارید: `python -c "import secrets; print(secrets.token_urlsafe(48))"`
- `PROCUREMENT_CORS_ORIGINS=http://localhost:5173` (اجازه‌ی پورتال وب برای حرف زدن با API)

### الف-۶) ساخت داده‌ی دمو و اجرا
```powershell
python -m scripts.generate_synthetic_data --mode small --reset
python -m scripts.train_models
uvicorn app.api.main:app --host 0.0.0.0 --port 8000
```
اگر ویندوز درباره‌ی فایروال پرسید: «Private networks» را Allow کنید.
✅ چک‌پوینت ۱: در مرورگر لپ‌تاپ `http://localhost:8000/docs` را باز کنید؛ صفحه‌ی مستندات API دیده شود.
✅ چک‌پوینت ۲ (مهم برای گوشی): با `ipconfig` عدد «IPv4 Address» را پیدا کنید (مثلاً 192.168.1.20). در **مرورگر گوشی** (به همان Wi‑Fi) باز کنید `http://192.168.1.20:8000/health` ← باید `{"status":"ok"}` ببینید. اگر نشد: فایروال یا Wi‑Fi متفاوت (بعضی Wi‑Fiها دستگاه‌ها را از هم جدا می‌کنند؛ از hotspot گوشی استفاده کنید).
(برای تست اختیاری: در پنجره‌ی دیگر با venv فعال `pytest tests/api -q` بزنید.)

**حساب‌های دمو** (گذرواژه‌ی همه = همان `PROCUREMENT_DEMO_PASSWORD`): `employee.demo` کارمند، `manager.demo` مدیر خرید، `finance.demo` مدیر مالی، `pm.demo` مدیر پروژه، `auditor.demo` ممیز، `admin.demo` ادمین.

---
## ب) پورتال وب
1. zip زیربخش ۳ را استخراج کنید (مثلاً `C:\procurement\procurement_phase3_part3`).
2. در پوشه‌اش روی `start_portal.bat` دوبار کلیک کنید (پنجره‌ی سیاه باز می‌ماند؛ نبندید). اگر `py` پیدا نشد، Python را مرحله‌ی الف-۱ نصب کنید.
3. مرورگر لپ‌تاپ: **`http://localhost:5173`** (حتماً localhost، نه آی‌پی).
4. با `manager.demo` وارد شوید.
✅ چک‌پوینت: داشبورد با کارت‌های KPI و نمودارها. اگر «اتصال به سرور برقرار نشد» دیدید: بک‌اند روشن نیست یا CORS در `.env` را اشتباه نوشته‌اید (بعد از تغییر `.env` بک‌اند را با Ctrl+C ببندید و دوباره اجرا کنید).

---
## پ) اپ موبایل
### پ-۱) نصب ابزارها (یک‌بار؛ حدود ۱ ساعت)
1. **Android Studio** را از developer.android.com/studio نصب کنید (همه‌ی گزینه‌های پیش‌فرض، Android SDK هم نصب شود).
2. **Flutter**: از docs.flutter.dev/get-started/install/windows ، فایل zip نسخه‌ی stable (۳٫۲۷ یا بالاتر) را در `C:\src\flutter` استخراج کنید. سپس پوشه‌ی `C:\src\flutter\bin` را به PATH اضافه کنید (Start ← «Edit environment variables» ← Path ← New). PowerShell را ببندید و دوباره باز کنید.
3. `flutter doctor` را بزنید. موارد Flutter و Android toolchain باید ✓ شوند. اگر درباره‌ی لایسنس‌ها گفت: `flutter doctor --android-licenses` و همه‌جا `y`.

### پ-۲) آماده‌سازی گوشی
تنظیمات ← About phone ← هفت بار روی «Build number» بزنید ← برگردید ← Developer options ← **USB debugging** را روشن کنید. گوشی را با کابل به لپ‌تاپ وصل کنید و پیام «Allow USB debugging» را تایید کنید.
✅ `flutter devices` در PowerShell باید گوشی را نشان دهد.

### پ-۳) پروژه‌ی اپ
zip زیربخش ۲ را استخراج کنید؛ پوشه‌ی `mobile` را باز کنید (در PowerShell `cd` به آن):
```powershell
flutter create . --org com.example --project-name procurement_mobile --platforms android
flutter pub get
flutter analyze
```
(اگر پرسید فایل‌ها را بازنویسی کند، `lib` و `pubspec.yaml` را **نگه دارید**.) خروجی `flutter analyze` را برای من بفرستید؛ کد هنوز هیچ‌جا کامپایل نشده و ممکن است چند خطای کوچک داشته باشد که سریع رفع می‌کنم.

دو تغییر در `android\app\src\main\AndroidManifest.xml` (با Notepad):
- بالای تگ `<application` اضافه کنید:
  `<uses-permission android:name="android.permission.INTERNET"/>` و `<uses-permission android:name="android.permission.CAMERA"/>`
- داخل خود تگ `<application` اضافه کنید: `android:usesCleartextTraffic="true"` (برای HTTP در دمو لازم است)

### پ-۴) اجرا روی گوشی
```powershell
flutter run --dart-define=API_BASE_URL=http://192.168.1.20:8000/api/v1
```
(آی‌پی را با آی‌پی خودتان عوض کنید.) بار اول چند دقیقه طول می‌کشد. با `employee.demo` وارد شوید.
**بدون کابل (اختیاری):** `flutter build apk --release --dart-define=API_BASE_URL=http://192.168.1.20:8000/api/v1` ← فایل `build\app\outputs\flutter-apk\app-release.apk` را به گوشی بفرستید و نصب کنید (اجازه‌ی «نصب از منبع ناشناس»).
✅ چک‌پوینت: ورود موفق، تب «ثبت فاکتور» باز شود و لیست تامین‌کننده‌ها بیاید.

---
## ت) تست هم‌زمان (سناریوی دمو)
1. لپ‌تاپ: پورتال با `manager.demo`، صفحه‌ی داشبورد (هر ۱۵ ثانیه خودکار به‌روز می‌شود).
2. گوشی: ورود با `employee.demo` ← «ثبت فاکتور» ← تامین‌کننده و پروژه را انتخاب کنید، یک ردیف با قیمت، یک عکس پیوست ← «ثبت و ارسال».
3. لپ‌تاپ: حداکثر ۱۵ ثانیه بعد، شمار «در انتظار تایید» و «آخرین اسناد» تغییر می‌کند. به «صف تایید» بروید، سند را باز کنید، «شروع بررسی» و سپس «تایید».
4. گوشی: تب «اسناد من» وضعیت «تایید شده» را نشان می‌دهد و تب «اعلان‌ها» پیام می‌آورد.

## مشکلات رایج
| علامت | علت و راه‌حل |
|---|---|
| اپ/پورتال «اتصال برقرار نشد» | بک‌اند خاموش است، یا آی‌پی اشتباه، یا فایروال، یا گوشی و لپ‌تاپ روی یک Wi‑Fi نیستند. چک‌پوینت الف-۶ را دوباره بزنید |
| ورود: «Invalid username or password» | گذرواژه = `PROCUREMENT_DEMO_PASSWORD` در `.env` **زمانی که داده ساخته شد**. بعد از تغییرش `generate_synthetic_data ... --reset` را دوباره بزنید |
| ورود بعد از چند خطا قفل شد | ۱۵ دقیقه صبر کنید یا داده را `--reset` کنید |
| پورتال: خطای CORS در مرورگر (F12) | `PROCUREMENT_CORS_ORIGINS` باید دقیقاً `http://localhost:5173` باشد و بک‌اند بعد از تغییر ری‌استارت شود |
| `uvicorn` شناخته نمی‌شود | venv فعال نیست (اول خط `(.venv)` نیست) |
| پورت 8000 مشغول است | `--port 8001` بگذارید و آدرس‌ها را هم عوض کنید |
| اپ: تب اعلان‌ها خطا می‌دهد | patch مرحله‌ی الف-۳ اعمال نشده/بک‌اند ری‌استارت نشده |
| اپ: «HTTP not permitted» / cleartext | `usesCleartextTraffic` را در Manifest نگذاشته‌اید |
