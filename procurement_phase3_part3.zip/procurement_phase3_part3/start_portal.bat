@echo off
REM Starts the manager portal on http://localhost:5173 (needs Python; no installation of packages).
cd /d "%~dp0portal"
echo Portal: http://localhost:5173   (stop with Ctrl+C)
py -3 -m http.server 5173
