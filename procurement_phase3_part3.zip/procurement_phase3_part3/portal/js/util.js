// Pure helpers (no DOM access) so they can be unit-tested in Node.

export const esc = (v) =>
  String(v ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/\x27/g, "&#39;");

class Safe { constructor(s) { this.s = s; } toString() { return this.s; } }
export const raw = (s) => new Safe(String(s));

/** Tagged template that HTML-escapes every interpolation unless it is raw() or an array of them. */
export function html(strings, ...vals) {
  let out = strings[0];
  vals.forEach((v, i) => {
    const part = Array.isArray(v) ? v.map((x) => (x instanceof Safe ? x.s : esc(x))).join("") : v instanceof Safe ? v.s : esc(v);
    out += part + strings[i + 1];
  });
  return new Safe(out);
}

export function fmtMoney(v, decimals = 2) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "-";
  const [w, f] = Math.abs(n).toFixed(decimals).split(".");
  const g = w.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (n < 0 ? "-" : "") + g + (f ? "." + f : "");
}

export function fmtCompact(v) {
  const n = Math.abs(Number(v));
  if (!Number.isFinite(n)) return "-";
  if (n >= 1e9) return (v / 1e9).toFixed(1).replace(/\.0$/, "") + "B";
  if (n >= 1e6) return (v / 1e6).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1e3) return (v / 1e3).toFixed(1).replace(/\.0$/, "") + "K";
  return String(Math.round(v));
}

export function fmtDateTime(iso) {
  if (!iso) return "-";
  // The API may return naive UTC timestamps; treat missing zone as UTC.
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : iso + "Z");
  if (isNaN(d)) return String(iso);
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

export const STATUS_FA = {
  draft: "پیش‌نویس", submitted: "ارسال‌شده", under_review: "در حال بررسی", resubmitted: "ارسال مجدد",
  approved: "تایید شده", rejected: "رد شده", cancelled: "لغو شده", correction_requested: "اصلاحیه در انتظار",
};
export const STATUS_COLOR = {
  draft: "#8A93A0", submitted: "#4A6FA5", under_review: "#C98A12", resubmitted: "#C98A12",
  approved: "#2E9E6B", rejected: "#D64545", cancelled: "#8A93A0", correction_requested: "#C98A12",
};
export const statusFa = (s) => STATUS_FA[s] || s;
export const statusColor = (s) => STATUS_COLOR[s] || "#8A93A0";
export const DOC_TYPE_FA = { invoice: "فاکتور", receipt: "رسید", quotation: "پیش‌فاکتور", purchase_request: "درخواست خرید" };
export const ROLE_FA = {
  purchasing_employee: "کارمند خرید", purchasing_manager: "مدیر خرید", finance_officer: "مدیر مالی",
  project_manager: "مدیر پروژه", auditor: "ممیز", administrator: "ادمین",
};

/** Human-readable differences of a correction request (mirrors the mobile app logic). */
export function correctionDiff(c) {
  const o = c.original?.input || {}, p = c.proposed?.input || {};
  const rows = [];
  for (const k of Object.keys(p)) {
    if (k === "lines") continue;
    if (String(o[k]) !== String(p[k])) rows.push({ field: k, before: String(o[k] ?? "-"), after: String(p[k] ?? "-") });
  }
  const ol = o.lines || [], pl = p.lines || [];
  for (let i = 0; i < Math.max(ol.length, pl.length); i++) {
    const a = ol[i], b = pl[i];
    if (!a || !b) { rows.push({ field: `line ${i + 1}`, before: a ? a.description : "-", after: b ? b.description : "-" }); continue; }
    for (const f of ["description", "quantity", "unit_price", "tax_rate"]) {
      if (String(a[f]) !== String(b[f])) rows.push({ field: `line ${i + 1} ${f}`, before: String(a[f]), after: String(b[f]) });
    }
  }
  if (String(c.original?.calculated_total) !== String(c.proposed?.calculated_total)) {
    rows.push({ field: "total", before: String(c.original?.calculated_total), after: String(c.proposed?.calculated_total) });
  }
  return rows;
}
