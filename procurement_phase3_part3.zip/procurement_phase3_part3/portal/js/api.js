// API client for /api/v1: bearer auth, one automatic refresh on 401 (refresh tokens are
// single-use, so refreshes are serialised), structured errors. No If-Match header is sent
// (it is optional server-side and not allowed by the API CORS policy).

export class ApiError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

export class Api {
  constructor(base, { storage = globalThis.sessionStorage, fetchImpl = (...a) => globalThis.fetch(...a), onExpire = () => {} } = {}) {
    this.base = base.replace(/\/$/, "");
    this.storage = storage;
    this.fetch = fetchImpl;
    this.onExpire = onExpire;
    this._refreshing = null;
  }

  get access() { return this.storage.getItem("pp_access"); }
  get refresh() { return this.storage.getItem("pp_refresh"); }
  get signedIn() { return !!this.refresh; }
  _set(a, r) { this.storage.setItem("pp_access", a); this.storage.setItem("pp_refresh", r); }
  clear() { this.storage.removeItem("pp_access"); this.storage.removeItem("pp_refresh"); }

  url(path, query) {
    const u = new URL(this.base + path, globalThis.location?.href || "http://localhost");
    for (const [k, v] of Object.entries(query || {})) {
      if (v === undefined || v === null || v === "") continue;
      (Array.isArray(v) ? v : [v]).forEach((x) => u.searchParams.append(k, String(x)));
    }
    return u.toString();
  }

  async login(username, password) {
    const body = new URLSearchParams({ username, password });
    const res = await this._fetch(this.url("/auth/login"), { method: "POST", body });
    const j = await this._parse(res);
    this._set(j.access_token, j.refresh_token);
    return j;
  }

  async logout() {
    try { if (this.access) await this.request("POST", "/auth/logout", { json: { refresh_token: this.refresh }, retry: false }); } catch { /* local sign-out must always work */ }
    this.clear();
  }

  async _refreshTokens() {
    return (this._refreshing ??= (async () => {
      try {
        const rt = this.refresh;
        if (!rt) return false;
        const res = await this._fetch(this.url("/auth/refresh"), {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refresh_token: rt }),
        });
        if (res.status === 200) { const j = await res.json(); this._set(j.access_token, j.refresh_token); return true; }
        if (res.status === 401 || res.status === 403) this.clear();
        return false;
      } catch { return false; } finally { this._refreshing = null; }
    })());
  }

  async _fetch(url, init) {
    try { return await this.fetch(url, init); }
    catch { throw new ApiError(0, "network", "اتصال به سرور برقرار نشد. آدرس API و اجرای سرور را بررسی کنید."); }
  }

  async _parse(res, wantBlob = false) {
    if (res.ok) {
      if (res.status === 204) return null;
      return wantBlob ? res.blob() : res.json();
    }
    let code = `http_${res.status}`, message = `خطای سرور (${res.status})`;
    try {
      const e = (await res.json()).error;
      code = e.code || code; message = e.message || message;
      if (Array.isArray(e.details) && e.details.length) message += "\n" + e.details.map((d) => `- ${(d.loc || []).join(".")}: ${d.msg}`).join("\n");
    } catch { /* non-JSON error body */ }
    throw new ApiError(res.status, code, message);
  }

  async request(method, path, { query, json, retry = true, blob = false } = {}) {
    const once = () => {
      const headers = {};
      if (this.access) headers.Authorization = `Bearer ${this.access}`;
      const init = { method, headers };
      if (json !== undefined) { headers["Content-Type"] = "application/json"; init.body = JSON.stringify(json); }
      return this._fetch(this.url(path, query), init);
    };
    let res = await once();
    if (res.status === 401 && retry && this.refresh) {
      if (await this._refreshTokens()) res = await once();
      else if (!this.refresh) this.onExpire();
    }
    return this._parse(res, blob);
  }

  get(path, query) { return this.request("GET", path, { query }); }
  post(path, json) { return this.request("POST", path, { json }); }

  // ---- typed helpers
  me() { return this.get("/auth/me"); }
  kpis() { return this.get("/analytics/kpis"); }
  operations() { return this.get("/analytics/operations"); }
  spend(groupBy, extra = {}) { return this.get("/analytics/spend", { group_by: groupBy, ...extra }); }
  budget() { return this.get("/analytics/budget-utilization"); }
  documents(query) { return this.get("/documents", query); }
  document(id) { return this.get(`/documents/${id}`); }
  history(id) { return this.get(`/documents/${id}/history`); }
  startReview(id) { return this.post(`/documents/${id}/review/start`); }
  approve(id, note) { return this.post(`/documents/${id}/approve`, { note }); }
  reject(id, note) { return this.post(`/documents/${id}/reject`, { note }); }
  corrections(query) { return this.get("/corrections", query); }
  decideCorrection(id, approve, note) { return this.post(`/corrections/${id}/decision`, { approve, note }); }

  /** Loads every page of a reference list (page size max 100) into an id -> label Map. */
  async refMap(path, label) {
    const map = new Map();
    for (let page = 1; page <= 20; page++) {
      const r = await this.get(path, { page, page_size: 100 });
      r.items.forEach((x) => map.set(x.id, label(x)));
      if (page >= r.pages) break;
    }
    return map;
  }
}
