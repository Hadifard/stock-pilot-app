import { API_BASE } from "./config.js";
import { Api } from "./api.js";
import { html, esc, ROLE_FA } from "./util.js";
import { dashboard } from "./pages/dashboard.js";
import { documents } from "./pages/documents.js";
import { approvals } from "./pages/approvals.js";

const app = document.getElementById("app");
const timers = [];
let toastEl = null;

const api = new Api(API_BASE, { onExpire: () => { location.hash = ""; start(); } });
const ctx = {
  api, me: null,
  can: (p) => ctx.me?.permissions.includes(p),
  toast(msg) {
    toastEl?.remove();
    toastEl = document.createElement("div");
    toastEl.className = "toast"; toastEl.textContent = msg;
    document.body.appendChild(toastEl);
    setTimeout(() => toastEl?.remove(), 4000);
  },
  setTimer(fn, ms) { timers.push(setInterval(() => { if (!document.hidden && !document.querySelector(".overlay")) fn(); }, ms)); },
  _names: null,
  lookups() { // supplier/project names are loaded once; ids are shown if a lookup is forbidden
    return (this._names ??= Promise.all([
      api.refMap("/reference/suppliers", (s) => s.name).catch(() => new Map()),
      api.refMap("/reference/projects", (p) => `${p.code} - ${p.name}`).catch(() => new Map()),
    ]).then(([suppliers, projects]) => ({ suppliers, projects })));
  },
};

const ROUTES = {
  dashboard: { title: "داشبورد", icon: "▦", mount: dashboard, perm: "analytics.view" },
  documents: { title: "اسناد", icon: "▤", mount: documents },
  approvals: { title: "صف تایید", icon: "✔", mount: approvals, perm: "document.decide" },
};

function loginView(error = "") {
  app.innerHTML = html`<div class="login"><div class="box">
    <div class="card dark hero"><div class="logo">▤</div><h1>پورتال مدیریتی خرید</h1></div>
    <div class="card"><form id="f">
      <input id="u" placeholder="نام کاربری" autocomplete="username" class="ltr" autofocus>
      <input id="p" type="password" placeholder="گذرواژه" autocomplete="current-password" class="ltr">
      ${error ? html`<div class="error">${error}</div>` : ""}
      <button class="btn" type="submit">ورود</button></form></div></div></div>`.toString();
  document.getElementById("f").addEventListener("submit", async (e) => {
    e.preventDefault();
    const u = document.getElementById("u").value.trim(), p = document.getElementById("p").value;
    if (!u || !p) return loginView("نام کاربری و گذرواژه را وارد کنید.");
    try { await api.login(u, p); await start(); } catch (err) { loginView(err.message); }
  });
}

function notAllowed() {
  app.innerHTML = html`<div class="login"><div class="box"><div class="card"><h2>دسترسی ندارید</h2>
    <p>این پورتال برای مدیر، مدیر مالی، مدیر پروژه، ممیز و ادمین است. کارمندان از اپ موبایل استفاده کنند.</p>
    <button class="btn" id="out">خروج</button></div></div></div>`.toString();
  document.getElementById("out").onclick = async () => { await api.logout(); start(); };
}

async function route() {
  timers.splice(0).forEach(clearInterval);
  const key = (location.hash.replace(/^#\/?/, "") || "").split("?")[0];
  const allowed = Object.entries(ROUTES).filter(([, r]) => !r.perm || ctx.can(r.perm));
  const [id, r] = allowed.find(([k]) => k === key) || allowed[0];
  document.querySelectorAll(".nav a").forEach((a) => a.classList.toggle("active", a.dataset.k === id));
  document.getElementById("title").textContent = r.title;
  const root = document.getElementById("page");
  root.innerHTML = `<div class="empty">در حال بارگذاری…</div>`;
  try { await r.mount(ctx, root); }
  catch (e) { root.innerHTML = `<div class="card error">${esc(e.message)}</div>`; }
}

async function start() {
  timers.splice(0).forEach(clearInterval);
  if (!api.signedIn) return loginView();
  try { ctx.me = await api.me(); } catch (e) { return e.status === 401 ? loginView() : loginView(e.message); }
  if (ctx.me.must_change_password) { await api.logout(); return loginView("گذرواژه باید ابتدا از اپ موبایل یا Streamlit تغییر کند."); }
  const allowed = Object.entries(ROUTES).filter(([, r]) => !r.perm || ctx.can(r.perm));
  if (!ctx.can("analytics.view") && !ctx.can("document.decide")) return notAllowed();
  app.innerHTML = html`<div class="shell"><aside class="sidebar"><div class="brand"><div class="logo">▤</div><div>سامانه خرید</div></div>
    <nav class="nav">${allowed.map(([k, r]) => html`<a href="#/${k}" data-k="${k}"><span>${r.icon}</span>${r.title}</a>`)}</nav>
    <div class="who"><b>${ctx.me.full_name}</b>${ROLE_FA[ctx.me.role] || ctx.me.role}<br><a href="#" id="out" style="color:var(--accent)">خروج</a></div></aside>
    <section class="main"><header class="topbar"><h1 id="title"></h1><div class="live"><i></i>به‌روزرسانی خودکار</div></header><div id="page" class="main"></div></section></div>`.toString();
  document.getElementById("out").addEventListener("click", async (e) => { e.preventDefault(); await api.logout(); ctx._names = null; start(); });
  await route();
}

window.addEventListener("hashchange", () => { if (ctx.me && api.signedIn) route(); });
start();
