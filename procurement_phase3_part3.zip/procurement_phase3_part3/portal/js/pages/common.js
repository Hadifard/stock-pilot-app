import { html, raw, fmtMoney, statusFa, statusColor, DOC_TYPE_FA } from "../util.js";

export const chip = (status) =>
  html`<span class="chip" style="background:${statusColor(status)}22;color:${statusColor(status)}">${statusFa(status)}</span>`;

/** Documents table; rows are clickable (data-id) - the page wires the click handler. */
export function docTable(rows, names) {
  if (!rows.length) return html`<div class="empty">سندی پیدا نشد</div>`;
  const body = rows.map((d) => html`<tr class="click" data-id="${d.id}">
    <td><b>${d.doc_number}</b></td>
    <td>${names.suppliers.get(d.supplier_id) || "#" + d.supplier_id}</td>
    <td>${names.projects.get(d.project_id) || "#" + d.project_id}</td>
    <td>${DOC_TYPE_FA[d.doc_type] || d.doc_type}</td>
    <td class="ltr">${d.purchase_date}</td>
    <td class="num">${fmtMoney(d.total)} ${d.currency}</td>
    <td>${chip(d.status)}</td></tr>`);
  return html`<div class="table-wrap"><table><thead><tr><th>شماره</th><th>تامین‌کننده</th><th>پروژه</th><th>نوع</th><th>تاریخ</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>${body}</tbody></table></div>`;
}

export function onRowClick(root, handler) {
  root.querySelectorAll("tr.click").forEach((tr) => tr.addEventListener("click", () => handler(Number(tr.dataset.id))));
}

export const errorBox = (e) => html`<div class="error">${e?.message || String(e)}</div>`;
export { raw };
