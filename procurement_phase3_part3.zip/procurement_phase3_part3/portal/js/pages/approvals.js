import { html, raw, fmtDateTime } from "../util.js";
import { docTable, onRowClick, errorBox } from "./common.js";
import { openDetail, diffBlock } from "./detail.js";

/** Approval queue: documents waiting for a decision + pending correction requests. */
export async function approvals(ctx, root) {
  let tab = "docs";
  const names = await ctx.lookups();

  async function load() {
    const body = root.querySelector("#body");
    try {
      if (tab === "docs") {
        const r = await ctx.api.documents({ page_size: 50, sort: "submitted_at", status: ["submitted", "resubmitted", "under_review"] });
        body.innerHTML = html`<div class="card"><h2>اسناد در انتظار تصمیم (${r.total})</h2>${docTable(r.items, names)}</div>`.toString();
        onRowClick(body, (id) => openDetail(ctx, id, load));
      } else {
        const r = await ctx.api.corrections({ pending_only: true, page_size: 50 });
        body.innerHTML = (r.items.length ? html`${r.items.map((c) => html`<div class="card" style="margin-bottom:16px">
          <h2>اصلاحیه‌ی سند #${c.document_id} · ${fmtDateTime(c.requested_at)}</h2>
          <p>${c.reason}</p>${c.deadline_exception ? html`<p class="error">استثنای مهلت: ${c.exception_reason}</p>` : ""}
          ${diffBlock(c)}
          <textarea data-note="${c.id}" rows="2" placeholder="یادداشت (برای رد الزامی)" style="margin-top:12px"></textarea>
          <div class="row-actions" style="margin-top:12px"><button class="btn" data-ok="${c.id}">تایید</button><button class="btn danger" data-no="${c.id}">رد</button>
          <button class="btn ghost" data-doc="${c.document_id}">مشاهده‌ی سند</button></div></div>`)}`
          : html`<div class="card"><div class="empty">اصلاحیه‌ای در انتظار نیست</div></div>`).toString();
        const decide = async (id, approve) => {
          const note = body.querySelector(`[data-note="${id}"]`).value.trim();
          if (!approve && !note) { ctx.toast("برای رد، دلیل را بنویسید."); return; }
          try { await ctx.api.decideCorrection(id, approve, note); ctx.toast(approve ? "اصلاحیه تایید شد." : "اصلاحیه رد شد."); }
          catch (e) { ctx.toast(e.message); }
          load();
        };
        body.querySelectorAll("[data-ok]").forEach((b) => b.addEventListener("click", () => decide(Number(b.dataset.ok), true)));
        body.querySelectorAll("[data-no]").forEach((b) => b.addEventListener("click", () => decide(Number(b.dataset.no), false)));
        body.querySelectorAll("[data-doc]").forEach((b) => b.addEventListener("click", () => openDetail(ctx, Number(b.dataset.doc), load)));
      }
    } catch (e) { body.innerHTML = errorBox(e).toString(); }
  }

  root.innerHTML = `<div class="tabs"><button class="tab active" data-t="docs">اسناد</button><button class="tab" data-t="corr">اصلاحیه‌ها</button></div><div id="body"></div>`;
  root.querySelectorAll(".tab").forEach((b) => b.addEventListener("click", () => {
    tab = b.dataset.t; root.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === b)); load();
  }));
  await load();
  ctx.setTimer(load, 15000);
}
export { raw };
