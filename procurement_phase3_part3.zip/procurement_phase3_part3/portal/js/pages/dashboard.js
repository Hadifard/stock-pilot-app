import { html, raw, fmtMoney, statusFa, statusColor } from "../util.js";
import { donut, barChart, hbars } from "../charts.js";
import { docTable, onRowClick, errorBox } from "./common.js";
import { openDetail } from "./detail.js";

const settle = (p) => p.then((v) => ({ ok: true, v }), (e) => ({ ok: false, e }));
const widget = (title, r, draw) => html`<div class="card"><h2>${title}</h2>${r.ok ? raw(draw(r.v)) : r.e.status === 403 ? html`<div class="empty">دسترسی ندارید</div>` : errorBox(r.e)}</div>`;

export async function dashboard(ctx, root) {
  async function load() {
    const [kpis, ops, byMonth, byCat, bySup, recent, names] = await Promise.all([
      settle(ctx.api.kpis()), settle(ctx.api.operations()), settle(ctx.api.spend("month")),
      settle(ctx.api.spend("category")), settle(ctx.api.spend("supplier")),
      settle(ctx.api.documents({ page_size: 8, sort: "-created_at" })), ctx.lookups(),
    ]);
    draw({ kpis, ops, byMonth, byCat, bySup, recent, names });
  }

  function draw({ kpis, ops, byMonth, byCat, bySup, recent, names }) {
    const k = kpis.ok ? kpis.v : null, o = ops.ok ? ops.v : null;
    const cur = k?.reporting_currency || "";
    const kpiCards = html`
      <div class="card dark kpi"><div class="label">هزینه‌ی ارسال‌شده (${cur})</div><div class="value ltr"><span class="accent">${k ? fmtMoney(k.submitted_spend, 0) : "—"}</span></div><div class="sub" style="color:var(--text-on-dark-muted)">${k ? k.documents_counted + " سند" : ""}</div></div>
      <div class="card kpi"><div class="label">در انتظار تایید</div><div class="value">${k ? k.pending_approvals : "—"}</div><div class="sub">اسناد ارسال‌شده/در بررسی</div></div>
      <div class="card kpi"><div class="label">اصلاحیه‌های در انتظار</div><div class="value">${k ? k.pending_corrections : "—"}</div></div>
      <div class="card kpi"><div class="label">میانگین زمان تایید (ساعت)</div><div class="value">${k && k.avg_approval_hours != null ? Number(k.avg_approval_hours).toFixed(1) : "—"}</div></div>`;
    const opsRow = o ? html`
      <div class="card kpi small"><div class="label">تراکنش‌های غیرعادی باز</div><div class="value">${o.open_unusual_transactions}</div></div>
      <div class="card kpi small"><div class="label">موارد مشکوک تکراری</div><div class="value">${o.open_duplicate_candidates}</div></div>
      <div class="card kpi small"><div class="label">پروژه‌های در/بالای بودجه</div><div class="value">${o.projects_at_or_over_budget}</div></div>` : html``;

    root.innerHTML = html`
      <div class="grid kpis">${kpiCards}</div>
      ${o ? html`<div class="grid three">${opsRow}</div>` : ""}
      <div class="grid two">
        ${widget("روند هزینه‌ی ماهانه", byMonth, (v) => barChart(v.rows.slice(-12).map((r) => ({ label: r.key, value: r.net_spend }))))}
        ${widget("وضعیت اسناد", ops, (v) => donut(Object.entries(v.documents_by_status).map(([s, n]) => ({ label: statusFa(s), value: n, color: statusColor(s) })), { centerValue: String(Object.values(v.documents_by_status).reduce((a, b) => a + b, 0)), centerLabel: "سند" }))}
      </div>
      <div class="grid two">
        ${widget("ترکیب هزینه بر اساس دسته", byCat, (v) => donut(v.rows.slice(0, 7).map((r) => ({ label: r.key, value: r.net_spend }))))}
        ${widget("برترین تامین‌کنندگان", bySup, (v) => hbars(v.rows.slice(0, 7).map((r) => ({ label: r.key, value: r.net_spend }))))}
      </div>
      <div class="card"><h2>آخرین اسناد</h2>${recent.ok ? docTable(recent.v.items, names) : errorBox(recent.e)}</div>
      ${k ? html`<small style="color:var(--text-secondary)">${k.synthetic_data_notice || ""}</small>` : ""}`.toString();
    onRowClick(root, (id) => openDetail(ctx, id, load));
  }

  await load();
  ctx.setTimer(load, 15000); // live refresh: new invoices from the phone show up without reloading
}
