import { html, raw, STATUS_FA, DOC_TYPE_FA } from "../util.js";
import { docTable, onRowClick, errorBox } from "./common.js";
import { openDetail } from "./detail.js";

/** All documents the signed-in role may see, with search, status/date filters and paging. */
export async function documents(ctx, root) {
  const st = { page: 1, q: "", status: "", date_from: "", date_to: "", sort: "-created_at" };
  const names = await ctx.lookups();

  async function load() {
    let table;
    try {
      const r = await ctx.api.documents({ page: st.page, page_size: 15, q: st.q, status: st.status, date_from: st.date_from, date_to: st.date_to, sort: st.sort });
      table = html`${docTable(r.items, names)}
        <div class="pager"><button class="btn ghost" id="prev" ${r.page <= 1 ? "disabled" : ""}>قبلی</button>
        <span>صفحه ${r.page} از ${r.pages} · ${r.total} سند</span>
        <button class="btn ghost" id="next" ${r.page >= r.pages ? "disabled" : ""}>بعدی</button></div>`;
    } catch (e) { table = errorBox(e); }
    root.querySelector("#tbl").innerHTML = table.toString();
    onRowClick(root, (id) => openDetail(ctx, id, load));
    root.querySelector("#prev")?.addEventListener("click", () => { st.page--; load(); });
    root.querySelector("#next")?.addEventListener("click", () => { st.page++; load(); });
  }

  root.innerHTML = html`<div class="card">
    <div class="filters">
      <label>جست‌وجو<input id="q" placeholder="شماره، مرجع، توضیحات"></label>
      <label>وضعیت<select id="status"><option value="">همه</option>${Object.entries(STATUS_FA).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select></label>
      <label>از تاریخ<input type="date" id="df"></label>
      <label>تا تاریخ<input type="date" id="dt"></label>
      <label>مرتب‌سازی<select id="sort"><option value="-created_at">جدیدترین</option><option value="-total">بیشترین مبلغ</option><option value="-purchase_date">تاریخ خرید</option></select></label>
      <button class="btn" id="go">اعمال</button>
    </div><div id="tbl"><div class="empty">در حال بارگذاری…</div></div></div>`.toString();

  const apply = () => {
    st.q = root.querySelector("#q").value.trim(); st.status = root.querySelector("#status").value;
    st.date_from = root.querySelector("#df").value; st.date_to = root.querySelector("#dt").value;
    st.sort = root.querySelector("#sort").value; st.page = 1; load();
  };
  root.querySelector("#go").addEventListener("click", apply);
  root.querySelector("#q").addEventListener("keydown", (e) => { if (e.key === "Enter") apply(); });
  await load();
  ctx.setTimer(load, 20000);
}
export { raw, DOC_TYPE_FA };
