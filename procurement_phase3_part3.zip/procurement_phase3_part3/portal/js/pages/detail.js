import { html, raw, esc, fmtMoney, fmtDateTime, statusFa, statusColor, DOC_TYPE_FA, correctionDiff } from "../util.js";
import { chip } from "./common.js";

/** Document detail modal: lines, attachments, history and decision actions for deciders. */
export async function openDetail(ctx, id, onChange = () => {}) {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="modal"><div class="empty">در حال بارگذاری…</div></div>`;
  document.body.appendChild(overlay);
  const close = () => overlay.remove();
  overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });
  const modal = overlay.firstElementChild;

  async function load() {
    try {
      const [d, hist, names] = await Promise.all([ctx.api.document(id), ctx.api.history(id), ctx.lookups()]);
      draw(d, hist, names);
    } catch (e) {
      modal.innerHTML = `<div class="modal-head"><h2>خطا</h2><button class="btn ghost" id="x">بستن</button></div><div class="error">${esc(e.message)}</div>`;
      modal.querySelector("#x").onclick = close;
    }
  }

  function draw(d, hist, names) {
    const own = d.employee_id === ctx.me.id;
    const canDecide = ctx.can("document.decide") && !own;
    const showStart = canDecide && (d.status === "submitted" || d.status === "resubmitted");
    const showDecision = canDecide && d.status === "under_review";
    const lines = d.lines.map((l) => html`<tr><td>${l.line_no}</td><td>${l.description}</td><td class="num">${fmtMoney(l.quantity)}</td><td class="num">${fmtMoney(l.unit_price)}</td><td class="num">${(Number(l.tax_rate) * 100).toFixed(1)}%</td><td class="num">${fmtMoney(l.line_total)}</td></tr>`);
    const events = hist.map((e) => {
      const to = e.payload?.to;
      const text = e.action === "document.status_changed" ? `${statusFa(e.payload.from)} ← ${statusFa(to)}` : e.action;
      return html`<li><span class="pt" style="background:${statusColor(to)}"></span><div><div>${text}</div>${e.payload?.note ? html`<div class="error" style="color:var(--text-secondary)">${e.payload.note}</div>` : ""}<small class="ltr">${fmtDateTime(e.timestamp)}</small></div></li>`;
    });
    modal.innerHTML = html`
      <div class="modal-head"><h2>${d.doc_number} ${chip(d.status)}</h2><button class="btn ghost" id="x">بستن</button></div>
      <div class="card dark"><div class="grid three">
        <div><small>${"مبلغ کل"}</small><div style="font-size:24px;font-weight:700" class="ltr">${fmtMoney(d.total)} ${d.currency}</div></div>
        <div><small>تامین‌کننده</small><div>${names.suppliers.get(d.supplier_id) || "#" + d.supplier_id}</div></div>
        <div><small>پروژه</small><div>${names.projects.get(d.project_id) || "#" + d.project_id}</div></div></div>
        <div style="margin-top:8px;color:var(--text-on-dark-muted)">${DOC_TYPE_FA[d.doc_type] || d.doc_type} · ${d.purchase_date} · ${d.description}</div></div>
      ${d.decision_note ? html`<div class="card"><b>یادداشت تصمیم:</b> ${d.decision_note}</div>` : ""}
      <div class="card"><h2>اقلام</h2><div class="table-wrap"><table><thead><tr><th>#</th><th>شرح</th><th>تعداد</th><th>قیمت واحد</th><th>مالیات</th><th>جمع</th></tr></thead><tbody>${lines}</tbody></table></div>
        <p class="ltr" style="text-align:end">Subtotal ${fmtMoney(d.subtotal)} · Tax ${fmtMoney(d.tax_total)} · <b>Total ${fmtMoney(d.total)}</b></p></div>
      ${d.attachments.length ? html`<div class="card"><h2>پیوست‌ها</h2>${d.attachments.map((a) => html`<div>${a.original_name} <small>(${Math.round(a.size_bytes / 1024)} KB)</small></div>`)}</div>` : ""}
      <div class="card"><h2>تاریخچه</h2><ul class="timeline">${events}</ul></div>
      ${showStart || showDecision ? html`<div class="card"><h2>تصمیم</h2>
        <textarea id="note" rows="2" placeholder="یادداشت (برای رد الزامی است)"></textarea>
        <div class="row-actions" style="margin-top:12px">
          ${showStart ? html`<button class="btn" id="start">شروع بررسی</button>` : ""}
          ${showDecision ? html`<button class="btn" id="approve">تایید</button><button class="btn danger" id="reject">رد</button>` : ""}
        </div></div>` : ""}`.toString();
    modal.querySelector("#x").onclick = close;
    const act = async (fn, msg) => {
      modal.querySelectorAll("button").forEach((b) => (b.disabled = true));
      try { await fn(); ctx.toast(msg); onChange(); await load(); }
      catch (e) { ctx.toast(e.message); onChange(); await load(); }
    };
    const note = () => modal.querySelector("#note")?.value.trim() || "";
    modal.querySelector("#start")?.addEventListener("click", () => act(() => ctx.api.startReview(id), "بررسی شروع شد."));
    modal.querySelector("#approve")?.addEventListener("click", () => act(() => ctx.api.approve(id, note()), "تایید شد."));
    modal.querySelector("#reject")?.addEventListener("click", () => {
      if (!note()) { ctx.toast("برای رد، دلیل را بنویسید."); return; }
      act(() => ctx.api.reject(id, note()), "رد شد.");
    });
  }
  await load();
}

/** Correction diff block used by the approvals page. */
export function diffBlock(c) {
  const rows = correctionDiff(c);
  if (!rows.length) return html`<div class="empty">تفاوتی ثبت نشده</div>`;
  return html`<div class="diff">${rows.map((r) => html`<b>${r.field}</b><span class="b">${r.before}</span><span class="a">${r.after}</span>`)}</div>`;
}
export { raw };
