// API address. By default the portal assumes the API runs on the same machine/host as the
// portal, on port 8000 (works for http://localhost:5173 and http://192.168.x.x:5173 alike).
// Override by editing the line below, e.g. export const API_BASE = "http://192.168.1.20:8000/api/v1";
export const API_BASE = `${location.protocol}//${location.hostname}:8000/api/v1`;
export const REPORTING_NOTE_FA = "داده‌ها مصنوعی (دمو) هستند.";
