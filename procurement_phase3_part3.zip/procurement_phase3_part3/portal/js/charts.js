// Dependency-free SVG charts (work offline on the LAN, no CDN). All return HTML strings built
// with escaped labels.
import { esc, fmtMoney, fmtCompact } from "./util.js";

const PALETTE = ["#1E2530", "#4A6FA5", "#2E9E6B", "#C98A12", "#8A93A0", "#D64545", "#6B7380", "#A9B0BA"];

/** Donut chart. items: [{label, value, color?}]. The largest slice gets the accent colour unless colours are given. */
export function donut(items, { size = 180, thickness = 28, centerLabel = "", centerValue = "" } = {}) {
  const data = items.filter((i) => Number(i.value) > 0);
  const total = data.reduce((s, i) => s + Number(i.value), 0);
  if (!data.length) return `<div class="empty">داده‌ای نیست</div>`;
  const r = (size - thickness) / 2, c = size / 2, circ = 2 * Math.PI * r;
  let offset = 0;
  const top = data.reduce((m, i) => (i.value > m.value ? i : m), data[0]);
  const arcs = data.map((it, idx) => {
    const frac = Number(it.value) / total;
    const color = it.color || (it === top ? "#FF7A33" : PALETTE[idx % PALETTE.length]);
    const seg = `<circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="${color}" stroke-width="${thickness}"
      stroke-dasharray="${(frac * circ).toFixed(3)} ${(circ - frac * circ).toFixed(3)}" stroke-dashoffset="${(-offset).toFixed(3)}"
      transform="rotate(-90 ${c} ${c})"><title>${esc(it.label)}: ${fmtMoney(it.value, 0)} (${(frac * 100).toFixed(1)}%)</title></circle>`;
    offset += frac * circ;
    return { seg, color, it, frac };
  });
  const legend = arcs.map((a) => `<li><span class="dot" style="background:${a.color}"></span><span class="lbl">${esc(a.it.label)}</span><span class="val">${fmtMoney(a.it.value, 0)} · ${(a.frac * 100).toFixed(0)}%</span></li>`).join("");
  return `<div class="donut"><svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" role="img">
    <circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="#E1E4E9" stroke-width="${thickness}"/>${arcs.map((a) => a.seg).join("")}
    <text x="${c}" y="${c - 2}" text-anchor="middle" class="donut-v">${esc(centerValue)}</text>
    <text x="${c}" y="${c + 16}" text-anchor="middle" class="donut-l">${esc(centerLabel)}</text></svg><ul class="legend">${legend}</ul></div>`;
}

/** Vertical bar chart. items: [{label, value}]. Bars use the accent colour. */
export function barChart(items, { width = 560, height = 230 } = {}) {
  if (!items.length) return `<div class="empty">داده‌ای نیست</div>`;
  const pad = { l: 44, r: 8, t: 14, b: 30 };
  const max = Math.max(...items.map((i) => Number(i.value)), 1);
  const w = width - pad.l - pad.r, h = height - pad.t - pad.b;
  const step = w / items.length, bw = Math.min(34, step * 0.62);
  const grid = [0, 0.25, 0.5, 0.75, 1].map((f) => {
    const y = pad.t + h - f * h;
    return `<line x1="${pad.l}" x2="${width - pad.r}" y1="${y}" y2="${y}" class="grid"/><text x="${pad.l - 6}" y="${y + 4}" text-anchor="end" class="axis">${fmtCompact(max * f)}</text>`;
  }).join("");
  const bars = items.map((it, i) => {
    const bh = (Number(it.value) / max) * h, x = pad.l + i * step + (step - bw) / 2, y = pad.t + h - bh;
    return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(bh, 0).toFixed(1)}" rx="8" class="bar"><title>${esc(it.label)}: ${fmtMoney(it.value, 0)}</title></rect>
      <text x="${(x + bw / 2).toFixed(1)}" y="${height - 10}" text-anchor="middle" class="axis">${esc(String(it.label).slice(-5))}</text>`;
  }).join("");
  return `<svg viewBox="0 0 ${width} ${height}" class="bars" role="img" preserveAspectRatio="xMidYMid meet">${grid}${bars}</svg>`;
}

/** Horizontal ranking bars in HTML (long labels such as supplier names). */
export function hbars(items) {
  if (!items.length) return `<div class="empty">داده‌ای نیست</div>`;
  const max = Math.max(...items.map((i) => Number(i.value)), 1);
  return `<ul class="hbars">${items.map((it) => `<li><div class="hb-top"><span>${esc(it.label)}</span><b dir="ltr">${fmtMoney(it.value, 0)}</b></div><div class="hb-track"><div class="hb-fill" style="width:${((Number(it.value) / max) * 100).toFixed(1)}%"></div></div></li>`).join("")}</ul>`;
}
