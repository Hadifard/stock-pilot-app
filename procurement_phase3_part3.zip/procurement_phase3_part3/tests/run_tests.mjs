// Offline tests: node tests/run_tests.mjs   (Node 18+; no packages needed)
import assert from "node:assert/strict";
import { createMock } from "./mock_api.mjs";
import { Api, ApiError } from "../portal/js/api.js";
import { esc, html, fmtMoney, fmtCompact, fmtDateTime, correctionDiff } from "../portal/js/util.js";
import { donut, barChart, hbars } from "../portal/js/charts.js";
import { dashboard } from "../portal/js/pages/dashboard.js";
import { documents } from "../portal/js/pages/documents.js";
import { approvals } from "../portal/js/pages/approvals.js";
import { openDetail } from "../portal/js/pages/detail.js";

let passed = 0;
const t = async (name, fn) => { try { await fn(); passed++; console.log("ok  -", name); } catch (e) { console.log("FAIL-", name, "\n", e); process.exitCode = 1; } };
const mem = () => { const m = new Map(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k) }; };

// ---------- pure helpers
await t("esc / html escape interpolations", () => {
  assert.equal(esc(`<a href="x">'&`), "&lt;a href=&quot;x&quot;&gt;&#39;&amp;");
  assert.equal(String(html`<p>${"<script>"}</p>`), "<p>&lt;script&gt;</p>");
  assert.equal(String(html`<b>${html`<i>${"<"}</i>`}</b>`), "<b><i>&lt;</i></b>");
});
await t("number/date formatting", () => {
  assert.equal(fmtMoney("1234567.891"), "1,234,567.89");
  assert.equal(fmtMoney("x"), "-");
  assert.equal(fmtCompact(1500), "1.5K");
  assert.equal(fmtCompact(2000000), "2M");
  assert.match(fmtDateTime("2026-10-17T09:30:00"), /^2026-10-17 \d\d:\d\d$/);
});
await t("correctionDiff reports only changes", () => {
  const rows = correctionDiff({ original: { input: { description: "a", lines: [{ description: "P", quantity: "1", unit_price: "100", tax_rate: "0.19" }] }, calculated_total: "119" }, proposed: { input: { description: "b", lines: [{ description: "P", quantity: "1", unit_price: "90", tax_rate: "0.19" }] }, calculated_total: "107.1" } });
  assert.deepEqual(rows.map((r) => r.field), ["description", "line 1 unit_price", "total"]);
});
await t("charts: donut shares sum, escapes labels, handles empty", () => {
  const d = donut([{ label: "<x>", value: 3 }, { label: "b", value: 1 }]);
  assert.ok(d.includes("&lt;x&gt;") && !d.includes("<x>") && d.includes("75%"));
  assert.ok(donut([]).includes("empty"));
  const b = barChart([{ label: "2026-09", value: 10 }, { label: "2026-10", value: 20 }]);
  assert.equal((b.match(/class="bar"/g) || []).length, 2);
  assert.ok(hbars([{ label: "<i>", value: 5 }]).includes("&lt;i&gt;"));
});

// ---------- API client against the mock
const mock = createMock({ expireFirstAccess: true });
const port = await mock.listen();
const base = `http://localhost:${port}/api/v1`;
const mk = (extra = {}) => new Api(base, { storage: mem(), ...extra });

await t("login failure surfaces server message", async () => {
  await assert.rejects(mk().login("u", "bad"), (e) => e instanceof ApiError && e.status === 401 && /Invalid/.test(e.message));
});
await t("network failure -> ApiError status 0", async () => {
  await assert.rejects(new Api("http://localhost:1/api/v1", { storage: mem() }).login("u", "p"), (e) => e.status === 0);
});
const api = mk();
await t("login stores tokens; expired access token triggers ONE refresh and retries", async () => {
  await api.login("manager.demo", "Mock-Pass-123");
  const me = await api.me(); // mock answers 401 once -> refresh -> retry
  assert.equal(me.username, "manager.demo");
  assert.equal(mock.state.refreshCalls, 1);
  assert.equal(api.refresh, "R2"); // rotated
});
await t("concurrent 401s share a single refresh (tokens are single-use)", async () => {
  mock.state.firstExpired = false; mock.state.accessSeq += 0;
  const before = mock.state.refreshCalls;
  await Promise.all([api.kpis(), api.operations(), api.spend("month")]);
  assert.equal(mock.state.refreshCalls - before, 1);
});
await t("refMap, documents query serialisation (repeated status)", async () => {
  const m = await api.refMap("/reference/suppliers", (s) => s.name);
  assert.equal(m.size, 2);
  await api.documents({ status: ["submitted", "under_review"], page_size: 50, q: "" });
  assert.ok(mock.state.log.some((l) => l.includes("status=submitted&status=under_review") && l.includes("page_size=50") && !l.includes("q=")));
});

// ---------- page rendering with real page code on mock data (fake root element)
const fakeEl = () => { const kids = new Map(); const el = { innerHTML: "", value: "", dataset: {}, textContent: "", classList: { toggle() {} }, addEventListener() {}, querySelectorAll: () => [], querySelector(sel) { if (!kids.has(sel)) kids.set(sel, fakeEl()); return kids.get(sel); } }; return el; };
const toasts = [];
const ctx = { api, me: { id: 5, permissions: ["analytics.view", "document.decide"] }, can(p) { return this.me.permissions.includes(p); }, toast: (m) => toasts.push(m), setTimer() {}, lookups: () => Promise.all([api.refMap("/reference/suppliers", (s) => s.name), api.refMap("/reference/projects", (p) => `${p.code} - ${p.name}`)]).then(([suppliers, projects]) => ({ suppliers, projects })) };

await t("dashboard renders KPIs, donuts, bars, table - and neutralises hostile supplier names", async () => {
  const root = fakeEl(); await dashboard(ctx, root);
  const h = root.innerHTML;
  assert.ok(h.includes("1,240") && h.includes("5.5"), "KPI values");
  assert.equal((h.match(/<circle/g) || []).length >= 4, true, "donut arcs");
  assert.ok(h.includes('class="bar"') && h.includes("hb-fill") && h.includes("DOC-000001"));
  assert.ok(!h.includes("<img src=x"), "raw hostile markup must not appear");
  assert.ok(h.includes("&lt;img src=x"), "hostile markup is escaped");
  assert.ok(h.includes("تایید شده") && h.includes("ارسال‌شده"), "status labels");
});
await t("documents page renders table + pager", async () => {
  const root = fakeEl(); await documents(ctx, root);
  assert.ok(root.innerHTML.includes('id="tbl"'));
  assert.ok(root.querySelector("#tbl").innerHTML.includes("DOC-000002") && root.querySelector("#tbl").innerHTML.includes("صفحه 1 از 1"));
});
await t("approvals: queue lists pending docs; corrections tab shows diff", async () => {
  const root = fakeEl(); await approvals(ctx, root);
  assert.ok(root.querySelector("#body").innerHTML.includes("DOC-000001"));
});
await t("approve/reject go without If-Match; reject needs a note (server rule mirrored)", async () => {
  await api.startReview(1);
  const d = await api.approve(1, "ok");
  assert.equal(d.status, "approved");
  await assert.rejects(api.reject(2, ""), (e) => e.status === 422);
});
await t("openDetail draws modal for a document without throwing", async () => {
  const added = [];
  globalThis.document = { createElement: () => { const o = fakeEl(); o.firstElementChild = fakeEl(); o.remove = () => {}; o.className = ""; return o; }, body: { appendChild: (x) => added.push(x) } };
  await openDetail(ctx, 2, () => {});
  const modal = added[0].firstElementChild;
  assert.ok(modal.innerHTML.includes("DOC-000002") && modal.innerHTML.includes("&lt;b&gt;paper&lt;/b&gt;"));
  delete globalThis.document;
});

await mock.close();
console.log(`\n${passed} checks passed${process.exitCode ? " (WITH FAILURES)" : ""}`);
