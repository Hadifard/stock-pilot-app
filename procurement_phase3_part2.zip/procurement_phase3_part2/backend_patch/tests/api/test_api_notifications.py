from tests.api.conftest import auth  # `client` fixture comes from tests/api/conftest.py


def test_notifications_list_and_read_all(client):
    h = auth(client, "employee.demo")
    r = client.get("/api/v1/notifications", headers=h)
    assert r.status_code == 200
    body = r.json()
    assert set(body) == {"items", "unread"}
    assert client.post("/api/v1/notifications/read-all", headers=h).status_code == 204
    assert client.get("/api/v1/notifications", headers=h).json()["unread"] == 0


def test_notifications_require_auth(client):
    assert client.get("/api/v1/notifications").status_code == 401
