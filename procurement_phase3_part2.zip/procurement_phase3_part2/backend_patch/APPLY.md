# Backend patch (2 small edits, no existing behaviour changed)
1. Copy `app/api/routers/notifications.py` and `tests/api/test_api_notifications.py` into the Phase 2 project.
2. In `app/api/main.py`:
   - change `from app.api.routers import admin, analytics, auth, documents, extraction, reference`
     to    `from app.api.routers import admin, analytics, auth, documents, extraction, notifications, reference`
   - change `for r in (auth, reference, documents, extraction, analytics, admin):`
     to    `for r in (auth, reference, documents, extraction, analytics, admin, notifications):`
3. Run `pytest tests/api -q`. (Not run in the build sandbox: no FastAPI available there.)
