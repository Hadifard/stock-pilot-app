"""In-app notifications (read-only list + mark all read). Thin wrapper over the existing
notification_service, which the Streamlit app already uses. Added for the Phase 3 mobile app."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Query, Response
from pydantic import BaseModel

from app.api.deps import CurrentUser, SessionDep
from app.services import notification_service as ns

router = APIRouter(prefix="/notifications", tags=["Notifications"])


class NotificationOut(BaseModel):
    id: int
    message: str
    document_id: int | None
    is_read: bool
    created_at: datetime


class NotificationList(BaseModel):
    items: list[NotificationOut]
    unread: int


@router.get("", response_model=NotificationList, summary="Your latest notifications")
def list_notifications(
    user: CurrentUser, session: SessionDep, limit: int = Query(50, ge=1, le=100)
):
    rows = ns.list_notifications(session, user, limit)
    return NotificationList(
        items=[
            NotificationOut(
                id=n.id,
                message=n.message,
                document_id=n.document_id,
                is_read=n.is_read,
                created_at=n.created_at,
            )
            for n in rows
        ],
        unread=ns.unread_count(session, user),
    )


@router.post("/read-all", status_code=204, summary="Mark all your notifications as read")
def read_all(user: CurrentUser, session: SessionDep):
    ns.mark_all_read(session, user)
    return Response(status_code=204)
