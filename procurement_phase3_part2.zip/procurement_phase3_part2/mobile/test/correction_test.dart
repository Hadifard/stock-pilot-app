import "package:flutter_test/flutter_test.dart";
import "package:procurement_mobile/core/api/models.dart";

Map<String, dynamic> _snap(String desc, String price, String total) => {
      "input": {
        "description": desc,
        "payment_method": "bank_transfer",
        "lines": [
          {"description": "Paper", "quantity": "2.0000", "unit_price": price, "tax_rate": "0.1900"}
        ],
      },
      "calculated_total": total,
    };

void main() {
  test("Correction.diff lists changed header, line and total values only", () {
    final c = Correction.fromJson({
      "id": 1, "document_id": 7, "requested_by": 3, "requested_at": "2026-10-17T09:30:00",
      "reason": "typo", "status": "pending", "deadline_exception": false, "exception_reason": null,
      "decision_note": null,
      "original": _snap("old", "100.0000", "238.0000"),
      "proposed": _snap("new", "90.0000", "214.2000"),
    });
    final f = c.diff().map((r) => r.field).toList();
    expect(f, containsAll(["description", "line 1 unit_price", "total"]));
    expect(f.contains("payment_method"), isFalse);
    expect(f.contains("line 1 quantity"), isFalse);
  });

  test("NotifItem and HistoryEvent parse", () {
    final n = NotifItem.fromJson({"id": 1, "message": "m", "document_id": null, "is_read": false, "created_at": "2026-10-17T09:30:00"});
    expect(n.isRead, isFalse);
    final h = HistoryEvent.fromJson({"timestamp": "2026-10-17T09:30:00", "action": "document.status_changed", "payload": {"from": "draft", "to": "submitted"}});
    expect(h.payload["to"], "submitted");
  });
}
