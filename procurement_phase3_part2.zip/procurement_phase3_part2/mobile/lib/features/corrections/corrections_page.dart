import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/strings.dart";
import "../../core/widgets/dialogs.dart";
import "../../core/widgets/widgets.dart";
import "../../state/auth_state.dart";
import "../documents/document_detail_page.dart";

/// Correction requests the caller may see (own requests + those they may decide).
/// [pendingOnly] is used by the manager queue; the account screen shows the full history.
class CorrectionsPage extends StatefulWidget {
  const CorrectionsPage({super.key, this.pendingOnly = false, this.embedded = false});
  final bool pendingOnly;
  final bool embedded; // true: no Scaffold (inside the review tab)
  @override
  State<CorrectionsPage> createState() => _CorrectionsPageState();
}

class _CorrectionsPageState extends State<CorrectionsPage> {
  List<Correction> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await context.read<ApiClient>().corrections(pendingOnly: widget.pendingOnly);
      if (mounted) setState(() => _items = r.items);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final body = _loading
        ? const LoadingView()
        : _error != null
            ? ErrorView(message: _error!, onRetry: _load)
            : _items.isEmpty
                ? const EmptyView(text: S.noCorrections, icon: Icons.edit_note_rounded)
                : RefreshIndicator(
                    color: T.accent,
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(T.lg),
                      itemCount: _items.length,
                      itemBuilder: (_, i) {
                        final c = _items[i];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: T.md),
                          child: AppCard(
                            onTap: () async {
                              await Navigator.push(context, MaterialPageRoute(builder: (_) => CorrectionDetailPage(c: c)));
                              _load();
                            },
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                Expanded(child: Text("سند #${c.documentId}", style: const TextStyle(fontWeight: FontWeight.w700))),
                                CorrectionChip(c.status),
                              ]),
                              const SizedBox(height: T.xs),
                              Text(c.reason, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                            ]),
                          ),
                        );
                      },
                    ),
                  );
    if (widget.embedded) return body;
    return Scaffold(appBar: AppBar(title: const Text(S.corrections)), body: body);
  }
}

class CorrectionChip extends StatelessWidget {
  const CorrectionChip(this.status, {super.key});
  final String status;
  @override
  Widget build(BuildContext context) {
    final c = status == "approved" ? T.success : status == "rejected" ? T.danger : T.warning;
    final label = status == "pending" ? S.pending : S.status(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: c.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(999)),
      child: Text(label, style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}

class CorrectionDetailPage extends StatefulWidget {
  const CorrectionDetailPage({super.key, required this.c});
  final Correction c;
  @override
  State<CorrectionDetailPage> createState() => _CorrectionDetailPageState();
}

class _CorrectionDetailPageState extends State<CorrectionDetailPage> {
  bool _busy = false;

  Future<void> _decide(bool approve) async {
    final note = await askNote(context, title: approve ? S.approve : S.noteRequired, label: approve ? S.note : S.reason, required: !approve);
    if (note == null || !mounted) return;
    setState(() => _busy = true);
    try {
      await context.read<ApiClient>().decideCorrection(widget.c.id, approve, note);
      if (!mounted) return;
      showMessage(context, approve ? "اصلاحیه تایید شد." : "اصلاحیه رد شد.");
      Navigator.pop(context);
    } on ApiException catch (e) {
      if (mounted) showMessage(context, e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    final me = context.watch<AuthState>().me!;
    final canDecide = c.status == "pending" && me.can("correction.decide") && c.requestedBy != me.id;
    final rows = c.diff();
    return Scaffold(
      appBar: AppBar(title: Text("اصلاحیه سند #${c.documentId}")),
      body: ListView(padding: const EdgeInsets.all(T.lg), children: [
        AppCard(
          dark: true,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text(S.reason, style: TextStyle(color: T.onDarkMuted, fontSize: 12)),
              const Spacer(),
              CorrectionChip(c.status),
            ]),
            const SizedBox(height: T.xs),
            Text(c.reason, style: const TextStyle(color: T.onDark)),
            if (c.deadlineException) ...[
              const SizedBox(height: T.sm),
              Text("${S.overrideReason}: ${c.exceptionReason ?? "-"}", style: const TextStyle(color: T.accent, fontSize: 12)),
            ],
          ]),
        ),
        const SizedBox(height: T.md),
        AppCard(
          child: rows.isEmpty
              ? const Text("-")
              : Column(children: [
                  for (final r in rows) ...[
                    Align(alignment: AlignmentDirectional.centerStart, child: Text(r.field, style: const TextStyle(fontWeight: FontWeight.w600))),
                    const SizedBox(height: 4),
                    Row(children: [
                      Expanded(child: Text(r.before, textDirection: TextDirection.ltr, style: const TextStyle(color: T.danger, decoration: TextDecoration.lineThrough))),
                      const Icon(Icons.arrow_forward_rounded, size: 16, color: T.neutral),
                      const SizedBox(width: T.sm),
                      Expanded(child: Text(r.after, textDirection: TextDirection.ltr, style: const TextStyle(color: T.success, fontWeight: FontWeight.w600))),
                    ]),
                    const Divider(height: T.xl),
                  ],
                ]),
        ),
        if (c.decisionNote != null && c.decisionNote!.isNotEmpty) ...[
          const SizedBox(height: T.md),
          AppCard(child: Text("${S.decisionNote}: ${c.decisionNote}")),
        ],
        const SizedBox(height: T.md),
        AppButton(
          label: "${S.myDocs} #${c.documentId}",
          primary: false,
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DocumentDetailPage(docId: c.documentId))),
        ),
        if (canDecide) ...[
          const SizedBox(height: T.md),
          Row(children: [
            Expanded(child: AppButton(label: S.reject, primary: false, onPressed: _busy ? null : () => _decide(false))),
            const SizedBox(width: T.md),
            Expanded(child: AppButton(label: S.approve, busy: _busy, onPressed: () => _decide(true))),
          ]),
        ],
      ]),
    );
  }
}
