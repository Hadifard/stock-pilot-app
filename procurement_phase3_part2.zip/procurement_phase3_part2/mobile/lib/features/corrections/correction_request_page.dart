import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/money.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";

/// Request a correction of a submitted document. Nothing is changed until a reviewer approves;
/// only fields the user actually changed are sent. Existing lines can be edited (not added or
/// removed) - enough for the common "wrong price/quantity/description" case.
class CorrectionRequestPage extends StatefulWidget {
  const CorrectionRequestPage({super.key, required this.doc, required this.needsOverride});
  final DocDetail doc;
  final bool needsOverride; // outside the window: written justification required
  @override
  State<CorrectionRequestPage> createState() => _CorrectionRequestPageState();
}

class _LineEdit {
  _LineEdit(DocLine l)
      : orig = l,
        desc = TextEditingController(text: l.description),
        qty = TextEditingController(text: Money.display(l.quantity, decimals: 4).replaceAll(",", "").replaceFirst(RegExp(r"\.?0+$"), "")),
        price = TextEditingController(text: l.unitPrice.replaceFirst(RegExp(r"\.?0+$"), "")),
        tax = TextEditingController(text: Money.fractionToPercent(l.taxRate));
  final DocLine orig;
  final TextEditingController desc, qty, price, tax;
  void dispose() {
    desc.dispose();
    qty.dispose();
    price.dispose();
    tax.dispose();
  }
}

class _CorrectionRequestPageState extends State<CorrectionRequestPage> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _desc = TextEditingController(text: widget.doc.description);
  late final TextEditingController _ref = TextEditingController(text: widget.doc.summary.supplierRef ?? "");
  late final TextEditingController _ship = TextEditingController(text: _trim(widget.doc.shipping));
  late final TextEditingController _other = TextEditingController(text: _trim(widget.doc.otherCharges));
  final _reason = TextEditingController();
  final _override = TextEditingController();
  late final List<_LineEdit> _lines = widget.doc.lines.map(_LineEdit.new).toList();
  late String _payment = widget.doc.paymentMethod;
  bool _busy = false;
  String? _error;

  static String _trim(String v) => v.replaceFirst(RegExp(r"\.?0+$"), "");

  @override
  void dispose() {
    for (final c in [_desc, _ref, _ship, _other, _reason, _override]) {
      c.dispose();
    }
    for (final l in _lines) {
      l.dispose();
    }
    super.dispose();
  }

  String? _num(String? v, {bool positive = false}) {
    final p = Money.parse(v ?? "");
    if (p == null) return S.invalidNumber;
    if (positive && Money.toDouble(p) <= 0) return S.invalidNumber;
    return null;
  }

  String? _pct(String? v) {
    final p = Money.percentToFraction(v ?? "");
    return (p == null || Money.toDouble(p) > 0.5) ? S.invalidNumber : null;
  }

  Future<void> _send() async {
    if (!_form.currentState!.validate()) return;
    final d = widget.doc;
    final header = <String, dynamic>{};
    if (_desc.text.trim() != d.description) header["description"] = _desc.text.trim();
    if (_ref.text.trim() != (d.summary.supplierRef ?? "")) {
      header["supplier_ref"] = _ref.text.trim().isEmpty ? null : _ref.text.trim();
    }
    if (_payment != d.paymentMethod) header["payment_method"] = _payment;
    final ship = Money.parse(_ship.text)!;
    if (ship != d.shipping) header["shipping"] = ship;
    final other = Money.parse(_other.text)!;
    if (other != d.otherCharges) header["other_charges"] = other;

    var linesChanged = false;
    final lines = <Map<String, dynamic>>[];
    for (final e in _lines) {
      final m = e.orig.toChange();
      m["description"] = e.desc.text.trim();
      m["quantity"] = Money.parse(e.qty.text);
      m["unit_price"] = Money.parse(e.price.text);
      m["tax_rate"] = Money.percentToFraction(e.tax.text);
      final before = e.orig.toChange();
      if (["description", "quantity", "unit_price", "tax_rate"].any((k) => "${m[k]}" != "${before[k]}")) {
        linesChanged = true;
      }
      lines.add(m);
    }

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await context.read<ApiClient>().requestCorrection(
            d.summary.id,
            header: header,
            lines: linesChanged ? lines : null,
            reason: _reason.text.trim(),
            overrideReason: widget.needsOverride ? _override.text.trim() : null,
          );
      if (!mounted) return;
      showMessage(context, "درخواست اصلاحیه ثبت شد.");
      Navigator.pop(context, true);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    String? req(String? v) => (v == null || v.trim().isEmpty) ? S.required : null;
    return Scaffold(
      appBar: AppBar(title: const Text(S.requestCorrection)),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(T.lg), children: [
          AppCard(
            child: Column(children: [
              TextFormField(controller: _desc, maxLines: 2, decoration: const InputDecoration(labelText: S.description), validator: req),
              const SizedBox(height: T.md),
              TextFormField(controller: _ref, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: S.supplierRef)),
              const SizedBox(height: T.md),
              DropdownButtonFormField<String>(
                value: _payment,
                isExpanded: true,
                decoration: const InputDecoration(labelText: S.payment),
                items: [for (final e in S.paymentMethods.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                onChanged: (v) => setState(() => _payment = v!),
              ),
              const SizedBox(height: T.md),
              Row(children: [
                Expanded(child: _numField(_ship, S.shipping, _num)),
                const SizedBox(width: T.md),
                Expanded(child: _numField(_other, S.otherCharges, _num)),
              ]),
            ]),
          ),
          const SizedBox(height: T.lg),
          Text(S.lines, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: T.sm),
          for (final l in _lines)
            Padding(
              padding: const EdgeInsets.only(bottom: T.md),
              child: AppCard(
                child: Column(children: [
                  TextFormField(controller: l.desc, decoration: const InputDecoration(labelText: S.lineDesc), validator: req),
                  const SizedBox(height: T.md),
                  Row(children: [
                    Expanded(child: _numField(l.qty, S.qty, (v) => _num(v, positive: true))),
                    const SizedBox(width: T.sm),
                    Expanded(flex: 2, child: _numField(l.price, S.unitPrice, (v) => _num(v, positive: true))),
                    const SizedBox(width: T.sm),
                    Expanded(child: _numField(l.tax, S.taxPct, _pct)),
                  ]),
                ]),
              ),
            ),
          AppCard(
            child: Column(children: [
              TextFormField(controller: _reason, maxLines: 2, decoration: const InputDecoration(labelText: S.reason), validator: req),
              if (widget.needsOverride) ...[
                const SizedBox(height: T.md),
                TextFormField(controller: _override, maxLines: 2, decoration: const InputDecoration(labelText: S.overrideReason), validator: req),
              ],
            ]),
          ),
          if (_error != null) ...[const SizedBox(height: T.md), Text(_error!, style: const TextStyle(color: T.danger))],
          const SizedBox(height: T.lg),
          AppButton(label: S.send, icon: Icons.send_rounded, busy: _busy, onPressed: _send),
          const SizedBox(height: T.xl),
        ]),
      ),
    );
  }

  Widget _numField(TextEditingController c, String label, String? Function(String?) v) => TextFormField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        textDirection: TextDirection.ltr,
        decoration: InputDecoration(labelText: label),
        validator: v,
      );
}
