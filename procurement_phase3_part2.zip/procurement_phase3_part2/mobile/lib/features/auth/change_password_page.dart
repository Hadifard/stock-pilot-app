import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/design/tokens.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";
import "../../state/auth_state.dart";

/// Shown when the server flags must_change_password (every other endpoint returns 403 until then),
/// and reusable from the profile screen in part 2. The server enforces the real policy
/// (min. 12 characters, 3 of 4 character classes) and its message is displayed as-is.
class ChangePasswordPage extends StatefulWidget {
  const ChangePasswordPage({super.key, this.forced = false});
  final bool forced;
  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final _cur = TextEditingController();
  final _new = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _cur.dispose();
    _new.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final nav = Navigator.of(context);
      await context.read<AuthState>().changePassword(_cur.text, _new.text);
      // The server revoked every token: the root switches to the login screen; drop this page.
      nav.popUntil((r) => r.isFirst);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text(S.changePassword), automaticallyImplyLeading: !widget.forced),
      body: ListView(padding: const EdgeInsets.all(T.xl), children: [
        if (widget.forced)
          const Padding(padding: EdgeInsets.only(bottom: T.lg), child: Text(S.mustChangePw)),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            TextField(
              controller: _cur,
              obscureText: true,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: S.currentPassword),
            ),
            const SizedBox(height: T.md),
            TextField(
              controller: _new,
              obscureText: true,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: S.newPassword),
            ),
            if (_error != null) ...[
              const SizedBox(height: T.md),
              Text(_error!, style: const TextStyle(color: T.danger)),
            ],
            const SizedBox(height: T.lg),
            AppButton(label: S.changePassword, onPressed: _submit, busy: _busy),
            if (widget.forced) ...[
              const SizedBox(height: T.md),
              AppButton(
                  label: S.signOut,
                  primary: false,
                  onPressed: () => context.read<AuthState>().logout()),
            ],
          ]),
        ),
      ]),
    );
  }
}
