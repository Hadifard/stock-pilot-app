import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/config.dart";
import "../../core/design/tokens.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";
import "../../state/auth_state.dart";
import "../auth/change_password_page.dart";
import "../corrections/corrections_page.dart";

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AuthState>().me!;
    Widget tile(IconData icon, String label, VoidCallback onTap) => Padding(
          padding: const EdgeInsets.only(bottom: T.md),
          child: AppCard(
            onTap: onTap,
            child: Row(children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: T.surfaceDark, borderRadius: BorderRadius.circular(T.rControl)),
                child: Icon(icon, color: T.onDark, size: 20),
              ),
              const SizedBox(width: T.md),
              Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
              const Icon(Icons.chevron_left_rounded, color: T.neutral),
            ]),
          ),
        );
    return ListView(padding: const EdgeInsets.all(T.lg), children: [
      AppCard(
        dark: true,
        child: Row(children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(color: T.accent, borderRadius: BorderRadius.circular(T.rControl)),
            alignment: Alignment.center,
            child: Text(me.fullName.isEmpty ? "?" : me.fullName.characters.first.toUpperCase(),
                style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(width: T.md),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(me.fullName, style: const TextStyle(color: T.onDark, fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text(me.username, textDirection: TextDirection.ltr, style: const TextStyle(color: T.onDarkMuted, fontSize: 12)),
              Text("${S.role}: ${S.role_(me.role)}", style: const TextStyle(color: T.onDarkMuted, fontSize: 12)),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: T.lg),
      tile(Icons.edit_note_rounded, S.corrections, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CorrectionsPage()))),
      tile(Icons.lock_outline_rounded, S.changePassword, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChangePasswordPage()))),
      AppCard(
        child: Row(children: [
          const Text(S.server, style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(width: T.md),
          Expanded(child: Text(AppConfig.baseUrl, textDirection: TextDirection.ltr, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall)),
        ]),
      ),
      const SizedBox(height: T.lg),
      AppButton(label: S.signOut, primary: false, icon: Icons.logout_rounded, onPressed: () => context.read<AuthState>().logout()),
    ]);
  }
}
