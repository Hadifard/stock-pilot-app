import "dart:async";

import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/design/tokens.dart";
import "../../core/strings.dart";
import "../../state/auth_state.dart";
import "../account/account_page.dart";
import "../documents/documents_page.dart";
import "../invoice/new_invoice_page.dart";
import "../notifications/notifications_page.dart";
import "../review/review_queue_page.dart";

/// Bottom navigation built from the user permissions: employees get documents / new invoice /
/// notifications / account; deciders also get the approval tab.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _Tab {
  _Tab(this.id, this.icon, this.label, this.page);
  final String id;
  final IconData icon;
  final String label;
  final Widget page;
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  int _formEpoch = 0; // bumping it rebuilds a fresh, empty invoice form
  int _unread = 0;
  Timer? _timer;
  final _docsKey = GlobalKey<DocumentsPageState>();
  final _reviewKey = GlobalKey<ReviewQueuePageState>();
  final _notifKey = GlobalKey<NotificationsPageState>();

  @override
  void initState() {
    super.initState();
    _pollUnread();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _pollUnread());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _pollUnread() async {
    try {
      final r = await context.read<ApiClient>().notifications();
      if (mounted) setState(() => _unread = r.unread);
    } on ApiException {
      // The badge is best-effort; errors are shown on the notifications tab itself.
    }
  }

  List<_Tab> _tabs() {
    final me = context.read<AuthState>().me!;
    return [
      _Tab("docs", Icons.folder_open_rounded, S.myDocs, DocumentsPage(key: _docsKey)),
      if (me.can("document.create"))
        _Tab(
          "new",
          Icons.add_circle_outline_rounded,
          S.newInvoice,
          NewInvoicePage(
            key: ValueKey(_formEpoch),
            onDone: () {
              setState(() {
                _formEpoch++;
                _index = 0;
              });
              _docsKey.currentState?.refresh();
            },
          ),
        ),
      if (me.can("document.decide")) _Tab("review", Icons.fact_check_outlined, S.reviewTab, ReviewQueuePage(key: _reviewKey)),
      _Tab("notif", Icons.notifications_none_rounded, S.notifications,
          NotificationsPage(key: _notifKey, onUnreadChanged: (n) => setState(() => _unread = n))),
      _Tab("account", Icons.person_outline_rounded, S.account, const AccountPage()),
    ];
  }

  void _onTab(String id) {
    switch (id) {
      case "docs":
        _docsKey.currentState?.refresh();
      case "review":
        _reviewKey.currentState?.refresh();
      case "notif":
        _notifKey.currentState?.refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    context.watch<AuthState>();
    final tabs = _tabs();
    if (_index >= tabs.length) _index = 0;
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: [for (final t in tabs) t.page])),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(T.md, 0, T.md, T.md),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(T.rLarge),
          child: NavigationBar(
            selectedIndex: _index,
            destinations: [
              for (final t in tabs)
                NavigationDestination(
                  icon: t.id == "notif" && _unread > 0
                      ? Badge(label: Text("$_unread"), backgroundColor: T.accent, child: Icon(t.icon))
                      : Icon(t.icon),
                  label: t.label,
                ),
            ],
            onDestinationSelected: (i) {
              setState(() => _index = i);
              _onTab(tabs[i].id);
            },
          ),
        ),
      ),
    );
  }
}
