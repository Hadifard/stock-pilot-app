import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";
import "../documents/document_detail_page.dart";

/// In-app notifications (GET /notifications, added by backend_patch). Unread ones are marked
/// with an orange dot; "mark all read" calls POST /notifications/read-all.
class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key, required this.onUnreadChanged});
  final ValueChanged<int> onUnreadChanged;
  @override
  State<NotificationsPage> createState() => NotificationsPageState();
}

class NotificationsPageState extends State<NotificationsPage> {
  List<NotifItem> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await context.read<ApiClient>().notifications();
      if (mounted) setState(() => _items = r.items);
      widget.onUnreadChanged(r.unread);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _readAll() async {
    try {
      await context.read<ApiClient>().markNotificationsRead();
      await refresh();
    } on ApiException catch (e) {
      if (mounted) showMessage(context, e.message);
    }
  }

  String _fmt(DateTime t) {
    final l = t.toLocal();
    String p(int n) => n.toString().padLeft(2, "0");
    return "${l.year}-${p(l.month)}-${p(l.day)} ${p(l.hour)}:${p(l.minute)}";
  }

  @override
  Widget build(BuildContext context) {
    final unread = _items.where((n) => !n.isRead).length;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(T.lg, T.lg, T.lg, T.sm),
        child: Row(children: [
          Expanded(child: Text(S.notifications, style: Theme.of(context).textTheme.headlineSmall)),
          if (unread > 0) TextButton(onPressed: _readAll, child: const Text(S.markAllRead, style: TextStyle(color: T.textPrimary))),
        ]),
      ),
      Expanded(
        child: _loading && _items.isEmpty
            ? const LoadingView()
            : _error != null && _items.isEmpty
                ? ErrorView(message: _error!, onRetry: refresh)
                : _items.isEmpty
                    ? const EmptyView(text: S.noNotifications, icon: Icons.notifications_none_rounded)
                    : RefreshIndicator(
                        color: T.accent,
                        onRefresh: refresh,
                        child: ListView.builder(
                          padding: const EdgeInsets.fromLTRB(T.lg, 0, T.lg, T.lg),
                          itemCount: _items.length,
                          itemBuilder: (_, i) {
                            final n = _items[i];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: T.md),
                              child: AppCard(
                                onTap: n.documentId == null
                                    ? null
                                    : () => Navigator.push(context, MaterialPageRoute(builder: (_) => DocumentDetailPage(docId: n.documentId!))),
                                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Container(
                                    margin: const EdgeInsets.only(top: 6, left: T.sm),
                                    width: 9,
                                    height: 9,
                                    decoration: BoxDecoration(color: n.isRead ? Colors.transparent : T.accent, shape: BoxShape.circle),
                                  ),
                                  Expanded(
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Text(n.message, style: TextStyle(fontWeight: n.isRead ? FontWeight.w400 : FontWeight.w600)),
                                      const SizedBox(height: 4),
                                      Text(_fmt(n.createdAt), textDirection: TextDirection.ltr, style: Theme.of(context).textTheme.bodySmall),
                                    ]),
                                  ),
                                ]),
                              ),
                            );
                          },
                        ),
                      ),
      ),
    ]);
  }
}
