import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/money.dart";
import "../../core/strings.dart";
import "../../core/widgets/dialogs.dart";
import "../../core/widgets/widgets.dart";
import "../../state/auth_state.dart";
import "../corrections/correction_request_page.dart";

/// Document detail with role-aware actions:
/// * owner: submit/cancel a draft, cancel a submitted document, request a correction
/// * reviewer (never on own document): start review, approve, reject (reason required)
/// Every action calls the same service-checked API endpoint; the buttons only mirror what the
/// server will allow, the server remains the authority.
class DocumentDetailPage extends StatefulWidget {
  const DocumentDetailPage({super.key, required this.docId});
  final int docId;
  @override
  State<DocumentDetailPage> createState() => _DocumentDetailPageState();
}

class _DocumentDetailPageState extends State<DocumentDetailPage> {
  DocDetail? _doc;
  List<HistoryEvent> _history = [];
  String? _error;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    final api = context.read<ApiClient>();
    try {
      final d = await api.document(widget.docId);
      final h = await api.history(widget.docId);
      if (mounted) {
        setState(() {
          _doc = d;
          _history = h;
        });
      }
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    }
  }

  /// Runs an action, then reloads detail + history so the screen never shows stale state.
  Future<void> _act(Future<void> Function(ApiClient api) fn, {String? done}) async {
    setState(() => _busy = true);
    try {
      await fn(context.read<ApiClient>());
      if (done != null && mounted) showMessage(context, done);
      await _load();
    } on ApiException catch (e) {
      if (mounted) {
        showMessage(context, e.message);
        if (e.status == 409 || e.status == 412) await _load(); // concurrent change: refresh
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = _doc;
    final me = context.watch<AuthState>().me!;
    return Scaffold(
      appBar: AppBar(title: Text(d?.summary.docNumber ?? "")),
      body: _error != null
          ? ErrorView(message: _error!, onRetry: _load)
          : d == null
              ? const LoadingView()
              : RefreshIndicator(
                  color: T.accent,
                  onRefresh: _load,
                  child: ListView(padding: const EdgeInsets.all(T.lg), children: [
                    _header(d),
                    if (d.decisionNote != null && d.decisionNote!.isNotEmpty) ...[
                      const SizedBox(height: T.md),
                      AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text(S.decisionNote, style: TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: T.xs),
                        Text(d.decisionNote!),
                      ])),
                    ],
                    const SizedBox(height: T.md),
                    _lines(d),
                    if (d.attachments.isNotEmpty) ...[const SizedBox(height: T.md), _attachments(d)],
                    const SizedBox(height: T.md),
                    _timeline(),
                    ..._actions(d, me),
                    const SizedBox(height: T.xl),
                  ]),
                ),
    );
  }

  // ------------------------------------------------------------------ actions
  List<Widget> _actions(DocDetail d, Me me) {
    final st = d.summary.status;
    final own = d.summary.employeeId == me.id;
    final out = <Widget>[];
    void add(Widget w) => out..add(const SizedBox(height: T.md))..add(w);

    if (own && st == "draft") {
      add(AppButton(label: S.submit, icon: Icons.send_rounded, busy: _busy, onPressed: () => _act((a) async => a.submitDocument(d.summary.id), done: "ارسال شد.")));
    }
    if (own && (st == "draft" || st == "submitted")) {
      add(AppButton(
        label: S.cancelDoc,
        primary: false,
        onPressed: _busy
            ? null
            : () async {
                final r = await askNote(context, title: S.cancelDoc, label: S.reason);
                if (r != null) await _act((a) async => a.cancelDocument(d.summary.id, r), done: "لغو شد.");
              },
      ));
    }
    // Correction: owner inside the window, or a user with the deadline-override permission.
    final canOverride = me.can("correction.override_deadline") &&
        const ["submitted", "under_review", "resubmitted", "approved"].contains(st);
    if ((own && d.correctionWindowOpen && me.can("correction.request")) || (!d.correctionWindowOpen && canOverride)) {
      add(AppButton(
        label: S.requestCorrection,
        primary: false,
        icon: Icons.edit_note_rounded,
        onPressed: _busy
            ? null
            : () async {
                final ok = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(
                        builder: (_) => CorrectionRequestPage(doc: d, needsOverride: !d.correctionWindowOpen)));
                if (ok == true) await _load();
              },
      ));
    }
    // Reviewer actions (never on the own document; the server enforces scope too).
    if (!own && me.can("document.decide")) {
      if (st == "submitted" || st == "resubmitted") {
        add(AppButton(label: S.startReview, busy: _busy, icon: Icons.fact_check_rounded, onPressed: () => _act((a) async => a.startReview(d.summary.id))));
      }
      if (st == "under_review") {
        add(Row(children: [
          Expanded(
            child: AppButton(
              label: S.reject,
              primary: false,
              onPressed: _busy
                  ? null
                  : () async {
                      final n = await askNote(context, title: S.noteRequired, label: S.reason, required: true);
                      if (n != null) await _act((a) async => a.reject(d.summary.id, n, d.rowVersion), done: "رد شد.");
                    },
            ),
          ),
          const SizedBox(width: T.md),
          Expanded(
            child: AppButton(
              label: S.approve,
              busy: _busy,
              onPressed: () async {
                final n = await askNote(context, title: S.approve);
                if (n != null) await _act((a) async => a.approve(d.summary.id, n, d.rowVersion), done: "تایید شد.");
              },
            ),
          ),
        ]));
      }
    }
    return out;
  }

  // ------------------------------------------------------------------ sections
  Widget _header(DocDetail d) => AppCard(
        dark: true,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Text(S.total, style: TextStyle(color: T.onDarkMuted, fontSize: 12)),
            const Spacer(),
            StatusChip(d.summary.status),
          ]),
          const SizedBox(height: T.sm),
          Text("${Money.display(d.summary.total)} ${d.summary.currency}",
              textDirection: TextDirection.ltr,
              style: const TextStyle(color: T.onDark, fontSize: 26, fontWeight: FontWeight.w700)),
          const SizedBox(height: T.xs),
          Text("${S.docTypes[d.summary.docType] ?? d.summary.docType}  ·  ${d.summary.purchaseDate}",
              style: const TextStyle(color: T.onDarkMuted, fontSize: 12)),
        ]),
      );

  Widget _lines(DocDetail d) => AppCard(
        child: Column(children: [
          for (final l in d.lines) ...[
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(l.description),
                  Text("${Money.display(l.quantity)} × ${Money.display(l.unitPrice)}",
                      textDirection: TextDirection.ltr, style: Theme.of(context).textTheme.bodySmall),
                ]),
              ),
              Text(Money.display(l.lineTotal), textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
            const Divider(height: T.xl),
          ],
          _kv("Subtotal", Money.display(d.subtotal)),
          _kv("Tax", Money.display(d.taxTotal)),
          _kv(S.total, "${Money.display(d.summary.total)} ${d.summary.currency}", bold: true),
        ]),
      );

  Widget _attachments(DocDetail d) => AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(S.attachments, style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: T.sm),
          for (final a in d.attachments)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                const Icon(Icons.attach_file_rounded, size: 18, color: T.textSecondary),
                const SizedBox(width: T.sm),
                Expanded(child: Text(a.name, overflow: TextOverflow.ellipsis)),
                Text("${(a.sizeBytes / 1024).round()} KB", style: Theme.of(context).textTheme.bodySmall),
              ]),
            ),
        ]),
      );

  Widget _timeline() {
    if (_history.isEmpty) return const SizedBox.shrink();
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text(S.history, style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: T.md),
        for (final e in _history)
          Padding(
            padding: const EdgeInsets.only(bottom: T.md),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                margin: const EdgeInsets.only(top: 5, left: T.sm, right: T.sm),
                width: 10,
                height: 10,
                decoration: BoxDecoration(color: T.statusColor(e.payload["to"] as String? ?? ""), shape: BoxShape.circle),
              ),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(e.action == "document.status_changed"
                      ? "${S.status(e.payload["from"] as String? ?? "")} ← ${S.status(e.payload["to"] as String? ?? "")}"
                      : S.action(e.action)),
                  if ((e.payload["note"] as String? ?? "").isNotEmpty)
                    Text(e.payload["note"] as String, style: Theme.of(context).textTheme.bodySmall),
                  Text(_fmt(e.timestamp), textDirection: TextDirection.ltr, style: Theme.of(context).textTheme.bodySmall),
                ]),
              ),
            ]),
          ),
      ]),
    );
  }

  String _fmt(DateTime t) {
    final l = t.toLocal();
    String p(int n) => n.toString().padLeft(2, "0");
    return "${l.year}-${p(l.month)}-${p(l.day)} ${p(l.hour)}:${p(l.minute)}";
  }

  Widget _kv(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Text(k, style: TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w400)),
          const Spacer(),
          Text(v, textDirection: TextDirection.ltr, style: TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w400)),
        ]),
      );
}
