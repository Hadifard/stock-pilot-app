import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/money.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";
import "../corrections/corrections_page.dart";
import "../documents/document_detail_page.dart";

/// Approval inbox for roles that can decide (manager, project manager, admin): documents waiting
/// for a decision and pending correction requests. The server scopes both lists to what the
/// caller may see and decide.
class ReviewQueuePage extends StatefulWidget {
  const ReviewQueuePage({super.key});
  @override
  State<ReviewQueuePage> createState() => ReviewQueuePageState();
}

class ReviewQueuePageState extends State<ReviewQueuePage> {
  int _seg = 0;
  List<DocSummary> _items = [];
  bool _loading = true;
  String? _error;
  int _corrKey = 0;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    setState(() {
      _loading = true;
      _error = null;
      _corrKey++;
    });
    try {
      final r = await context.read<ApiClient>().reviewQueue();
      if (mounted) setState(() => _items = r.items);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(T.lg, T.lg, T.lg, T.sm),
        child: AppCard(
          dark: true,
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text(S.reviewTab, style: TextStyle(color: T.onDarkMuted, fontSize: 12)),
                const SizedBox(height: 4),
                Text("${_items.length}", style: const TextStyle(color: T.onDark, fontSize: 28, fontWeight: FontWeight.w700)),
              ]),
            ),
            const Icon(Icons.fact_check_rounded, color: T.accent, size: 32),
          ]),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: T.lg),
        child: SegmentedButton<int>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: 0, label: Text(S.myDocs)),
            ButtonSegment(value: 1, label: Text(S.corrections)),
          ],
          selected: {_seg},
          onSelectionChanged: (s) => setState(() => _seg = s.first),
          style: SegmentedButton.styleFrom(
            backgroundColor: T.surfaceLight,
            selectedBackgroundColor: T.surfaceDark,
            selectedForegroundColor: T.onDark,
            side: BorderSide.none,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(T.rControl)),
          ),
        ),
      ),
      const SizedBox(height: T.sm),
      Expanded(
        child: _seg == 1
            ? CorrectionsPage(key: ValueKey(_corrKey), pendingOnly: true, embedded: true)
            : _docs(),
      ),
    ]);
  }

  Widget _docs() {
    if (_loading && _items.isEmpty) return const LoadingView();
    if (_error != null && _items.isEmpty) return ErrorView(message: _error!, onRetry: refresh);
    if (_items.isEmpty) return const EmptyView(text: S.queueEmpty, icon: Icons.task_alt_rounded);
    return RefreshIndicator(
      color: T.accent,
      onRefresh: refresh,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(T.lg, T.sm, T.lg, T.lg),
        itemCount: _items.length,
        itemBuilder: (_, i) {
          final d = _items[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: T.md),
            child: AppCard(
              onTap: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => DocumentDetailPage(docId: d.id)));
                if (mounted) refresh();
              },
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(d.docNumber, style: const TextStyle(fontWeight: FontWeight.w700))),
                  StatusChip(d.status),
                ]),
                const SizedBox(height: T.sm),
                Row(children: [
                  Text(S.docTypes[d.docType] ?? d.docType, style: Theme.of(context).textTheme.bodySmall),
                  const Spacer(),
                  Text("${Money.display(d.total)} ${d.currency}", textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w700)),
                ]),
              ]),
            ),
          );
        },
      ),
    );
  }
}
