import "dart:async";
import "dart:convert";
import "dart:io";
import "dart:typed_data";

import "package:flutter_secure_storage/flutter_secure_storage.dart";
import "package:http/http.dart" as http;
import "package:http_parser/http_parser.dart";

import "../config.dart";
import "models.dart";

class ApiException implements Exception {
  final int status; // 0 = network/timeout
  final String code;
  final String message;
  ApiException(this.status, this.code, this.message);
  bool get isNetwork => status == 0;
  bool get isAuth => status == 401;
  @override
  String toString() => message;
}

/// Thin client for /api/v1: bearer auth, one automatic refresh on 401 (refresh tokens are
/// single-use and rotated by the server, so refreshes are serialised), structured errors.
class ApiClient {
  ApiClient({http.Client? client, FlutterSecureStorage? storage})
      : _http = client ?? http.Client(),
        _storage = storage ?? const FlutterSecureStorage();

  final http.Client _http;
  final FlutterSecureStorage _storage;
  static const _kRefresh = "refresh_token";

  String? _access;
  String? _refresh;
  Future<bool>? _refreshing;

  /// Called when the session can no longer be renewed (refresh rejected).
  void Function()? onSessionExpired;

  bool get hasSession => _refresh != null;

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    final u = Uri.parse("${AppConfig.baseUrl}$path");
    if (query == null || query.isEmpty) return u;
    final all = <String, List<String>>{};
    query.forEach((k, v) {
      if (v == null) return;
      all[k] = v is Iterable ? v.map((e) => e.toString()).toList() : [v.toString()];
    });
    return u.replace(queryParametersAll: all);
  }

  // ------------------------------------------------------------------ session
  Future<void> loadStoredSession() async {
    _refresh = await _storage.read(key: _kRefresh);
  }

  Future<bool> restoreSession() async {
    await loadStoredSession();
    if (_refresh == null) return false;
    return _doRefresh();
  }

  Future<TokenInfo> login(String username, String password) async {
    final res = await _guard(() => _http
        .post(_uri("/auth/login"), body: {"username": username, "password": password})
        .timeout(AppConfig.requestTimeout));
    final j = _decode(res) as Map<String, dynamic>;
    await _setTokens(j["access_token"] as String, j["refresh_token"] as String);
    return TokenInfo(j["must_change_password"] as bool? ?? false);
  }

  Future<void> logout() async {
    final refresh = _refresh;
    try {
      if (_access != null) {
        await _send("POST", "/auth/logout", json: refresh == null ? null : {"refresh_token": refresh}, retry: false);
      }
    } catch (_) {
      // Signing out locally must always succeed, even offline.
    }
    await clearSession();
  }

  Future<void> clearSession() async {
    _access = null;
    _refresh = null;
    await _storage.delete(key: _kRefresh);
  }

  Future<void> _setTokens(String access, String refresh) async {
    _access = access;
    _refresh = refresh;
    await _storage.write(key: _kRefresh, value: refresh);
  }

  Future<bool> _doRefresh() {
    // Single-flight: concurrent 401s share one refresh (the token is single-use).
    return _refreshing ??= () async {
      try {
        final rt = _refresh;
        if (rt == null) return false;
        final res = await _http
            .post(_uri("/auth/refresh"),
                headers: {"Content-Type": "application/json"}, body: jsonEncode({"refresh_token": rt}))
            .timeout(AppConfig.requestTimeout);
        if (res.statusCode == 200) {
          final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
          await _setTokens(j["access_token"] as String, j["refresh_token"] as String);
          return true;
        }
        if (res.statusCode == 401 || res.statusCode == 403) {
          await clearSession();
        }
        return false;
      } on SocketException {
        return false; // offline: keep the stored token, try again later
      } on TimeoutException {
        return false;
      } finally {
        _refreshing = null;
      }
    }();
  }

  // ------------------------------------------------------------------ requests
  Future<dynamic> get(String path, {Map<String, dynamic>? query}) =>
      _send("GET", path, query: query);

  Future<dynamic> postJson(String path, [Object? body, Map<String, String>? headers]) =>
      _send("POST", path, json: body, headers: headers);

  Future<dynamic> putJson(String path, Object body, {Map<String, String>? headers}) =>
      _send("PUT", path, json: body, headers: headers);

  Future<dynamic> uploadFile(String path, String filename, Uint8List bytes, String mime) {
    return _send("POST", path, upload: () {
      final req = http.MultipartRequest("POST", _uri(path));
      req.files.add(http.MultipartFile.fromBytes("file", bytes,
          filename: filename, contentType: MediaType.parse(mime)));
      return req;
    });
  }

  Future<dynamic> _send(
    String method,
    String path, {
    Map<String, dynamic>? query,
    Object? json,
    Map<String, String>? headers,
    http.MultipartRequest Function()? upload,
    bool retry = true,
  }) async {
    Future<http.Response> once() async {
      final h = <String, String>{if (_access != null) "Authorization": "Bearer $_access", ...?headers};
      if (upload != null) {
        final req = upload();
        req.headers.addAll(h);
        final streamed = await _http.send(req).timeout(AppConfig.uploadTimeout);
        return http.Response.fromStream(streamed);
      }
      final uri = _uri(path, query);
      if (json != null) h["Content-Type"] = "application/json";
      final body = json == null ? null : jsonEncode(json);
      switch (method) {
        case "GET":
          return _http.get(uri, headers: h).timeout(AppConfig.requestTimeout);
        case "PUT":
          return _http.put(uri, headers: h, body: body).timeout(AppConfig.requestTimeout);
        default:
          return _http.post(uri, headers: h, body: body).timeout(AppConfig.requestTimeout);
      }
    }

    var res = await _guard(once);
    if (res.statusCode == 401 && retry && _refresh != null) {
      final ok = await _doRefresh();
      if (ok) {
        res = await _guard(once);
      } else if (_refresh == null) {
        onSessionExpired?.call();
      }
    }
    return _decode(res);
  }

  Future<http.Response> _guard(Future<http.Response> Function() call) async {
    try {
      return await call();
    } on SocketException {
      throw ApiException(0, "network", "اتصال به سرور برقرار نشد. شبکه و آدرس API را بررسی کنید.");
    } on TimeoutException {
      throw ApiException(0, "timeout", "پاسخ سرور دیر رسید. دوباره تلاش کنید.");
    } on http.ClientException {
      throw ApiException(0, "network", "اتصال به سرور برقرار نشد.");
    }
  }

  dynamic _decode(http.Response res) {
    final text = utf8.decode(res.bodyBytes);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return text.isEmpty ? null : jsonDecode(text);
    }
    var code = "http_${res.statusCode}";
    var message = "خطای سرور (${res.statusCode})";
    try {
      final err = (jsonDecode(text) as Map<String, dynamic>)["error"] as Map<String, dynamic>;
      code = err["code"] as String? ?? code;
      message = err["message"] as String? ?? message;
      final details = err["details"];
      if (details is List && details.isNotEmpty) {
        message = "$message\n${details.map((d) => "- ${(d as Map)["loc"]}: ${d["msg"]}").join("\n")}";
      }
    } catch (_) {
      // non-JSON body (e.g. proxy error page): keep the generic message
    }
    throw ApiException(res.statusCode, code, message);
  }

  // ------------------------------------------------------------------ typed helpers
  Future<Me> me() async => Me.fromJson(await get("/auth/me") as Map<String, dynamic>);

  Future<void> changePassword(String current, String next) async {
    await postJson("/auth/change-password", {"current_password": current, "new_password": next});
    await clearSession(); // the server revokes every token on change; sign in again
  }

  Future<PageResult<T>> page<T>(
      String path, Map<String, dynamic> query, T Function(Map<String, dynamic>) parse) async {
    final j = await get(path, query: query) as Map<String, dynamic>;
    return PageResult<T>(
      (j["items"] as List).map((e) => parse(e as Map<String, dynamic>)).toList(),
      j["total"] as int,
      j["page"] as int,
      j["pages"] as int,
    );
  }

  Future<PageResult<DocSummary>> myDocuments({List<String> statuses = const [], int page = 1}) =>
      this.page("/documents", {
        "own": true,
        "page": page,
        "page_size": 20,
        "sort": "-created_at",
        if (statuses.isNotEmpty) "status": statuses,
      }, DocSummary.fromJson);

  Future<DocDetail> document(int id) async =>
      DocDetail.fromJson(await get("/documents/$id") as Map<String, dynamic>);

  Future<PageResult<RefItem>> suppliers(String q, {int page = 1}) =>
      this.page("/reference/suppliers", {"q": q, "page": page, "page_size": 30}, RefItem.supplier);
  Future<PageResult<RefItem>> projects(String q, {int page = 1}) =>
      this.page("/reference/projects", {"q": q, "page": page, "page_size": 30}, RefItem.project);
  Future<PageResult<RefItem>> costCenters({int page = 1}) =>
      this.page("/reference/cost-centers", {"page": page, "page_size": 100}, RefItem.costCenter);

  Future<DocDetail> createDraft(Map<String, dynamic> body) async =>
      DocDetail.fromJson(await postJson("/documents", body) as Map<String, dynamic>);
  Future<DocDetail> updateDraft(int id, Map<String, dynamic> body, int rowVersion) async =>
      DocDetail.fromJson(
          await putJson("/documents/$id", body, headers: {"If-Match": "$rowVersion"}) as Map<String, dynamic>);
  Future<DocDetail> submitDocument(int id) async =>
      DocDetail.fromJson(await postJson("/documents/$id/submit") as Map<String, dynamic>);

  // ------------------------------------------------------------------ part 2
  Future<List<HistoryEvent>> history(int id) async => (await get("/documents/$id/history") as List)
      .map((e) => HistoryEvent.fromJson(e as Map<String, dynamic>))
      .toList();

  Future<DocDetail> cancelDocument(int id, String reason) async =>
      DocDetail.fromJson(await postJson("/documents/$id/cancel", {"reason": reason}) as Map<String, dynamic>);

  Future<DocDetail> startReview(int id) async =>
      DocDetail.fromJson(await postJson("/documents/$id/review/start") as Map<String, dynamic>);

  Future<DocDetail> approve(int id, String note, int rowVersion) async => DocDetail.fromJson(
      await postJson("/documents/$id/approve", {"note": note}, {"If-Match": "$rowVersion"}) as Map<String, dynamic>);

  Future<DocDetail> reject(int id, String note, int rowVersion) async => DocDetail.fromJson(
      await postJson("/documents/$id/reject", {"note": note}, {"If-Match": "$rowVersion"}) as Map<String, dynamic>);

  /// Documents waiting for a decision in the caller scope (server filters by role/org/project).
  Future<PageResult<DocSummary>> reviewQueue({int page = 1}) => this.page("/documents", {
        "page": page,
        "page_size": 20,
        "sort": "submitted_at",
        "status": ["submitted", "resubmitted", "under_review"],
      }, DocSummary.fromJson);

  Future<Correction> requestCorrection(int docId,
          {required Map<String, dynamic> header,
          List<Map<String, dynamic>>? lines,
          required String reason,
          String? overrideReason}) async =>
      Correction.fromJson(await postJson("/documents/$docId/corrections", {
        "header_changes": header,
        "line_changes": lines,
        "reason": reason,
        if (overrideReason != null) "override_reason": overrideReason,
      }) as Map<String, dynamic>);

  Future<PageResult<Correction>> corrections({bool pendingOnly = false, int page = 1}) =>
      this.page("/corrections", {"pending_only": pendingOnly, "page": page, "page_size": 30}, Correction.fromJson);

  Future<Correction> decideCorrection(int id, bool approve, String note) async => Correction.fromJson(
      await postJson("/corrections/$id/decision", {"approve": approve, "note": note}) as Map<String, dynamic>);

  Future<({List<NotifItem> items, int unread})> notifications() async {
    final j = await get("/notifications", query: {"limit": 50}) as Map<String, dynamic>;
    return (
      items: (j["items"] as List).map((e) => NotifItem.fromJson(e as Map<String, dynamic>)).toList(),
      unread: j["unread"] as int,
    );
  }

  Future<void> markNotificationsRead() async => postJson("/notifications/read-all");
}

class TokenInfo {
  final bool mustChangePassword;
  TokenInfo(this.mustChangePassword);
}
