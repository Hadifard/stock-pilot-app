class Me {
  final int id;
  final String username;
  final String fullName;
  final String role;
  final int orgUnitId;
  final List<String> permissions;
  final bool mustChangePassword;
  Me({
    required this.id,
    required this.username,
    required this.fullName,
    required this.role,
    required this.orgUnitId,
    required this.permissions,
    required this.mustChangePassword,
  });
  factory Me.fromJson(Map<String, dynamic> j) => Me(
        id: j["id"] as int,
        username: j["username"] as String,
        fullName: j["full_name"] as String,
        role: j["role"] as String,
        orgUnitId: j["org_unit_id"] as int,
        permissions: (j["permissions"] as List).cast<String>(),
        mustChangePassword: j["must_change_password"] as bool? ?? false,
      );
  bool can(String perm) => permissions.contains(perm);
}

class RefItem {
  final int id;
  final String label; // what the user sees
  final String? sub; // secondary text
  RefItem(this.id, this.label, [this.sub]);
  factory RefItem.supplier(Map<String, dynamic> j) =>
      RefItem(j["id"] as int, j["name"] as String, j["country"] as String?);
  factory RefItem.project(Map<String, dynamic> j) =>
      RefItem(j["id"] as int, "${j["code"]} - ${j["name"]}", null);
  factory RefItem.costCenter(Map<String, dynamic> j) =>
      RefItem(j["id"] as int, "${j["code"]} - ${j["name"]}", null);
}

class PageResult<T> {
  final List<T> items;
  final int total;
  final int page;
  final int pages;
  PageResult(this.items, this.total, this.page, this.pages);
  bool get hasMore => page < pages;
}

class DocSummary {
  final int id;
  final String docNumber;
  final String status;
  final String docType;
  final String purchaseDate;
  final String currency;
  final String total;
  final String? supplierRef;
  final int employeeId;
  final DateTime createdAt;
  DocSummary({
    required this.id,
    required this.docNumber,
    required this.status,
    required this.docType,
    required this.purchaseDate,
    required this.currency,
    required this.total,
    required this.supplierRef,
    required this.employeeId,
    required this.createdAt,
  });
  factory DocSummary.fromJson(Map<String, dynamic> j) => DocSummary(
        id: j["id"] as int,
        docNumber: j["doc_number"] as String,
        status: j["status"] as String,
        docType: j["doc_type"] as String,
        purchaseDate: j["purchase_date"] as String,
        currency: j["currency"] as String,
        total: j["total"] as String,
        supplierRef: j["supplier_ref"] as String?,
        employeeId: j["employee_id"] as int,
        createdAt: DateTime.parse(j["created_at"] as String),
      );
}

class DocLine {
  final int lineNo;
  final String description;
  final String quantity;
  final String unit;
  final String unitPrice;
  final String discountRate;
  final String taxRate; // fraction, 4 decimals
  final String category;
  final String lineTotal;
  DocLine(this.lineNo, this.description, this.quantity, this.unit, this.unitPrice, this.discountRate,
      this.taxRate, this.category, this.lineTotal);
  factory DocLine.fromJson(Map<String, dynamic> j) => DocLine(
        j["line_no"] as int,
        j["description"] as String,
        j["quantity"] as String,
        j["unit"] as String,
        j["unit_price"] as String,
        j["discount_rate"] as String,
        j["tax_rate"] as String,
        j["category"] as String,
        j["line_total"] as String,
      );

  /// Shape expected inside CorrectionIn.line_changes.
  Map<String, dynamic> toChange() => {
        "description": description,
        "quantity": quantity,
        "unit_price": unitPrice,
        "unit": unit,
        "discount_rate": discountRate,
        "tax_rate": taxRate,
        "category": category,
      };
}

class DocAttachment {
  final int id;
  final String name;
  final int sizeBytes;
  DocAttachment(this.id, this.name, this.sizeBytes);
  factory DocAttachment.fromJson(Map<String, dynamic> j) =>
      DocAttachment(j["id"] as int, j["original_name"] as String, j["size_bytes"] as int);
}

class DocDetail {
  final DocSummary summary;
  final int rowVersion;
  final String description;
  final String paymentMethod;
  final String shipping;
  final String otherCharges;
  final String subtotal;
  final String taxTotal;
  final String? decisionNote;
  final bool correctionWindowOpen;
  final DateTime? correctionDeadline;
  final List<DocLine> lines;
  final List<DocAttachment> attachments;
  DocDetail({
    required this.summary,
    required this.rowVersion,
    required this.description,
    required this.paymentMethod,
    required this.shipping,
    required this.otherCharges,
    required this.subtotal,
    required this.taxTotal,
    required this.decisionNote,
    required this.correctionWindowOpen,
    required this.correctionDeadline,
    required this.lines,
    required this.attachments,
  });
  factory DocDetail.fromJson(Map<String, dynamic> j) => DocDetail(
        summary: DocSummary.fromJson(j),
        rowVersion: j["row_version"] as int,
        description: j["description"] as String? ?? "",
        paymentMethod: j["payment_method"] as String? ?? "bank_transfer",
        shipping: j["shipping"] as String? ?? "0.0000",
        otherCharges: j["other_charges"] as String? ?? "0.0000",
        subtotal: j["subtotal"] as String,
        taxTotal: j["tax_total"] as String,
        decisionNote: j["decision_note"] as String?,
        correctionWindowOpen: j["correction_window_open"] as bool? ?? false,
        correctionDeadline:
            j["correction_deadline"] == null ? null : DateTime.parse(j["correction_deadline"] as String),
        lines: (j["lines"] as List).map((e) => DocLine.fromJson(e as Map<String, dynamic>)).toList(),
        attachments: (j["attachments"] as List)
            .map((e) => DocAttachment.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

class HistoryEvent {
  final DateTime timestamp;
  final String action;
  final Map<String, dynamic> payload;
  HistoryEvent(this.timestamp, this.action, this.payload);
  factory HistoryEvent.fromJson(Map<String, dynamic> j) => HistoryEvent(
        DateTime.parse(j["timestamp"] as String),
        j["action"] as String,
        (j["payload"] as Map).cast<String, dynamic>(),
      );
}

class Correction {
  final int id;
  final int documentId;
  final int requestedBy;
  final DateTime requestedAt;
  final String reason;
  final String status; // pending | approved | rejected
  final bool deadlineException;
  final String? exceptionReason;
  final String? decisionNote;
  final Map<String, dynamic> original; // {"input": {...}, "calculated_total": "..."}
  final Map<String, dynamic> proposed;
  Correction({
    required this.id,
    required this.documentId,
    required this.requestedBy,
    required this.requestedAt,
    required this.reason,
    required this.status,
    required this.deadlineException,
    required this.exceptionReason,
    required this.decisionNote,
    required this.original,
    required this.proposed,
  });
  factory Correction.fromJson(Map<String, dynamic> j) => Correction(
        id: j["id"] as int,
        documentId: j["document_id"] as int,
        requestedBy: j["requested_by"] as int,
        requestedAt: DateTime.parse(j["requested_at"] as String),
        reason: j["reason"] as String,
        status: j["status"] as String,
        deadlineException: j["deadline_exception"] as bool? ?? false,
        exceptionReason: j["exception_reason"] as String?,
        decisionNote: j["decision_note"] as String?,
        original: (j["original"] as Map).cast<String, dynamic>(),
        proposed: (j["proposed"] as Map).cast<String, dynamic>(),
      );

  Map<String, dynamic> get _o => (original["input"] as Map).cast<String, dynamic>();
  Map<String, dynamic> get _p => (proposed["input"] as Map).cast<String, dynamic>();

  /// Human-readable differences: header fields + total + line count/line changes.
  List<DiffRow> diff() {
    final rows = <DiffRow>[];
    for (final k in _p.keys) {
      if (k == "lines") continue;
      if ("${_o[k]}" != "${_p[k]}") rows.add(DiffRow(k, "${_o[k] ?? "-"}", "${_p[k] ?? "-"}"));
    }
    final ol = (_o["lines"] as List).cast<Map>();
    final pl = (_p["lines"] as List).cast<Map>();
    for (var i = 0; i < (ol.length > pl.length ? ol.length : pl.length); i++) {
      final a = i < ol.length ? ol[i] : null;
      final b = i < pl.length ? pl[i] : null;
      if (a == null || b == null) {
        rows.add(DiffRow("line ${i + 1}", a == null ? "-" : "${a["description"]}", b == null ? "-" : "${b["description"]}"));
        continue;
      }
      for (final f in ["description", "quantity", "unit_price", "tax_rate"]) {
        if ("${a[f]}" != "${b[f]}") rows.add(DiffRow("line ${i + 1} $f", "${a[f]}", "${b[f]}"));
      }
    }
    if ("${original["calculated_total"]}" != "${proposed["calculated_total"]}") {
      rows.add(DiffRow("total", "${original["calculated_total"]}", "${proposed["calculated_total"]}"));
    }
    return rows;
  }
}

class DiffRow {
  final String field, before, after;
  DiffRow(this.field, this.before, this.after);
}

class NotifItem {
  final int id;
  final String message;
  final int? documentId;
  final bool isRead;
  final DateTime createdAt;
  NotifItem(this.id, this.message, this.documentId, this.isRead, this.createdAt);
  factory NotifItem.fromJson(Map<String, dynamic> j) => NotifItem(
        j["id"] as int,
        j["message"] as String,
        j["document_id"] as int?,
        j["is_read"] as bool,
        DateTime.parse(j["created_at"] as String),
      );
}
