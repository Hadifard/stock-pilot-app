import "package:flutter/material.dart";

import "../design/tokens.dart";
import "../strings.dart";
import "widgets.dart";

/// Asks for a text note. Returns null when cancelled. When [required] the confirm button stays
/// disabled until something is typed.
Future<String?> askNote(BuildContext context, {required String title, String label = S.note, bool required = false}) {
  final c = TextEditingController();
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: T.pageBg,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(T.rLarge))),
    builder: (ctx) => Padding(
      padding: EdgeInsets.fromLTRB(T.lg, T.lg, T.lg, MediaQuery.of(ctx).viewInsets.bottom + T.lg),
      child: StatefulBuilder(
        builder: (ctx, setS) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(title, style: Theme.of(ctx).textTheme.titleMedium),
          const SizedBox(height: T.md),
          TextField(
            controller: c,
            maxLines: 3,
            maxLength: 2000,
            autofocus: true,
            onChanged: (_) => setS(() {}),
            decoration: InputDecoration(labelText: label, counterText: ""),
          ),
          const SizedBox(height: T.md),
          AppButton(
            label: S.confirm,
            onPressed: (required && c.text.trim().isEmpty) ? null : () => Navigator.pop(ctx, c.text.trim()),
          ),
        ]),
      ),
    ),
  );
}
