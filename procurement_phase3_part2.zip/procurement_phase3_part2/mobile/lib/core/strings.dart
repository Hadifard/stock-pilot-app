/// All user-facing text lives here so the app can be re-labelled (e.g. English) in one place.
class S {
  S._();
  static const appName = "سامانه خرید";
  static const signIn = "ورود";
  static const username = "نام کاربری";
  static const password = "گذرواژه";
  static const signOut = "خروج";
  static const myDocs = "اسناد من";
  static const newInvoice = "ثبت فاکتور";
  static const account = "حساب من";
  static const retry = "تلاش دوباره";
  static const all = "همه";
  static const noDocs = "هنوز سندی ثبت نکرده‌اید";
  static const loadFailed = "بارگذاری ناموفق بود";
  static const saveDraft = "ذخیره پیش‌نویس";
  static const submit = "ثبت و ارسال";
  static const supplier = "تامین‌کننده";
  static const project = "پروژه";
  static const costCenter = "مرکز هزینه";
  static const docType = "نوع سند";
  static const purchaseDate = "تاریخ خرید";
  static const currency = "ارز";
  static const payment = "روش پرداخت";
  static const supplierRef = "شماره فاکتور تامین‌کننده";
  static const description = "توضیحات";
  static const lines = "اقلام";
  static const addLine = "افزودن ردیف";
  static const lineDesc = "شرح کالا/خدمت";
  static const qty = "تعداد";
  static const unitPrice = "قیمت واحد";
  static const taxPct = "مالیات ٪";
  static const attachments = "پیوست‌ها";
  static const camera = "عکس";
  static const gallery = "گالری";
  static const pdfFile = "PDF";
  static const approxTotal = "جمع تقریبی (مبلغ نهایی را سرور محاسبه می‌کند)";
  static const required = "الزامی";
  static const invalidNumber = "عدد معتبر نیست";
  static const changePassword = "تغییر گذرواژه";
  static const currentPassword = "گذرواژه فعلی";
  static const newPassword = "گذرواژه جدید";
  static const mustChangePw = "برای ادامه باید گذرواژه را تغییر دهید";
  static const decisionNote = "یادداشت تصمیم";
  static const total = "مبلغ کل";
  static const history = "تاریخچه";
  static const notifications = "اعلان‌ها";
  static const noNotifications = "اعلانی ندارید";
  static const markAllRead = "همه خوانده شد";
  static const reviewTab = "تایید";
  static const queueEmpty = "سندی در انتظار تصمیم نیست";
  static const corrections = "اصلاحیه‌ها";
  static const noCorrections = "اصلاحیه‌ای وجود ندارد";
  static const requestCorrection = "درخواست اصلاحیه";
  static const reason = "دلیل";
  static const overrideReason = "توجیه استثنای مهلت";
  static const cancelDoc = "لغو سند";
  static const startReview = "شروع بررسی";
  static const approve = "تایید";
  static const reject = "رد";
  static const note = "یادداشت";
  static const noteRequired = "برای رد، نوشتن دلیل الزامی است";
  static const confirm = "تایید نهایی";
  static const back = "بازگشت";
  static const profile = "پروفایل";
  static const role = "نقش";
  static const server = "سرور";
  static const shipping = "هزینه حمل";
  static const otherCharges = "سایر هزینه‌ها";
  static const send = "ارسال";
  static const before = "قبل";
  static const after = "بعد";
  static const pending = "در انتظار";
  static const roleLabels = {
    "purchasing_employee": "کارمند خرید",
    "purchasing_manager": "مدیر خرید",
    "finance_officer": "مدیر مالی",
    "project_manager": "مدیر پروژه",
    "auditor": "ممیز",
    "administrator": "ادمین",
  };
  static const actionLabels = {
    "document.created": "سند ایجاد شد",
    "document.draft_updated": "پیش‌نویس ویرایش شد",
    "document.submitted": "سند ارسال شد",
    "document.status_changed": "تغییر وضعیت",
    "attachment.added": "پیوست اضافه شد",
    "correction.requested": "درخواست اصلاحیه",
    "correction.deadline_exception": "اصلاحیه با استثنای مهلت",
    "correction.approved": "اصلاحیه تایید شد",
    "correction.rejected": "اصلاحیه رد شد",
  };
  static String role_(String r) => roleLabels[r] ?? r;
  static String action(String a) => actionLabels[a] ?? a;

  static const statusLabels = {
    "draft": "پیش‌نویس",
    "submitted": "ارسال‌شده",
    "under_review": "در حال بررسی",
    "resubmitted": "ارسال مجدد",
    "approved": "تایید شده",
    "rejected": "رد شده",
    "cancelled": "لغو شده",
    "correction_requested": "اصلاحیه در انتظار",
  };
  static const docTypes = {
    "invoice": "فاکتور",
    "receipt": "رسید",
    "quotation": "پیش‌فاکتور",
    "purchase_request": "درخواست خرید",
  };
  static const paymentMethods = {
    "bank_transfer": "انتقال بانکی",
    "credit_card": "کارت اعتباری",
    "cash": "نقدی",
    "purchase_order": "سفارش خرید",
  };
  static String status(String s) => statusLabels[s] ?? s;
}
