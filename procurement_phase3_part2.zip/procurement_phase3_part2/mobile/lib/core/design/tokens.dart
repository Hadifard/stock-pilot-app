import "package:flutter/material.dart";

/// Mirrors design/tokens.json (shared with the web portal). Change both together.
class T {
  T._();
  static const pageBg = Color(0xFFEEF0F3);
  static const surfaceDark = Color(0xFF1E2530);
  static const surfaceLight = Color(0xFFF7F8FA);
  static const onDark = Color(0xFFE7E9EC);
  static const onDarkMuted = Color(0xFFA9B0BA);
  static const textPrimary = Color(0xFF1E2530);
  static const textSecondary = Color(0xFF6B7380);
  static const border = Color(0xFFE1E4E9);
  static const accent = Color(0xFFFF7A33);
  static const accentPressed = Color(0xFFE8651F);
  static const success = Color(0xFF2E9E6B);
  static const warning = Color(0xFFC98A12);
  static const danger = Color(0xFFD64545);
  static const info = Color(0xFF4A6FA5);
  static const neutral = Color(0xFF8A93A0);

  static const rControl = 16.0;
  static const rCard = 18.0;
  static const rLarge = 20.0;

  static const xs = 4.0, sm = 8.0, md = 12.0, lg = 16.0, xl = 24.0, xxl = 32.0;

  /// One soft, wide shadow used under every card and button.
  static const softShadow = [
    BoxShadow(color: Color(0x141E2530), blurRadius: 24, offset: Offset(0, 8)),
  ];

  static Color statusColor(String status) {
    switch (status) {
      case "approved":
        return success;
      case "rejected":
        return danger;
      case "under_review":
      case "resubmitted":
      case "correction_requested":
        return warning;
      case "submitted":
        return info;
      default:
        return neutral; // draft, cancelled, unknown
    }
  }
}
