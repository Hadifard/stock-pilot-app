# فاز ۳ - زیربخش ۱: Design system + اپ Flutter (ورود، ثبت فاکتور، پیگیری اسناد)

## محتویات
```
design/tokens.json, tokens.css     منبع واحد هویت بصری (موبایل و پورتال وب هر دو از همین‌ها)
mobile/                            پروژه Flutter (lib/, test/, pubspec.yaml)
```
بک‌اند فاز ۲ **دست نخورده** است؛ این بسته فقط کلاینت است.

## چیزهایی که ساخته شد
- **Design system**: پالت (زمینه #EEF0F3، کارت تیره #1E2530، کارت روشن #F7F8FA، تاکید نارنجی #FF7A33 فقط روی دکمه اصلی/آیکون برند/ناوبری انتخاب‌شده)، شعاع ۱۶/۱۸/۲۰، یک سایه نرم یکسان زیر کارت‌ها و دکمه‌ها. ویجت‌ها: `AppCard(dark:)`، `AppButton`، `StatusChip`، فیلد انتخاب جست‌وجوپذیر، حالت‌های loading/error/empty.
- **ورود** (OAuth2 password)، ذخیره refresh token در secure storage، تمدید خودکار توکن روی 401 (single-flight چون refresh token یک‌بارمصرف است)، خروج، صفحه‌ی تغییر گذرواژه‌ی اجباری (`must_change_password`).
- **ثبت فاکتور**: تامین‌کننده/پروژه (جست‌وجو)، مرکز هزینه، نوع سند، ارز، تاریخ، روش پرداخت، چند ردیف، پیوست عکس (دوربین/گالری) یا PDF، جمع تقریبی. جریان: ساخت پیش‌نویس ← آپلود پیوست‌ها ← ارسال. اگر وسط راه خطا شد، پیش‌نویس حفظ می‌شود و تلاش مجدد **سند تکراری نمی‌سازد**.
- **اسناد من**: فقط اسناد خود کاربر (`own=true`)، فیلتر وضعیت، pull-to-refresh، صفحه‌بندی، جزئیات سند (ردیف‌ها، پیوست‌ها، یادداشت تصمیم) و ارسال پیش‌نویس.

## نکات مهم قرارداد با API (از کد بک‌اند خوانده شد)
- مبالغ فقط رشته‌ی ۴ رقم اعشار ارسال می‌شوند؛ نرخ مالیات **کسر** است (۱۹٪ ← `0.1900`) و فرم، درصد می‌گیرد و تبدیل می‌کند. حداکثر مالیات ۵۰٪، تاریخ خرید نباید آینده باشد، «توضیحات» الزامی است (همه در فرم اعمال شده‌اند).
- پیوست فقط PDF/PNG/JPG و محتوا باید با پسوند بخواند؛ نوع فایل از روی بایت‌ها تشخیص داده می‌شود (HEIC/WebP پیش از ارسال با پیام روشن رد می‌شود).
- ورودی عددی مبهم مثل `1,500` عمداً رد می‌شود (۱٫۵ یا ۱۵۰۰؟) تا مبلغ اشتباه ثبت نشود.

## اجرا
۱. بک‌اند را طوری بالا بیاورید که از موبایل دیده شود: `uvicorn app.api.main:app --host 0.0.0.0 --port 8000` (فایروال پورت ۸۰۰۰ را باز کنید).
۲. داخل `mobile/` یک‌بار پوشه‌های پلتفرم را بسازید (این بسته android/ios ندارد):
   `flutter create . --org com.example --project-name procurement_mobile --platforms android,ios`
   (فایل‌های `lib/` و `pubspec.yaml` را بازنویسی نمی‌کند؛ اگر پرسید، نگه‌دارید.)
۳. دسترسی‌ها:
   - Android `android/app/src/main/AndroidManifest.xml`: `<uses-permission android:name="android.permission.INTERNET"/>`، `<uses-permission android:name="android.permission.CAMERA"/>` و برای HTTP محلی در برچسب `<application>`: `android:usesCleartextTraffic="true"` (فقط دمو؛ در تولید HTTPS).
   - iOS `ios/Runner/Info.plist`: `NSCameraUsageDescription`، `NSPhotoLibraryUsageDescription` و برای HTTP محلی `NSAppTransportSecurity` ← `NSAllowsLocalNetworking`=true.
   - Android: `minSdkVersion` را برای flutter_secure_storage روی ۲۱ یا بالاتر بگذارید (معمولاً پیش‌فرض است).
۴. اجرا: `flutter pub get` سپس
   `flutter run --dart-define=API_BASE_URL=http://<IP-لپ‌تاپ>:8000/api/v1`
   (امولاتور اندروید: پیش‌فرض `10.0.2.2` کافی است.)
۵. ورود با `employee.demo` و گذرواژه‌ی `PROCUREMENT_DEMO_PASSWORD` از `.env` بک‌اند.
۶. تست واحد: `flutter test` (کد Flutter حداقل ۳٫۲۷ لازم است).

## فونت
پیش‌فرض فونت سیستم است. برای Vazirmatn فایل‌های ttf را در `assets/fonts/` بگذارید و بخش کامنت‌شده‌ی `pubspec.yaml` را فعال کنید، سپس در `theme.dart` مقدار `fontFamily: "Vazirmatn"` را بدهید. تاریخ‌ها میلادی (ISO) هستند چون API همین را می‌گیرد.

## صادقانه: چه چیزی تست شده و چه چیزی نه
- **اجرا نشده**: Flutter SDK، امولاتور و دستگاه واقعی در این محیط نیست؛ بنابراین هیچ‌یک از کدهای Dart **کامپایل یا اجرا نشده‌اند** (نه `flutter analyze` نه `flutter test`). کد با بازخوانی دقیق نوشته شده، ولی ممکن است هشدار/خطای کوچک کامپایل (مثلاً deprecation در `DropdownButtonFormField.value` روی Flutter جدیدتر) داشته باشد. لطفاً اول `flutter analyze` و `flutter test` را بزنید و خروجی را برایم بفرستید.
- **بررسی شد**: منطق تبدیل/اعتبارسنجی مبلغ و درصد (`money.dart`) با پورت JavaScript خط‌به‌خط و ۲۰ حالت (همان مقادیر `test/money_test.dart`) اجرا و همگی درست بود. این تست خود Dart نیست، فقط الگوریتم را تایید می‌کند.
- **بک‌اند اجرا نشد**: محیط اینترنت ندارد و وابستگی‌های FastAPI نصب نیست؛ بنابراین ارتباط واقعی اپ با API امتحان نشده. قرارداد (نام فیلدها، نوع‌ها، قوانین اعتبارسنجی، refresh) از روی `schemas.py`، routerها و `validation_service.py` تطبیق داده شد.
- **هنوز نیست** (زیربخش ۲): اصلاحیه‌ها، اعلان/پیام، پروفایل کامل، تاریخچه‌ی سند، لغو سند، تایید برای نقش‌های مدیریتی، صیقل نهایی UI. API پیام/اعلان جدا ندارد؛ آنچه موجود است وضعیت اسناد و اصلاحیه‌هاست و در زیربخش ۲ بر همان پایه ساخته می‌شود.

## یادداشت برای پورتال وب (زیربخش ۳)
CORS بک‌اند فقط هدرهای `Authorization` و `Content-Type` را مجاز می‌کند و `If-Match` را نه؛ مرورگر درخواست‌های approve/reject با `If-Match` را مسدود می‌کند. دو راه: پورتال بدون `If-Match` کار کند (مجاز است) یا یک تغییر یک‌خطی در `app/api/main.py` (افزودن `If-Match` به `allow_headers`). همچنین `PROCUREMENT_CORS_ORIGINS` باید آدرس پورتال را داشته باشد. این را در زیربخش ۳ با توضیح انجام می‌دهم.
