/// Decimal helpers. Money is exchanged with the API as strings with at most 4 decimals;
/// floats are never sent. The on-screen total is only a preview (double); the server calculates
/// the authoritative totals.
class Money {
  Money._();

  /// Persian/Arabic digits -> ASCII; Arabic decimal separator -> "."; thousands separators and
  /// spaces removed. A plain comma is kept (it is ambiguous) and resolved in [canonical].
  static String normalize(String input) {
    const fa = "۰۱۲۳۴۵۶۷۸۹";
    const ar = "٠١٢٣٤٥٦٧٨٩";
    final b = StringBuffer();
    for (final ch in input.trim().split("")) {
      final i = fa.indexOf(ch);
      final j = ar.indexOf(ch);
      if (i >= 0) {
        b.write(i);
      } else if (j >= 0) {
        b.write(j);
      } else if (ch == "٫") {
        b.write(".");
      } else if (ch == "،") {
        b.write(",");
      } else if (ch == " " || ch == "٬" || ch == "\u200c") {
        continue;
      } else {
        b.write(ch);
      }
    }
    return b.toString();
  }

  /// ASCII decimal string with "." or null. A comma is accepted as a decimal separator only when
  /// it is the single separator and not followed by exactly 3 digits ("12,5" ok; "1,500" is
  /// ambiguous between 1.5 and 1500 and is rejected instead of guessed).
  static String? canonical(String input) {
    var s = normalize(input);
    if (s.contains(",")) {
      final parts = s.split(",");
      if (s.contains(".") || parts.length != 2 || parts[1].isEmpty || parts[1].length == 3) {
        return null;
      }
      s = "${parts[0]}.${parts[1]}";
    }
    return s;
  }

  static final _re = RegExp(r"^\d+(\.\d{1,4})?$");

  /// Canonical 4-decimal string (e.g. "12.5000") or null when the input is not a valid
  /// non-negative decimal with at most 4 decimals.
  static String? parse(String input) {
    final s = canonical(input);
    if (s == null || !_re.hasMatch(s)) return null;
    final parts = s.split(".");
    final frac = (parts.length > 1 ? parts[1] : "").padRight(4, "0");
    final whole = parts[0].replaceFirst(RegExp(r"^0+(?=\d)"), "");
    return "$whole.$frac";
  }

  /// Percent typed by the user (<= 2 decimals) -> fraction string with 4 decimals, as the API
  /// expects ("19" -> "0.1900", "7.5" -> "0.0750"). Empty means 0. Returns null when invalid
  /// or above 100.
  static String? percentToFraction(String input) {
    final s = canonical(input.trim().isEmpty ? "0" : input);
    if (s == null || !RegExp(r"^\d+(\.\d{1,2})?$").hasMatch(s)) return null;
    final parts = s.split(".");
    final frac2 = (parts.length > 1 ? parts[1] : "").padRight(2, "0");
    final hundredths = BigInt.parse(parts[0]) * BigInt.from(100) + BigInt.parse(frac2);
    if (hundredths > BigInt.from(10000)) return null;
    final text = hundredths.toString().padLeft(5, "0"); // = fraction in units of 1e-4
    final intPart = text.substring(0, text.length - 4);
    final fracPart = text.substring(text.length - 4);
    return "${BigInt.parse(intPart)}.$fracPart";
  }

  static double toDouble(String? v) => double.tryParse(v ?? "") ?? 0;

  /// "1234567.8900" -> "1,234,567.89"
  static String display(String? v, {int decimals = 2}) {
    final d = double.tryParse(v ?? "");
    if (d == null) return v ?? "-";
    return group(d, decimals);
  }

  static String group(double d, int decimals) {
    final fixed = d.toStringAsFixed(decimals);
    final parts = fixed.split(".");
    final neg = parts[0].startsWith("-");
    final digits = neg ? parts[0].substring(1) : parts[0];
    final b = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) b.write(",");
      b.write(digits[i]);
    }
    return "${neg ? "-" : ""}$b${parts.length > 1 ? ".${parts[1]}" : ""}";
  }
}
