import "dart:async";

import "package:flutter/material.dart";

import "../api/api_client.dart";
import "../api/models.dart";
import "../design/tokens.dart";
import "../strings.dart";

typedef RefLoader = Future<PageResult<RefItem>> Function(String query);

/// Form field that opens a searchable bottom sheet (suppliers/projects can be long lists).
class RefPickerField extends FormField<RefItem> {
  RefPickerField({
    super.key,
    required String label,
    required RefLoader loader,
    required ValueChanged<RefItem?> onChanged,
    RefItem? initial,
  }) : super(
          initialValue: initial,
          validator: (v) => v == null ? S.required : null,
          builder: (state) {
            final ctx = state.context;
            return InkWell(
              borderRadius: BorderRadius.circular(T.rControl),
              onTap: () async {
                final picked = await showModalBottomSheet<RefItem>(
                  context: ctx,
                  isScrollControlled: true,
                  backgroundColor: T.pageBg,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.vertical(top: Radius.circular(T.rLarge))),
                  builder: (_) => _PickerSheet(title: label, loader: loader),
                );
                if (picked != null) {
                  state.didChange(picked);
                  onChanged(picked);
                }
              },
              child: InputDecorator(
                decoration: InputDecoration(
                  labelText: label,
                  errorText: state.errorText,
                  suffixIcon: const Icon(Icons.keyboard_arrow_down_rounded),
                ),
                child: Text(
                  state.value?.label ?? "",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            );
          },
        );
}

class _PickerSheet extends StatefulWidget {
  const _PickerSheet({required this.title, required this.loader});
  final String title;
  final RefLoader loader;
  @override
  State<_PickerSheet> createState() => _PickerSheetState();
}

class _PickerSheetState extends State<_PickerSheet> {
  List<RefItem> items = [];
  bool loading = true;
  String? error;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _load("");
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  Future<void> _load(String q) async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = await widget.loader(q);
      if (!mounted) return;
      setState(() {
        items = r.items;
        loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.message;
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(bottom: bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.7,
        child: Column(children: [
          const SizedBox(height: T.md),
          Container(width: 40, height: 4, decoration: BoxDecoration(color: T.border, borderRadius: BorderRadius.circular(4))),
          Padding(
            padding: const EdgeInsets.all(T.lg),
            child: TextField(
              decoration: InputDecoration(hintText: widget.title, prefixIcon: const Icon(Icons.search_rounded)),
              onChanged: (v) {
                _debounce?.cancel();
                _debounce = Timer(const Duration(milliseconds: 300), () => _load(v.trim()));
              },
            ),
          ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator(color: T.accent))
                : error != null
                    ? Center(child: Text(error!))
                    : ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: T.lg),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const Divider(),
                        itemBuilder: (_, i) => ListTile(
                          title: Text(items[i].label),
                          subtitle: items[i].sub == null ? null : Text(items[i].sub!),
                          onTap: () => Navigator.pop(context, items[i]),
                        ),
                      ),
          ),
        ]),
      ),
    );
  }
}
