import "package:flutter/material.dart";

import "../design/tokens.dart";
import "../strings.dart";

/// Two-level hierarchy: [dark] for prominent cards (headers, KPI), light for normal content.
class AppCard extends StatelessWidget {
  const AppCard({
    super.key,
    required this.child,
    this.dark = false,
    this.padding = const EdgeInsets.all(T.lg),
    this.onTap,
    this.margin,
  });
  final Widget child;
  final bool dark;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    final content = Padding(padding: padding, child: child);
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        color: dark ? T.surfaceDark : T.surfaceLight,
        borderRadius: BorderRadius.circular(T.rCard),
        boxShadow: T.softShadow,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(T.rCard),
        child: onTap == null
            ? content
            : InkWell(borderRadius: BorderRadius.circular(T.rCard), onTap: onTap, child: content),
      ),
    );
  }
}

/// Primary = orange accent (use sparingly: one per screen). Secondary = dark outline.
class AppButton extends StatelessWidget {
  const AppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.primary = true,
    this.busy = false,
    this.icon,
  });
  final String label;
  final VoidCallback? onPressed;
  final bool primary;
  final bool busy;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !busy;
    final bg = primary ? (enabled ? T.accent : T.accent.withValues(alpha: 0.45)) : Colors.white;
    final fg = primary ? Colors.white : T.textPrimary;
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(T.rControl),
        border: primary ? null : Border.all(color: T.border),
        boxShadow: enabled ? T.softShadow : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(T.rControl),
          onTap: enabled ? onPressed : null,
          child: Center(
            child: busy
                ? SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2.4, color: fg),
                  )
                : Row(mainAxisSize: MainAxisSize.min, children: [
                    if (icon != null) ...[Icon(icon, size: 20, color: fg), const SizedBox(width: 8)],
                    Text(label, style: TextStyle(color: fg, fontSize: 15, fontWeight: FontWeight.w600)),
                  ]),
          ),
        ),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  const StatusChip(this.status, {super.key});
  final String status;
  @override
  Widget build(BuildContext context) {
    final c = T.statusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(S.status(status), style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});
  @override
  Widget build(BuildContext context) =>
      const Center(child: CircularProgressIndicator(color: T.accent));
}

class ErrorView extends StatelessWidget {
  const ErrorView({super.key, required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(T.xl),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.cloud_off_rounded, size: 44, color: T.neutral),
            const SizedBox(height: T.md),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: T.lg),
            SizedBox(width: 180, child: AppButton(label: S.retry, onPressed: onRetry, primary: false)),
          ]),
        ),
      );
}

class EmptyView extends StatelessWidget {
  const EmptyView({super.key, required this.text, this.icon = Icons.receipt_long_rounded});
  final String text;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 48, color: T.neutral),
          const SizedBox(height: T.md),
          Text(text, style: Theme.of(context).textTheme.bodySmall),
        ]),
      );
}

void showMessage(BuildContext context, String text) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text)));
}
