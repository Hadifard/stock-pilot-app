/// All user-facing text lives here so the app can be re-labelled (e.g. English) in one place.
class S {
  S._();
  static const appName = "سامانه خرید";
  static const signIn = "ورود";
  static const username = "نام کاربری";
  static const password = "گذرواژه";
  static const signOut = "خروج";
  static const myDocs = "اسناد من";
  static const newInvoice = "ثبت فاکتور";
  static const account = "حساب من";
  static const retry = "تلاش دوباره";
  static const all = "همه";
  static const noDocs = "هنوز سندی ثبت نکرده‌اید";
  static const loadFailed = "بارگذاری ناموفق بود";
  static const saveDraft = "ذخیره پیش‌نویس";
  static const submit = "ثبت و ارسال";
  static const supplier = "تامین‌کننده";
  static const project = "پروژه";
  static const costCenter = "مرکز هزینه";
  static const docType = "نوع سند";
  static const purchaseDate = "تاریخ خرید";
  static const currency = "ارز";
  static const payment = "روش پرداخت";
  static const supplierRef = "شماره فاکتور تامین‌کننده";
  static const description = "توضیحات";
  static const lines = "اقلام";
  static const addLine = "افزودن ردیف";
  static const lineDesc = "شرح کالا/خدمت";
  static const qty = "تعداد";
  static const unitPrice = "قیمت واحد";
  static const taxPct = "مالیات ٪";
  static const attachments = "پیوست‌ها";
  static const camera = "عکس";
  static const gallery = "گالری";
  static const pdfFile = "PDF";
  static const approxTotal = "جمع تقریبی (مبلغ نهایی را سرور محاسبه می‌کند)";
  static const required = "الزامی";
  static const invalidNumber = "عدد معتبر نیست";
  static const changePassword = "تغییر گذرواژه";
  static const currentPassword = "گذرواژه فعلی";
  static const newPassword = "گذرواژه جدید";
  static const mustChangePw = "برای ادامه باید گذرواژه را تغییر دهید";
  static const decisionNote = "یادداشت تصمیم";
  static const total = "مبلغ کل";

  static const statusLabels = {
    "draft": "پیش‌نویس",
    "submitted": "ارسال‌شده",
    "under_review": "در حال بررسی",
    "resubmitted": "ارسال مجدد",
    "approved": "تایید شده",
    "rejected": "رد شده",
    "cancelled": "لغو شده",
  };
  static const docTypes = {
    "invoice": "فاکتور",
    "receipt": "رسید",
    "quotation": "پیش‌فاکتور",
    "purchase_request": "درخواست خرید",
  };
  static const paymentMethods = {
    "bank_transfer": "انتقال بانکی",
    "credit_card": "کارت اعتباری",
    "cash": "نقدی",
    "purchase_order": "سفارش خرید",
  };
  static String status(String s) => statusLabels[s] ?? s;
}
