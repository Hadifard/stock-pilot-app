/// API address. Override at build/run time:
///   flutter run --dart-define=API_BASE_URL=http://192.168.1.20:8000/api/v1
/// Android emulator reaches the host machine at 10.0.2.2; a real phone needs the laptop LAN IP
/// (and the API started with --host 0.0.0.0).
class AppConfig {
  static const baseUrl = String.fromEnvironment(
    "API_BASE_URL",
    defaultValue: "http://10.0.2.2:8000/api/v1",
  );
  static const requestTimeout = Duration(seconds: 30);
  static const uploadTimeout = Duration(seconds: 90);
}
