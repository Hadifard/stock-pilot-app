class Me {
  final int id;
  final String username;
  final String fullName;
  final String role;
  final int orgUnitId;
  final List<String> permissions;
  final bool mustChangePassword;
  Me({
    required this.id,
    required this.username,
    required this.fullName,
    required this.role,
    required this.orgUnitId,
    required this.permissions,
    required this.mustChangePassword,
  });
  factory Me.fromJson(Map<String, dynamic> j) => Me(
        id: j["id"] as int,
        username: j["username"] as String,
        fullName: j["full_name"] as String,
        role: j["role"] as String,
        orgUnitId: j["org_unit_id"] as int,
        permissions: (j["permissions"] as List).cast<String>(),
        mustChangePassword: j["must_change_password"] as bool? ?? false,
      );
  bool can(String perm) => permissions.contains(perm);
}

class RefItem {
  final int id;
  final String label; // what the user sees
  final String? sub; // secondary text
  RefItem(this.id, this.label, [this.sub]);
  factory RefItem.supplier(Map<String, dynamic> j) =>
      RefItem(j["id"] as int, j["name"] as String, j["country"] as String?);
  factory RefItem.project(Map<String, dynamic> j) =>
      RefItem(j["id"] as int, "${j["code"]} - ${j["name"]}", null);
  factory RefItem.costCenter(Map<String, dynamic> j) =>
      RefItem(j["id"] as int, "${j["code"]} - ${j["name"]}", null);
}

class PageResult<T> {
  final List<T> items;
  final int total;
  final int page;
  final int pages;
  PageResult(this.items, this.total, this.page, this.pages);
  bool get hasMore => page < pages;
}

class DocSummary {
  final int id;
  final String docNumber;
  final String status;
  final String docType;
  final String purchaseDate;
  final String currency;
  final String total;
  final String? supplierRef;
  final DateTime createdAt;
  DocSummary({
    required this.id,
    required this.docNumber,
    required this.status,
    required this.docType,
    required this.purchaseDate,
    required this.currency,
    required this.total,
    required this.supplierRef,
    required this.createdAt,
  });
  factory DocSummary.fromJson(Map<String, dynamic> j) => DocSummary(
        id: j["id"] as int,
        docNumber: j["doc_number"] as String,
        status: j["status"] as String,
        docType: j["doc_type"] as String,
        purchaseDate: j["purchase_date"] as String,
        currency: j["currency"] as String,
        total: j["total"] as String,
        supplierRef: j["supplier_ref"] as String?,
        createdAt: DateTime.parse(j["created_at"] as String),
      );
}

class DocLine {
  final int lineNo;
  final String description;
  final String quantity;
  final String unitPrice;
  final String lineTotal;
  DocLine(this.lineNo, this.description, this.quantity, this.unitPrice, this.lineTotal);
  factory DocLine.fromJson(Map<String, dynamic> j) => DocLine(
        j["line_no"] as int,
        j["description"] as String,
        j["quantity"] as String,
        j["unit_price"] as String,
        j["line_total"] as String,
      );
}

class DocAttachment {
  final int id;
  final String name;
  final int sizeBytes;
  DocAttachment(this.id, this.name, this.sizeBytes);
  factory DocAttachment.fromJson(Map<String, dynamic> j) =>
      DocAttachment(j["id"] as int, j["original_name"] as String, j["size_bytes"] as int);
}

class DocDetail {
  final DocSummary summary;
  final int rowVersion;
  final String description;
  final String subtotal;
  final String taxTotal;
  final String? decisionNote;
  final List<DocLine> lines;
  final List<DocAttachment> attachments;
  DocDetail({
    required this.summary,
    required this.rowVersion,
    required this.description,
    required this.subtotal,
    required this.taxTotal,
    required this.decisionNote,
    required this.lines,
    required this.attachments,
  });
  factory DocDetail.fromJson(Map<String, dynamic> j) => DocDetail(
        summary: DocSummary.fromJson(j),
        rowVersion: j["row_version"] as int,
        description: j["description"] as String? ?? "",
        subtotal: j["subtotal"] as String,
        taxTotal: j["tax_total"] as String,
        decisionNote: j["decision_note"] as String?,
        lines: (j["lines"] as List).map((e) => DocLine.fromJson(e as Map<String, dynamic>)).toList(),
        attachments: (j["attachments"] as List)
            .map((e) => DocAttachment.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}
