import "dart:typed_data";

/// The server accepts PDF, PNG and JPG and verifies the content against the extension, so the
/// type is derived from the file bytes (not the picker name): HEIC/WebP photos are rejected here
/// with a clear message instead of a server 400.
class DetectedFile {
  final String ext; // ".pdf" | ".png" | ".jpg"
  final String mime;
  const DetectedFile(this.ext, this.mime);
}

const maxUploadBytes = 10 * 1024 * 1024; // server default; the server remains the authority

DetectedFile? detectFile(Uint8List b) {
  bool starts(List<int> sig) {
    if (b.length < sig.length) return false;
    for (var i = 0; i < sig.length; i++) {
      if (b[i] != sig[i]) return false;
    }
    return true;
  }

  if (starts([0x25, 0x50, 0x44, 0x46, 0x2D])) return const DetectedFile(".pdf", "application/pdf");
  if (starts([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])) return const DetectedFile(".png", "image/png");
  if (starts([0xFF, 0xD8, 0xFF])) return const DetectedFile(".jpg", "image/jpeg");
  return null;
}

String baseName(String path) {
  final n = path.replaceAll("\\", "/").split("/").last;
  final dot = n.lastIndexOf(".");
  return dot > 0 ? n.substring(0, dot) : n;
}
