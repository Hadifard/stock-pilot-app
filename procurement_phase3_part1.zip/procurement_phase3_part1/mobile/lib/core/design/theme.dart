import "package:flutter/material.dart";
import "tokens.dart";

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: T.accent, brightness: Brightness.light).copyWith(
    primary: T.accent,
    onPrimary: Colors.white,
    surface: T.surfaceLight,
    onSurface: T.textPrimary,
    error: T.danger,
  );
  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(T.rControl),
        borderSide: BorderSide(color: c, width: w),
      );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    // Set fontFamily: "Vazirmatn" after bundling the font (see pubspec.yaml).
    scaffoldBackgroundColor: T.pageBg,
    canvasColor: T.pageBg,
    textTheme: const TextTheme(
      headlineSmall: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: T.textPrimary),
      titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: T.textPrimary),
      bodyMedium: TextStyle(fontSize: 14, color: T.textPrimary, height: 1.5),
      bodySmall: TextStyle(fontSize: 12, color: T.textSecondary),
      labelLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: T.pageBg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      foregroundColor: T.textPrimary,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: border(T.border),
      enabledBorder: border(T.border),
      focusedBorder: border(T.accent, 1.6),
      errorBorder: border(T.danger),
      focusedErrorBorder: border(T.danger, 1.6),
      labelStyle: const TextStyle(color: T.textSecondary),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: T.surfaceDark,
      contentTextStyle: const TextStyle(color: T.onDark),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(T.rControl)),
    ),
    dividerTheme: const DividerThemeData(color: T.border, space: 1),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: T.surfaceDark,
      indicatorColor: T.accent,
      height: 68,
      labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 11, color: T.onDark)),
      iconTheme: WidgetStateProperty.resolveWith(
        (s) => IconThemeData(color: s.contains(WidgetState.selected) ? Colors.white : T.onDarkMuted),
      ),
    ),
  );
}
