import "package:flutter/foundation.dart";

import "../core/api/api_client.dart";
import "../core/api/models.dart";

enum AuthStatus { unknown, signedOut, mustChangePassword, signedIn }

class AuthState extends ChangeNotifier {
  AuthState(this.api) {
    api.onSessionExpired = () {
      me = null;
      status = AuthStatus.signedOut;
      notifyListeners();
    };
  }

  final ApiClient api;
  AuthStatus status = AuthStatus.unknown;
  Me? me;

  Future<void> restore() async {
    try {
      if (await api.restoreSession()) {
        await _loadMe();
        return;
      }
    } on ApiException {
      // fall through to signed-out
    }
    status = AuthStatus.signedOut;
    notifyListeners();
  }

  Future<void> login(String username, String password) async {
    final info = await api.login(username.trim(), password);
    await _loadMe(forceChange: info.mustChangePassword);
  }

  Future<void> _loadMe({bool forceChange = false}) async {
    me = await api.me();
    status = (forceChange || me!.mustChangePassword) ? AuthStatus.mustChangePassword : AuthStatus.signedIn;
    notifyListeners();
  }

  Future<void> changePassword(String current, String next) async {
    await api.changePassword(current, next);
    me = null;
    status = AuthStatus.signedOut;
    notifyListeners();
  }

  Future<void> logout() async {
    await api.logout();
    me = null;
    status = AuthStatus.signedOut;
    notifyListeners();
  }
}
