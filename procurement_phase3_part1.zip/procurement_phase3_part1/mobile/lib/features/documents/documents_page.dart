import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/money.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";
import "document_detail_page.dart";

/// "My documents": own documents only (own=true), newest first, filter by status, infinite scroll.
class DocumentsPage extends StatefulWidget {
  const DocumentsPage({super.key});
  @override
  State<DocumentsPage> createState() => DocumentsPageState();
}

class DocumentsPageState extends State<DocumentsPage> {
  static const _filters = <String, List<String>>{
    "all": [],
    "draft": ["draft"],
    "submitted": ["submitted", "resubmitted"],
    "under_review": ["under_review"],
    "approved": ["approved"],
    "rejected": ["rejected"],
  };

  final _scroll = ScrollController();
  final List<DocSummary> _items = [];
  String _filter = "all";
  int _page = 0;
  int _total = 0;
  bool _hasMore = true;
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 300) _loadMore();
    });
    refresh();
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  Future<void> refresh() async {
    _page = 0;
    _hasMore = true;
    _items.clear();
    await _loadMore(reset: true);
  }

  Future<void> _loadMore({bool reset = false}) async {
    if (_loading || (!_hasMore && !reset)) return;
    final api = context.read<ApiClient>();
    final requested = _filter;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await api.myDocuments(statuses: _filters[requested]!, page: _page + 1);
      if (!mounted || requested != _filter) return; // filter changed while loading
      setState(() {
        _items.addAll(r.items);
        _page = r.page;
        _total = r.total;
        _hasMore = r.hasMore;
      });
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _setFilter(String f) {
    if (f == _filter) return;
    _filter = f;
    _loading = false;
    refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(T.lg, T.lg, T.lg, T.sm),
        child: AppCard(
          dark: true,
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text(S.myDocs, style: TextStyle(color: T.onDarkMuted, fontSize: 12)),
                const SizedBox(height: 4),
                Text("$_total", style: const TextStyle(color: T.onDark, fontSize: 28, fontWeight: FontWeight.w700)),
              ]),
            ),
            const Icon(Icons.folder_copy_rounded, color: T.accent, size: 32),
          ]),
        ),
      ),
      SizedBox(
        height: 46,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: T.lg, vertical: 4),
          children: [
            for (final f in _filters.keys)
              Padding(
                padding: const EdgeInsetsDirectional.only(end: T.sm),
                child: ChoiceChip(
                  label: Text(f == "all" ? S.all : S.status(f)),
                  selected: _filter == f,
                  onSelected: (_) => _setFilter(f),
                  selectedColor: T.surfaceDark,
                  backgroundColor: T.surfaceLight,
                  labelStyle: TextStyle(color: _filter == f ? T.onDark : T.textPrimary, fontSize: 13),
                  showCheckmark: false,
                  side: BorderSide.none,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(T.rControl)),
                ),
              ),
          ],
        ),
      ),
      Expanded(child: _body()),
    ]);
  }

  Widget _body() {
    if (_items.isEmpty && _loading) return const LoadingView();
    if (_items.isEmpty && _error != null) return ErrorView(message: _error!, onRetry: refresh);
    if (_items.isEmpty) return const EmptyView(text: S.noDocs);
    return RefreshIndicator(
      color: T.accent,
      onRefresh: refresh,
      child: ListView.builder(
        controller: _scroll,
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(T.lg, T.sm, T.lg, T.lg),
        itemCount: _items.length + (_hasMore || _error != null ? 1 : 0),
        itemBuilder: (_, i) {
          if (i == _items.length) {
            return Padding(
              padding: const EdgeInsets.all(T.lg),
              child: _error != null
                  ? TextButton(onPressed: _loadMore, child: const Text(S.retry))
                  : const Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: T.accent))),
            );
          }
          final d = _items[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: T.md),
            child: AppCard(
              onTap: () async {
                await Navigator.push(
                    context, MaterialPageRoute(builder: (_) => DocumentDetailPage(docId: d.id)));
                if (mounted) refresh(); // status may have changed (e.g. draft submitted)
              },
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(d.docNumber, style: const TextStyle(fontWeight: FontWeight.w700))),
                  StatusChip(d.status),
                ]),
                const SizedBox(height: T.sm),
                Row(children: [
                  Text(S.docTypes[d.docType] ?? d.docType, style: Theme.of(context).textTheme.bodySmall),
                  const Text("  ·  ", style: TextStyle(color: T.textSecondary)),
                  Text(d.purchaseDate, style: Theme.of(context).textTheme.bodySmall),
                  const Spacer(),
                  Text("${Money.display(d.total)} ${d.currency}",
                      style: const TextStyle(fontWeight: FontWeight.w700), textDirection: TextDirection.ltr),
                ]),
              ]),
            ),
          );
        },
      ),
    );
  }
}
