import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/money.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";

/// Read-only detail (status, totals, lines, attachments, decision note). A draft can be submitted
/// from here. Corrections, history timeline and cancel arrive in part 2.
class DocumentDetailPage extends StatefulWidget {
  const DocumentDetailPage({super.key, required this.docId});
  final int docId;
  @override
  State<DocumentDetailPage> createState() => _DocumentDetailPageState();
}

class _DocumentDetailPageState extends State<DocumentDetailPage> {
  DocDetail? _doc;
  String? _error;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final d = await context.read<ApiClient>().document(widget.docId);
      if (mounted) setState(() => _doc = d);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    }
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    try {
      final d = await context.read<ApiClient>().submitDocument(widget.docId);
      if (mounted) setState(() => _doc = d);
    } on ApiException catch (e) {
      if (mounted) showMessage(context, e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = _doc;
    return Scaffold(
      appBar: AppBar(title: Text(d?.summary.docNumber ?? "")),
      body: _error != null
          ? ErrorView(message: _error!, onRetry: _load)
          : d == null
              ? const LoadingView()
              : ListView(padding: const EdgeInsets.all(T.lg), children: [
                  AppCard(
                    dark: true,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        const Text(S.total, style: TextStyle(color: T.onDarkMuted, fontSize: 12)),
                        const Spacer(),
                        StatusChip(d.summary.status),
                      ]),
                      const SizedBox(height: T.sm),
                      Text("${Money.display(d.summary.total)} ${d.summary.currency}",
                          textDirection: TextDirection.ltr,
                          style: const TextStyle(color: T.onDark, fontSize: 26, fontWeight: FontWeight.w700)),
                      const SizedBox(height: T.xs),
                      Text("${S.docTypes[d.summary.docType] ?? d.summary.docType}  ·  ${d.summary.purchaseDate}",
                          style: const TextStyle(color: T.onDarkMuted, fontSize: 12)),
                    ]),
                  ),
                  if (d.decisionNote != null && d.decisionNote!.isNotEmpty) ...[
                    const SizedBox(height: T.md),
                    AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text(S.decisionNote, style: TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: T.xs),
                      Text(d.decisionNote!),
                    ])),
                  ],
                  const SizedBox(height: T.md),
                  AppCard(
                    child: Column(children: [
                      for (final l in d.lines) ...[
                        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(l.description),
                              Text("${Money.display(l.quantity, decimals: 2)} × ${Money.display(l.unitPrice)}",
                                  textDirection: TextDirection.ltr, style: Theme.of(context).textTheme.bodySmall),
                            ]),
                          ),
                          Text(Money.display(l.lineTotal), textDirection: TextDirection.ltr,
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                        ]),
                        const Divider(height: T.xl),
                      ],
                      _kv("Subtotal", Money.display(d.subtotal)),
                      _kv("Tax", Money.display(d.taxTotal)),
                      _kv(S.total, "${Money.display(d.summary.total)} ${d.summary.currency}", bold: true),
                    ]),
                  ),
                  if (d.attachments.isNotEmpty) ...[
                    const SizedBox(height: T.md),
                    AppCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text(S.attachments, style: TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: T.sm),
                        for (final a in d.attachments)
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(children: [
                              const Icon(Icons.attach_file_rounded, size: 18, color: T.textSecondary),
                              const SizedBox(width: T.sm),
                              Expanded(child: Text(a.name, overflow: TextOverflow.ellipsis)),
                              Text("${(a.sizeBytes / 1024).round()} KB", style: Theme.of(context).textTheme.bodySmall),
                            ]),
                          ),
                      ]),
                    ),
                  ],
                  if (d.summary.status == "draft") ...[
                    const SizedBox(height: T.lg),
                    AppButton(label: S.submit, onPressed: _submit, busy: _busy, icon: Icons.send_rounded),
                  ],
                ]),
    );
  }

  Widget _kv(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Text(k, style: TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w400)),
          const Spacer(),
          Text(v, textDirection: TextDirection.ltr, style: TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w400)),
        ]),
      );
}
