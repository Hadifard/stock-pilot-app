import "dart:typed_data";

import "package:file_picker/file_picker.dart";
import "package:flutter/material.dart";
import "package:image_picker/image_picker.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/api/models.dart";
import "../../core/design/tokens.dart";
import "../../core/files.dart";
import "../../core/money.dart";
import "../../core/strings.dart";
import "../../core/widgets/ref_picker.dart";
import "../../core/widgets/widgets.dart";

class _LineCtl {
  final desc = TextEditingController();
  final qty = TextEditingController(text: "1");
  final price = TextEditingController();
  final tax = TextEditingController(text: "0");
  void dispose() {
    desc.dispose();
    qty.dispose();
    price.dispose();
    tax.dispose();
  }
}

class _Pick {
  _Pick(this.name, this.bytes, this.mime);
  final String name;
  final Uint8List bytes;
  final String mime;
  bool uploaded = false;
}

/// Fast invoice entry for the live demo: pick supplier/project, add lines, attach a photo or PDF,
/// then "Submit". Flow: create draft -> upload attachments -> submit. If a step fails after the
/// draft exists, the draft is kept and the next tap continues (updates the same draft, uploads
/// only what is still pending) instead of creating duplicates.
class NewInvoicePage extends StatefulWidget {
  const NewInvoicePage({super.key, required this.onDone});
  final VoidCallback onDone;
  @override
  State<NewInvoicePage> createState() => _NewInvoicePageState();
}

class _NewInvoicePageState extends State<NewInvoicePage> {
  final _form = GlobalKey<FormState>();
  final _supplierRef = TextEditingController();
  final _description = TextEditingController();
  final _lines = <_LineCtl>[_LineCtl()];
  final _picks = <_Pick>[];

  RefItem? _supplier;
  RefItem? _project;
  RefItem? _costCenter;
  List<RefItem> _costCenters = [];
  String? _ccError;
  String _docType = "invoice";
  String _currency = "EUR";
  String _payment = "bank_transfer";
  DateTime _date = DateTime.now();
  bool _busy = false;
  int? _draftId;
  String? _error;

  static const _currencies = ["EUR", "USD", "GBP", "CHF", "PLN", "AED", "CNY"];

  @override
  void initState() {
    super.initState();
    _loadCostCenters();
  }

  @override
  void dispose() {
    _supplierRef.dispose();
    _description.dispose();
    for (final l in _lines) {
      l.dispose();
    }
    super.dispose();
  }

  Future<void> _loadCostCenters() async {
    try {
      final r = await context.read<ApiClient>().costCenters();
      if (!mounted) return;
      setState(() {
        _costCenters = r.items;
        _costCenter = r.items.isNotEmpty ? r.items.first : null;
        _ccError = null;
      });
    } on ApiException catch (e) {
      if (mounted) setState(() => _ccError = e.message);
    }
  }

  // ------------------------------------------------------------------ attachments
  Future<void> _addFromCamera() async {
    final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 85, maxWidth: 2400);
    if (x != null) _addBytes(await x.readAsBytes(), x.name);
  }

  Future<void> _addFromGallery() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 2400);
    if (x != null) _addBytes(await x.readAsBytes(), x.name);
  }

  Future<void> _addPdf() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ["pdf"], withData: true);
    final f = r?.files.single;
    if (f != null && f.bytes != null) _addBytes(f.bytes!, f.name);
  }

  void _addBytes(Uint8List bytes, String originalName) {
    final t = detectFile(bytes);
    if (t == null) {
      showMessage(context, "فقط PDF، PNG و JPG پذیرفته می‌شود.");
      return;
    }
    if (bytes.length > maxUploadBytes) {
      showMessage(context, "حجم فایل بیش از ۱۰ مگابایت است.");
      return;
    }
    setState(() => _picks.add(_Pick("${baseName(originalName)}${t.ext}", bytes, t.mime)));
  }

  // ------------------------------------------------------------------ totals preview
  double get _approxTotal {
    var sum = 0.0;
    for (final l in _lines) {
      final q = Money.toDouble(Money.parse(l.qty.text));
      final p = Money.toDouble(Money.parse(l.price.text));
      final t = Money.toDouble(Money.parse(l.tax.text.isEmpty ? "0" : l.tax.text));
      sum += q * p * (1 + t / 100);
    }
    return sum;
  }

  // ------------------------------------------------------------------ submit
  Map<String, dynamic> _body() => {
        "project_id": _project!.id,
        "cost_center_id": _costCenter!.id,
        "supplier_id": _supplier!.id,
        "doc_type": _docType,
        "purchase_date": "${_date.year.toString().padLeft(4, "0")}-${_date.month.toString().padLeft(2, "0")}-${_date.day.toString().padLeft(2, "0")}",
        "currency": _currency,
        "payment_method": _payment,
        "supplier_ref": _supplierRef.text.trim().isEmpty ? null : _supplierRef.text.trim(),
        "description": _description.text.trim(),
        "lines": [
          for (final l in _lines)
            {
              "description": l.desc.text.trim(),
              "quantity": Money.parse(l.qty.text),
              "unit_price": Money.parse(l.price.text),
              "unit": "pcs",
              "discount_rate": "0.0000",
              "tax_rate": Money.percentToFraction(l.tax.text),
              "category": "general",
            }
        ],
      };

  Future<void> _run({required bool submit}) async {
    if (!_form.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    final api = context.read<ApiClient>();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final body = _body();
      if (_draftId == null) {
        _draftId = (await api.createDraft(body)).summary.id;
      } else {
        // Re-read the row_version first: an attachment upload may have bumped it.
        final fresh = await api.document(_draftId!);
        await api.updateDraft(_draftId!, body, fresh.rowVersion);
      }
      for (final p in _picks.where((p) => !p.uploaded)) {
        await api.uploadFile("/documents/$_draftId/attachments", p.name, p.bytes, p.mime);
        p.uploaded = true;
      }
      if (submit) {
        await api.submitDocument(_draftId!);
      }
      if (!mounted) return;
      showMessage(context, submit ? "فاکتور ثبت و ارسال شد." : "پیش‌نویس ذخیره شد.");
      widget.onDone();
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = _draftId == null
            ? e.message
            : "${e.message}\nپیش‌نویس ذخیره شده است؛ با زدن دوباره‌ی دکمه ادامه می‌یابد (بدون ایجاد سند تکراری).";
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ------------------------------------------------------------------ UI
  String? _num(String? v, {bool positive = true}) {
    if (v == null || v.trim().isEmpty) return S.required;
    final p = Money.parse(v);
    if (p == null) return S.invalidNumber;
    if (positive && Money.toDouble(p) <= 0) return S.invalidNumber;
    return null;
  }

  String? _pct(String? v) {
    final p = Money.percentToFraction(v ?? "");
    if (p == null || Money.toDouble(p) > 0.5) return S.invalidNumber;
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final api = context.read<ApiClient>();
    return Form(
      key: _form,
      child: ListView(padding: const EdgeInsets.all(T.lg), children: [
        Text(S.newInvoice, style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: T.md),
        AppCard(
          child: Column(children: [
            RefPickerField(label: S.supplier, loader: (q) => api.suppliers(q), onChanged: (v) => _supplier = v),
            const SizedBox(height: T.md),
            RefPickerField(label: S.project, loader: (q) => api.projects(q), onChanged: (v) => _project = v),
            const SizedBox(height: T.md),
            if (_ccError != null)
              Row(children: [
                Expanded(child: Text(_ccError!, style: const TextStyle(color: T.danger))),
                TextButton(onPressed: _loadCostCenters, child: const Text(S.retry)),
              ])
            else
              DropdownButtonFormField<int>(
                value: _costCenter?.id,
                isExpanded: true,
                decoration: const InputDecoration(labelText: S.costCenter),
                items: [for (final c in _costCenters) DropdownMenuItem(value: c.id, child: Text(c.label, overflow: TextOverflow.ellipsis))],
                onChanged: (id) => setState(() => _costCenter = _costCenters.firstWhere((c) => c.id == id)),
                validator: (v) => v == null ? S.required : null,
              ),
            const SizedBox(height: T.md),
            Row(children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _docType,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: S.docType),
                  items: [for (final e in S.docTypes.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                  onChanged: (v) => setState(() => _docType = v!),
                ),
              ),
              const SizedBox(width: T.md),
              SizedBox(
                width: 110,
                child: DropdownButtonFormField<String>(
                  value: _currency,
                  decoration: const InputDecoration(labelText: S.currency),
                  items: [for (final c in _currencies) DropdownMenuItem(value: c, child: Text(c))],
                  onChanged: (v) => setState(() => _currency = v!),
                ),
              ),
            ]),
            const SizedBox(height: T.md),
            InkWell(
              borderRadius: BorderRadius.circular(T.rControl),
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: _date,
                  firstDate: DateTime.now().subtract(const Duration(days: 365 * 6)),
                  lastDate: DateTime.now(), // the server rejects future dates
                );
                if (d != null) setState(() => _date = d);
              },
              child: InputDecorator(
                decoration: const InputDecoration(labelText: S.purchaseDate, suffixIcon: Icon(Icons.calendar_today_rounded, size: 20)),
                child: Text("${_date.year}-${_date.month.toString().padLeft(2, "0")}-${_date.day.toString().padLeft(2, "0")}", textDirection: TextDirection.ltr),
              ),
            ),
            const SizedBox(height: T.md),
            DropdownButtonFormField<String>(
              value: _payment,
              isExpanded: true,
              decoration: const InputDecoration(labelText: S.payment),
              items: [for (final e in S.paymentMethods.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
              onChanged: (v) => setState(() => _payment = v!),
            ),
            const SizedBox(height: T.md),
            TextFormField(
              controller: _supplierRef,
              textDirection: TextDirection.ltr,
              maxLength: 60,
              decoration: const InputDecoration(labelText: S.supplierRef, counterText: ""),
            ),
            const SizedBox(height: T.md),
            TextFormField(
              controller: _description,
              maxLines: 2,
              maxLength: 2000,
              decoration: const InputDecoration(labelText: S.description, counterText: ""),
              validator: (v) => (v == null || v.trim().isEmpty) ? S.required : null, // required by the server
            ),
          ]),
        ),
        const SizedBox(height: T.lg),
        Text(S.lines, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: T.sm),
        for (var i = 0; i < _lines.length; i++) _lineCard(i),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: TextButton.icon(
            onPressed: () => setState(() => _lines.add(_LineCtl())),
            icon: const Icon(Icons.add_rounded, color: T.textPrimary),
            label: const Text(S.addLine, style: TextStyle(color: T.textPrimary)),
          ),
        ),
        const SizedBox(height: T.sm),
        _attachmentsCard(),
        const SizedBox(height: T.lg),
        AppCard(
          dark: true,
          child: Row(children: [
            const Expanded(child: Text(S.approxTotal, style: TextStyle(color: T.onDarkMuted, fontSize: 12))),
            Text("${Money.group(_approxTotal, 2)} $_currency",
                textDirection: TextDirection.ltr,
                style: const TextStyle(color: T.onDark, fontSize: 20, fontWeight: FontWeight.w700)),
          ]),
        ),
        if (_error != null) ...[
          const SizedBox(height: T.md),
          Text(_error!, style: const TextStyle(color: T.danger)),
        ],
        const SizedBox(height: T.lg),
        AppButton(label: S.submit, icon: Icons.send_rounded, busy: _busy, onPressed: () => _run(submit: true)),
        const SizedBox(height: T.md),
        AppButton(label: S.saveDraft, primary: false, onPressed: _busy ? null : () => _run(submit: false)),
        const SizedBox(height: T.xl),
      ]),
    );
  }

  Widget _lineCard(int i) {
    final l = _lines[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: T.md),
      child: AppCard(
        child: Column(children: [
          Row(children: [
            Expanded(
              child: TextFormField(
                controller: l.desc,
                maxLength: 300,
                decoration: const InputDecoration(labelText: S.lineDesc, counterText: ""),
                validator: (v) => (v == null || v.trim().isEmpty) ? S.required : null,
              ),
            ),
            if (_lines.length > 1)
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded, color: T.danger),
                onPressed: () => setState(() => _lines.removeAt(i).dispose()),
              ),
          ]),
          const SizedBox(height: T.md),
          Row(children: [
            Expanded(child: _numField(l.qty, S.qty, (v) => _num(v))),
            const SizedBox(width: T.sm),
            Expanded(flex: 2, child: _numField(l.price, S.unitPrice, (v) => _num(v))),
            const SizedBox(width: T.sm),
            Expanded(child: _numField(l.tax, S.taxPct, _pct)),
          ]),
        ]),
      ),
    );
  }

  Widget _numField(TextEditingController c, String label, String? Function(String?) validator) => TextFormField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        textDirection: TextDirection.ltr,
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(labelText: label),
        validator: validator,
      );

  Widget _attachmentsCard() => AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(S.attachments, style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: T.md),
          Row(children: [
            Expanded(child: AppButton(label: S.camera, icon: Icons.photo_camera_rounded, primary: false, onPressed: _busy ? null : _addFromCamera)),
            const SizedBox(width: T.sm),
            Expanded(child: AppButton(label: S.gallery, icon: Icons.photo_library_rounded, primary: false, onPressed: _busy ? null : _addFromGallery)),
            const SizedBox(width: T.sm),
            Expanded(child: AppButton(label: S.pdfFile, icon: Icons.picture_as_pdf_rounded, primary: false, onPressed: _busy ? null : _addPdf)),
          ]),
          for (var i = 0; i < _picks.length; i++)
            ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: Icon(_picks[i].mime == "application/pdf" ? Icons.picture_as_pdf_rounded : Icons.image_rounded, color: T.textSecondary),
              title: Text(_picks[i].name, overflow: TextOverflow.ellipsis),
              subtitle: Text("${(_picks[i].bytes.length / 1024).round()} KB${_picks[i].uploaded ? "  ✓" : ""}"),
              // An uploaded attachment cannot be removed (the API has no delete endpoint).
              trailing: _picks[i].uploaded
                  ? null
                  : IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => _picks.removeAt(i))),
            ),
        ]),
      );
}
