import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/design/tokens.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";
import "../../state/auth_state.dart";
import "../documents/documents_page.dart";
import "../invoice/new_invoice_page.dart";

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  int _formEpoch = 0; // bumping it rebuilds a fresh, empty invoice form
  final _docsKey = GlobalKey<DocumentsPageState>();

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AuthState>().me!;
    final canCreate = me.can("document.create");
    final pages = <Widget>[
      DocumentsPage(key: _docsKey),
      if (canCreate)
        NewInvoicePage(
          key: ValueKey(_formEpoch),
          onDone: () {
            setState(() {
              _formEpoch++;
              _index = 0;
            });
            _docsKey.currentState?.refresh();
          },
        ),
      _AccountPage(name: me.fullName, username: me.username, role: me.role),
    ];
    final items = <NavigationDestination>[
      const NavigationDestination(icon: Icon(Icons.folder_open_rounded), label: S.myDocs),
      if (canCreate)
        const NavigationDestination(icon: Icon(Icons.add_circle_outline_rounded), label: S.newInvoice),
      const NavigationDestination(icon: Icon(Icons.person_outline_rounded), label: S.account),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: pages)),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(T.md, 0, T.md, T.md),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(T.rLarge),
          child: NavigationBar(
            selectedIndex: _index,
            destinations: items,
            onDestinationSelected: (i) {
              setState(() => _index = i);
              if (i == 0) _docsKey.currentState?.refresh();
            },
          ),
        ),
      ),
    );
  }
}

/// Minimal account tab; the full profile (change password, notifications) arrives in part 2.
class _AccountPage extends StatelessWidget {
  const _AccountPage({required this.name, required this.username, required this.role});
  final String name, username, role;
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(T.lg), children: [
      AppCard(
        dark: true,
        child: Row(children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(color: T.accent, borderRadius: BorderRadius.circular(T.rControl)),
            child: const Icon(Icons.person_rounded, color: Colors.white),
          ),
          const SizedBox(width: T.md),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(color: T.onDark, fontSize: 16, fontWeight: FontWeight.w700)),
              Text("$username  ·  $role", style: const TextStyle(color: T.onDarkMuted, fontSize: 12)),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: T.lg),
      AppButton(label: S.signOut, primary: false, icon: Icons.logout_rounded, onPressed: () => context.read<AuthState>().logout()),
    ]);
  }
}
