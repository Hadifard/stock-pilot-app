import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../core/api/api_client.dart";
import "../../core/design/tokens.dart";
import "../../core/strings.dart";
import "../../core/widgets/widgets.dart";
import "../../state/auth_state.dart";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  String? _error;

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_user.text.trim().isEmpty || _pass.text.isEmpty) {
      setState(() => _error = S.required);
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await context.read<AuthState>().login(_user.text, _pass.text);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(T.xl),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                AppCard(
                  dark: true,
                  padding: const EdgeInsets.symmetric(vertical: T.xxl, horizontal: T.xl),
                  child: Column(children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: T.accent,
                        borderRadius: BorderRadius.circular(T.rLarge),
                        boxShadow: T.softShadow,
                      ),
                      child: const Icon(Icons.receipt_long_rounded, color: Colors.white, size: 32),
                    ),
                    const SizedBox(height: T.lg),
                    const Text(S.appName,
                        style: TextStyle(color: T.onDark, fontSize: 22, fontWeight: FontWeight.w700)),
                  ]),
                ),
                const SizedBox(height: T.xl),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    TextField(
                      controller: _user,
                      textDirection: TextDirection.ltr,
                      autocorrect: false,
                      enableSuggestions: false,
                      textInputAction: TextInputAction.next,
                      autofillHints: const [AutofillHints.username],
                      decoration: const InputDecoration(labelText: S.username),
                    ),
                    const SizedBox(height: T.md),
                    TextField(
                      controller: _pass,
                      obscureText: _hide,
                      textDirection: TextDirection.ltr,
                      onSubmitted: (_) => _submit(),
                      autofillHints: const [AutofillHints.password],
                      decoration: InputDecoration(
                        labelText: S.password,
                        suffixIcon: IconButton(
                          icon: Icon(_hide ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                          onPressed: () => setState(() => _hide = !_hide),
                        ),
                      ),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: T.md),
                      Text(_error!, style: const TextStyle(color: T.danger)),
                    ],
                    const SizedBox(height: T.lg),
                    AppButton(label: S.signIn, onPressed: _submit, busy: _busy),
                  ]),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
