import "package:flutter_test/flutter_test.dart";
import "package:procurement_mobile/core/money.dart";

void main() {
  group("Money.parse", () {
    test("canonical 4-decimal output", () {
      expect(Money.parse("12.5"), "12.5000");
      expect(Money.parse("0012"), "12.0000");
      expect(Money.parse("0"), "0.0000");
      expect(Money.parse(" 7 "), "7.0000");
    });
    test("Persian digits and separators", () {
      expect(Money.parse("۱۲٫۵"), "12.5000");
      expect(Money.parse("1٬234"), "1234.0000");
    });
    test("comma is a decimal separator only when unambiguous", () {
      expect(Money.parse("12,5"), "12.5000");
      expect(Money.parse("1,500"), isNull); // 1.5 or 1500? refuse to guess
      expect(Money.parse("1.5,2"), isNull);
    });
    test("rejects invalid input", () {
      expect(Money.parse("1.23456"), isNull);
      expect(Money.parse("-1"), isNull);
      expect(Money.parse(""), isNull);
      expect(Money.parse("abc"), isNull);
    });
  });

  group("Money.percentToFraction", () {
    test("converts percent to the API fraction", () {
      expect(Money.percentToFraction("19"), "0.1900");
      expect(Money.percentToFraction("7.5"), "0.0750");
      expect(Money.percentToFraction("0.05"), "0.0005");
      expect(Money.percentToFraction("50"), "0.5000");
      expect(Money.percentToFraction("100"), "1.0000");
    });
    test("empty means zero; invalid is null", () {
      expect(Money.percentToFraction(""), "0.0000");
      expect(Money.percentToFraction("100.01"), isNull);
      expect(Money.percentToFraction("19.555"), isNull);
    });
  });

  test("Money.display groups thousands", () {
    expect(Money.display("1234567.8900"), "1,234,567.89");
    expect(Money.display("12.0000"), "12.00");
    expect(Money.display(null), "-");
  });
}
