import "package:flutter_test/flutter_test.dart";
import "package:procurement_mobile/core/api/models.dart";

// Sample shaped exactly like DocumentOut / MeOut in app/api/schemas.py.
const _doc = {
  "id": 7, "doc_number": "DOC-000007", "status": "draft", "doc_type": "invoice",
  "purchase_date": "2026-10-01", "currency": "EUR", "total": "224.2000",
  "total_reporting": null, "reporting_currency": "EUR", "supplier_id": 1, "project_id": 2,
  "employee_id": 3, "supplier_ref": null, "created_at": "2026-10-17T09:30:00", "submitted_at": null,
  "is_synthetic": true, "org_unit_id": 1, "cost_center_id": 1, "description": "x",
  "business_purpose": "", "payment_method": "bank_transfer", "shipping": "0.0000",
  "other_charges": "0.0000", "shipping_tax_rate": "0.0000", "subtotal": "200.0000",
  "discount_total": "0.0000", "tax_total": "24.2000", "fx_rate": null, "decided_at": null,
  "decided_by": null, "decision_note": null, "row_version": 3,
  "lines": [
    {"line_no": 1, "description": "Paper", "category": "general", "quantity": "2.0000", "unit": "pcs",
     "unit_price": "100.0000", "discount_rate": "0.0000", "tax_rate": "0.1210", "discount_amount": "0.0000",
     "net_amount": "200.0000", "tax_amount": "24.2000", "line_total": "224.2000"}
  ],
  "attachments": [
    {"id": 5, "original_name": "a.pdf", "mime_type": "application/pdf", "size_bytes": 2048, "sha256": "x", "created_at": "2026-10-17T09:31:00"}
  ],
  "correction_deadline": null, "correction_window_open": false,
};

void main() {
  test("DocDetail parses the API document shape", () {
    final d = DocDetail.fromJson(Map<String, dynamic>.from(_doc));
    expect(d.summary.docNumber, "DOC-000007");
    expect(d.summary.total, "224.2000");
    expect(d.rowVersion, 3);
    expect(d.lines.single.lineTotal, "224.2000");
    expect(d.attachments.single.name, "a.pdf");
    expect(d.decisionNote, isNull);
  });

  test("Me parses permissions", () {
    final m = Me.fromJson({
      "id": 1, "username": "employee.demo", "full_name": "E", "role": "purchasing_employee",
      "org_unit_id": 1, "is_active": true, "permissions": ["document.create"], "must_change_password": false,
    });
    expect(m.can("document.create"), isTrue);
    expect(m.can("document.review"), isFalse);
  });
}
