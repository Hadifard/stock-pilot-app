import "dart:typed_data";

import "package:flutter_test/flutter_test.dart";
import "package:procurement_mobile/core/files.dart";

void main() {
  test("detects PDF, PNG, JPEG by content", () {
    expect(detectFile(Uint8List.fromList([0x25, 0x50, 0x44, 0x46, 0x2D, 0x31]))?.ext, ".pdf");
    expect(detectFile(Uint8List.fromList([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0]))?.mime, "image/png");
    expect(detectFile(Uint8List.fromList([0xFF, 0xD8, 0xFF, 0xE0]))?.ext, ".jpg");
  });
  test("rejects other content (HEIC/WebP/text) and short input", () {
    expect(detectFile(Uint8List.fromList([0x52, 0x49, 0x46, 0x46])), isNull);
    expect(detectFile(Uint8List(0)), isNull);
  });
  test("baseName strips directories and extension", () {
    expect(baseName("/a/b/photo.HEIC"), "photo");
    expect(baseName(r"C:\x\inv.pdf"), "inv");
    expect(baseName("noext"), "noext");
  });
}
