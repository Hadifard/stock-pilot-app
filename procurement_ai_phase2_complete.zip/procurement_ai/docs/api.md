# REST API (Phase 2, part 1)

Start (development, SQLite):
```powershell
python -m scripts.generate_synthetic_data --mode small --reset   # runs Alembic migrations, then seeds
$env:PROCUREMENT_JWT_SECRET = python -c "import secrets; print(secrets.token_urlsafe(48))"
uvicorn app.api.main:app --reload --port 8000
```
Swagger UI: http://localhost:8000/api/v1/docs, ReDoc: `/api/v1/redoc`, schema: `/api/v1/openapi.json`. Click *Authorize* and sign in with a demo account (OAuth2 password flow).

PostgreSQL (production-oriented):
```bash
export PROCUREMENT_DATABASE_URL=postgresql+psycopg://user:password@host:5432/procurement
export PROCUREMENT_ENV=production PROCUREMENT_JWT_SECRET=<48+ random characters>
alembic upgrade head            # or: python -m scripts.initialize_database
uvicorn app.api.main:app --host 0.0.0.0 --port 8000 --workers 2
```
In production the API refuses to start without `PROCUREMENT_JWT_SECRET`. Put it behind HTTPS (reverse proxy).

## Conventions
* Base path `/api/v1`. JSON in/out; money and quantities are **strings** with 4 decimals (`"224.2000"`), never floats. Totals are calculated by the server; clients cannot send them.
* Auth: `POST /auth/login` (form: username, password) returns `access_token` (30 min) and `refresh_token` (7 days). Send `Authorization: Bearer <access_token>`. `POST /auth/refresh` exchanges a refresh token; `POST /auth/logout` revokes every token of the user (per-user `token_version`). Five failed logins lock the account for 15 minutes (generic error text, no user enumeration).
* Errors: `{"error": {"code", "message", "details": [{"loc","msg"}], "request_id"}}` with status 401 unauthenticated, 403 forbidden, 404 not_found, 409 invalid_transition / correction_window_expired / concurrent_modification / conflict, 413 upload_too_large, 422 validation_error, 400 upload_rejected, 500 internal_error (no internals leaked). `X-Request-ID` is accepted and echoed.
* Lists: `page` (>=1), `page_size` (1-100, default 25) -> `{items,total,page,page_size,pages}`. Documents support `status` (repeatable), `q`, `own`, `project_id`, `supplier_id`, `currency`, `date_from`, `date_to`, `sort` (`-created_at`, `total`, `purchase_date`, ...). `q` treats `%` and `_` literally.
* Permissions are enforced in the shared services (the same code the Streamlit app uses) and again at route level where useful. Listings and analytics are scoped to what the caller may see.
* Transactions: one database transaction per request (commit on success, rollback on any error). Documents carry `row_version`; a concurrent write to the same row fails with 409 `concurrent_modification` instead of silently overwriting.
* Background jobs: `POST /jobs` (`anomaly_scan`, `duplicate_scan`, `train_anomaly_model`) and `POST /jobs/extraction` (file) return 202 with a job id; poll `GET /jobs/{id}`. Jobs run in the API process after the response (single-instance only); for multiple instances move `app/api/jobs.run_job` to a worker such as Celery/RQ that reads the same `background_jobs` table.
* Attachments: multipart upload (draft owner only), content checked against extension, size limit, UUID storage names; download is permission-checked, `nosniff`, `Cache-Control: no-store`.

## Endpoint groups
| Group | Highlights |
|---|---|
| Authentication | login, refresh, logout, me (with permission list) |
| Reference data | org units, projects, cost centers, suppliers (search + pagination) |
| Documents | create/update draft, submit, cancel, start review, approve, reject, history, list/filter/sort |
| Corrections | request (owner in window, audited exception after), list, decide |
| Attachments | upload, download |
| Extraction and jobs | synchronous extraction, resolutions, background jobs |
| Analytics | kpis, operations, spend (group_by + filters), budget utilisation, inconsistent totals, forecast, alerts + review, duplicates + review, price benchmark + match decisions |
| Reports/audit/admin | CSV/XLSX/PDF export, audit events + chain verification, user admin |

## Reuse between phases
Unchanged and shared: `app/services`, `app/ml`, `app/security`, `app/database/models.py`. New in Phase 2: `app/api`, Alembic `migrations/`, `token_version`/lockout columns, `row_version`, `background_jobs`. The Streamlit app still talks to the services directly; switching it to the API is optional and not needed for Phase 3.

## Not done in part 1 (tracked for part 2)
Rate limiting at the API (lockout exists; use a reverse proxy for IP limits), request body size limit at the proxy, refresh-token rotation with server-side revocation list, password change/reset endpoints, Dockerfile/compose, load testing, an `If-Match` header for clients (the `row_version` field is exposed, but updates are not yet conditional on it).

## Part 2 additions: security hardening, concurrency, deployment

* **Refresh-token rotation.** Each refresh token is single-use and tracked server-side (`refresh_tokens` table). `/auth/refresh` consumes the presented token and returns a new one in the same "family". Replaying an already-used or revoked token revokes the whole family (theft response), forcing re-login. `/auth/logout` also accepts `{"refresh_token": "..."}` to revoke that specific token immediately, in addition to bumping `token_version` (which invalidates every access token).
* **Password policy.** `POST /auth/change-password` (current + new password, min 12 chars, 3 of 4 character classes) revokes all of the user's tokens. `POST /admin/users/{id}/reset-password` (administrators) sets a temporary password and flags `must_change_password`; that account can then only call `/auth/me` and `/auth/change-password` until it complies (every other route returns 403 `password_change_required`).
* **Rate limiting.** In-process sliding window per client IP: `PROCUREMENT_RATE_LIMIT_LOGIN_PER_MIN` (default 10) on `/auth/login`, `PROCUREMENT_RATE_LIMIT_PER_MIN` (default 600) on everything else under `/api/v1`. Returns 429 `rate_limited` with `Retry-After: 60`. **Single-process only** — behind multiple API instances, put this in a reverse proxy or shared store (Redis) instead; `PROCUREMENT_TRUST_PROXY=1` makes it read the client IP from `X-Forwarded-For` (only enable this behind a proxy you control).
* **Optimistic concurrency.** `PurchaseDocument.row_version` is returned on every document response. Send `If-Match: <row_version>` on `PUT /documents/{id}`, `/submit`, `/approve`, `/reject` to guard against a concurrent change; a stale value returns 412 `precondition_failed`. The header is optional — omitting it keeps last-write-wins, same as Part 1.
* **Background jobs, two modes.** `PROCUREMENT_JOBS_MODE=inline` (default) runs jobs inside the API process after the response. `PROCUREMENT_JOBS_MODE=worker` makes the API only enqueue; run one or more `python -m scripts.run_worker` processes, which poll `background_jobs` and claim one row at a time (`UPDATE ... WHERE status='queued'`, so two workers never run the same job).
* **Docker.** Multi-stage `Dockerfile` (targets `api`, `worker`, `streamlit`) and `docker-compose.yml` (PostgreSQL + migrate + api + worker + streamlit). **Not build-tested**: this sandbox has no Docker daemon. Before relying on it: `cp .env.docker.example .env`, fill in `POSTGRES_PASSWORD` and `PROCUREMENT_JWT_SECRET`, then `docker compose up --build` and verify `/health/ready`.

### Still not done (tracked, not blocking)
Refresh-token cleanup job for expired rows (they're just ignored, not deleted), a `/auth/forgot-password` self-service flow (only admin-initiated reset exists), request body size limit at the proxy layer, and load testing. See `docs/security_checklist.md`.
