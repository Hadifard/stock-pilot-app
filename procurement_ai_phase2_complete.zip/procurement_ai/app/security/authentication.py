"""Authentication shared by the Streamlit demo and the API.

Passwords are verified against scrypt hashes. After `max_failed_logins` consecutive failures the
account is locked for `lockout_minutes`. Failure messages are generic so they do not reveal which
usernames exist or whether an account is locked.
"""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import User
from app.security import audit_log
from app.security.hashing import verify_password
from app.utils.dates import utcnow
from app.utils.exceptions import AuthenticationError

GENERIC = "Invalid username or password."


def authenticate(session: Session, username: str, password: str) -> User:
    """Return the user or raise AuthenticationError; failed attempts are audited and committed."""
    settings = get_settings()
    now = utcnow()
    user = session.execute(
        select(User).where(User.username == username.strip().lower())
    ).scalar_one_or_none()
    locked = bool(user and user.locked_until and user.locked_until > now)
    ok = bool(
        user and user.is_active and not locked and verify_password(password, user.password_hash)
    )
    if not ok:
        action = "auth.login_blocked_locked" if locked else "auth.login_failed"
        if user is not None and user.is_active and not locked:
            user.failed_login_count += 1
            if user.failed_login_count >= settings.max_failed_logins:
                user.locked_until = now + timedelta(minutes=settings.lockout_minutes)
                user.failed_login_count = 0
                action = "auth.account_locked"
        audit_log.record(
            session,
            actor_id=None,
            action=action,
            entity_type="user",
            entity_id=user.id if user else None,
            payload={"username": username[:60]},
        )
        session.commit()  # keep the failure record and counter although the caller raises
        raise AuthenticationError(GENERIC)
    user.failed_login_count = 0
    user.locked_until = None
    audit_log.record(
        session, actor_id=user.id, action="auth.login", entity_type="user", entity_id=user.id
    )
    return user
