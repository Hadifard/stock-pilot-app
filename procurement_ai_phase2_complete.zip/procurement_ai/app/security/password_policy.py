"""Minimum password strength rule (length + character variety), used by change/reset.

Not a production policy by itself: pair with the API's rate limiting and account lockout, and
consider a breached-password check (e.g. HaveIBeenPwned k-anonymity) before real deployment.
"""

from __future__ import annotations

MIN_LENGTH = 12


def weaknesses(password: str) -> list[str]:
    issues = []
    if len(password) < MIN_LENGTH:
        issues.append(f"Password must be at least {MIN_LENGTH} characters.")
    classes = (
        sum(any(c.islower() for c in password) for _ in [0])
        + sum(any(c.isupper() for c in password) for _ in [0])
        + sum(any(c.isdigit() for c in password) for _ in [0])
        + sum(any(not c.isalnum() for c in password) for _ in [0])
    )
    if classes < 3:
        issues.append("Password must contain at least 3 of: lowercase, uppercase, digit, symbol.")
    return issues
