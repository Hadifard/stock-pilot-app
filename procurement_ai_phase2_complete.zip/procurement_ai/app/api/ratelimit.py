"""In-process sliding-window rate limiter (per client IP), keyed per limiter name.

Single-process only: with multiple API instances behind a load balancer, put a shared limiter
(e.g. Redis) in front, or rely on the reverse proxy. Adequate for Phase 1/2 development and a
single-instance deployment; documented as a known limitation otherwise.
"""

from __future__ import annotations

import time
from collections import defaultdict
from threading import Lock

from fastapi import Request

from app.config import get_settings
from app.utils.exceptions import RateLimited

_buckets: dict[tuple[str, str], list[float]] = defaultdict(list)
_lock = Lock()


def client_ip(request: Request) -> str:
    settings = get_settings()
    if settings.trust_proxy:
        fwd = request.headers.get("x-forwarded-for")
        if fwd:
            return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def check(name: str, key: str, limit_per_min: int) -> None:
    """Raise RateLimited if `key` exceeded `limit_per_min` requests for `name` in the last 60s."""
    if limit_per_min <= 0:
        return
    now = time.monotonic()
    bucket_key = (name, key)
    with _lock:
        hits = _buckets[bucket_key]
        cutoff = now - 60.0
        while hits and hits[0] < cutoff:
            hits.pop(0)
        if len(hits) >= limit_per_min:
            raise RateLimited(f"Too many requests ({name}); try again shortly.")
        hits.append(now)


def reset() -> None:  # tests
    with _lock:
        _buckets.clear()
