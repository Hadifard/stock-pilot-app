"""Background jobs: queued in the database, executed after the HTTP response is sent.

Execution uses FastAPI BackgroundTasks, i.e. inside the API process. That is adequate for one
instance and short jobs; for production move `run_job` to a worker (Celery/RQ/Arq) reading the same
background_jobs table. Permissions are re-checked by the services inside the job.
"""

from __future__ import annotations

import json
import logging
import uuid
from pathlib import Path

from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import BackgroundJob, User
from app.database.session import session_scope
from app.security.authorization import Perm, require
from app.services import analytics_service as an
from app.services import extraction_service
from app.utils.dates import utcnow
from app.utils.exceptions import DomainError, ValidationError

log = logging.getLogger("procurement.jobs")
KINDS = {
    "anomaly_scan": Perm.ALERT_REVIEW,
    "duplicate_scan": Perm.ALERT_REVIEW,
    "train_anomaly_model": Perm.ADMIN_MANAGE,
    "extraction": Perm.DOC_CREATE,
}


def jobs_dir() -> Path:
    d = get_settings().attachment_dir.parent / "jobs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def enqueue(session: Session, actor: User, kind: str, params: dict | None = None) -> BackgroundJob:
    if kind not in KINDS:
        raise ValidationError(f"Unknown job kind '{kind}'. Allowed: {', '.join(sorted(KINDS))}.")
    require(actor, KINDS[kind])  # fail fast; the job re-checks when it runs
    job = BackgroundJob(kind=kind, created_by=actor.id, params_json=json.dumps(params or {}))
    session.add(job)
    session.flush()
    return job


def stage_upload(filename: str, data: bytes) -> str:
    """Write the upload to a private temp file; returns the stored name (not a user path)."""
    name = uuid.uuid4().hex + Path(filename).suffix.lower()[:8]
    (jobs_dir() / name).write_bytes(data)
    return name


def _execute(session: Session, actor: User, job: BackgroundJob) -> dict:
    params = json.loads(job.params_json)
    if job.kind == "anomaly_scan":
        r = an.run_anomaly_scan(session, actor)
        return {
            "scanned": r.scanned,
            "flagged": r.flagged,
            "new_alerts": r.new_alerts,
            "model": r.model_version,
        }
    if job.kind == "duplicate_scan":
        found, new = an.run_duplicate_scan(session, actor)
        return {"found": found, "new": new}
    if job.kind == "train_anomaly_model":
        m = an.train_anomaly_model(session, actor)
        return {"version": m.version, "documents": m.n_train_docs}
    if job.kind == "extraction":
        path = jobs_dir() / Path(params["stored"]).name
        try:
            data = path.read_bytes()
            out = extraction_service.run_extraction(session, actor, params["filename"], data)
        finally:
            path.unlink(missing_ok=True)
        return {"record_id": out.record_id, "status": out.status, "method": out.method}
    raise ValidationError("Unknown job kind.")


def run_job(job_id: int) -> None:
    """Entry point executed in the background. Never raises."""
    try:
        with session_scope() as s:
            job = s.get(BackgroundJob, job_id)
            if job is None or job.status not in ("queued", "claimed"):
                return
            job.status, job.started_at = "running", utcnow()
        with session_scope() as s:
            job = s.get(BackgroundJob, job_id)
            actor = s.get(User, job.created_by)
            result = _execute(s, actor, job)
            job.status, job.finished_at = "succeeded", utcnow()
            job.result_json = json.dumps(result, default=str)
    except Exception as exc:  # record the failure; the work's own transaction was rolled back
        log.exception("Job %s failed", job_id)
        message = str(exc) if isinstance(exc, DomainError) else "The job failed unexpectedly."
        with session_scope() as s:
            job = s.get(BackgroundJob, job_id)
            if job is not None:
                job.status, job.finished_at, job.error = "failed", utcnow(), message[:1000]
