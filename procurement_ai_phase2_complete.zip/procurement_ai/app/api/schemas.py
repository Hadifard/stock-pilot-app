"""Pydantic request/response models for /api/v1.

Money and quantities are Decimals serialised as JSON strings (never floats). Shape and type
validation happens here; business rules (ranges, currencies, workflow) are enforced by the
services, whose errors are returned in the same structured format.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field, PlainSerializer

T = TypeVar("T")
Money = Annotated[Decimal, Field(max_digits=18, decimal_places=4)]
Rate = Annotated[Decimal, Field(max_digits=8, decimal_places=4)]
# Output decimals always have exactly 4 places as JSON strings, however the value was produced.
Dec4 = Annotated[
    Decimal,
    PlainSerializer(
        lambda v: format(v.quantize(Decimal("0.0001")), "f"), return_type=str, when_used="json"
    ),
]


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int
    pages: int


def make_page(items: list, total: int, page: int, page_size: int) -> dict:
    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": max(1, -(-total // page_size)),
    }


# ------------------------------------------------------------------ auth
class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int = Field(description="Access token lifetime in seconds")
    must_change_password: bool = False


class RefreshRequest(BaseModel):
    refresh_token: str


class UserOut(ORM):
    id: int
    username: str
    full_name: str
    role: str
    org_unit_id: int
    is_active: bool


class MeOut(UserOut):
    permissions: list[str]
    must_change_password: bool


class AdminUserOut(UserOut):
    is_synthetic: bool
    failed_login_count: int
    locked_until: datetime | None


class AdminUserPatch(BaseModel):
    is_active: bool | None = None
    unlock: bool = False


class ChangePasswordIn(BaseModel):
    current_password: str = Field(min_length=1)
    new_password: str = Field(min_length=1, max_length=200)


class AdminResetPasswordIn(BaseModel):
    temporary_password: str = Field(min_length=1, max_length=200)


# ------------------------------------------------------------------ reference data
class OrgUnitOut(ORM):
    id: int
    code: str
    name: str
    kind: str
    country: str


class ProjectOut(ORM):
    id: int
    code: str
    name: str
    org_unit_id: int
    budget: Dec4
    budget_currency: str


class CostCenterOut(ORM):
    id: int
    code: str
    name: str
    org_unit_id: int


class SupplierOut(ORM):
    id: int
    name: str
    country: str


# ------------------------------------------------------------------ documents
class LineIn(BaseModel):
    description: str = Field(min_length=1, max_length=300)
    quantity: Money
    unit_price: Money
    unit: str = "pcs"
    discount_rate: Rate = Decimal("0")
    tax_rate: Rate = Decimal("0")
    category: str = Field("general", max_length=60)


class DocumentIn(BaseModel):
    project_id: int
    cost_center_id: int
    supplier_id: int
    doc_type: str
    purchase_date: date
    currency: str = Field(min_length=3, max_length=3)
    lines: list[LineIn] = Field(min_length=1, max_length=200)
    supplier_ref: str | None = Field(None, max_length=60)
    description: str = Field("", max_length=2000)
    business_purpose: str = Field("", max_length=2000)
    payment_method: str = "bank_transfer"
    shipping: Money = Decimal("0")
    other_charges: Money = Decimal("0")
    shipping_tax_rate: Rate = Decimal("0")


class LineOut(ORM):
    line_no: int
    description: str
    category: str
    quantity: Dec4
    unit: str
    unit_price: Dec4
    discount_rate: Dec4
    tax_rate: Dec4
    discount_amount: Dec4
    net_amount: Dec4
    tax_amount: Dec4
    line_total: Dec4


class AttachmentOut(ORM):
    id: int
    original_name: str
    mime_type: str
    size_bytes: int
    sha256: str
    created_at: datetime


class DocumentSummary(ORM):
    id: int
    doc_number: str
    status: str
    doc_type: str
    purchase_date: date
    currency: str
    total: Dec4
    total_reporting: Dec4 | None
    reporting_currency: str
    supplier_id: int
    project_id: int
    employee_id: int
    supplier_ref: str | None
    created_at: datetime
    submitted_at: datetime | None
    is_synthetic: bool


class DocumentOut(DocumentSummary):
    org_unit_id: int
    cost_center_id: int
    description: str
    business_purpose: str
    payment_method: str
    shipping: Dec4
    other_charges: Dec4
    shipping_tax_rate: Dec4
    subtotal: Dec4
    discount_total: Dec4
    tax_total: Dec4
    fx_rate: Dec4 | None
    decided_at: datetime | None
    decided_by: int | None
    decision_note: str | None
    row_version: int
    lines: list[LineOut]
    attachments: list[AttachmentOut]
    correction_deadline: datetime | None = None
    correction_window_open: bool = False


class DecisionIn(BaseModel):
    note: str = Field("", max_length=2000)


class CancelIn(BaseModel):
    reason: str = Field("", max_length=500)


class HistoryEvent(BaseModel):
    id: int
    timestamp: datetime
    actor_id: int | None
    action: str
    payload: dict[str, Any]


# ------------------------------------------------------------------ corrections
class CorrectionIn(BaseModel):
    header_changes: dict[str, Any] = Field(default_factory=dict, description="Field -> new value")
    line_changes: list[dict[str, Any]] | None = Field(
        None, description="Full replacement line list"
    )
    reason: str = Field(min_length=1, max_length=2000)
    override_reason: str | None = Field(None, max_length=2000)


class CorrectionDecisionIn(BaseModel):
    approve: bool
    note: str = Field("", max_length=2000)


class CorrectionOut(BaseModel):
    id: int
    document_id: int
    requested_by: int
    requested_at: datetime
    reason: str
    status: str
    deadline_exception: bool
    exception_reason: str | None
    decided_by: int | None
    decided_at: datetime | None
    decision_note: str | None
    original: dict[str, Any]
    proposed: dict[str, Any]


# ------------------------------------------------------------------ extraction / jobs
class ExtractedFieldOut(BaseModel):
    value: Any
    confidence: float
    evidence: str
    candidates: list[Any] = []


class ExtractionOut(BaseModel):
    record_id: int
    status: str
    source_type: str
    method: str
    text: str
    fields: dict[str, ExtractedFieldOut]
    lines: list[dict[str, Any]]
    issues: list[str]
    missing: list[str]
    warnings: list[str]
    ocr_confidence: float | None


class ResolutionsIn(BaseModel):
    resolutions: dict[str, dict[str, Any]]
    document_id: int | None = None


class JobCreate(BaseModel):
    kind: str = Field(description="anomaly_scan | duplicate_scan | train_anomaly_model")


class JobOut(BaseModel):
    id: int
    kind: str
    status: str
    created_by: int
    created_at: datetime
    started_at: datetime | None
    finished_at: datetime | None
    result: dict[str, Any] | None
    error: str | None


# ------------------------------------------------------------------ analytics
class ReviewIn(BaseModel):
    disposition: str
    note: str = Field(min_length=1, max_length=2000)


class MatchDecisionIn(BaseModel):
    text_a: str = Field(min_length=1, max_length=300)
    text_b: str = Field(min_length=1, max_length=300)
    equivalent: bool


class AuditEventOut(BaseModel):
    id: int
    timestamp: datetime
    actor_id: int | None
    action: str
    entity_type: str
    entity_id: int | None
    payload: dict[str, Any]
    hash: str
