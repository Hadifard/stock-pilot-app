from __future__ import annotations

import json
from datetime import date
from typing import Annotated

from fastapi import APIRouter, File, Query, Response, UploadFile
from sqlalchemy import select

from app.api.deps import CurrentUser, IfMatch, Pagination, SessionDep, check_row_version
from app.api.schemas import (
    AttachmentOut,
    CancelIn,
    CorrectionDecisionIn,
    CorrectionIn,
    CorrectionOut,
    DecisionIn,
    DocumentIn,
    DocumentOut,
    DocumentSummary,
    HistoryEvent,
    Page,
    make_page,
)
from app.config import get_settings
from app.database.models import AuditEvent, CorrectionRequest
from app.services import approval_service as appr
from app.services import attachment_service as att
from app.services import correction_service as corr
from app.services import document_service as docs
from app.services.validation_service import DocumentInput, LineInput
from app.utils.exceptions import UploadTooLarge

router = APIRouter(tags=["Documents"])

SORT_DESC = "Sort field, optionally prefixed with '-' for descending: " + ", ".join(
    sorted(docs.SORT_FIELDS)
)


def to_input(body: DocumentIn) -> DocumentInput:
    return DocumentInput(
        project_id=body.project_id,
        cost_center_id=body.cost_center_id,
        supplier_id=body.supplier_id,
        doc_type=body.doc_type,
        purchase_date=body.purchase_date,
        currency=body.currency.upper(),
        lines=tuple(
            LineInput(
                x.description,
                x.quantity,
                x.unit_price,
                x.unit,
                x.discount_rate,
                x.tax_rate,
                x.category,
            )
            for x in body.lines
        ),
        supplier_ref=body.supplier_ref,
        description=body.description,
        business_purpose=body.business_purpose,
        payment_method=body.payment_method,
        shipping=body.shipping,
        other_charges=body.other_charges,
        shipping_tax_rate=body.shipping_tax_rate,
    )


def doc_out(doc) -> DocumentOut:
    out = DocumentOut.model_validate(doc)
    out.correction_deadline = docs.correction_deadline(doc)
    out.correction_window_open = doc.status in corr.CORRECTABLE and docs.within_correction_window(
        doc
    )
    return out


@router.post(
    "/documents", response_model=DocumentOut, status_code=201, summary="Create a draft document"
)
def create_document(body: DocumentIn, user: CurrentUser, session: SessionDep):
    """Totals are calculated by the server; any total sent by a client is ignored (there is no such field)."""
    return doc_out(docs.create_draft(session, user, to_input(body)))


@router.get(
    "/documents", response_model=Page[DocumentSummary], summary="List documents you may see"
)
def list_documents(
    user: CurrentUser,
    session: SessionDep,
    page: Pagination,
    status: Annotated[
        list[str] | None, Query(description="Repeat to filter by several statuses")
    ] = None,
    q: Annotated[
        str | None, Query(max_length=100, description="Search number, reference, description")
    ] = None,
    own: Annotated[bool, Query(description="Only documents created by me")] = False,
    project_id: int | None = None,
    supplier_id: int | None = None,
    currency: str | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
    sort: Annotated[str, Query(description=SORT_DESC)] = "-created_at",
):
    flt = docs.DocumentFilter(
        tuple(status or ()), q or "", own, project_id, supplier_id, currency, date_from, date_to
    )
    rows, total = docs.list_documents(session, user, flt, page.page, page.page_size, sort)
    return make_page(rows, total, page.page, page.page_size)


@router.get("/documents/{doc_id}", response_model=DocumentOut)
def get_document(doc_id: int, user: CurrentUser, session: SessionDep):
    return doc_out(docs.get_document(session, user, doc_id))


@router.put("/documents/{doc_id}", response_model=DocumentOut, summary="Edit a draft")
def update_document(
    doc_id: int, body: DocumentIn, user: CurrentUser, session: SessionDep, version: IfMatch
):
    """Only the owner, only while the document is a draft. Submitted documents change only through
    corrections. Send `If-Match: <row_version>` (from a previous GET) to guard against a concurrent
    edit; a mismatch returns 412."""
    check_row_version(docs.get_document(session, user, doc_id), version)
    return doc_out(docs.update_draft(session, user, doc_id, to_input(body)))


@router.post("/documents/{doc_id}/submit", response_model=DocumentOut)
def submit_document(doc_id: int, user: CurrentUser, session: SessionDep, version: IfMatch):
    """Optional `If-Match: <row_version>` guards against submitting a draft that changed elsewhere."""
    check_row_version(docs.get_document(session, user, doc_id), version)
    return doc_out(docs.submit(session, user, doc_id))


@router.post("/documents/{doc_id}/cancel", response_model=DocumentOut)
def cancel_document(
    doc_id: int, user: CurrentUser, session: SessionDep, body: CancelIn | None = None
):
    return doc_out(appr.cancel(session, user, doc_id, body.reason if body else ""))


@router.post(
    "/documents/{doc_id}/review/start", response_model=DocumentOut, summary="Start reviewing"
)
def start_review(doc_id: int, user: CurrentUser, session: SessionDep):
    return doc_out(appr.start_review(session, user, doc_id))


@router.post("/documents/{doc_id}/approve", response_model=DocumentOut)
def approve_document(
    doc_id: int,
    user: CurrentUser,
    session: SessionDep,
    version: IfMatch,
    body: DecisionIn | None = None,
):
    """Optional `If-Match: <row_version>` prevents approving a document two reviewers opened at once."""
    check_row_version(docs.get_document(session, user, doc_id), version)
    return doc_out(appr.approve(session, user, doc_id, body.note if body else ""))


@router.post("/documents/{doc_id}/reject", response_model=DocumentOut)
def reject_document(
    doc_id: int, body: DecisionIn, user: CurrentUser, session: SessionDep, version: IfMatch
):
    """A reason (`note`) is required. Optional `If-Match: <row_version>`."""
    check_row_version(docs.get_document(session, user, doc_id), version)
    return doc_out(appr.reject(session, user, doc_id, body.note))


@router.get(
    "/documents/{doc_id}/history",
    response_model=list[HistoryEvent],
    summary="Audit history of a document",
)
def document_history(doc_id: int, user: CurrentUser, session: SessionDep):
    docs.get_document(session, user, doc_id)  # permission check
    rows = session.execute(
        select(AuditEvent)
        .where(AuditEvent.entity_type == "document", AuditEvent.entity_id == doc_id)
        .order_by(AuditEvent.id)
    ).scalars()
    return [
        HistoryEvent(
            id=e.id,
            timestamp=e.timestamp,
            actor_id=e.actor_id,
            action=e.action,
            payload=json.loads(e.payload_json),
        )
        for e in rows
    ]


# ------------------------------------------------------------------ corrections
def correction_out(req: CorrectionRequest) -> CorrectionOut:
    return CorrectionOut(
        id=req.id,
        document_id=req.document_id,
        requested_by=req.requested_by,
        requested_at=req.requested_at,
        reason=req.reason,
        status=req.status,
        deadline_exception=req.deadline_exception,
        exception_reason=req.exception_reason,
        decided_by=req.decided_by,
        decided_at=req.decided_at,
        decision_note=req.decision_note,
        original=json.loads(req.original_json),
        proposed=json.loads(req.proposed_json),
    )


@router.post(
    "/documents/{doc_id}/corrections",
    response_model=CorrectionOut,
    status_code=201,
    summary="Request a correction of a submitted document",
)
def request_correction(doc_id: int, body: CorrectionIn, user: CurrentUser, session: SessionDep):
    """Inside the correction window only the owner may file; afterwards only users with the
    deadline-override permission, with a written justification (`override_reason`)."""
    req = corr.create_request(
        session,
        user,
        doc_id,
        body.header_changes,
        body.line_changes,
        body.reason,
        body.override_reason,
    )
    return correction_out(req)


@router.get(
    "/corrections", response_model=Page[CorrectionOut], summary="Correction requests you may see"
)
def list_corrections(
    user: CurrentUser, session: SessionDep, page: Pagination, pending_only: bool = False
):
    rows = corr.list_requests(session, user, pending_only)
    start = (page.page - 1) * page.page_size
    return make_page(
        [correction_out(r) for r in rows[start : start + page.page_size]],
        len(rows),
        page.page,
        page.page_size,
    )


@router.post("/corrections/{request_id}/decision", response_model=CorrectionOut)
def decide_correction(
    request_id: int, body: CorrectionDecisionIn, user: CurrentUser, session: SessionDep
):
    return correction_out(corr.decide_request(session, user, request_id, body.approve, body.note))


# ------------------------------------------------------------------ attachments
@router.post(
    "/documents/{doc_id}/attachments",
    response_model=AttachmentOut,
    status_code=201,
    summary="Upload an attachment to a draft",
)
def upload_attachment(
    doc_id: int, file: Annotated[UploadFile, File()], user: CurrentUser, session: SessionDep
):
    """PDF, PNG, JPG, WAV, MP3 or M4A up to the configured size. Content is checked against the extension."""
    limit = get_settings().max_upload_bytes
    data = file.file.read(limit + 1)  # never read more than limit+1 bytes into memory
    if len(data) > limit:
        raise UploadTooLarge(f"The file exceeds the {get_settings().max_upload_mb} MB limit.")
    return att.store_attachment(session, user, doc_id, file.filename or "upload", data)


@router.get("/attachments/{attachment_id}/download", summary="Download an attachment")
def download_attachment(attachment_id: int, user: CurrentUser, session: SessionDep):
    meta, data = att.read_attachment(session, user, attachment_id)
    safe = meta.original_name.replace('"', "")
    return Response(
        content=data,
        media_type=meta.mime_type,
        headers={
            "Content-Disposition": f'attachment; filename="{safe}"',
            "X-Content-Type-Options": "nosniff",
            "Cache-Control": "private, no-store",
        },
    )
