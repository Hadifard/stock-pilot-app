from __future__ import annotations

import json
from typing import Annotated, Literal

from fastapi import APIRouter, Query, Response
from sqlalchemy import func, select

from app.api.deps import CurrentUser, Pagination, SessionDep
from app.api.schemas import (
    AdminResetPasswordIn,
    AdminUserOut,
    AdminUserPatch,
    AuditEventOut,
    Page,
    make_page,
)
from app.database.models import AuditEvent
from app.security import audit_log
from app.security.authorization import Perm, require
from app.services import password_service
from app.services import reporting_service as rep
from app.services import user_admin_service as ua
from app.utils.exceptions import NotFound

router = APIRouter(tags=["Reports, audit and administration"])


@router.get("/reports/documents", summary="Export documents as CSV, Excel or PDF")
def export_documents(
    user: CurrentUser,
    session: SessionDep,
    format: Literal["csv", "xlsx", "pdf"] = "csv",
    status: Annotated[list[str] | None, Query()] = None,
):
    """Only documents you may see; includes generation time, reporting currency, filters and a synthetic-data note."""
    st = tuple(status or ())
    if format == "csv":
        data, mime = rep.export_csv(session, user, st), "text/csv"
    elif format == "xlsx":
        data, mime = (
            rep.export_excel(session, user, st),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    else:
        data, mime = rep.export_pdf(session, user, st), "application/pdf"
    return Response(
        data,
        media_type=mime,
        headers={
            "Content-Disposition": f'attachment; filename="documents.{format}"',
            "X-Content-Type-Options": "nosniff",
            "Cache-Control": "private, no-store",
        },
    )


@router.get(
    "/audit/events",
    response_model=Page[AuditEventOut],
    summary="Audit events (auditors, administrators)",
)
def audit_events(
    user: CurrentUser,
    session: SessionDep,
    page: Pagination,
    action: str | None = None,
    entity_type: str | None = None,
    entity_id: int | None = None,
    actor_id: int | None = None,
):
    require(user, Perm.AUDIT_VIEW)
    q = select(AuditEvent)
    for col, val in (
        (AuditEvent.entity_type, entity_type),
        (AuditEvent.entity_id, entity_id),
        (AuditEvent.actor_id, actor_id),
    ):
        if val is not None:
            q = q.where(col == val)
    if action:
        q = q.where(AuditEvent.action.like(f"{action}%"))
    total = session.execute(select(func.count()).select_from(q.subquery())).scalar_one()
    rows = session.execute(
        q.order_by(AuditEvent.id.desc())
        .limit(page.page_size)
        .offset((page.page - 1) * page.page_size)
    ).scalars()
    items = [
        AuditEventOut(
            id=e.id,
            timestamp=e.timestamp,
            actor_id=e.actor_id,
            action=e.action,
            entity_type=e.entity_type,
            entity_id=e.entity_id,
            payload=json.loads(e.payload_json),
            hash=e.hash,
        )
        for e in rows
    ]
    return make_page(items, total, page.page, page.page_size)


@router.get("/audit/verify", summary="Verify the audit hash chain")
def verify_audit(user: CurrentUser, session: SessionDep):
    """Detects casual modification or deletion. It cannot stop an attacker who controls the whole
    database and recomputes every hash (see docs/security_checklist.md)."""
    require(user, Perm.AUDIT_VIEW)
    r = audit_log.verify_chain(session)
    return {"ok": r.ok, "checked": r.checked, "first_bad_id": r.first_bad_id, "message": r.message}


@router.get(
    "/admin/users", response_model=Page[AdminUserOut], summary="List users (administrators)"
)
def admin_users(
    user: CurrentUser,
    session: SessionDep,
    page: Pagination,
    q: Annotated[str, Query(max_length=60)] = "",
):
    rows, total = ua.list_users(session, user, page.page, page.page_size, q)
    return make_page(rows, total, page.page, page.page_size)


@router.patch(
    "/admin/users/{user_id}",
    response_model=AdminUserOut,
    summary="Activate/deactivate or unlock a user",
)
def admin_update_user(user_id: int, body: AdminUserPatch, user: CurrentUser, session: SessionDep):
    return ua.update_user(session, user, user_id, body.is_active, body.unlock)


@router.post(
    "/admin/users/{user_id}/reset-password",
    status_code=204,
    summary="Set a temporary password (administrators)",
)
def admin_reset_password(
    user_id: int, body: AdminResetPasswordIn, user: CurrentUser, session: SessionDep
):
    """Requires admin.manage. The target user must change this password at next login; every
    existing token of that user is revoked immediately."""
    require(user, Perm.ADMIN_MANAGE)
    from app.database.models import User

    target = session.get(User, user_id)
    if target is None:
        raise NotFound(f"User {user_id} was not found.")
    password_service.admin_reset_password(session, user, target, body.temporary_password)
