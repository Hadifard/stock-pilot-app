from __future__ import annotations

import json
from datetime import date
from typing import Annotated, Any

import pandas as pd
from fastapi import APIRouter, Query
from pydantic import BaseModel

from app.api.deps import CurrentUser, Pagination, SessionDep
from app.api.schemas import MatchDecisionIn, Page, ReviewIn, make_page
from app.services import analytics_service as an
from app.services import price_service as ps
from app.services import reporting_service as rep
from app.utils.exceptions import ValidationError

router = APIRouter(prefix="/analytics", tags=["Analytics"])
GROUPS = {
    "month": "month",
    "category": "category",
    "project": "project",
    "supplier": "supplier",
    "org_unit": "org_unit",
    "currency": "currency",
    "status": "status",
}


def records(df: pd.DataFrame) -> list[dict]:
    """DataFrame -> JSON-safe rows (numbers as float, everything else as str/None)."""
    out = []
    for row in df.to_dict("records"):
        out.append(
            {
                k: (
                    None
                    if pd.isna(v)
                    else (
                        float(v)
                        if isinstance(v, int | float)
                        or hasattr(v, "__float__")
                        and not isinstance(v, str | bool)
                        else (v if isinstance(v, str | bool) else str(v))
                    )
                )
                for k, v in row.items()
            }
        )
    return out


@router.get("/kpis", summary="Executive KPIs (scoped to what you may see)")
def kpis(user: CurrentUser, session: SessionDep) -> dict[str, Any]:
    k = rep.compute_kpis(session, user)
    return {
        "submitted_spend": str(k.submitted_total_reporting),
        "reporting_currency": k.reporting_currency,
        "documents_counted": k.documents_counted,
        "pending_approvals": k.pending_approvals,
        "pending_corrections": k.pending_corrections,
        "avg_approval_hours": k.avg_approval_hours,
        "documents_without_fx_rate": k.missing_fx_count,
        "definitions": {
            "submitted_spend": "SUM(total_reporting) of documents not draft/cancelled/rejected",
            "pending_approvals": "status submitted, resubmitted or under_review",
            "avg_approval_hours": "mean(decided_at - submitted_at) over approved documents",
        },
        "synthetic_data_notice": rep.SYNTHETIC_NOTE,
    }


@router.get("/operations", summary="Counts for operational monitoring")
def operations(user: CurrentUser, session: SessionDep) -> dict[str, Any]:
    return rep.operations_summary(session, user)


@router.get("/spend", summary="Net spend grouped by a dimension, with filters")
def spend(
    user: CurrentUser,
    session: SessionDep,
    group_by: Annotated[
        str,
        Query(description="month | category | project | supplier | org_unit | currency | status"),
    ] = "month",
    date_from: date | None = None,
    date_to: date | None = None,
    org_unit_id: int | None = None,
    project_id: int | None = None,
    supplier_id: int | None = None,
    category: str | None = None,
    currency: str | None = None,
    status: Annotated[list[str] | None, Query()] = None,
) -> dict[str, Any]:
    if group_by not in GROUPS:
        raise ValidationError(f"group_by must be one of: {', '.join(GROUPS)}.")
    flt = rep.SpendFilter(
        date_from,
        date_to,
        org_unit_id,
        project_id,
        supplier_id,
        category,
        currency,
        tuple(status or ()),
    )
    df = rep.spend_lines(session, user, flt)
    if df.empty:
        rows: list[dict] = []
    else:
        g = (
            df.groupby(GROUPS[group_by])
            .agg(net_spend=("net_reporting", "sum"), documents=("doc_id", "nunique"))
            .reset_index()
            .rename(columns={GROUPS[group_by]: "key"})
        )
        rows = records(
            g.sort_values("net_spend", ascending=False)
            if group_by != "month"
            else g.sort_values("key")
        )
    return {
        "group_by": group_by,
        "rows": rows,
        "missing_fx_lines": df.attrs.get("missing_fx", 0),
        "basis": "Net line amounts (excluding tax and shipping) converted to the reporting currency with the stored rate.",
    }


@router.get("/budget-utilization", summary="Budget use per project (documents you can see)")
def budget_utilization(user: CurrentUser, session: SessionDep) -> list[dict]:
    return records(rep.budget_utilization(session, user))


@router.get(
    "/inconsistent-totals", summary="Documents whose stored total does not match their lines"
)
def inconsistent_totals(user: CurrentUser, session: SessionDep) -> list[dict]:
    return records(rep.inconsistent_totals(session, user))


@router.get("/forecast", summary="Monthly spend forecast with backtest and baselines")
def forecast(
    user: CurrentUser,
    session: SessionDep,
    org_unit_id: int | None = None,
    project_id: int | None = None,
    horizon: Annotated[int, Query(ge=1, le=12)] = 6,
) -> dict[str, Any]:
    r = an.spend_forecast(session, user, org_unit_id, project_id, horizon)
    return {
        "chosen_model": r.chosen,
        "history": [{"month": str(p), "spend": float(v)} for p, v in r.history.items()],
        "forecast": [
            {"month": str(p), **{k: float(v) for k, v in row.items()}}
            for p, row in r.forecast.iterrows()
        ],
        "backtest": [
            {"month": str(p), **{k: float(v) for k, v in row.items()}}
            for p, row in r.backtest.iterrows()
        ],
        "metrics": r.metrics,
        "warnings": r.warnings,
        "disclaimer": "An estimate from historical spend, not a guarantee of future expenditure or savings.",
    }


class AlertOut(BaseModel):
    id: int
    document_id: int
    doc_number: str
    score: float
    severity: str
    rules: list[str]
    factors: list[dict[str, Any]]
    status: str
    disposition: str | None
    review_note: str | None
    model_version: str


@router.get(
    "/alerts", response_model=Page[AlertOut], summary="Unusual transactions requiring review"
)
def alerts(user: CurrentUser, session: SessionDep, page: Pagination, status: str | None = "new"):
    """An alert is a prompt for human review, not a finding of error, fraud or misconduct."""
    rows = an.list_alerts(session, user, None if status in (None, "all") else status, limit=1000)
    start = (page.page - 1) * page.page_size
    items = [
        AlertOut(
            id=a.id,
            document_id=d.id,
            doc_number=d.doc_number,
            score=a.score,
            severity=a.severity,
            rules=json.loads(a.rules_json),
            factors=json.loads(a.factors_json),
            status=a.status,
            disposition=a.disposition,
            review_note=a.review_note,
            model_version=a.model_version,
        )
        for a, d in rows[start : start + page.page_size]
    ]
    return make_page(items, len(rows), page.page, page.page_size)


@router.post("/alerts/{alert_id}/review", response_model=AlertOut)
def review_alert(alert_id: int, body: ReviewIn, user: CurrentUser, session: SessionDep):
    a = an.review_alert(session, user, alert_id, body.disposition, body.note)
    from app.database.models import PurchaseDocument

    d = session.get(PurchaseDocument, a.document_id)
    return AlertOut(
        id=a.id,
        document_id=d.id,
        doc_number=d.doc_number,
        score=a.score,
        severity=a.severity,
        rules=json.loads(a.rules_json),
        factors=json.loads(a.factors_json),
        status=a.status,
        disposition=a.disposition,
        review_note=a.review_note,
        model_version=a.model_version,
    )


class DuplicateOut(BaseModel):
    id: int
    doc_a_id: int
    doc_b_id: int
    score: float
    reasons: list[str]
    status: str
    disposition: str | None
    review_note: str | None


def _dup(c) -> DuplicateOut:
    return DuplicateOut(
        id=c.id,
        doc_a_id=c.doc_a_id,
        doc_b_id=c.doc_b_id,
        score=c.score,
        reasons=json.loads(c.reasons_json),
        status=c.status,
        disposition=c.disposition,
        review_note=c.review_note,
    )


@router.get(
    "/duplicates", response_model=Page[DuplicateOut], summary="Possible duplicate documents"
)
def duplicates(
    user: CurrentUser, session: SessionDep, page: Pagination, status: str | None = "new"
):
    rows = an.list_duplicates(
        session, user, None if status in (None, "all") else status, limit=1000
    )
    start = (page.page - 1) * page.page_size
    return make_page(
        [_dup(c) for c in rows[start : start + page.page_size]],
        len(rows),
        page.page,
        page.page_size,
    )


@router.post("/duplicates/{candidate_id}/review", response_model=DuplicateOut)
def review_duplicate(candidate_id: int, body: ReviewIn, user: CurrentUser, session: SessionDep):
    return _dup(an.review_duplicate(session, user, candidate_id, body.disposition, body.note))


@router.get("/price-benchmark", summary="Benchmark an item against comparable internal purchases")
def price_benchmark(
    user: CurrentUser,
    session: SessionDep,
    description: Annotated[str, Query(min_length=1, max_length=300)],
    unit: str = "pcs",
) -> dict[str, Any]:
    """Attribute-first matching. Returns 'No verified benchmark available' instead of inventing a price."""
    b = ps.benchmark(session, user, description, unit)
    return {
        "query": b.query,
        "unit": b.unit,
        "samples": b.n_samples,
        "stats_eur": b.stats,
        "message": b.message,
        "benchmark_available": b.stats is not None,
        "comparables": [
            {
                "description": d,
                "level": r.level,
                "score": r.score,
                "matched": r.matched,
                "conflicts": r.conflicts,
                "missing": r.missing,
                "text_similarity": r.text_similarity,
                "explanation": r.explanation,
                "purchases": n,
            }
            for d, r, n in b.comparables
        ],
        "purchases": records(b.purchases.head(50)) if not b.purchases.empty else [],
        "note": "Internal history (synthetic in the demo). No external market prices are used.",
    }


@router.post("/price-benchmark/decisions", status_code=204, summary="Confirm or reject a match")
def match_decision(body: MatchDecisionIn, user: CurrentUser, session: SessionDep):
    ps.confirm_match(session, user, body.text_a, body.text_b, body.equivalent)
