from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, File, UploadFile
from sqlalchemy import func, select

from app.api import jobs
from app.api.deps import CurrentUser, Pagination, SessionDep
from app.api.schemas import ExtractionOut, JobCreate, JobOut, Page, ResolutionsIn, make_page
from app.config import get_settings
from app.database.models import BackgroundJob
from app.security.authorization import Perm, has_permission
from app.services import extraction_service as xs
from app.utils.exceptions import NotFound, UploadTooLarge

router = APIRouter(tags=["Extraction and jobs"])


def _read(file: UploadFile) -> bytes:
    limit = get_settings().max_upload_bytes
    data = file.file.read(limit + 1)
    if len(data) > limit:
        raise UploadTooLarge(f"The file exceeds the {get_settings().max_upload_mb} MB limit.")
    return data


def _extraction_out(o: xs.ExtractionOutcome) -> ExtractionOut:
    def ser(v):
        return xs._ser(v)

    return ExtractionOut(
        record_id=o.record_id,
        status=o.status,
        source_type=o.source_type,
        method=o.method,
        text=o.text,
        fields={
            k: {
                "value": ser(f.value),
                "confidence": f.confidence,
                "evidence": f.evidence,
                "candidates": ser(f.candidates),
            }
            for k, f in o.fields.items()
        },
        lines=[
            {
                "description": ln.description,
                "quantity": str(ln.quantity),
                "unit": ln.unit,
                "unit_price": str(ln.unit_price),
                "amount": str(ln.amount),
                "consistent": ln.consistent,
            }
            for ln in o.lines
        ],
        issues=o.issues,
        missing=o.missing,
        warnings=o.warnings,
        ocr_confidence=o.ocr_confidence,
    )


@router.post(
    "/extraction",
    response_model=ExtractionOut,
    summary="Extract candidate values from a file (synchronous)",
)
def extract(file: Annotated[UploadFile, File()], user: CurrentUser, session: SessionDep):
    """OCR/PDF/speech extraction with fixed rules. Values are *candidates*: the client must show them
    to the user, highlight conflicts and record the user's choices via `/extraction/{id}/resolutions`.
    Large scans should use the asynchronous `/jobs/extraction` endpoint."""
    return _extraction_out(xs.run_extraction(session, user, file.filename or "upload", _read(file)))


@router.post(
    "/extraction/{record_id}/resolutions",
    status_code=204,
    summary="Record which values the user chose",
)
def record_resolutions(record_id: int, body: ResolutionsIn, user: CurrentUser, session: SessionDep):
    xs.record_resolutions(session, user, record_id, body.resolutions, body.document_id)


# ------------------------------------------------------------------ jobs
def job_out(job: BackgroundJob) -> JobOut:
    import json

    return JobOut(
        id=job.id,
        kind=job.kind,
        status=job.status,
        created_by=job.created_by,
        created_at=job.created_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
        result=json.loads(job.result_json) if job.result_json else None,
        error=job.error,
    )


@router.post("/jobs", response_model=JobOut, status_code=202, summary="Start a background job")
def create_job(body: JobCreate, user: CurrentUser, session: SessionDep, tasks: BackgroundTasks):
    """Kinds: `anomaly_scan`, `duplicate_scan` (need alert.review), `train_anomaly_model` (admin).
    Poll `GET /jobs/{id}`."""
    job = jobs.enqueue(session, user, body.kind)
    session.commit()  # the row must be visible before a worker (inline or separate process) reads it
    if get_settings().jobs_mode == "inline":
        tasks.add_task(jobs.run_job, job.id)
    return job_out(job)


@router.post(
    "/jobs/extraction",
    response_model=JobOut,
    status_code=202,
    summary="Extract from a file in the background",
)
def create_extraction_job(
    file: Annotated[UploadFile, File()],
    user: CurrentUser,
    session: SessionDep,
    tasks: BackgroundTasks,
):
    data = _read(file)
    from app.services.attachment_service import validate_upload

    validate_upload(file.filename or "upload", data)  # reject bad files before queueing
    stored = jobs.stage_upload(file.filename or "upload", data)
    job = jobs.enqueue(
        session, user, "extraction", {"stored": stored, "filename": file.filename or "upload"}
    )
    session.commit()
    tasks.add_task(jobs.run_job, job.id)
    return job_out(job)


@router.get("/jobs/{job_id}", response_model=JobOut)
def get_job(job_id: int, user: CurrentUser, session: SessionDep):
    job = session.get(BackgroundJob, job_id)
    if job is None or (job.created_by != user.id and not has_permission(user, Perm.ADMIN_MANAGE)):
        raise NotFound(
            f"Job {job_id} was not found."
        )  # same answer for 'not yours' (no enumeration)
    return job_out(job)


@router.get("/jobs", response_model=Page[JobOut], summary="My jobs")
def list_jobs(user: CurrentUser, session: SessionDep, page: Pagination):
    q = select(BackgroundJob).where(BackgroundJob.created_by == user.id)
    total = session.execute(select(func.count()).select_from(q.subquery())).scalar_one()
    rows = session.execute(
        q.order_by(BackgroundJob.id.desc())
        .limit(page.page_size)
        .offset((page.page - 1) * page.page_size)
    ).scalars()
    return make_page([job_out(j) for j in rows], total, page.page, page.page_size)
