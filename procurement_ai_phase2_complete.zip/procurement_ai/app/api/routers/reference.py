from __future__ import annotations

from fastapi import APIRouter, Query
from sqlalchemy import func, select

from app.api.deps import CurrentUser, Pagination, SessionDep
from app.api.schemas import CostCenterOut, OrgUnitOut, Page, ProjectOut, SupplierOut, make_page
from app.database.models import CostCenter, OrgUnit, Project, Supplier

router = APIRouter(prefix="/reference", tags=["Reference data"])


def _page(session, q, page, order):
    total = session.execute(select(func.count()).select_from(q.subquery())).scalar_one()
    rows = (
        session.execute(
            q.order_by(order).limit(page.page_size).offset((page.page - 1) * page.page_size)
        )
        .scalars()
        .all()
    )
    return rows, total


@router.get("/org-units", response_model=Page[OrgUnitOut])
def org_units(user: CurrentUser, session: SessionDep, page: Pagination):
    rows, total = _page(session, select(OrgUnit), page, OrgUnit.code)
    return make_page(rows, total, page.page, page.page_size)


@router.get("/projects", response_model=Page[ProjectOut])
def projects(
    user: CurrentUser,
    session: SessionDep,
    page: Pagination,
    org_unit_id: int | None = None,
    q: str | None = Query(None, max_length=60),
):
    query = select(Project)
    if org_unit_id:
        query = query.where(Project.org_unit_id == org_unit_id)
    if q:
        query = query.where(Project.code.ilike(f"%{q}%") | Project.name.ilike(f"%{q}%"))
    rows, total = _page(session, query, page, Project.code)
    return make_page(rows, total, page.page, page.page_size)


@router.get("/cost-centers", response_model=Page[CostCenterOut])
def cost_centers(
    user: CurrentUser, session: SessionDep, page: Pagination, org_unit_id: int | None = None
):
    """Defaults to the caller's own organisational unit."""
    query = select(CostCenter).where(CostCenter.org_unit_id == (org_unit_id or user.org_unit_id))
    rows, total = _page(session, query, page, CostCenter.code)
    return make_page(rows, total, page.page, page.page_size)


@router.get("/suppliers", response_model=Page[SupplierOut])
def suppliers(
    user: CurrentUser,
    session: SessionDep,
    page: Pagination,
    q: str | None = Query(None, max_length=60),
):
    query = select(Supplier)
    if q:
        query = query.where(Supplier.name.ilike(f"%{q}%"))
    rows, total = _page(session, query, page, Supplier.name)
    return make_page(rows, total, page.page, page.page_size)
