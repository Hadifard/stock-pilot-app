from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.security import OAuth2PasswordRequestForm

from app.api import ratelimit
from app.api.deps import CurrentUserAllowPending, SessionDep
from app.api.schemas import ChangePasswordIn, MeOut, RefreshRequest, TokenPair
from app.api.tokens import (
    create_access_token,
    issue_refresh_token,
    revoke_token,
    rotate_refresh_token,
)
from app.config import get_settings
from app.database.models import User
from app.security.authentication import authenticate
from app.security.authorization import ROLE_PERMISSIONS, Role
from app.services import password_service

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _pair(session: SessionDep, user: User, family_id: str | None = None) -> TokenPair:
    refresh = issue_refresh_token(session, user, family_id)
    return TokenPair(
        access_token=create_access_token(user),
        refresh_token=refresh,
        expires_in=get_settings().jwt_access_minutes * 60,
        must_change_password=user.must_change_password,
    )


@router.post("/login", response_model=TokenPair, summary="Sign in (OAuth2 password flow)")
def login(
    request: Request, form: Annotated[OAuth2PasswordRequestForm, Depends()], session: SessionDep
):
    """Exchange username and password for an access and a refresh token.

    Rate-limited per client IP. After repeated failures the account is locked for a while; the
    response never reveals whether the username exists or the account is locked. If
    `must_change_password` is true, every endpoint except `/auth/me` and `/auth/change-password`
    returns 403 `password_change_required` until the password is changed.
    """
    ratelimit.check("login", ratelimit.client_ip(request), get_settings().rate_limit_login_per_min)
    return _pair(session, authenticate(session, form.username, form.password))


@router.post("/refresh", response_model=TokenPair, summary="Rotate a refresh token")
def refresh(body: RefreshRequest, session: SessionDep):
    """Each refresh token can be used once. Replaying a used or revoked token revokes its whole
    token family (possible theft), forcing a fresh login."""
    user, new_refresh = rotate_refresh_token(session, body.refresh_token)
    return TokenPair(
        access_token=create_access_token(user),
        refresh_token=new_refresh,
        expires_in=get_settings().jwt_access_minutes * 60,
        must_change_password=user.must_change_password,
    )


@router.post("/logout", status_code=204, summary="Revoke all tokens of the current user")
def logout(user: CurrentUserAllowPending, session: SessionDep, body: RefreshRequest | None = None):
    user.token_version += 1
    if body:
        revoke_token(session, body.refresh_token)
    from app.security import audit_log

    audit_log.record(
        session, actor_id=user.id, action="auth.logout", entity_type="user", entity_id=user.id
    )


@router.post("/change-password", status_code=204, summary="Change your own password")
def change_password(body: ChangePasswordIn, user: CurrentUserAllowPending, session: SessionDep):
    """Requires the current password. Revokes every previously issued token; sign in again afterwards."""
    password_service.change_password(session, user, body.current_password, body.new_password)


@router.get("/me", response_model=MeOut, summary="Current user and permissions")
def me(user: CurrentUserAllowPending):
    perms = sorted(p.value for p in ROLE_PERMISSIONS[Role(user.role)])
    return MeOut(
        id=user.id,
        username=user.username,
        full_name=user.full_name,
        role=user.role,
        org_unit_id=user.org_unit_id,
        is_active=user.is_active,
        permissions=perms,
        must_change_password=user.must_change_password,
    )
