"""JWT access tokens (HS256) + rotating, server-tracked refresh tokens.

Access tokens are short-lived and stateless. Refresh tokens are long-lived and are issued one at
a time inside a "family": each refresh call consumes the presented token and issues a new one in
the same family. If a *used or revoked* refresh token is presented again (token theft / replay),
the whole family is revoked, forcing re-login. A user's `token_version` additionally invalidates
every access token on logout or admin deactivation.
"""

from __future__ import annotations

import logging
import secrets
import uuid
from datetime import timedelta

import jwt
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import RefreshToken, User
from app.utils.dates import utcnow
from app.utils.exceptions import AuthenticationError

log = logging.getLogger(__name__)
ALGORITHM = "HS256"
_ephemeral_secret: str | None = None


def signing_secret() -> str:
    global _ephemeral_secret
    settings = get_settings()
    if settings.jwt_secret:
        if len(settings.jwt_secret) < 32:
            raise RuntimeError("PROCUREMENT_JWT_SECRET must be at least 32 characters.")
        return settings.jwt_secret
    if settings.environment == "production":
        raise RuntimeError("PROCUREMENT_JWT_SECRET is required when PROCUREMENT_ENV=production.")
    if _ephemeral_secret is None:
        _ephemeral_secret = secrets.token_urlsafe(48)
        log.warning("No PROCUREMENT_JWT_SECRET set: using a random development secret.")
    return _ephemeral_secret


def create_access_token(user: User) -> str:
    now = utcnow()
    payload = {
        "sub": str(user.id),
        "typ": "access",
        "ver": user.token_version,
        "iat": now,
        "exp": now + timedelta(minutes=get_settings().jwt_access_minutes),
        "jti": uuid.uuid4().hex,
        "pwd": user.must_change_password,
    }
    return jwt.encode(payload, signing_secret(), algorithm=ALGORITHM)


def _encode_refresh(user: User, jti: str, family_id: str, exp) -> str:
    now = utcnow()
    payload = {
        "sub": str(user.id),
        "typ": "refresh",
        "ver": user.token_version,
        "iat": now,
        "exp": exp,
        "jti": jti,
        "fam": family_id,
    }
    return jwt.encode(payload, signing_secret(), algorithm=ALGORITHM)


def issue_refresh_token(session: Session, user: User, family_id: str | None = None) -> str:
    """Start (family_id=None) or continue a refresh-token family."""
    jti = uuid.uuid4().hex
    fam = family_id or uuid.uuid4().hex
    exp = utcnow() + timedelta(days=get_settings().jwt_refresh_days)
    session.add(RefreshToken(jti=jti, user_id=user.id, family_id=fam, expires_at=exp))
    return _encode_refresh(user, jti, fam, exp)


def decode_token(token: str, expected_type: str) -> dict:
    try:
        claims = jwt.decode(
            token,
            signing_secret(),
            algorithms=[ALGORITHM],
            options={"require": ["exp", "iat", "sub", "typ"]},
        )
    except jwt.PyJWTError as exc:
        raise AuthenticationError("Invalid or expired token.") from exc
    if claims.get("typ") != expected_type:
        raise AuthenticationError("Invalid token type.")
    return claims


def rotate_refresh_token(session: Session, token: str) -> tuple[User, str]:
    """Verify, consume and replace a refresh token. Returns (user, new_refresh_token).

    Presenting an already-used or revoked token revokes its whole family (possible theft).
    """
    claims = decode_token(token, "refresh")
    user = session.get(User, int(claims["sub"]))
    if user is None or not user.is_active or claims.get("ver") != user.token_version:
        raise AuthenticationError("Invalid or expired token.")
    record = session.get(RefreshToken, claims["jti"])
    if record is None or record.user_id != user.id:
        raise AuthenticationError("Invalid or expired token.")
    if record.used_at is not None or record.revoked_at is not None:
        revoke_family(session, record.family_id)
        session.commit()  # the revocation must survive even though this request then fails
        log.warning(
            "Refresh token reuse detected for user %s; family %s revoked", user.id, record.family_id
        )
        raise AuthenticationError("This refresh token was already used. Please sign in again.")
    record.used_at = utcnow()
    new_token = issue_refresh_token(session, user, record.family_id)
    return user, new_token


def revoke_family(session: Session, family_id: str) -> None:
    for rt in session.execute(
        select(RefreshToken).where(
            RefreshToken.family_id == family_id, RefreshToken.revoked_at.is_(None)
        )
    ).scalars():
        rt.revoked_at = utcnow()


def revoke_token(session: Session, token: str) -> None:
    """Best-effort revoke of one refresh token (used on logout); ignores invalid tokens."""
    try:
        claims = decode_token(token, "refresh")
    except AuthenticationError:
        return
    record = session.get(RefreshToken, claims.get("jti"))
    if record is not None:
        revoke_family(session, record.family_id)
