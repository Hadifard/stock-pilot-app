"""FastAPI application:  uvicorn app.api.main:app

Run `alembic upgrade head` (or `python -m scripts.initialize_database`) before the first start.
Interactive documentation: /api/v1/docs (Swagger UI) and /api/v1/redoc.
"""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.api import ratelimit
from app.api.errors import install_error_handlers
from app.api.routers import admin, analytics, auth, documents, extraction, reference
from app.api.tokens import signing_secret
from app.config import get_settings
from app.database.session import get_engine, init_engine
from app.utils.exceptions import RateLimited
from app.utils.logging_config import configure_logging

log = logging.getLogger("procurement.api")
API_PREFIX = "/api/v1"
TAGS = [
    {"name": "Authentication", "description": "Sign in, refresh and revoke tokens."},
    {"name": "Reference data", "description": "Lookup lists for forms."},
    {
        "name": "Documents",
        "description": "Purchase documents, workflow, corrections and attachments.",
    },
    {
        "name": "Extraction and jobs",
        "description": "OCR/PDF/speech candidates and background jobs.",
    },
    {
        "name": "Analytics",
        "description": "KPIs, spend, forecast, alerts, duplicates, price benchmark.",
    },
    {"name": "Reports, audit and administration", "description": "Exports, audit trail, users."},
    {"name": "Health", "description": "Liveness and readiness."},
]
DESCRIPTION = """
REST API for the procurement intelligence platform (Phase 2). All business rules live in shared
services; this layer adds authentication, validation, pagination and transport concerns.

* **Demo data is synthetic.** Nothing returned here represents real expenditure or verified prices.
* Errors use one format: `{"error": {"code", "message", "details", "request_id"}}`.
* Lists are paginated (`page`, `page_size` <= 100) and sortable where documented.
"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    configure_logging(settings.log_level)
    signing_secret()  # fail at startup if production has no secret
    init_engine()
    log.info("API started (env=%s)", settings.environment)
    yield
    get_engine().dispose()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="Procurement Intelligence API",
        version="2.0.0",
        description=DESCRIPTION,
        openapi_tags=TAGS,
        openapi_url=f"{API_PREFIX}/openapi.json",
        docs_url=f"{API_PREFIX}/docs",
        redoc_url=f"{API_PREFIX}/redoc",
        lifespan=lifespan,
    )
    install_error_handlers(app)
    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(settings.cors_origins),
            allow_credentials=False,
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
            allow_headers=["Authorization", "Content-Type"],
        )

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        request.state.request_id = request.headers.get("X-Request-ID", "")[:64] or uuid.uuid4().hex
        if request.url.path.startswith(API_PREFIX) and "/auth/login" not in request.url.path:
            try:
                ratelimit.check(
                    "api", ratelimit.client_ip(request), get_settings().rate_limit_per_min
                )
            except RateLimited as exc:
                return JSONResponse(
                    {
                        "error": {
                            "code": "rate_limited",
                            "message": str(exc),
                            "details": [],
                            "request_id": request.state.request_id,
                        }
                    },
                    status_code=429,
                    headers={"Retry-After": "60", "X-Request-ID": request.state.request_id},
                )
        start = time.perf_counter()
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        if request.url.path.startswith(API_PREFIX) and "/docs" not in request.url.path:
            response.headers.setdefault("Cache-Control", "no-store")
        log.info(
            "%s %s -> %s (%.0f ms) [%s]",
            request.method,
            request.url.path,
            response.status_code,
            (time.perf_counter() - start) * 1000,
            request.state.request_id,
        )
        return response

    for r in (auth, reference, documents, extraction, analytics, admin):
        app.include_router(r.router, prefix=API_PREFIX)

    @app.get("/health", tags=["Health"], summary="Liveness")
    def health():
        return {"status": "ok"}

    @app.get(
        "/health/ready", tags=["Health"], summary="Readiness (database reachable and migrated)"
    )
    def ready():
        try:
            with get_engine().connect() as c:
                c.execute(text("SELECT 1 FROM users LIMIT 1"))
        except Exception:
            return JSONResponse(
                {"status": "not_ready", "hint": "run: alembic upgrade head"}, status_code=503
            )
        return {"status": "ready"}

    return app


app = create_app()
