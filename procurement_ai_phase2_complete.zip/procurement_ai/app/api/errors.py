"""One error format for every failure: {"error": {"code", "message", "details", "request_id"}}."""

from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.exc import StaleDataError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.utils.exceptions import (
    AuthenticationError,
    CorrectionWindowExpired,
    DomainError,
    InvalidTransition,
    NotFound,
    PasswordChangeRequired,
    PermissionDenied,
    PreconditionFailed,
    RateLimited,
    UploadRejected,
    UploadTooLarge,
    ValidationError,
)

log = logging.getLogger("procurement.api")


def _body(request: Request, code: str, message: str, details: list | None = None) -> dict:
    return {
        "error": {
            "code": code,
            "message": message,
            "details": details or [],
            "request_id": getattr(request.state, "request_id", None),
        }
    }


def _resp(request: Request, status: int, code: str, message: str, details=None, headers=None):
    return JSONResponse(_body(request, code, message, details), status_code=status, headers=headers)


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(ValidationError)
    async def _domain_validation(request: Request, exc: ValidationError):
        return _resp(
            request,
            422,
            "validation_error",
            "The request contains invalid values.",
            [{"loc": [], "msg": m} for m in exc.errors],
        )

    @app.exception_handler(RequestValidationError)
    async def _schema_validation(request: Request, exc: RequestValidationError):
        details = [
            {"loc": [str(x) for x in e["loc"]], "msg": e["msg"], "type": e["type"]}
            for e in exc.errors()
        ]
        return _resp(request, 422, "validation_error", "The request is malformed.", details)

    @app.exception_handler(AuthenticationError)
    async def _auth(request: Request, exc: AuthenticationError):
        return _resp(
            request, 401, "unauthenticated", str(exc), headers={"WWW-Authenticate": "Bearer"}
        )

    @app.exception_handler(PasswordChangeRequired)
    async def _pwd(request: Request, exc: PasswordChangeRequired):
        return _resp(
            request,
            403,
            "password_change_required",
            "You must change your password before continuing.",
        )

    @app.exception_handler(PreconditionFailed)
    async def _precondition(request: Request, exc: PreconditionFailed):
        return _resp(request, 412, "precondition_failed", str(exc))

    @app.exception_handler(PermissionDenied)
    async def _perm(request: Request, exc: PermissionDenied):
        return _resp(request, 403, "forbidden", str(exc))

    @app.exception_handler(NotFound)
    async def _nf(request: Request, exc: NotFound):
        return _resp(request, 404, "not_found", str(exc))

    @app.exception_handler(InvalidTransition)
    async def _trans(request: Request, exc: InvalidTransition):
        return _resp(request, 409, "invalid_transition", str(exc))

    @app.exception_handler(CorrectionWindowExpired)
    async def _window(request: Request, exc: CorrectionWindowExpired):
        return _resp(request, 409, "correction_window_expired", str(exc))

    @app.exception_handler(RateLimited)
    async def _rate(request: Request, exc: RateLimited):
        return _resp(request, 429, "rate_limited", str(exc), headers={"Retry-After": "60"})

    @app.exception_handler(UploadTooLarge)
    async def _big(request: Request, exc: UploadTooLarge):
        return _resp(request, 413, "upload_too_large", str(exc))

    @app.exception_handler(UploadRejected)
    async def _upload(request: Request, exc: UploadRejected):
        return _resp(request, 400, "upload_rejected", str(exc))

    @app.exception_handler(DomainError)
    async def _domain(request: Request, exc: DomainError):
        return _resp(request, 400, "bad_request", str(exc))

    @app.exception_handler(StaleDataError)
    async def _stale(request: Request, exc: StaleDataError):
        return _resp(
            request,
            409,
            "concurrent_modification",
            "The record was changed by someone else. Reload it and try again.",
        )

    @app.exception_handler(IntegrityError)
    async def _integrity(request: Request, exc: IntegrityError):
        log.warning("Integrity error: %s", exc.orig)
        return _resp(request, 409, "conflict", "The request conflicts with existing data.")

    @app.exception_handler(StarletteHTTPException)
    async def _http(request: Request, exc: StarletteHTTPException):
        code = {404: "not_found", 405: "method_not_allowed"}.get(exc.status_code, "http_error")
        return _resp(
            request, exc.status_code, code, str(exc.detail), headers=getattr(exc, "headers", None)
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        log.exception("Unhandled error (request %s)", getattr(request.state, "request_id", None))
        return _resp(request, 500, "internal_error", "An internal error occurred.")
