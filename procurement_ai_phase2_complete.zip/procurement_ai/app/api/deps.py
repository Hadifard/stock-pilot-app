"""FastAPI dependencies: transactional session, current user, pagination."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Header, Query
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.api.tokens import decode_token
from app.database.models import User
from app.database.session import new_session
from app.security.authorization import Perm, require
from app.utils.exceptions import AuthenticationError, PasswordChangeRequired, PreconditionFailed

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


def get_session() -> Iterator[Session]:
    """One transaction per request: commit if the handler succeeded, otherwise roll back."""
    session = new_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


SessionDep = Annotated[Session, Depends(get_session)]


def _resolve_user(session: Session, token: str | None) -> tuple[User, dict]:
    if not token:
        raise AuthenticationError("Not authenticated.")
    claims = decode_token(token, "access")
    user = session.get(User, int(claims["sub"]))
    if user is None or not user.is_active or claims.get("ver") != user.token_version:
        raise AuthenticationError("Invalid or expired token.")
    return user, claims


def get_current_user(
    session: SessionDep, token: Annotated[str | None, Depends(oauth2_scheme)]
) -> User:
    """Normal protected-route dependency: blocks access while a password change is pending."""
    user, claims = _resolve_user(session, token)
    if claims.get("pwd"):
        raise PasswordChangeRequired("You must change your password before continuing.")
    return user


def get_current_user_allow_pending_password(
    session: SessionDep, token: Annotated[str | None, Depends(oauth2_scheme)]
) -> User:
    """Used only by /auth/me and /auth/change-password, which must work even when a password
    change is pending (otherwise the user could never satisfy the requirement)."""
    user, _claims = _resolve_user(session, token)
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]
CurrentUserAllowPending = Annotated[User, Depends(get_current_user_allow_pending_password)]


def require_permission(perm: Perm):
    """Route-level early check (services check again; never rely on only one layer)."""

    def dep(user: CurrentUser) -> User:
        require(user, perm)
        return user

    return dep


@dataclass
class PageParams:
    page: int
    page_size: int


def page_params(
    page: Annotated[int, Query(ge=1, description="1-based page number")] = 1,
    page_size: Annotated[int, Query(ge=1, le=100, description="Items per page (max 100)")] = 25,
) -> PageParams:
    return PageParams(page, page_size)


Pagination = Annotated[PageParams, Depends(page_params)]


def if_match(if_match: Annotated[str | None, Header(alias="If-Match")] = None) -> int | None:
    """Optional optimistic-concurrency precondition: parses an integer row_version from If-Match.

    Clients should send the `row_version` from a previous GET. If present and it no longer
    matches the stored row, the request fails with 412 before any change is applied.
    """
    if if_match is None:
        return None
    try:
        return int(if_match.strip('"'))
    except ValueError as exc:
        raise PreconditionFailed(
            "If-Match must be the document's row_version (an integer)."
        ) from exc


IfMatch = Annotated[int | None, Depends(if_match)]


def check_row_version(doc, expected: int | None) -> None:
    if expected is not None and doc.row_version != expected:
        raise PreconditionFailed(
            f"The document changed since you last read it (expected version {expected}, now {doc.row_version}). Reload and retry."
        )
