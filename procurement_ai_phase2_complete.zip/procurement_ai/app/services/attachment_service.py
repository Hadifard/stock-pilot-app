"""Safe attachment storage: whitelist, magic-byte check, size limit, controlled paths."""

from __future__ import annotations

import re
import uuid
from pathlib import Path

from sqlalchemy.orm import Session

from app.config import get_settings
from app.database.models import Attachment, User
from app.security import audit_log
from app.security.hashing import sha256_hex
from app.services.document_service import DRAFT, get_document
from app.utils.exceptions import NotFound, PermissionDenied, UploadRejected, UploadTooLarge

# extension -> (mime type, magic-byte validator)
_ALLOWED = {
    ".pdf": ("application/pdf", lambda b: b.startswith(b"%PDF-")),
    ".png": ("image/png", lambda b: b.startswith(b"\x89PNG\r\n\x1a\n")),
    ".jpg": ("image/jpeg", lambda b: b.startswith(b"\xff\xd8\xff")),
    ".jpeg": ("image/jpeg", lambda b: b.startswith(b"\xff\xd8\xff")),
    ".wav": ("audio/wav", lambda b: b[:4] == b"RIFF" and b[8:12] == b"WAVE"),
    ".mp3": ("audio/mpeg", lambda b: b.startswith(b"ID3") or b[:2] in (b"\xff\xfb", b"\xff\xf3")),
    ".m4a": ("audio/mp4", lambda b: b[4:8] == b"ftyp"),
}


def safe_display_name(name: str) -> str:
    base = Path(name.replace("\\", "/")).name
    cleaned = re.sub(r"[^A-Za-z0-9._ -]", "_", base).strip(" .")
    return (cleaned or "file")[:100]


def validate_upload(filename: str, data: bytes) -> tuple[str, str]:
    """Return (extension, mime). Raises UploadRejected on any problem."""
    settings = get_settings()
    ext = Path(filename).suffix.lower()
    if ext not in _ALLOWED:
        raise UploadRejected(
            f"File type '{ext or '(none)'}' is not allowed. Allowed: " + ", ".join(sorted(_ALLOWED))
        )
    if len(data) == 0:
        raise UploadRejected("The file is empty.")
    if len(data) > settings.max_upload_bytes:
        raise UploadTooLarge(f"The file exceeds the {settings.max_upload_mb} MB limit.")
    mime, check = _ALLOWED[ext]
    if not check(data[:16]):
        raise UploadRejected("The file content does not match its extension.")
    return ext, mime


def _resolve_inside(base: Path, name: str) -> Path:
    path = (base / name).resolve()
    if base.resolve() not in path.parents:
        raise PermissionDenied("Invalid storage path.")
    return path


def store_attachment(
    session: Session, actor: User, doc_id: int, filename: str, data: bytes
) -> Attachment:
    doc = get_document(session, actor, doc_id)
    if doc.employee_id != actor.id or doc.status != DRAFT:
        raise PermissionDenied(
            "Attachments can only be added by the owner while the document is a draft."
        )
    ext, mime = validate_upload(filename, data)
    stored = f"{uuid.uuid4().hex}{ext}"  # user-supplied names never reach the filesystem
    base = get_settings().attachment_dir
    base.mkdir(parents=True, exist_ok=True)
    _resolve_inside(base, stored).write_bytes(data)
    att = Attachment(
        document_id=doc.id,
        stored_name=stored,
        original_name=safe_display_name(filename),
        mime_type=mime,
        size_bytes=len(data),
        sha256=sha256_hex(data),
        uploaded_by=actor.id,
    )
    session.add(att)
    session.flush()
    audit_log.record(
        session,
        actor_id=actor.id,
        action="attachment.added",
        entity_type="document",
        entity_id=doc.id,
        payload={"attachment_id": att.id, "sha256": att.sha256, "name": att.original_name},
    )
    return att


def read_attachment(session: Session, actor: User, attachment_id: int) -> tuple[Attachment, bytes]:
    att = session.get(Attachment, attachment_id)
    if att is None:
        raise NotFound("Attachment not found.")
    get_document(session, actor, att.document_id)  # enforces view permission
    path = _resolve_inside(get_settings().attachment_dir, att.stored_name)
    if not path.exists():
        raise NotFound("The stored file is missing.")
    data = path.read_bytes()
    if sha256_hex(data) != att.sha256:
        raise PermissionDenied("Stored file failed its integrity check.")
    audit_log.record(
        session,
        actor_id=actor.id,
        action="attachment.downloaded",
        entity_type="document",
        entity_id=att.document_id,
        payload={"attachment_id": att.id},
    )
    return att, data
