"""Extraction runs: OCR/PDF/speech -> structured candidate values, with history and review."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import ExtractionRecord, Supplier, User
from app.security import audit_log
from app.security.authorization import Perm, has_permission, require
from app.security.hashing import sha256_hex
from app.services import field_extraction as fx
from app.services import ocr_service, speech_service
from app.services.attachment_service import validate_upload
from app.utils.exceptions import NotFound, PermissionDenied, ValidationError

AUDIO_EXT = (".wav", ".mp3", ".m4a")


def _ser(v: object) -> object:
    if isinstance(v, (date, Decimal)):
        return v.isoformat() if isinstance(v, date) else str(v)
    if isinstance(v, list):
        return [_ser(x) for x in v]
    return v


@dataclass
class ExtractionOutcome:
    record_id: int
    status: str  # ok | partial | failed
    source_type: str
    method: str
    text: str
    fields: dict[str, fx.ExtractedField] = field(default_factory=dict)
    lines: list[fx.ExtractedLine] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    ocr_confidence: float | None = None


def _suppliers(session: Session) -> list[tuple[int, str]]:
    return [(r.id, r.name) for r in session.execute(select(Supplier)).scalars()]


def run_extraction(session: Session, actor: User, filename: str, data: bytes) -> ExtractionOutcome:
    require(actor, Perm.DOC_CREATE)
    ext, _mime = validate_upload(filename, data)
    sha = sha256_hex(data)
    suppliers = _suppliers(session)
    warnings: list[str] = []
    error: str | None = None
    fields: dict[str, fx.ExtractedField] = {}
    lines: list[fx.ExtractedLine] = []
    issues: list[str] = []
    missing: list[str] = []
    text, method, conf = "", "none", None
    source = "audio" if ext in AUDIO_EXT else ("pdf" if ext == ".pdf" else "image")
    try:
        if source == "audio":
            provider = speech_service.get_speech_provider()
            if provider is None:
                error = "No speech-to-text provider is installed/configured. Type the description instead."
            else:
                tr = provider.transcribe(data, filename)
                text, method = tr.text, tr.method
                fields = speech_service.parse_transcript(text, suppliers)
                missing = [
                    n
                    for n in ("supplier", "supplier_ref", "purchase_date", "total", "currency")
                    if fields[n].value is None
                ]
                warnings.append(
                    "Speech transcripts contain recognition errors; check every value. Transcription does not identify the speaker."
                )
        else:
            res = ocr_service.extract_text(filename, data)
            text, method, conf, warnings = res.text, res.method, res.confidence, list(res.warnings)
            if text.strip():
                parsed = fx.extract_fields(text, suppliers, conf)
                fields, lines, issues, missing = (
                    parsed.fields,
                    parsed.lines,
                    parsed.issues,
                    parsed.missing,
                )
            else:
                error = error or (warnings[0] if warnings else "No text could be extracted.")
    except Exception as exc:  # malformed files must never crash the page
        error = f"Extraction failed: {type(exc).__name__}"
    status = (
        "failed"
        if (error or not text.strip())
        else ("ok" if not (issues or missing) else "partial")
    )
    record = ExtractionRecord(
        user_id=actor.id,
        source_type=source,
        filename=Path(filename).name[:200],
        sha256=sha,
        method=method[:60],
        status=status,
        raw_text=text[:20000],
        result_json=json.dumps(
            {
                "fields": {
                    k: {
                        "value": _ser(v.value),
                        "confidence": v.confidence,
                        "evidence": v.evidence,
                        "candidates": _ser(v.candidates),
                    }
                    for k, v in fields.items()
                },
                "lines": [
                    {
                        "description": ln.description,
                        "quantity": str(ln.quantity),
                        "unit": ln.unit,
                        "unit_price": str(ln.unit_price),
                        "amount": str(ln.amount),
                        "consistent": ln.consistent,
                    }
                    for ln in lines
                ],
                "issues": issues,
                "missing": missing,
                "ocr_confidence": conf,
            }
        ),
        error=error,
    )
    session.add(record)
    session.flush()
    audit_log.record(
        session,
        actor_id=actor.id,
        action="extraction.run",
        entity_type="extraction",
        entity_id=record.id,
        payload={"source": source, "method": method, "status": status, "sha256": sha},
    )
    return ExtractionOutcome(
        record.id,
        status,
        source,
        method,
        text,
        fields,
        lines,
        issues,
        missing,
        warnings + ([error] if error else []),
        conf,
    )


def record_resolutions(
    session: Session,
    actor: User,
    record_id: int,
    resolutions: dict[str, dict],
    document_id: int | None = None,
) -> ExtractionRecord:
    """Store which value the employee chose per field (and from which source)."""
    rec = session.get(ExtractionRecord, record_id)
    if rec is None:
        raise NotFound("Extraction record not found.")
    if rec.user_id != actor.id:
        raise PermissionDenied("Only the user who ran the extraction can record its review.")
    rec.resolutions_json = json.dumps(resolutions, default=str)
    if document_id:
        rec.document_id = document_id
    audit_log.record(
        session,
        actor_id=actor.id,
        action="extraction.reviewed",
        entity_type="extraction",
        entity_id=rec.id,
        payload={"resolutions": resolutions, "document_id": document_id},
    )
    return rec


def list_problem_extractions(
    session: Session, actor: User, limit: int = 100
) -> list[ExtractionRecord]:
    """Failed/partial runs: own runs, or everyone's for users who can see all documents."""
    q = select(ExtractionRecord).where(ExtractionRecord.status.in_(("failed", "partial")))
    if not has_permission(actor, Perm.DOC_VIEW_ALL):
        if has_permission(actor, Perm.DOC_VIEW_ORG):
            q = q.join(User, User.id == ExtractionRecord.user_id).where(
                User.org_unit_id == actor.org_unit_id
            )
        else:
            q = q.where(ExtractionRecord.user_id == actor.id)
    return list(
        session.execute(q.order_by(ExtractionRecord.created_at.desc()).limit(limit)).scalars()
    )


def form_values(outcome: ExtractionOutcome) -> dict[str, object]:
    """Candidate values keyed like the create-document form. Lines are returned as dict rows."""
    vals: dict[str, object] = {}
    mapping = {
        "supplier": "supplier_id",
        "supplier_ref": "supplier_ref",
        "purchase_date": "purchase_date",
        "currency": "currency",
        "description": "description",
    }
    for src, dst in mapping.items():
        f = outcome.fields.get(src)
        if f is not None and f.value is not None:
            vals[dst] = f.value
    if outcome.lines:
        vals["lines"] = [
            {
                "description": ln.description,
                "quantity": float(ln.quantity),
                "unit": ln.unit if ln.unit in ("pcs", "kg", "m", "l", "h", "set", "lot") else "pcs",
                "unit_price": float(ln.unit_price),
                "discount_pct": 0.0,
                "tax_pct": 0.0,
                "category": "general",
            }
            for ln in outcome.lines
        ]
    return vals


def require_text(outcome: ExtractionOutcome) -> None:
    if not outcome.text.strip():
        raise ValidationError("Nothing could be extracted.")
