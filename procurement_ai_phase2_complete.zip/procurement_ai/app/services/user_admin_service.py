"""Administrative user management (API only). Every change is audited."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import User
from app.security import audit_log
from app.security.authorization import Perm, require
from app.utils.exceptions import NotFound, ValidationError


def list_users(session: Session, actor: User, page: int, page_size: int, search: str = ""):
    from sqlalchemy import func

    require(actor, Perm.ADMIN_MANAGE)
    q = select(User)
    if search.strip():
        like = f"%{search.strip().lower()}%"
        q = q.where(User.username.ilike(like) | User.full_name.ilike(like))
    total = session.execute(select(func.count()).select_from(q.subquery())).scalar_one()
    rows = session.execute(
        q.order_by(User.id).limit(page_size).offset((page - 1) * page_size)
    ).scalars()
    return list(rows), total


def update_user(
    session: Session, actor: User, user_id: int, is_active: bool | None, unlock: bool
) -> User:
    require(actor, Perm.ADMIN_MANAGE)
    user = session.get(User, user_id)
    if user is None:
        raise NotFound(f"User {user_id} was not found.")
    if user.id == actor.id and is_active is False:
        raise ValidationError("You cannot deactivate your own account.")
    changes: dict[str, object] = {}
    if is_active is not None and is_active != user.is_active:
        user.is_active = is_active
        user.token_version += 1  # revoke every issued token
        changes["is_active"] = is_active
    if unlock:
        user.locked_until, user.failed_login_count = None, 0
        changes["unlocked"] = True
    if changes:
        audit_log.record(
            session,
            actor_id=actor.id,
            action="user.updated",
            entity_type="user",
            entity_id=user.id,
            payload=changes,
        )
    return user
