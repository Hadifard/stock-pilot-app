"""Password change and admin-triggered reset. Every change bumps `token_version` (revokes tokens)."""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.database.models import User
from app.security import audit_log
from app.security.authentication import GENERIC
from app.security.authorization import Perm, require
from app.security.hashing import hash_password, verify_password
from app.security.password_policy import weaknesses
from app.utils.dates import utcnow
from app.utils.exceptions import AuthenticationError, ValidationError


def change_password(
    session: Session, actor: User, current_password: str, new_password: str
) -> None:
    if not verify_password(current_password, actor.password_hash):
        raise AuthenticationError(GENERIC)
    issues = weaknesses(new_password)
    if issues:
        raise ValidationError(issues)
    if verify_password(new_password, actor.password_hash):
        raise ValidationError("The new password must differ from the current one.")
    actor.password_hash = hash_password(new_password)
    actor.password_changed_at = utcnow()
    actor.must_change_password = False
    actor.token_version += 1  # revoke every previously issued token, including this request's
    audit_log.record(
        session,
        actor_id=actor.id,
        action="auth.password_changed",
        entity_type="user",
        entity_id=actor.id,
    )


def admin_reset_password(
    session: Session, admin: User, user: User, temporary_password: str
) -> None:
    require(admin, Perm.ADMIN_MANAGE)
    issues = weaknesses(temporary_password)
    if issues:
        raise ValidationError(issues)
    user.password_hash = hash_password(temporary_password)
    user.must_change_password = True
    user.password_changed_at = utcnow()
    user.token_version += 1
    user.locked_until, user.failed_login_count = None, 0
    audit_log.record(
        session,
        actor_id=admin.id,
        action="auth.password_reset_by_admin",
        entity_type="user",
        entity_id=user.id,
    )
