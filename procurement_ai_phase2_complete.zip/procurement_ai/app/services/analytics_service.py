"""Glue between the database and the ML modules; enforces permissions and writes audit events."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date

import pandas as pd
from sqlalchemy import Select, select
from sqlalchemy.orm import Session

from app.database.functions import month_key
from app.database.models import (
    AnomalyAlert,
    Attachment,
    DuplicateCandidate,
    LineItem,
    Project,
    PurchaseDocument,
    User,
)
from app.ml import anomaly_detection as ad
from app.ml import duplicate_detection as dd
from app.ml import forecasting as fc
from app.ml import model_registry as registry
from app.security import audit_log
from app.security.authorization import Perm, require, require_view
from app.services.document_service import CANCELLED, DRAFT, REJECTED, get_document, scoped_query
from app.utils.dates import utcnow
from app.utils.exceptions import NotFound, ValidationError

ANOMALY_MODEL = "anomaly"
BUDGET_STATUSES = ("submitted", "under_review", "approved", "resubmitted", "correction_requested")
ALERT_DISPOSITIONS = {
    "expected_business_reason": "Expected - business reason exists",
    "data_entry_error": "Data entry error - correct it",
    "needs_follow_up": "Needs follow-up with requester/supplier",
    "not_unusual": "Not unusual after review",
}
DUPLICATE_DISPOSITIONS = {
    "confirmed_duplicate": "Confirmed duplicate",
    "not_duplicate": "Not a duplicate",
    "legitimate_repeat": "Legitimate repeat (instalment, re-order)",
}


def _doc_ids(q: Select) -> Select:
    return q.with_only_columns(PurchaseDocument.id)


def load_frames(
    session: Session, doc_query: Select, include_statuses: tuple[str, ...] | None = None
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Lines and documents for the documents selected by `doc_query` (already permission-scoped)."""
    excluded = (DRAFT, CANCELLED)
    ids = _doc_ids(doc_query).where(PurchaseDocument.total_reporting.is_not(None))
    if include_statuses:
        ids = ids.where(PurchaseDocument.status.in_(include_statuses))
    else:
        ids = ids.where(PurchaseDocument.status.not_in(excluded))
    docs_rows = session.execute(
        select(
            PurchaseDocument.id,
            PurchaseDocument.supplier_id,
            PurchaseDocument.project_id,
            PurchaseDocument.purchase_date,
            PurchaseDocument.currency,
            PurchaseDocument.total,
            PurchaseDocument.total_reporting,
            PurchaseDocument.supplier_ref,
            PurchaseDocument.doc_type,
            PurchaseDocument.status,
            Project.budget,
            Project.budget_currency,
        )
        .join(Project, Project.id == PurchaseDocument.project_id)
        .where(PurchaseDocument.id.in_(ids))
    ).all()
    docs = pd.DataFrame(
        [tuple(r) for r in docs_rows],
        columns=[
            "document_id",
            "supplier_id",
            "project_id",
            "purchase_date",
            "currency",
            "total",
            "total_eur",
            "supplier_ref",
            "doc_type",
            "status",
            "budget",
            "budget_currency",
        ],
    )
    if docs.empty:
        return pd.DataFrame(columns=["document_id"]), docs
    docs["total_eur"] = docs["total_eur"].astype(float)
    docs["budget_eur"] = (
        docs["budget"].astype(float).where(docs["budget_currency"] == "EUR", float("inf"))
    )
    docs["counts_toward_budget"] = docs["status"].isin(BUDGET_STATUSES)
    line_rows = session.execute(
        select(
            LineItem.id,
            LineItem.document_id,
            LineItem.description,
            LineItem.unit,
            LineItem.quantity,
            LineItem.unit_price,
            LineItem.discount_rate,
            PurchaseDocument.fx_rate,
        )
        .join(PurchaseDocument, PurchaseDocument.id == LineItem.document_id)
        .where(LineItem.document_id.in_(docs["document_id"].tolist()))
    ).all()
    lines = pd.DataFrame(
        [tuple(r) for r in line_rows],
        columns=[
            "line_id",
            "document_id",
            "description",
            "unit",
            "quantity",
            "unit_price",
            "discount_rate",
            "fx_rate",
        ],
    )
    lines["price_eur"] = [
        float(u * (1 - d) * f)
        for u, d, f in zip(
            lines["unit_price"], lines["discount_rate"], lines["fx_rate"], strict=True
        )
    ]
    lines["quantity"] = lines["quantity"].astype(float)
    return lines, docs


# ------------------------------------------------------------------ training (admin / scripts)
def train_anomaly_model(session: Session, actor: User, seed: int = 42) -> ad.AnomalyModel:
    require(actor, Perm.ADMIN_MANAGE)
    lines, docs = load_frames(session, select(PurchaseDocument))
    if len(docs) < 200:
        raise ValidationError("At least 200 documents are needed to fit the anomaly model.")
    model = ad.fit(lines, docs, seed)
    registry.save_model(
        ANOMALY_MODEL,
        model.version,
        model,
        {
            "features": ad.FEATURES,
            "params": model.params,
            "n_train_docs": model.n_train_docs,
            "alert_quantile": ad.ALERT_QUANTILE,
            "alert_threshold": model.alert_threshold,
            "seed": seed,
            "trained_at": model.trained_at,
        },
    )
    audit_log.record(
        session,
        actor_id=actor.id,
        action="model.trained",
        entity_type="model",
        entity_id=None,
        payload={"name": ANOMALY_MODEL, "version": model.version},
    )
    return model


# ------------------------------------------------------------------ anomaly alerts
@dataclass(frozen=True)
class ScanResult:
    scanned: int
    flagged: int
    new_alerts: int
    model_version: str


def run_anomaly_scan(session: Session, actor: User) -> ScanResult:
    require(actor, Perm.ALERT_REVIEW)
    loaded = registry.load_latest(ANOMALY_MODEL)
    if loaded is None:
        raise ValidationError(
            "No anomaly model has been trained yet. Run: python -m scripts.train_models"
        )
    model, _meta = loaded
    lines, docs = load_frames(session, scoped_query(session, actor))
    if docs.empty:
        return ScanResult(0, 0, 0, model.version)
    scores = ad.score(model, lines, docs, context=docs)
    flagged = scores[scores["flagged"]]
    existing = set(
        session.execute(
            select(AnomalyAlert.document_id).where(AnomalyAlert.model_version == model.version)
        ).scalars()
    )
    new = 0
    for did, row in flagged.iterrows():
        if int(did) in existing:
            continue
        session.add(
            AnomalyAlert(
                document_id=int(did),
                model_version=model.version,
                score=float(row["iforest_score"]),
                severity=str(row["severity"]),
                rules_json=ad.dumps_list(row["rules"]),
                factors_json=ad.dumps_list(row["factors"]),
            )
        )
        new += 1
    audit_log.record(
        session,
        actor_id=actor.id,
        action="anomaly.scan",
        entity_type="system",
        entity_id=None,
        payload={
            "scanned": len(scores),
            "flagged": len(flagged),
            "new": new,
            "model": model.version,
        },
    )
    return ScanResult(len(scores), len(flagged), new, model.version)


def list_alerts(session: Session, actor: User, status: str | None = "new", limit: int = 200):
    require(actor, Perm.ANALYTICS_VIEW)
    q = (
        select(AnomalyAlert, PurchaseDocument)
        .join(PurchaseDocument, PurchaseDocument.id == AnomalyAlert.document_id)
        .where(PurchaseDocument.id.in_(_doc_ids(scoped_query(session, actor))))
        .order_by(AnomalyAlert.score.desc())
        .limit(limit)
    )
    if status:
        q = q.where(AnomalyAlert.status == status)
    return session.execute(q).all()


def review_alert(
    session: Session, actor: User, alert_id: int, disposition: str, note: str
) -> AnomalyAlert:
    require(actor, Perm.ALERT_REVIEW)
    alert = session.get(AnomalyAlert, alert_id)
    if alert is None:
        raise NotFound("Alert not found.")
    get_document(session, actor, alert.document_id)
    if disposition not in ALERT_DISPOSITIONS:
        raise ValidationError("Choose a disposition.")
    if not note.strip():
        raise ValidationError("A review note is required.")
    alert.status, alert.disposition, alert.review_note = "reviewed", disposition, note.strip()
    alert.reviewed_by, alert.reviewed_at = actor.id, utcnow()
    audit_log.record(
        session,
        actor_id=actor.id,
        action="anomaly.reviewed",
        entity_type="document",
        entity_id=alert.document_id,
        payload={"alert_id": alert.id, "disposition": disposition, "note": note.strip()},
    )
    return alert


# ------------------------------------------------------------------ duplicates
def duplicate_records(session: Session, doc_query: Select) -> list[dd.DocRecord]:
    ids = _doc_ids(doc_query).where(PurchaseDocument.status.not_in((DRAFT, CANCELLED, REJECTED)))
    docs = session.execute(
        select(
            PurchaseDocument.id,
            PurchaseDocument.supplier_id,
            PurchaseDocument.doc_type,
            PurchaseDocument.supplier_ref,
            PurchaseDocument.currency,
            PurchaseDocument.total,
            PurchaseDocument.purchase_date,
        ).where(PurchaseDocument.id.in_(ids))
    ).all()
    ddf = pd.DataFrame(
        [tuple(r) for r in docs],
        columns=[
            "id",
            "supplier_id",
            "doc_type",
            "supplier_ref",
            "currency",
            "total",
            "purchase_date",
        ],
    )
    if ddf.empty:
        return []
    lrows = session.execute(
        select(LineItem.document_id, LineItem.description, LineItem.quantity).where(
            LineItem.document_id.in_(ids)
        )
    ).all()
    ldf = pd.DataFrame(
        [tuple(r) for r in lrows], columns=["document_id", "description", "quantity"]
    )
    frows = session.execute(
        select(Attachment.document_id, Attachment.sha256).where(Attachment.document_id.in_(ids))
    ).all()
    fdf = pd.DataFrame([tuple(r) for r in frows], columns=["document_id", "sha256"])
    return dd.records_from_frames(ddf, ldf, fdf)


def run_duplicate_scan(session: Session, actor: User) -> tuple[int, int]:
    """Returns (candidates found, newly stored)."""
    require(actor, Perm.ALERT_REVIEW)
    matches = dd.find_candidates(duplicate_records(session, scoped_query(session, actor)))
    existing = set(
        session.execute(select(DuplicateCandidate.doc_a_id, DuplicateCandidate.doc_b_id)).all()
    )
    new = 0
    for m in matches:
        if (m.doc_a, m.doc_b) in existing:
            continue
        session.add(
            DuplicateCandidate(
                doc_a_id=m.doc_a,
                doc_b_id=m.doc_b,
                score=m.score,
                reasons_json=json.dumps(m.reasons),
            )
        )
        new += 1
    audit_log.record(
        session,
        actor_id=actor.id,
        action="duplicate.scan",
        entity_type="system",
        entity_id=None,
        payload={"found": len(matches), "new": new},
    )
    return len(matches), new


def list_duplicates(session: Session, actor: User, status: str | None = "new", limit: int = 200):
    require(actor, Perm.ANALYTICS_VIEW)
    visible = _doc_ids(scoped_query(session, actor))
    q = (
        select(DuplicateCandidate)
        .where(DuplicateCandidate.doc_a_id.in_(visible), DuplicateCandidate.doc_b_id.in_(visible))
        .order_by(DuplicateCandidate.score.desc())
        .limit(limit)
    )
    if status:
        q = q.where(DuplicateCandidate.status == status)
    return list(session.execute(q).scalars())


def review_duplicate(
    session: Session, actor: User, candidate_id: int, disposition: str, note: str
) -> DuplicateCandidate:
    require(actor, Perm.ALERT_REVIEW)
    cand = session.get(DuplicateCandidate, candidate_id)
    if cand is None:
        raise NotFound("Candidate not found.")
    require_view(actor, get_document(session, actor, cand.doc_a_id))
    get_document(session, actor, cand.doc_b_id)
    if disposition not in DUPLICATE_DISPOSITIONS:
        raise ValidationError("Choose a disposition.")
    if not note.strip():
        raise ValidationError("A review note is required.")
    cand.status, cand.disposition, cand.review_note = "reviewed", disposition, note.strip()
    cand.reviewed_by, cand.reviewed_at = actor.id, utcnow()
    audit_log.record(
        session,
        actor_id=actor.id,
        action="duplicate.reviewed",
        entity_type="document",
        entity_id=cand.doc_a_id,
        payload={
            "candidate_id": cand.id,
            "other": cand.doc_b_id,
            "disposition": disposition,
            "note": note.strip(),
        },
    )
    return cand


# ------------------------------------------------------------------ forecasting
def spend_forecast(
    session: Session,
    actor: User,
    org_unit_id: int | None = None,
    project_id: int | None = None,
    horizon: int = 6,
    today: date | None = None,
) -> fc.ForecastResult:
    require(actor, Perm.ANALYTICS_VIEW)
    q = scoped_query(session, actor).where(
        PurchaseDocument.status.not_in((DRAFT, CANCELLED, REJECTED)),
        PurchaseDocument.total_reporting.is_not(None),
    )
    if org_unit_id:
        q = q.where(PurchaseDocument.org_unit_id == org_unit_id)
    if project_id:
        q = q.where(PurchaseDocument.project_id == project_id)
    sub = q.subquery()
    from sqlalchemy import func

    month = month_key(sub.c.purchase_date).label("month")
    rows = session.execute(
        select(month, func.sum(sub.c.total_reporting)).group_by(month).order_by(month)
    ).all()
    frame = pd.DataFrame([(m, float(s)) for m, s in rows], columns=["month", "spend"])
    return fc.forecast(fc.monthly_series(frame, today), horizon)
