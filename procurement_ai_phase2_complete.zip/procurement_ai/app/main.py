"""Streamlit entry point:  streamlit run app/main.py

LOCAL DEMO. The sign-in below is a demonstration mechanism with synthetic accounts and is not a
production authentication system.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st  # noqa: E402
from sqlalchemy import func, select  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.database.migrate import upgrade_to_head
from app.database.models import User  # noqa: E402
from app.database.session import get_engine, session_scope  # noqa: E402
from app.security.authentication import authenticate  # noqa: E402
from app.security.authorization import ROLE_LABELS, Perm, has_permission  # noqa: E402
from app.services import notification_service  # noqa: E402
from app.ui.employee_pages import (  # noqa: E402
    corrections,
    create_document,
    home,
    my_documents,
    notifications,
    profile,
)
from app.ui.manager_pages import (
    alerts,
    audit,
    forecast,
    operations,
    overview,
    price_benchmark,
    reports,
    review_queue,
    spend_analysis,
)  # noqa: E402
from app.ui.styles.theme import inject_css  # noqa: E402
from app.utils.exceptions import AuthenticationError, DomainError  # noqa: E402
from app.utils.logging_config import configure_logging  # noqa: E402

log = logging.getLogger("procurement.ui")

# label -> (render function, permission predicate)
PAGES = {
    "Home": (
        lambda s, a: (
            overview.render(s, a) if has_permission(a, Perm.ANALYTICS_VIEW) else home.render(s, a)
        ),
        lambda a: True,
    ),
    "My documents": (
        lambda s, a: my_documents.render(s, a, only_own=True),
        lambda a: has_permission(a, Perm.DOC_CREATE),
    ),
    "Create document": (create_document.render, lambda a: has_permission(a, Perm.DOC_CREATE)),
    "Documents": (
        lambda s, a: my_documents.render(s, a, only_own=False),
        lambda a: any(
            has_permission(a, p)
            for p in (Perm.DOC_VIEW_ALL, Perm.DOC_VIEW_ORG, Perm.DOC_VIEW_PROJECT)
        ),
    ),
    "Review queue": (review_queue.render, lambda a: has_permission(a, Perm.DOC_DECIDE)),
    "Corrections": (
        corrections.render,
        lambda a: (
            has_permission(a, Perm.CORRECTION_REQUEST) or has_permission(a, Perm.CORRECTION_DECIDE)
        ),
    ),
    "Operations": (operations.render, lambda a: has_permission(a, Perm.ANALYTICS_VIEW)),
    "Spend analysis": (spend_analysis.render, lambda a: has_permission(a, Perm.ANALYTICS_VIEW)),
    "Forecast": (forecast.render, lambda a: has_permission(a, Perm.ANALYTICS_VIEW)),
    "Alerts": (alerts.render, lambda a: has_permission(a, Perm.ANALYTICS_VIEW)),
    "Price benchmark": (price_benchmark.render, lambda a: has_permission(a, Perm.ANALYTICS_VIEW)),
    "Reports": (reports.render, lambda a: has_permission(a, Perm.REPORT_EXPORT)),
    "Audit log": (audit.render, lambda a: has_permission(a, Perm.AUDIT_VIEW)),
    "Notifications": (notifications.render, lambda a: True),
    "Profile": (profile.render, lambda a: True),
}


@st.cache_resource
def _bootstrap() -> bool:
    settings = get_settings()
    configure_logging(settings.log_level)
    get_engine()
    upgrade_to_head()
    return True


def _login_view() -> None:
    st.markdown(
        '<div class="app-title">Procurement Intelligence Platform</div>', unsafe_allow_html=True
    )
    st.title("Sign in")
    st.info(
        "Local demonstration with **synthetic** accounts and data - not a production "
        "authentication system."
    )
    with st.form("login"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        go = st.form_submit_button("Sign in", type="primary")
    if go:
        try:
            with session_scope() as s:
                user = authenticate(s, username, password)
                st.session_state["user_id"] = user.id
            st.rerun()
        except AuthenticationError as exc:
            st.error(str(exc))
    with st.expander("Demo accounts"):
        st.write(
            "`employee.demo`, `employee2.demo`, `manager.demo`, `finance.demo`, `pm.demo`, "
            "`auditor.demo`, `admin.demo`. The password is `PROCUREMENT_DEMO_PASSWORD` from "
            "your `.env` (see README)."
        )


def main() -> None:
    st.set_page_config(
        page_title="Procurement Intelligence", page_icon=":bar_chart:", layout="wide"
    )
    inject_css()
    _bootstrap()
    with session_scope() as s:
        user_count = s.execute(select(func.count(User.id))).scalar_one()
    if user_count == 0:
        st.error(
            "The database is empty. Run `python -m scripts.generate_synthetic_data --mode small` "
            "and reload this page."
        )
        return
    uid = st.session_state.get("user_id")
    if uid is None:
        _login_view()
        return
    try:
        with session_scope() as s:
            actor = s.get(User, uid)
            if actor is None or not actor.is_active:
                st.session_state.pop("user_id", None)
                st.rerun()
            _shell(s, actor)
    except DomainError as exc:
        st.error(str(exc))
    except Exception:  # noqa: BLE001 - never show stack traces or internals to users
        log.exception("Unhandled error in page")
        st.error(
            "Something went wrong. The incident was logged; please try again or contact support."
        )


def _shell(session, actor: User) -> None:
    allowed = [name for name, (_, ok) in PAGES.items() if ok(actor)]
    with st.sidebar:
        st.markdown('<div class="app-title">Procurement Intelligence</div>', unsafe_allow_html=True)
        st.caption(f"{actor.full_name}  \n{ROLE_LABELS[actor.role]}")
        unread = notification_service.unread_count(session, actor)
        page = st.radio(
            "Navigation",
            allowed,
            key="nav",
            label_visibility="collapsed",
            format_func=lambda n: (
                f"Notifications ({unread})" if n == "Notifications" and unread else n
            ),
        )
        if st.button("Sign out"):
            st.session_state.clear()
            st.rerun()
    render_fn, _ = PAGES[page]
    render_fn(session, actor)


main()
