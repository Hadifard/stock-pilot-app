"""Dialect-neutral SQL functions."""

from __future__ import annotations

from sqlalchemy import String
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.sql.expression import FunctionElement


class month_key(FunctionElement):  # noqa: N801 - SQL function style
    """'YYYY-MM' string for a date column (SQLite strftime / PostgreSQL to_char)."""

    type = String()
    inherit_cache = True
    name = "month_key"


@compiles(month_key, "sqlite")
def _month_sqlite(element, compiler, **kw):
    return f"strftime('%Y-%m', {compiler.process(element.clauses, **kw)})"


@compiles(month_key, "postgresql")
def _month_pg(element, compiler, **kw):
    return f"to_char({compiler.process(element.clauses, **kw)}, 'YYYY-MM')"
