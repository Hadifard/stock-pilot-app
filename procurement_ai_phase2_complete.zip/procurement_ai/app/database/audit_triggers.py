"""Database-level append-only protection for audit_events (SQLite and PostgreSQL).

Shared by `create_all()` (local development / tests) and Alembic migrations so both produce the
same protection. A privileged database administrator can still drop these triggers; the hash chain
(app/security/audit_log.py) is what makes that detectable.
"""

from __future__ import annotations

SQLITE = [
    "CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_events "
    "BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END",
    "CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_events "
    "BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END",
]
POSTGRESQL = [
    "CREATE OR REPLACE FUNCTION audit_events_immutable() RETURNS trigger AS $$ "
    "BEGIN RAISE EXCEPTION 'audit_events is append-only'; END; $$ LANGUAGE plpgsql",
    "DROP TRIGGER IF EXISTS audit_no_update ON audit_events",
    "DROP TRIGGER IF EXISTS audit_no_delete ON audit_events",
    "DROP TRIGGER IF EXISTS audit_no_truncate ON audit_events",
    "CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_events FOR EACH ROW EXECUTE FUNCTION audit_events_immutable()",
    "CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_events FOR EACH ROW EXECUTE FUNCTION audit_events_immutable()",
    "CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_events FOR EACH STATEMENT EXECUTE FUNCTION audit_events_immutable()",
]
POSTGRESQL_DROP = [
    "DROP TRIGGER IF EXISTS audit_no_update ON audit_events",
    "DROP TRIGGER IF EXISTS audit_no_delete ON audit_events",
    "DROP TRIGGER IF EXISTS audit_no_truncate ON audit_events",
    "DROP FUNCTION IF EXISTS audit_events_immutable()",
]
SQLITE_DROP = ["DROP TRIGGER IF EXISTS audit_no_update", "DROP TRIGGER IF EXISTS audit_no_delete"]


def statements(dialect: str) -> list[str]:
    return {"sqlite": SQLITE, "postgresql": POSTGRESQL}.get(dialect, [])


def drop_statements(dialect: str) -> list[str]:
    return {"sqlite": SQLITE_DROP, "postgresql": POSTGRESQL_DROP}.get(dialect, [])
