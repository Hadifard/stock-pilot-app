"""Run Alembic migrations programmatically (used by scripts and the Streamlit bootstrap)."""

from __future__ import annotations

import logging

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect

from app.config import PROJECT_ROOT, get_settings

log = logging.getLogger(__name__)
FIRST_REVISION = "0001"  # the Phase 1 schema, created before migrations existed


def alembic_config(url: str) -> Config:
    cfg = Config(str(PROJECT_ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(PROJECT_ROOT / "migrations"))
    cfg.attributes["url"] = url
    cfg.attributes["skip_logging"] = True
    return cfg


def upgrade_to_head(url: str | None = None) -> None:
    """Create or upgrade the schema. A Phase 1 database (tables but no alembic_version) is
    stamped as revision 0001 first, so existing data is migrated instead of recreated."""
    url = url or get_settings().database_url
    engine = create_engine(url)
    try:
        insp = inspect(engine)
        tables = set(insp.get_table_names())
        has_phase2_columns = "users" in tables and "token_version" in {
            c["name"] for c in insp.get_columns("users")
        }
    finally:
        engine.dispose()
    cfg = alembic_config(url)
    if "users" in tables and "alembic_version" not in tables:
        # Tables without version tracking: either a Phase 1 database (schema == revision 0001)
        # or one created by create_all() from the current models (schema == head).
        revision = "head" if has_phase2_columns else FIRST_REVISION
        log.info("Unversioned database detected; stamping revision %s", revision)
        command.stamp(cfg, revision)
    command.upgrade(cfg, "head")
