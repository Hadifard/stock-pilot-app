"""Engine and session management (SQLite for local use, PostgreSQL for production)."""

from __future__ import annotations

import logging
from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import DDL, Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from app.config import get_settings
from app.database import audit_triggers
from app.database.base import Base
from app.database.models import AuditEvent

log = logging.getLogger(__name__)

_engine: Engine | None = None
_factory: sessionmaker[Session] | None = None

for _dialect in ("sqlite", "postgresql"):
    for _stmt in audit_triggers.statements(_dialect):
        event.listen(AuditEvent.__table__, "after_create", DDL(_stmt).execute_if(dialect=_dialect))


def make_engine(url: str) -> Engine:
    if url.startswith("sqlite"):
        engine = create_engine(url, future=True)

        @event.listens_for(engine, "connect")
        def _pragmas(dbapi_conn, _record):  # pragma: no cover - trivial
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.close()

        return engine
    return create_engine(url, future=True, pool_pre_ping=True, pool_size=10, max_overflow=20)


def init_engine(url: str | None = None) -> Engine:
    """(Re)bind the global engine. Tests call this with a temporary database URL."""
    global _engine, _factory
    _engine = make_engine(url or get_settings().database_url)
    _factory = sessionmaker(_engine, expire_on_commit=False, future=True)
    return _engine


def get_engine() -> Engine:
    return _engine if _engine is not None else init_engine()


def create_all() -> None:
    Base.metadata.create_all(get_engine())


def new_session() -> Session:
    get_engine()
    assert _factory is not None
    return _factory()


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope: commit on success, roll back on any exception."""
    session = new_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
