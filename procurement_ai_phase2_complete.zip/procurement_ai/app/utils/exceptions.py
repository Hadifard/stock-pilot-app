"""Domain exceptions. UI code catches DomainError and shows its message to the user."""

from __future__ import annotations


class DomainError(Exception):
    """Base class for expected, user-presentable business errors."""


class ValidationError(DomainError):
    """Input failed validation. `errors` holds one message per problem."""

    def __init__(self, errors: list[str] | str):
        self.errors = [errors] if isinstance(errors, str) else list(errors)
        super().__init__("; ".join(self.errors))


class PermissionDenied(DomainError):
    pass


class NotFound(DomainError):
    pass


class InvalidTransition(DomainError):
    pass


class CorrectionWindowExpired(DomainError):
    pass


class AuthenticationError(DomainError):
    pass


class UploadRejected(DomainError):
    pass


class UploadTooLarge(UploadRejected):
    pass


class PasswordChangeRequired(PermissionDenied):
    pass


class PreconditionFailed(DomainError):
    pass


class RateLimited(DomainError):
    pass
