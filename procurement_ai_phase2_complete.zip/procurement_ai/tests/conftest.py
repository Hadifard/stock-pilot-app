"""Shared fixtures: every test gets its own temporary SQLite database and attachment folder."""

from __future__ import annotations

import os
import sys
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import select

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import reset_settings_cache  # noqa: E402
from app.database.base import Base  # noqa: E402
from app.database.models import CostCenter, Project, Supplier, User  # noqa: E402
from app.database.seed import seed_reference_data  # noqa: E402
from app.database.session import create_all, init_engine, session_scope  # noqa: E402
from app.services.validation_service import DocumentInput, LineInput  # noqa: E402

PASSWORD = "test-pass-123"


@pytest.fixture
def db(tmp_path, monkeypatch):
    url = os.environ.get("PROCUREMENT_TEST_DATABASE_URL") or f"sqlite:///{tmp_path / 'test.db'}"
    monkeypatch.setenv("PROCUREMENT_DATABASE_URL", url)
    monkeypatch.setenv("PROCUREMENT_ATTACHMENT_DIR", str(tmp_path / "attachments"))
    monkeypatch.setenv("PROCUREMENT_MODEL_DIR", str(tmp_path / "models"))
    monkeypatch.setenv("PROCUREMENT_DEMO_PASSWORD", PASSWORD)
    reset_settings_cache()
    engine = init_engine()
    if engine.dialect.name != "sqlite":  # shared server: start every test from an empty schema
        Base.metadata.drop_all(engine)
    create_all()
    with session_scope() as s:
        seed_reference_data(s, "tiny", 1, PASSWORD)
    yield
    engine.dispose()
    reset_settings_cache()


@pytest.fixture
def session(db):
    with session_scope() as s:
        yield s


def get_user(s, username: str) -> User:
    return s.execute(select(User).where(User.username == username)).scalar_one()


def make_input(s, **overrides) -> DocumentInput:
    project = s.execute(select(Project).where(Project.code == "PRJ-001")).scalar_one()
    cc = (
        s.execute(select(CostCenter).where(CostCenter.org_unit_id == project.org_unit_id))
        .scalars()
        .first()
    )
    supplier = s.execute(select(Supplier)).scalars().first()
    data = dict(
        project_id=project.id,
        cost_center_id=cc.id,
        supplier_id=supplier.id,
        doc_type="invoice",
        purchase_date=date.today() - timedelta(days=1),
        currency="EUR",
        lines=(
            LineInput(
                "Ball valve DN50",
                Decimal("2"),
                Decimal("100.00"),
                "pcs",
                Decimal("0.10"),
                Decimal("0.19"),
            ),
        ),
        supplier_ref="INV-1001",
        description="Valves for pump station",
        business_purpose="Maintenance",
        shipping=Decimal("10.00"),
    )
    data.update(overrides)
    return DocumentInput(**data)


def drop_audit_triggers(session) -> None:
    """Simulate a privileged attacker removing the append-only triggers."""
    from sqlalchemy import text

    from app.database import audit_triggers

    for stmt in audit_triggers.drop_statements(session.get_bind().dialect.name):
        session.execute(text(stmt))
