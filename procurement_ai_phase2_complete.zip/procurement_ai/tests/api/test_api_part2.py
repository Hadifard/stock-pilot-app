from tests.api.conftest import auth, create_doc, doc_body, login, submit_doc
from tests.conftest import PASSWORD


# ------------------------------------------------------------------ refresh-token rotation
def test_refresh_rotates_and_old_token_is_rejected(client):
    t = login(client).json()
    rot = client.post("/api/v1/auth/refresh", json={"refresh_token": t["refresh_token"]})
    assert rot.status_code == 200
    new = rot.json()
    assert new["refresh_token"] != t["refresh_token"]
    again = client.post("/api/v1/auth/refresh", json={"refresh_token": t["refresh_token"]})
    assert again.status_code == 401


def test_refresh_reuse_revokes_whole_family(client):
    t = login(client).json()
    first_new = client.post(
        "/api/v1/auth/refresh", json={"refresh_token": t["refresh_token"]}
    ).json()
    # replay the already-used original token -> family revoked
    assert (
        client.post("/api/v1/auth/refresh", json={"refresh_token": t["refresh_token"]}).status_code
        == 401
    )
    # the token issued from that family is now also revoked
    assert (
        client.post(
            "/api/v1/auth/refresh", json={"refresh_token": first_new["refresh_token"]}
        ).status_code
        == 401
    )


def test_logout_can_revoke_the_presented_refresh_token(client):
    t = login(client).json()
    h = {"Authorization": f"Bearer {t['access_token']}"}
    r = client.post("/api/v1/auth/logout", headers=h, json={"refresh_token": t["refresh_token"]})
    assert r.status_code == 204
    assert (
        client.post("/api/v1/auth/refresh", json={"refresh_token": t["refresh_token"]}).status_code
        == 401
    )


# ------------------------------------------------------------------ password change / reset
def test_change_password_requires_current_and_revokes_tokens(client):
    t = login(client).json()
    h = {"Authorization": f"Bearer {t['access_token']}"}
    bad = client.post(
        "/api/v1/auth/change-password",
        headers=h,
        json={"current_password": "wrong", "new_password": "Str0ng!NewPass123"},
    )
    assert bad.status_code == 401
    weak = client.post(
        "/api/v1/auth/change-password",
        headers=h,
        json={"current_password": PASSWORD, "new_password": "short"},
    )
    assert weak.status_code == 422
    ok = client.post(
        "/api/v1/auth/change-password",
        headers=h,
        json={"current_password": PASSWORD, "new_password": "Str0ng!NewPass123"},
    )
    assert ok.status_code == 204
    assert client.get("/api/v1/auth/me", headers=h).status_code == 401  # old token revoked
    assert login(client).status_code == 401  # old password no longer works
    assert login(client, password="Str0ng!NewPass123").status_code == 200


def test_admin_reset_password_forces_change_on_next_login(client):
    admin = auth(client, "admin.demo")
    users = client.get("/api/v1/admin/users?q=employee2.demo", headers=admin).json()["items"]
    uid = users[0]["id"]
    r = client.post(
        f"/api/v1/admin/users/{uid}/reset-password",
        headers=admin,
        json={"temporary_password": "Temp0rary!Pass99"},
    )
    assert r.status_code == 204
    assert login(client, "employee2.demo", PASSWORD).status_code == 401  # old password dead
    t = login(client, "employee2.demo", "Temp0rary!Pass99").json()
    assert t["must_change_password"] is True
    h = {"Authorization": f"Bearer {t['access_token']}"}
    assert client.get("/api/v1/auth/me", headers=h).json()["must_change_password"] is True
    assert client.get("/api/v1/documents", headers=h).status_code == 403  # blocked until changed
    assert (
        client.get("/api/v1/documents", headers=h).json()["error"]["code"]
        == "password_change_required"
    )
    ch = client.post(
        "/api/v1/auth/change-password",
        headers=h,
        json={"current_password": "Temp0rary!Pass99", "new_password": "An0ther!GoodPass1"},
    )
    assert ch.status_code == 204
    fresh = login(client, "employee2.demo", "An0ther!GoodPass1").json()
    assert fresh["must_change_password"] is False
    h2 = {"Authorization": f"Bearer {fresh['access_token']}"}
    assert client.get("/api/v1/documents", headers=h2).status_code == 200


def test_cannot_reset_own_password_via_admin_endpoint_bypassing_non_admin(client):
    emp = auth(client)
    assert (
        client.post(
            "/api/v1/admin/users/1/reset-password",
            headers=emp,
            json={"temporary_password": "Whatever!1234567"},
        ).status_code
        == 403
    )


# ------------------------------------------------------------------ rate limiting
def test_login_rate_limit_triggers_429(client, monkeypatch):
    from app.config import reset_settings_cache

    monkeypatch.setenv("PROCUREMENT_RATE_LIMIT_LOGIN_PER_MIN", "3")
    reset_settings_cache()
    for _ in range(3):
        login(client, password="wrong")
    r = login(client, password="wrong")
    assert (
        r.status_code == 429
        and r.json()["error"]["code"] == "rate_limited"
        and r.headers["retry-after"] == "60"
    )
    reset_settings_cache()


def test_general_api_rate_limit(client, monkeypatch):
    from app.config import reset_settings_cache

    monkeypatch.setenv("PROCUREMENT_RATE_LIMIT_PER_MIN", "2")
    reset_settings_cache()
    h = auth(client)
    client.get("/api/v1/auth/me", headers=h)
    client.get("/api/v1/auth/me", headers=h)
    r = client.get("/api/v1/auth/me", headers=h)
    assert r.status_code == 429
    reset_settings_cache()


def test_rate_limit_is_per_ip_not_global(client, monkeypatch):
    from app.config import reset_settings_cache

    monkeypatch.setenv("PROCUREMENT_RATE_LIMIT_LOGIN_PER_MIN", "2")
    reset_settings_cache()
    client.headers.update({"X-Forwarded-For": "1.1.1.1"})
    for _ in range(2):
        login(client, password="wrong")
    assert login(client, password="wrong").status_code in (
        401,
        429,
    )  # trust_proxy is off by default -> same bucket (test host)
    reset_settings_cache()


# ------------------------------------------------------------------ If-Match concurrency
def test_if_match_blocks_stale_update_and_succeeds_with_fresh_version(client, ids):
    h = auth(client)
    d = create_doc(client, h, ids)
    stale = client.put(
        f"/api/v1/documents/{d['id']}",
        json=doc_body(ids, description="first"),
        headers={**h, "If-Match": str(d["row_version"])},
    )
    assert stale.status_code == 200
    new_version = stale.json()["row_version"]
    conflict = client.put(
        f"/api/v1/documents/{d['id']}",
        json=doc_body(ids, description="second"),
        headers={**h, "If-Match": str(d["row_version"])},
    )
    assert conflict.status_code == 412 and conflict.json()["error"]["code"] == "precondition_failed"
    ok = client.put(
        f"/api/v1/documents/{d['id']}",
        json=doc_body(ids, description="second"),
        headers={**h, "If-Match": str(new_version)},
    )
    assert ok.status_code == 200 and ok.json()["description"] == "second"


def test_if_match_is_optional_and_malformed_value_is_rejected(client, ids):
    h = auth(client)
    d = create_doc(client, h, ids)
    assert (
        client.put(
            f"/api/v1/documents/{d['id']}", json=doc_body(ids, description="no header"), headers=h
        ).status_code
        == 200
    )
    bad = client.put(
        f"/api/v1/documents/{d['id']}",
        json=doc_body(ids),
        headers={**h, "If-Match": "not-a-number"},
    )
    assert bad.status_code == 412


def test_if_match_on_approve_guards_concurrent_reviewers(client, ids):
    emp, mgr = auth(client), auth(client, "manager.demo")
    d = submit_doc(client, emp, ids)
    client.post(f"/api/v1/documents/{d['id']}/review/start", headers=mgr)
    fresh = client.get(f"/api/v1/documents/{d['id']}", headers=mgr).json()
    stale_version = d["row_version"]
    r = client.post(
        f"/api/v1/documents/{d['id']}/approve",
        json={"note": "ok"},
        headers={**mgr, "If-Match": str(stale_version)},
    )
    assert r.status_code == 412
    r2 = client.post(
        f"/api/v1/documents/{d['id']}/approve",
        json={"note": "ok"},
        headers={**mgr, "If-Match": str(fresh["row_version"])},
    )
    assert r2.status_code == 200 and r2.json()["status"] == "approved"
