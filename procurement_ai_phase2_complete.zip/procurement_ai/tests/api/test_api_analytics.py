import pandas as pd
import pytest
from sqlalchemy import select

from app.database.models import Supplier
from app.database.seed import generate_documents
from app.database.session import session_scope
from tests.api.conftest import auth, create_doc
from tests.unit.test_extraction import INVOICE, make_pdf


@pytest.fixture
def populated(client):
    with session_scope() as s:
        generate_documents(s, 600, seed=21)


def wait_job(client, headers, job_id):
    """Background tasks run when the response completes in TestClient; poll once to be safe."""
    for _ in range(5):
        j = client.get(f"/api/v1/jobs/{job_id}", headers=headers).json()
        if j["status"] in ("succeeded", "failed"):
            return j
    return j


# ------------------------------------------------------------------ extraction and jobs
def test_synchronous_extraction_and_resolutions(client, ids):
    h = auth(client)
    with session_scope() as s:
        name = s.execute(select(Supplier.name)).scalars().first()
    pdf = make_pdf([name, *INVOICE[1:]])
    r = client.post(
        "/api/v1/extraction", headers=h, files={"file": ("inv.pdf", pdf, "application/pdf")}
    )
    assert r.status_code == 200
    out = r.json()
    assert out["method"] == "pdf_text" and out["fields"]["supplier_ref"]["value"] == "INV-2026-0042"
    assert len(out["lines"]) == 2 and out["fields"]["total"]["value"] == "924.63"
    d = create_doc(client, h, ids)
    ok = client.post(
        f"/api/v1/extraction/{out['record_id']}/resolutions",
        headers=h,
        json={
            "resolutions": {"supplier_ref": {"chosen_source": "document", "conflict": False}},
            "document_id": d["id"],
        },
    )
    assert ok.status_code == 204
    other = auth(client, "employee2.demo")
    assert (
        client.post(
            f"/api/v1/extraction/{out['record_id']}/resolutions",
            headers=other,
            json={"resolutions": {}},
        ).status_code
        == 403
    )
    assert (
        client.post(
            "/api/v1/extraction",
            headers=auth(client, "auditor.demo"),
            files={"file": ("inv.pdf", pdf, "application/pdf")},
        ).status_code
        == 403
    )
    assert (
        client.post(
            "/api/v1/extraction", headers=h, files={"file": ("x.pdf", b"nope", "application/pdf")}
        ).status_code
        == 400
    )


def test_extraction_job_runs_in_background_and_cleans_up(client):
    h = auth(client)
    pdf = make_pdf(INVOICE)
    r = client.post(
        "/api/v1/jobs/extraction", headers=h, files={"file": ("inv.pdf", pdf, "application/pdf")}
    )
    assert r.status_code == 202 and r.json()["status"] in ("queued", "running", "succeeded")
    j = wait_job(client, h, r.json()["id"])
    assert j["status"] == "succeeded" and j["result"]["method"] == "pdf_text" and j["finished_at"]
    from app.api.jobs import jobs_dir

    assert list(jobs_dir().glob("*")) == []  # staged upload was deleted
    assert client.get("/api/v1/jobs", headers=h).json()["total"] == 1
    assert (
        client.get(f"/api/v1/jobs/{j['id']}", headers=auth(client, "employee2.demo")).status_code
        == 404
    )


def test_scan_and_training_jobs_permissions_and_failures(client, populated):
    fin, admin, emp = auth(client, "finance.demo"), auth(client, "admin.demo"), auth(client)
    assert (
        client.post("/api/v1/jobs", json={"kind": "anomaly_scan"}, headers=emp).status_code == 403
    )
    assert (
        client.post("/api/v1/jobs", json={"kind": "train_anomaly_model"}, headers=fin).status_code
        == 403
    )
    assert client.post("/api/v1/jobs", json={"kind": "bogus"}, headers=fin).status_code == 422
    early = client.post("/api/v1/jobs", json={"kind": "anomaly_scan"}, headers=fin).json()
    failed = wait_job(client, fin, early["id"])
    assert (
        failed["status"] == "failed" and "No anomaly model" in failed["error"]
    )  # no stack trace, clear message
    tr = wait_job(
        client,
        admin,
        client.post("/api/v1/jobs", json={"kind": "train_anomaly_model"}, headers=admin).json()[
            "id"
        ],
    )
    assert tr["status"] == "succeeded" and tr["result"]["documents"] > 400
    sc = wait_job(
        client,
        fin,
        client.post("/api/v1/jobs", json={"kind": "anomaly_scan"}, headers=fin).json()["id"],
    )
    assert sc["status"] == "succeeded" and sc["result"]["flagged"] > 0
    dp = wait_job(
        client,
        fin,
        client.post("/api/v1/jobs", json={"kind": "duplicate_scan"}, headers=fin).json()["id"],
    )
    assert dp["status"] == "succeeded" and dp["result"]["found"] > 0
    assert (
        client.get(f"/api/v1/jobs/{sc['id']}", headers=admin).status_code == 200
    )  # admins may inspect any job


# ------------------------------------------------------------------ analytics
def test_kpis_spend_budget_operations_and_scope(client, populated):
    fin, mgr, emp = auth(client, "finance.demo"), auth(client, "manager.demo"), auth(client)
    k = client.get("/api/v1/analytics/kpis", headers=fin).json()
    assert (
        float(k["submitted_spend"]) > 0
        and k["reporting_currency"] == "EUR"
        and "definitions" in k
        and "synthetic" in k["synthetic_data_notice"].lower()
    )
    assert client.get("/api/v1/analytics/kpis", headers=emp).status_code == 403
    mk = client.get("/api/v1/analytics/kpis", headers=mgr).json()
    assert mk["documents_counted"] < k["documents_counted"]  # manager only sees their unit
    m = client.get("/api/v1/analytics/spend?group_by=month", headers=fin).json()
    keys = [r["key"] for r in m["rows"]]
    assert keys == sorted(keys) and m["rows"][0]["net_spend"] > 0
    cat = client.get(
        "/api/v1/analytics/spend?group_by=category&date_from=2025-01-01&date_to=2025-12-31",
        headers=fin,
    ).json()
    assert cat["rows"] and all(r["documents"] > 0 for r in cat["rows"])
    assert client.get("/api/v1/analytics/spend?group_by=password", headers=fin).status_code == 422
    assert isinstance(client.get("/api/v1/analytics/budget-utilization", headers=fin).json(), list)
    ops = client.get("/api/v1/analytics/operations", headers=fin).json()
    assert ops["pending_approvals"] > 0 and "documents_by_status" in ops
    assert client.get("/api/v1/analytics/inconsistent-totals", headers=fin).json() == []


def test_forecast_alerts_duplicates_review_flow(client, populated):
    fin, admin, aud = (
        auth(client, "finance.demo"),
        auth(client, "admin.demo"),
        auth(client, "auditor.demo"),
    )
    f = client.get("/api/v1/analytics/forecast?horizon=4", headers=fin).json()
    assert (
        len(f["forecast"]) == 4
        and f["chosen_model"] != "none"
        and "not a guarantee" in f["disclaimer"]
    )
    assert f["metrics"] and all(r["lower"] <= r["prediction"] <= r["upper"] for r in f["forecast"])
    assert client.get("/api/v1/analytics/forecast?horizon=99", headers=fin).status_code == 422
    wait_job(
        client,
        admin,
        client.post("/api/v1/jobs", json={"kind": "train_anomaly_model"}, headers=admin).json()[
            "id"
        ],
    )
    wait_job(
        client,
        fin,
        client.post("/api/v1/jobs", json={"kind": "anomaly_scan"}, headers=fin).json()["id"],
    )
    wait_job(
        client,
        fin,
        client.post("/api/v1/jobs", json={"kind": "duplicate_scan"}, headers=fin).json()["id"],
    )
    al = client.get("/api/v1/analytics/alerts?page_size=5", headers=fin).json()
    assert (
        al["total"] > 0
        and al["items"][0]["score"] >= al["items"][-1]["score"]
        and al["items"][0]["status"] == "new"
    )
    a = al["items"][0]
    assert (
        client.post(
            f"/api/v1/analytics/alerts/{a['id']}/review",
            json={"disposition": "needs_follow_up", "note": "asked requester"},
            headers=aud,
        ).status_code
        == 403
    )
    assert (
        client.post(
            f"/api/v1/analytics/alerts/{a['id']}/review",
            json={"disposition": "nonsense", "note": "x"},
            headers=fin,
        ).status_code
        == 422
    )
    r = client.post(
        f"/api/v1/analytics/alerts/{a['id']}/review",
        json={"disposition": "needs_follow_up", "note": "asked requester"},
        headers=fin,
    )
    assert r.status_code == 200 and r.json()["status"] == "reviewed"
    assert (
        client.get("/api/v1/analytics/alerts?status=reviewed", headers=aud).json()["total"] == 1
    )  # auditor can read
    du = client.get("/api/v1/analytics/duplicates", headers=fin).json()
    assert du["total"] > 0 and du["items"][0]["reasons"]
    rv = client.post(
        f"/api/v1/analytics/duplicates/{du['items'][0]['id']}/review",
        json={"disposition": "confirmed_duplicate", "note": "same PO"},
        headers=fin,
    )
    assert rv.json()["status"] == "reviewed"


def test_price_benchmark_and_match_decisions(client, populated):
    fin = auth(client, "finance.demo")
    b = client.get(
        "/api/v1/analytics/price-benchmark",
        params={"description": "Ball valve DN50 PN16 stainless 316", "unit": "pcs"},
        headers=fin,
    ).json()
    assert (
        b["benchmark_available"]
        and b["stats_eur"]["p25"] <= b["stats_eur"]["median"] <= b["stats_eur"]["p75"]
    )
    assert any(
        c["level"] == "similar_description_only" and c["conflicts"] for c in b["comparables"]
    )
    none = client.get(
        "/api/v1/analytics/price-benchmark",
        params={"description": "Quantum flux capacitor"},
        headers=fin,
    ).json()
    assert (
        none["benchmark_available"] is False
        and "No verified benchmark available" in none["message"]
        and none["stats_eur"] is None
    )
    other = next(
        c["description"] for c in b["comparables"] if c["level"] == "similar_description_only"
    )
    d = client.post(
        "/api/v1/analytics/price-benchmark/decisions",
        headers=fin,
        json={"text_a": "Ball valve DN50 PN16 stainless 316", "text_b": other, "equivalent": True},
    )
    assert d.status_code == 204
    after = client.get(
        "/api/v1/analytics/price-benchmark",
        params={"description": "Ball valve DN50 PN16 stainless 316"},
        headers=fin,
    ).json()
    assert after["samples"] > b["samples"]
    assert (
        client.get(
            "/api/v1/analytics/price-benchmark", params={"description": "x"}, headers=auth(client)
        ).status_code
        == 403
    )


# ------------------------------------------------------------------ reports, audit, admin
def test_reports_scope_and_formats(client, populated):
    mgr, fin, emp = auth(client, "manager.demo"), auth(client, "finance.demo"), auth(client)
    csv = client.get("/api/v1/reports/documents?format=csv", headers=mgr)
    assert (
        csv.headers["content-type"].startswith("text/csv")
        and b"# Reporting currency" in csv.content
    )
    import io

    n_mgr = len(pd.read_csv(io.BytesIO(csv.content), comment="#"))
    n_fin = len(
        pd.read_csv(
            io.BytesIO(client.get("/api/v1/reports/documents?format=csv", headers=fin).content),
            comment="#",
        )
    )
    assert 0 < n_mgr < n_fin
    assert client.get("/api/v1/reports/documents?format=xlsx", headers=fin).content[:2] == b"PK"
    assert (
        client.get("/api/v1/reports/documents?format=pdf&status=approved", headers=fin).content[:4]
        == b"%PDF"
    )
    assert client.get("/api/v1/reports/documents?format=csv", headers=emp).status_code == 403
    assert client.get("/api/v1/reports/documents?format=exe", headers=fin).status_code == 422


def test_audit_endpoints_and_admin_rbac(client, ids):
    emp, aud, admin = auth(client), auth(client, "auditor.demo"), auth(client, "admin.demo")
    create_doc(client, emp, ids)
    assert client.get("/api/v1/audit/events", headers=emp).status_code == 403
    ev = client.get("/api/v1/audit/events?action=document.&page_size=10", headers=aud).json()
    assert ev["total"] >= 1 and ev["items"][0]["hash"]
    v = client.get("/api/v1/audit/verify", headers=aud).json()
    assert v["ok"] is True and v["checked"] >= 3
    assert client.get("/api/v1/admin/users", headers=aud).status_code == 403
    users = client.get("/api/v1/admin/users?page_size=5&q=admin.demo", headers=admin).json()
    assert users["total"] == 1 and "password_hash" not in str(users)
    me = next(u for u in users["items"] if u["username"] == "admin.demo")
    assert (
        client.patch(
            f"/api/v1/admin/users/{me['id']}", json={"is_active": False}, headers=admin
        ).status_code
        == 422
    )  # not yourself
    assert (
        client.patch("/api/v1/admin/users/999999", json={"unlock": True}, headers=admin).status_code
        == 404
    )
    ref = client.get("/api/v1/reference/projects?q=PRJ-001", headers=emp).json()
    assert ref["total"] == 1 and ref["items"][0]["budget"].count(".") == 1
    assert client.get("/api/v1/reference/suppliers?page_size=3", headers=emp).json()["pages"] > 1
    assert client.get("/api/v1/reference/projects").status_code == 401
