import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.api.main import create_app
from app.database.models import CostCenter, Project, Supplier
from app.database.session import session_scope
from tests.conftest import PASSWORD

SECRET = "test-secret-" + "x" * 40


@pytest.fixture(autouse=True)
def _reset_rate_limits():
    from app.api import ratelimit

    ratelimit.reset()
    yield
    ratelimit.reset()


@pytest.fixture
def client(db, monkeypatch):
    from app.config import reset_settings_cache

    monkeypatch.setenv("PROCUREMENT_JWT_SECRET", SECRET)
    monkeypatch.setenv("PROCUREMENT_MAX_UPLOAD_MB", "1")
    reset_settings_cache()
    with TestClient(create_app(), raise_server_exceptions=False) as c:
        yield c


def login(client, username="employee.demo", password=PASSWORD):
    r = client.post("/api/v1/auth/login", data={"username": username, "password": password})
    return r


def auth(client, username="employee.demo") -> dict:
    r = login(client, username)
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture
def ids(db):
    with session_scope() as s:
        project = s.execute(select(Project).where(Project.code == "PRJ-001")).scalar_one()
        cc = (
            s.execute(select(CostCenter).where(CostCenter.org_unit_id == project.org_unit_id))
            .scalars()
            .first()
        )
        supplier = s.execute(select(Supplier)).scalars().first()
        return {"project_id": project.id, "cost_center_id": cc.id, "supplier_id": supplier.id}


def doc_body(ids, **over):
    from datetime import date, timedelta

    body = {
        **ids,
        "doc_type": "invoice",
        "purchase_date": (date.today() - timedelta(days=1)).isoformat(),
        "currency": "EUR",
        "supplier_ref": "INV-1001",
        "description": "Valves for pump station",
        "business_purpose": "Maintenance",
        "shipping": "10.00",
        "lines": [
            {
                "description": "Ball valve DN50 PN16 stainless 316",
                "quantity": "2",
                "unit_price": "100.00",
                "unit": "pcs",
                "discount_rate": "0.10",
                "tax_rate": "0.19",
            }
        ],
    }
    body.update(over)
    return body


def create_doc(client, headers, ids, **over):
    r = client.post("/api/v1/documents", json=doc_body(ids, **over), headers=headers)
    assert r.status_code == 201, r.text
    return r.json()


def submit_doc(client, headers, ids, **over):
    d = create_doc(client, headers, ids, **over)
    r = client.post(f"/api/v1/documents/{d['id']}/submit", headers=headers)
    assert r.status_code == 200, r.text
    return r.json()
