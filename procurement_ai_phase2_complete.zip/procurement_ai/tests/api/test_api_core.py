from datetime import timedelta

import jwt
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy.orm.exc import StaleDataError

from app.api.errors import install_error_handlers
from app.database.models import PurchaseDocument
from app.database.session import new_session, session_scope
from tests.api.conftest import SECRET, auth, create_doc, doc_body, login, submit_doc
from tests.conftest import get_user

PDF = b"%PDF-1.4\n%magic bytes only\n"


# ------------------------------------------------------------------ authentication
def test_login_me_refresh_and_error_format(client):
    r = login(client)
    assert (
        r.status_code == 200
        and r.json()["token_type"] == "bearer"
        and r.json()["expires_in"] == 1800
    )
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    me = client.get("/api/v1/auth/me", headers=h).json()
    assert me["username"] == "employee.demo" and "document.create" in me["permissions"]
    assert "document.decide" not in me["permissions"]
    new = client.post("/api/v1/auth/refresh", json={"refresh_token": r.json()["refresh_token"]})
    assert new.status_code == 200
    bad = login(client, password="wrong")
    assert bad.status_code == 401
    err = bad.json()["error"]
    assert err["code"] == "unauthenticated" and err["message"] == "Invalid username or password."
    assert err["request_id"] and bad.headers["X-Request-ID"] == err["request_id"]


def test_token_type_confusion_tampering_and_missing_token(client):
    t = login(client).json()
    assert (
        client.post("/api/v1/auth/refresh", json={"refresh_token": t["access_token"]}).status_code
        == 401
    )
    assert (
        client.get(
            "/api/v1/auth/me", headers={"Authorization": f"Bearer {t['refresh_token']}"}
        ).status_code
        == 401
    )
    forged = jwt.encode(
        {"sub": "1", "typ": "access", "ver": 0, "iat": 0, "exp": 9999999999},
        "another-secret-" + "y" * 40,
        algorithm="HS256",
    )
    assert (
        client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {forged}"}).status_code
        == 401
    )
    assert (
        client.get(
            "/api/v1/auth/me", headers={"Authorization": f"Bearer {t['access_token']}x"}
        ).status_code
        == 401
    )
    assert client.get("/api/v1/auth/me").status_code == 401
    expired = jwt.encode(
        {"sub": "1", "typ": "access", "ver": 0, "iat": 1, "exp": 2}, SECRET, algorithm="HS256"
    )
    assert (
        client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {expired}"}).status_code
        == 401
    )


def test_lockout_after_repeated_failures_even_with_correct_password(client):
    for _ in range(5):
        assert login(client, "employee2.demo", "nope").status_code == 401
    assert login(client, "employee2.demo").status_code == 401  # locked, same generic answer
    assert login(client, "employee.demo").status_code == 200  # other accounts unaffected
    with session_scope() as s:
        u = get_user(s, "employee2.demo")
        assert u.locked_until is not None


def test_logout_revokes_all_tokens_and_deactivation_revokes(client):
    t = login(client).json()
    h = {"Authorization": f"Bearer {t['access_token']}"}
    assert client.post("/api/v1/auth/logout", headers=h).status_code == 204
    assert client.get("/api/v1/auth/me", headers=h).status_code == 401
    assert (
        client.post("/api/v1/auth/refresh", json={"refresh_token": t["refresh_token"]}).status_code
        == 401
    )
    admin = auth(client, "admin.demo")
    victim = auth(client, "finance.demo")
    users = client.get("/api/v1/admin/users?q=finance", headers=admin).json()["items"]
    uid = users[0]["id"]
    assert (
        client.patch(
            f"/api/v1/admin/users/{uid}", json={"is_active": False}, headers=admin
        ).status_code
        == 200
    )
    assert client.get("/api/v1/auth/me", headers=victim).status_code == 401
    assert login(client, "finance.demo").status_code == 401


# ------------------------------------------------------------------ documents
def test_create_calculates_on_server_and_ignores_client_totals(client, ids):
    h = auth(client)
    body = doc_body(ids)
    body["total"] = "1.00"  # unknown field: must have no effect
    r = client.post("/api/v1/documents", json=body, headers=h)
    assert r.status_code == 201
    d = r.json()
    assert d["status"] == "draft" and d["total"] == "224.2000" and d["subtotal"] == "180.0000"
    assert isinstance(d["total"], str) and d["lines"][0]["net_amount"] == "180.0000"
    assert d["correction_window_open"] is False and d["doc_number"].startswith("PD-")


def test_structured_validation_errors(client, ids):
    h = auth(client)
    r = client.post("/api/v1/documents", json={"currency": "EUR"}, headers=h)
    assert r.status_code == 422 and r.json()["error"]["code"] == "validation_error"
    assert any("project_id" in ".".join(x["loc"]) for x in r.json()["error"]["details"])
    bad_line = doc_body(ids, lines=[{"description": "x", "quantity": "0", "unit_price": "-5"}])
    r = client.post("/api/v1/documents", json=bad_line, headers=h)
    msgs = " ".join(x["msg"] for x in r.json()["error"]["details"])
    assert r.status_code == 422 and "quantity" in msgs and "unit price" in msgs
    r = client.post("/api/v1/documents", json=doc_body(ids, project_id=999999), headers=h)
    assert r.status_code == 422 and "project" in r.text.lower()
    too_precise = doc_body(
        ids, lines=[{"description": "x", "quantity": "1.123456", "unit_price": "1"}]
    )
    assert client.post("/api/v1/documents", json=too_precise, headers=h).status_code == 422


def test_full_workflow_permissions_and_history(client, ids):
    emp, mgr, other = auth(client), auth(client, "manager.demo"), auth(client, "employee2.demo")
    d = submit_doc(client, emp, ids)
    did = d["id"]
    assert d["status"] == "submitted" and d["correction_window_open"] is True
    assert client.post(f"/api/v1/documents/{did}/approve", headers=emp).status_code == 403
    assert client.get(f"/api/v1/documents/{did}", headers=other).status_code == 403
    assert client.get("/api/v1/documents/999999", headers=emp).status_code == 404
    r = client.post(f"/api/v1/documents/{did}/approve", headers=mgr)  # must be under review first
    assert r.status_code == 409 and r.json()["error"]["code"] == "invalid_transition"
    assert (
        client.post(f"/api/v1/documents/{did}/review/start", headers=mgr).json()["status"]
        == "under_review"
    )
    assert (
        client.post(f"/api/v1/documents/{did}/reject", json={"note": " "}, headers=mgr).status_code
        == 422
    )
    done = client.post(f"/api/v1/documents/{did}/approve", json={"note": "ok"}, headers=mgr).json()
    assert done["status"] == "approved" and done["decision_note"] == "ok"
    hist = client.get(f"/api/v1/documents/{did}/history", headers=emp).json()
    assert [e["action"] for e in hist][:3] == [
        "document.created",
        "document.status_changed",
        "document.submitted",
    ]
    assert (
        hist[-1]["action"] == "document.status_changed" and hist[-1]["payload"]["to"] == "approved"
    )


def test_draft_edit_and_cancel_rules(client, ids):
    h = auth(client)
    d = create_doc(client, h, ids)
    r = client.put(
        f"/api/v1/documents/{d['id']}", json=doc_body(ids, description="Changed"), headers=h
    )
    assert r.status_code == 200 and r.json()["description"] == "Changed"
    assert (
        client.post(
            f"/api/v1/documents/{d['id']}/cancel", json={"reason": "dup"}, headers=h
        ).json()["status"]
        == "cancelled"
    )
    s = submit_doc(client, h, ids)
    assert (
        client.put(f"/api/v1/documents/{s['id']}", json=doc_body(ids), headers=h).status_code == 403
    )


def test_list_pagination_filter_sort_search(client, ids):
    h, aud = auth(client), auth(client, "auditor.demo")
    for i, ref in enumerate(["AAA_1", "AAB%2", "ZZZ-3"]):
        create_doc(client, h, ids, supplier_ref=ref, shipping=str(10 * (i + 1)))
    p = client.get("/api/v1/documents?page_size=2&sort=total", headers=aud).json()
    assert p["total"] == 3 and p["pages"] == 2 and len(p["items"]) == 2
    assert float(p["items"][0]["total"]) <= float(p["items"][1]["total"])
    desc = client.get("/api/v1/documents?sort=-total", headers=aud).json()["items"]
    assert float(desc[0]["total"]) >= float(desc[-1]["total"])
    assert (
        client.get("/api/v1/documents?q=%25", headers=aud).json()["total"] == 1
    )  # '%' is literal, not a wildcard
    assert client.get("/api/v1/documents?q=_", headers=aud).json()["total"] == 1
    assert client.get("/api/v1/documents?status=draft&own=true", headers=h).json()["total"] == 3
    assert client.get("/api/v1/documents?status=approved", headers=h).json()["total"] == 0
    assert client.get("/api/v1/documents?sort=password", headers=h).status_code == 422
    assert client.get("/api/v1/documents?page_size=500", headers=h).status_code == 422
    assert client.get("/api/v1/documents?page=0", headers=h).status_code == 422
    assert (
        client.get("/api/v1/documents?own=true", headers=auth(client, "employee2.demo")).json()[
            "total"
        ]
        == 0
    )


# ------------------------------------------------------------------ corrections
def test_correction_flow_and_deadline_exception(client, ids):
    emp, mgr = auth(client), auth(client, "manager.demo")
    d = submit_doc(client, emp, ids)
    r = client.post(
        f"/api/v1/documents/{d['id']}/corrections",
        headers=emp,
        json={"header_changes": {"shipping": "50.00"}, "reason": "Wrong shipping"},
    )
    assert r.status_code == 201 and r.json()["status"] == "pending"
    assert (
        client.get(f"/api/v1/documents/{d['id']}", headers=emp).json()["shipping"] == "10.0000"
    )  # untouched
    rid = r.json()["id"]
    assert (
        client.post(
            f"/api/v1/corrections/{rid}/decision", json={"approve": True}, headers=emp
        ).status_code
        == 403
    )
    dec = client.post(
        f"/api/v1/corrections/{rid}/decision", json={"approve": True, "note": "ok"}, headers=mgr
    )
    assert dec.status_code == 200 and dec.json()["status"] == "approved"
    after = client.get(f"/api/v1/documents/{d['id']}", headers=emp).json()
    assert (
        after["status"] == "resubmitted"
        and after["shipping"] == "50.0000"
        and after["total"] == "264.2000"
    )
    pending = client.get("/api/v1/corrections?pending_only=true", headers=mgr).json()
    assert pending["total"] == 0
    # expire the window
    with session_scope() as s:
        s.get(PurchaseDocument, d["id"]).submitted_at -= timedelta(hours=6)
    r = client.post(
        f"/api/v1/documents/{d['id']}/corrections",
        headers=emp,
        json={"header_changes": {"shipping": "1"}, "reason": "late"},
    )
    assert r.status_code == 409 and r.json()["error"]["code"] == "correction_window_expired"
    r = client.post(
        f"/api/v1/documents/{d['id']}/corrections",
        headers=mgr,
        json={"header_changes": {"shipping": "1"}, "reason": "late"},
    )
    assert r.status_code == 422  # exception needs a written justification
    r = client.post(
        f"/api/v1/documents/{d['id']}/corrections",
        headers=mgr,
        json={
            "header_changes": {"shipping": "1"},
            "reason": "late",
            "override_reason": "credit note",
        },
    )
    assert r.status_code == 201 and r.json()["deadline_exception"] is True
    ev = client.get(
        "/api/v1/audit/events?action=correction.deadline_exception",
        headers=auth(client, "auditor.demo"),
    ).json()
    assert ev["total"] == 1


# ------------------------------------------------------------------ attachments
def test_attachment_upload_download_and_rules(client, ids):
    h, other = auth(client), auth(client, "employee2.demo")
    d = create_doc(client, h, ids)
    up = client.post(
        f"/api/v1/documents/{d['id']}/attachments",
        headers=h,
        files={"file": ("../../evil name.pdf", PDF, "application/pdf")},
    )
    assert up.status_code == 201 and up.json()["original_name"] == "evil name.pdf"
    aid = up.json()["id"]
    dl = client.get(f"/api/v1/attachments/{aid}/download", headers=h)
    assert dl.content == PDF and dl.headers["x-content-type-options"] == "nosniff"
    assert (
        "attachment" in dl.headers["content-disposition"]
        and "../" not in dl.headers["content-disposition"]
    )
    assert client.get(f"/api/v1/attachments/{aid}/download", headers=other).status_code == 403
    assert client.get(f"/api/v1/attachments/{aid}/download").status_code == 401
    bad = client.post(
        f"/api/v1/documents/{d['id']}/attachments",
        headers=h,
        files={"file": ("x.pdf", b"not a pdf", "application/pdf")},
    )
    assert bad.status_code == 400 and bad.json()["error"]["code"] == "upload_rejected"
    exe = client.post(
        f"/api/v1/documents/{d['id']}/attachments",
        headers=h,
        files={"file": ("x.exe", b"MZ" + b"0" * 10, "application/octet-stream")},
    )
    assert exe.status_code == 400
    big = client.post(
        f"/api/v1/documents/{d['id']}/attachments",
        headers=h,
        files={"file": ("big.pdf", b"%PDF-" + b"0" * (2 * 1024 * 1024), "application/pdf")},
    )
    assert big.status_code == 413 and big.json()["error"]["code"] == "upload_too_large"
    client.post(f"/api/v1/documents/{d['id']}/submit", headers=h)
    late = client.post(
        f"/api/v1/documents/{d['id']}/attachments",
        headers=h,
        files={"file": ("a.pdf", PDF, "application/pdf")},
    )
    assert late.status_code == 403
    assert len(client.get(f"/api/v1/documents/{d['id']}", headers=h).json()["attachments"]) == 1


# ------------------------------------------------------------------ concurrency and errors
def test_optimistic_locking_detects_concurrent_changes(client, ids):
    h = auth(client)
    d = create_doc(client, h, ids)
    v0 = client.get(f"/api/v1/documents/{d['id']}", headers=h).json()["row_version"]
    a, b = new_session(), new_session()
    try:
        da, db_ = a.get(PurchaseDocument, d["id"]), b.get(PurchaseDocument, d["id"])
        da.description = "first writer"
        a.commit()
        db_.description = "second writer (stale)"
        with pytest.raises(StaleDataError):
            b.commit()
    finally:
        a.close()
        b.close()
    assert (
        client.get(f"/api/v1/documents/{d['id']}", headers=h).json()["description"]
        == "first writer"
    )
    assert client.get(f"/api/v1/documents/{d['id']}", headers=h).json()["row_version"] == v0 + 1


def test_stale_data_error_maps_to_409_and_unhandled_errors_are_generic():
    app = FastAPI()
    install_error_handlers(app)

    @app.get("/stale")
    def stale():
        raise StaleDataError("x")

    @app.get("/boom")
    def boom():
        raise RuntimeError("secret internals: password=hunter2")

    c = TestClient(app, raise_server_exceptions=False)
    r = c.get("/stale")
    assert r.status_code == 409 and r.json()["error"]["code"] == "concurrent_modification"
    r = c.get("/boom")
    assert (
        r.status_code == 500
        and "hunter2" not in r.text
        and r.json()["error"]["code"] == "internal_error"
    )
    assert c.get("/missing").json()["error"]["code"] == "not_found"


def test_failed_request_rolls_back_whole_transaction(client, ids):
    h = auth(client)
    before = client.get("/api/v1/documents", headers=h).json()["total"]
    # valid JSON shape, but business validation fails after nothing may be persisted
    bad = doc_body(ids, currency="XXX")
    assert client.post("/api/v1/documents", json=bad, headers=h).status_code == 422
    assert client.get("/api/v1/documents", headers=h).json()["total"] == before


def test_health_openapi_security_headers_and_request_id(client):
    assert client.get("/health").json() == {"status": "ok"}
    assert client.get("/health/ready").json() == {"status": "ready"}
    spec = client.get("/api/v1/openapi.json").json()
    assert (
        len(spec["paths"]) >= 40 and "OAuth2PasswordBearer" in spec["components"]["securitySchemes"]
    )
    assert spec["info"]["version"] == "2.0.0"
    assert client.get("/api/v1/docs").status_code == 200
    r = client.get("/health", headers={"X-Request-ID": "abc-123"})
    assert r.headers["x-request-id"] == "abc-123" and r.headers["x-frame-options"] == "DENY"
