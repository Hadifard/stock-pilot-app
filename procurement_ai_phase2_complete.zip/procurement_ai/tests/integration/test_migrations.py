"""Alembic migrations: upgrade, drift check against the models, downgrade, and Phase-1 DB adoption."""

import os

import pytest
from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from sqlalchemy import create_engine, inspect, text

from app.database.base import Base
from app.database.migrate import alembic_config, upgrade_to_head


def _urls(tmp_path):
    urls = [f"sqlite:///{tmp_path / 'mig.db'}"]
    if os.environ.get("PROCUREMENT_TEST_DATABASE_URL", "").startswith("postgresql"):
        urls.append(os.environ["PROCUREMENT_TEST_DATABASE_URL"])
    return urls


def _clean(url):
    e = create_engine(url)
    if e.dialect.name == "postgresql":
        with e.begin() as c:
            c.execute(text("DROP SCHEMA public CASCADE"))
            c.execute(text("CREATE SCHEMA public"))
    e.dispose()


@pytest.fixture(params=["sqlite", "postgresql"])
def url(request, tmp_path):
    match = [u for u in _urls(tmp_path) if u.startswith(request.param)]
    if not match:
        pytest.skip(f"{request.param} not configured")
    _clean(match[0])
    yield match[0]
    _clean(match[0])


def test_upgrade_matches_models_and_installs_audit_triggers(url):
    upgrade_to_head(url)
    e = create_engine(url)
    with e.connect() as c:
        assert (
            compare_metadata(MigrationContext.configure(c), Base.metadata) == []
        )  # no schema drift
        assert c.execute(text("SELECT version_num FROM alembic_version")).scalar() == "0003"
    with e.begin() as c:
        c.execute(
            text(
                "INSERT INTO audit_events (timestamp, action, entity_type, payload_json, prev_hash, hash) "
                "VALUES ('2026-01-01 00:00:00', 'x', 'y', '{}', 'a', 'b')"
            )
        )
    with pytest.raises(Exception, match="append-only"), e.begin() as c:
        c.execute(text("UPDATE audit_events SET action = 'tampered'"))
    with pytest.raises(Exception, match="append-only"), e.begin() as c:
        c.execute(text("DELETE FROM audit_events"))
    e.dispose()


def test_downgrade_and_reupgrade(url):
    upgrade_to_head(url)
    cfg = alembic_config(url)
    command.downgrade(cfg, "0001")
    e = create_engine(url)
    cols = {c["name"] for c in inspect(e).get_columns("users")}
    assert "token_version" not in cols and "background_jobs" not in inspect(e).get_table_names()
    e.dispose()
    command.upgrade(cfg, "head")
    command.downgrade(cfg, "base")
    e = create_engine(url)
    assert inspect(e).get_table_names() in ([], ["alembic_version"])
    e.dispose()


def test_phase1_database_is_stamped_and_upgraded_without_data_loss(url):
    cfg = alembic_config(url)
    command.upgrade(cfg, "0001")  # exactly the Phase 1 schema
    e = create_engine(url)
    with e.begin() as c:
        c.execute(
            text(
                "INSERT INTO org_units (code, name, kind, country) VALUES ('X', 'Unit X', 'domestic', 'DE')"
            )
        )
        c.execute(text("DROP TABLE alembic_version"))  # a Phase 1 DB never had this table
    e.dispose()
    upgrade_to_head(url)
    e = create_engine(url)
    with e.connect() as c:
        assert c.execute(text("SELECT name FROM org_units WHERE code = 'X'")).scalar() == "Unit X"
        assert c.execute(text("SELECT version_num FROM alembic_version")).scalar() == "0003"
    e.dispose()
