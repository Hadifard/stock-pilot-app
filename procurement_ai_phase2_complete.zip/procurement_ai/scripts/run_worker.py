"""Background-job worker (polling). Use with PROCUREMENT_JOBS_MODE=worker so the API only enqueues.

Usage: python -m scripts.run_worker [--interval 2]
Run one or more instances; each queued job is claimed by exactly one worker (an UPDATE ... WHERE
status='queued' guards against two workers picking the same job).
"""

from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select, update  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.database.models import BackgroundJob  # noqa: E402
from app.database.session import init_engine, session_scope  # noqa: E402
from app.utils.logging_config import configure_logging  # noqa: E402

log = logging.getLogger("procurement.worker")


def claim_one() -> int | None:
    with session_scope() as s:
        job_id = s.execute(
            select(BackgroundJob.id)
            .where(BackgroundJob.status == "queued")
            .order_by(BackgroundJob.id)
            .limit(1)
        ).scalar_one_or_none()
        if job_id is None:
            return None
        result = s.execute(
            update(BackgroundJob)
            .where(BackgroundJob.id == job_id, BackgroundJob.status == "queued")
            .values(status="claimed")
        )
        if result.rowcount == 0:
            return None  # another worker claimed it first
        return job_id


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interval", type=float, default=2.0, help="Seconds to wait when idle")
    parser.add_argument(
        "--once", action="store_true", help="Process at most one job then exit (for tests)"
    )
    args = parser.parse_args()
    settings = get_settings()
    configure_logging(settings.log_level)
    init_engine()
    from app.api.jobs import run_job

    log.info("Worker started (poll interval %.1fs)", args.interval)
    while True:
        job_id = claim_one()
        if job_id is None:
            if args.once:
                return
            time.sleep(args.interval)
            continue
        log.info("Running job %s", job_id)
        run_job(job_id)
        if args.once:
            return


if __name__ == "__main__":
    main()
