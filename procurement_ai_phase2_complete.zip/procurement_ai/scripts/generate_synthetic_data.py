"""Generate reproducible SYNTHETIC data.

Usage:
    python -m scripts.generate_synthetic_data --mode small --reset
Modes: tiny (300 docs), small (4,000 docs), full (50,000 docs; takes a few minutes).
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import func, select, text  # noqa: E402
from sqlalchemy.engine import make_url  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.database.migrate import upgrade_to_head  # noqa: E402
from app.database.models import LineItem, PurchaseDocument  # noqa: E402
from app.database.seed import MODES, generate_documents, seed_reference_data  # noqa: E402
from app.database.session import init_engine, session_scope  # noqa: E402
from app.utils.logging_config import configure_logging  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=sorted(MODES), default="small")
    parser.add_argument("--seed", type=int, default=None, help="default: PROCUREMENT_RANDOM_SEED")
    parser.add_argument("--reset", action="store_true", help="delete the SQLite database first")
    args = parser.parse_args()
    settings = get_settings()
    configure_logging(settings.log_level)
    seed = settings.random_seed if args.seed is None else args.seed
    url = make_url(settings.database_url)
    if args.reset and url.drivername.startswith("sqlite") and url.database:
        for suffix in ("", "-wal", "-shm"):
            Path(url.database + suffix).unlink(missing_ok=True)
    if url.database:
        Path(url.database).parent.mkdir(parents=True, exist_ok=True)
    upgrade_to_head()
    init_engine()
    t0 = time.perf_counter()
    mode = MODES[args.mode]
    with session_scope() as s:
        seed_reference_data(s, args.mode, seed, settings.demo_password)
        n = generate_documents(s, mode.documents, seed)
    with session_scope() as s:
        docs = s.execute(select(func.count(PurchaseDocument.id))).scalar_one()
        lines = s.execute(select(func.count(LineItem.id))).scalar_one()
    with session_scope() as s:
        s.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
    size_mb = Path(url.database).stat().st_size / 1e6 if url.database else 0
    print(
        f"Generated {n} synthetic documents ({docs} total, {lines} line items) "
        f"in {time.perf_counter() - t0:.1f}s; database size {size_mb:.1f} MB; seed={seed}"
    )
    print("Demo login: any '*.demo' username with the password from PROCUREMENT_DEMO_PASSWORD.")


if __name__ == "__main__":
    main()
