# Procurement Intelligence Platform - Phase 1 (Python + Streamlit)

A local, modular procurement and financial-document platform for a large industrial company
(17 domestic subsidiaries + 3 international offices). **All demo data is synthetic.** Nothing here
represents real spend, supplier quotations or verified market prices.

## Status of Phase 1
Phase 1 (Python + Streamlit) is feature-complete as specified, with the limitations listed below. Everything marked "Done" has automated tests or a recorded measurement.

| Area | Status |
|---|---|
| Config, logging, SQLite/SQLAlchemy, models, indexes | Done |
| Roles + permissions enforced in services; demo login (scrypt) | Done (local demo only) |
| Document creation, line items, server-side decimal totals, validation | Done |
| Draft editing, attachments (whitelist, magic bytes, size, safe paths, access control) | Done |
| State machine, corrections (4 h window, reviewer decision, audited exceptions) | Done |
| Append-only audit log + hash chain + triggers | Done |
| Synthetic data (tiny / small / full 51k docs, 166k lines, 1.7k corrections, FX rates, injected labels) | Done |
| Overview, spend analysis with filters, budget utilisation, operations monitoring | Done |
| CSV, Excel and PDF export (scoped, with metadata) | Done |
| Forecasting, unusual-transaction detection, duplicate detection, item matching + price benchmark | Done (see `docs/ml_methods.md` for honest results) |
| PDF text extraction, Tesseract OCR, rule-based field extraction, conflict review, extraction history | Done; verified with Tesseract 5.3 on generated invoices |
| Speech-to-text | Interface + transcript parser done; **model path untested here** (needs `faster-whisper` and a model) |
| Handwriting | Not reliably supported by OCR; manual-entry fallback |
| Credit-note document type, online/market price providers, location capture, PDF of dashboards | Not implemented (documented) |
| Screenshots | Not captured in the build environment; see `docs/demo_checklist.md` |
| FastAPI backend (Phase 2) | Done: 46 endpoints, JWT auth + lockout + refresh-token rotation + password policy, rate limiting, optimistic concurrency (If-Match), Alembic, PostgreSQL, background jobs (inline or worker), Dockerfile/compose; see `docs/api.md` |
| Mobile app / web portal | Phase 3 - not started |

## Requirements
Python 3.11 or 3.12. No cloud services or paid APIs.

## Setup - Windows PowerShell
```powershell
cd procurement_ai
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1          # if blocked: Set-ExecutionPolicy -Scope Process Bypass
pip install -r requirements-dev.txt
Copy-Item .env.example .env           # then edit PROCUREMENT_DEMO_PASSWORD
python -m scripts.generate_synthetic_data --mode small --reset
streamlit run app/main.py
```
## Setup - Linux / macOS
```bash
cd procurement_ai
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env
python -m scripts.generate_synthetic_data --mode small --reset
streamlit run app/main.py
```
Open http://localhost:8501. To use a phone on the same network:
`streamlit run app/main.py --server.address 0.0.0.0` and open `http://<PC-IP>:8501`
(allow the port in the firewall; the demo login is not safe on untrusted networks).

### Data modes
| Mode | Documents | Time (1 CPU, measured) |
|---|---|---|
| `tiny` | 300 | < 1 s |
| `small` | 4,000 (10,434 lines, 2.8 MB DB) | ~3 s |
| `full` | 51,250 documents, 166,228 lines (53 MB) | ~78 s |

The generator is seeded (`PROCUREMENT_RANDOM_SEED`, default 42) and reproducible. It is never run
at application start. Synthetic documents are inserted directly and have no per-event audit
history; documents created in the UI have full history.

## Demo accounts
`employee.demo`, `employee2.demo` (other unit), `manager.demo`, `finance.demo`, `pm.demo`,
`auditor.demo`, `admin.demo` - password = `PROCUREMENT_DEMO_PASSWORD` from `.env`.

## Quality commands
```bash
pytest -q                     # 151 tests (+3 PostgreSQL-only migration tests, included when run against PostgreSQL): unit, integration, API, UI
ruff check .
ruff format --check .
python -m scripts.run_demo_checks   # end-to-end scenario incl. ML + extraction on a throw-away DB
python -m scripts.train_models --evaluate   # train models, write data/reports/ml_evaluation.md
python -m scripts.measure_performance       # timings on the configured database
```

## Demo scenario (about 5 minutes)
1. Sign in as `employee.demo` -> **Create document**: pick project PRJ-001, add two lines, watch the
   server-side preview, **Save and submit**.
2. Sign in as `manager.demo` -> **Review queue** -> open it -> **Start review**.
3. As `employee.demo` -> **Corrections**: change the shipping cost with a reason.
4. As `manager.demo` -> **Corrections**: compare old/proposed values, approve.
5. **Review queue** -> review again -> confirm -> **Approve**.
6. Sign in as `auditor.demo` -> **Audit log** -> **Verify hash chain**.
7. As `finance.demo` -> **Home**, **Spend analysis** (filters), **Forecast**, **Price benchmark**, **Reports** (CSV/Excel/PDF).
8. As `finance.demo` -> **Alerts**: run the anomaly and duplicate scans (after `python -m scripts.train_models`) and record a review.
9. As `employee.demo` -> **Create document** -> *Autofill from a file*: upload a PDF invoice, review conflicts, apply.

## Layout
```
app/config.py, main.py     settings, Streamlit entry point
app/database/              base types, models, session, seed
app/security/              hashing, RBAC, audit hash chain, demo auth
app/services/              business logic (the only place rules live)
app/ui/                    Streamlit pages and components (no business rules)
app/ml/                    reserved for Milestone 4
scripts/                   init DB, synthetic data, end-to-end checks
tests/                     unit, integration, ui
docs/                      architecture, calculation rules, ML methods + evaluation, performance, OCR/speech setup, security, roadmap
```

## Troubleshooting
* **"The database is empty"** - run `python -m scripts.generate_synthetic_data --mode small`.
* **Invalid username or password** - the password is the value of `PROCUREMENT_DEMO_PASSWORD` *when
  the data was generated*; regenerate with `--reset` after changing it.
* **`database is locked`** - close other processes using `data/procurement.db`; SQLite allows one writer.
* **PowerShell refuses to activate the venv** - `Set-ExecutionPolicy -Scope Process Bypass`.
* **Port in use** - `streamlit run app/main.py --server.port 8502`.
* **Upload rejected** - allowed: PDF, PNG, JPG, WAV, MP3, M4A up to `PROCUREMENT_MAX_UPLOAD_MB`;
  content must match the extension.

See `docs/` for details.

## Performance (measured, 1 CPU, 51k documents)
See `docs/performance.md`. Interactive queries take 0.05-1.4 s; Excel export of all 51k documents takes ~14 s, the anomaly scan ~14 s and the duplicate scan ~6 s (button-triggered).

## Backup and restore
Stop the app, copy `data/procurement.db` (and the `-wal`/`-shm` files if present), `data/attachments/` and `data/models/`; restore by copying them back. Test restores before relying on them.

## Phase 2 (FastAPI) quick start
```powershell
pip install -r requirements-dev.txt
python -m scripts.generate_synthetic_data --mode small --reset      # applies Alembic migrations, then seeds
$env:PROCUREMENT_JWT_SECRET = python -c "import secrets; print(secrets.token_urlsafe(48))"
uvicorn app.api.main:app --reload
# Swagger UI: http://localhost:8000/api/v1/docs
```
PostgreSQL: set `PROCUREMENT_DATABASE_URL=postgresql+psycopg://...`, then `alembic upgrade head`. Run the test suite against PostgreSQL with
`PROCUREMENT_TEST_DATABASE_URL=postgresql+psycopg://... pytest --ignore=tests/ui`. Details: `docs/api.md`.

### Docker (not build-tested here — no Docker daemon in the build sandbox)
```bash
cp .env.docker.example .env   # fill in POSTGRES_PASSWORD and PROCUREMENT_JWT_SECRET
docker compose up --build
# API: http://localhost:8000/api/v1/docs   Streamlit: http://localhost:8501
```
